// Bundled inside theme.js; explicit item clicks use Dooray's native message pipeline.
function installCustomEmoticons({rpc}){
  let disposed=false,scheduled=0,catalog=null,loading=null;const popups=new Map(),decorated=new Map(),assetPromises=new Map();
  const scrollStates=new Map();
  const atBottom=scroll=>scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<=48;
  function scrollState(node){
    let scroll=node.closest('.js-scroll-area');
    // Some Dooray layouts put the actual overflow on a wrapper around the message list.
    for(let p=node.parentElement;p&&p!==document.body;p=p.parentElement){if(/auto|scroll/.test(getComputedStyle(p).overflowY)&&p.clientHeight>0){scroll=p;break}}
    if(!scroll)return null;
    if(!scrollStates.has(scroll)){
      const state={scroll,follow:atBottom(scroll),frame:0};
      const changed=()=>{state.follow=atBottom(scroll)};
      const cancel=()=>{state.follow=false};
      const wheel=e=>{if(e.deltaY<0)cancel()};
      const key=e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))cancel()};
      scroll.addEventListener('scroll',changed,{passive:true});scroll.addEventListener('wheel',wheel,{passive:true});
      scroll.addEventListener('touchstart',cancel,{passive:true});scroll.addEventListener('pointerdown',cancel,{passive:true});scroll.addEventListener('keydown',key);
      state.dispose=()=>{cancelAnimationFrame(state.frame);scroll.removeEventListener('scroll',changed);scroll.removeEventListener('wheel',wheel);scroll.removeEventListener('touchstart',cancel);scroll.removeEventListener('pointerdown',cancel);scroll.removeEventListener('keydown',key)};
      scrollStates.set(scroll,state);
    }
    return scrollStates.get(scroll);
  }
  function followBottom(state){
    if(!state||!state.follow||disposed||!state.scroll.isConnected)return;
    state.scroll.scrollTop=state.scroll.scrollHeight;
    cancelAnimationFrame(state.frame);
    state.frame=requestAnimationFrame(()=>{state.frame=0;if(state.follow&&!disposed&&state.scroll.isConnected)state.scroll.scrollTop=state.scroll.scrollHeight});
  }
  const resized=new ResizeObserver(entries=>{for(const entry of entries){const state=scrollState(entry.target);followBottom(state)}});
  const prefix='[[dooray-emoji:v1:',suffix=']]';
  const encode=item=>prefix+btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify({p:item.path,r:item.ref,n:item.label})))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')+suffix;
  function decode(text){try{text=text.replace(/[\s\u200B-\u200D\uFEFF]/g,'');if(text.length>5000||!text.startsWith(prefix)||!text.endsWith(suffix))return null;const base=text.slice(prefix.length,-suffix.length).replace(/-/g,'+').replace(/_/g,'/');const obj=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(base),c=>c.charCodeAt(0))));if(typeof obj.p!=='string'||!obj.p.startsWith('packs/')||obj.p.length>1000||!/^([a-f\d]{40})$/i.test(obj.r)||!(/\.(png|gif|jpe?g|webp)$/i.test(obj.p)))return null;return {path:obj.p,ref:obj.r,label:String(obj.n||'커스텀 이모티콘').slice(0,100)}}catch{return null}}
  function image(item){const key=item.ref+'/'+item.path;if(!assetPromises.has(key)){if(assetPromises.size>=48)assetPromises.delete(assetPromises.keys().next().value);const p=rpc('emoticon-image',{path:item.path,ref:item.ref}).then(r=>{if(!/^data:image\/(png|gif|jpeg|webp);base64,/.test(r.data))throw Error('이미지 응답 오류');return r.data}).catch(e=>{assetPromises.delete(key);throw e});assetPromises.set(key,p)}return assetPromises.get(key)}
  function context(popup){let f=popup[Object.keys(popup).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<35;i++,f=f.return){const p=f.memoizedProps;if(p?.actions?.emoticonStickerActions&&p?.data?.emoticonStickerStore)return p}return null}
  const sending=new WeakSet();
  async function insert(popup,item,status){if(sending.has(popup))return;sending.add(popup);try{const p=context(popup),active=p?.data.emoticonStickerStore.activePopperState,stickers=p?.actions.emoticonStickerActions,logs=stickers?.logActions,channel=stickers?.activeChannelId;if(!popup.isConnected||!active||!channel||typeof logs?.createAndSendLog!=='function'||typeof logs?.fetchLatestLogsIfNeeded!=='function')throw Error('이모티콘 창을 다시 열어 주세요.');status.textContent='전송 중…';await logs.fetchLatestLogsIfNeeded(channel);if(!popup.isConnected||disposed||stickers.activeChannelId!==channel||p.data.emoticonStickerStore.activePopperState!==active)throw Error('대화방이 변경되어 전송하지 않았습니다.');logs.createAndSendLog(channel,encode(item));active.setOpen(false);}catch(e){status.textContent=e.message}finally{sending.delete(popup)}}
  const css=document.createElement('style');css.id='dooray-custom-emoticons-style';css.textContent=`
  .js-sticker-emotion[data-dt-custom-open] > :not(.lcdHJ):not(.dt-emoticon-custom){display:none!important}
  .dt-emoticon-custom[hidden]{display:none!important}
  [data-dt-emoticon][data-dt-emoticon]{font-size:0!important;line-height:0!important;visibility:hidden!important}
  [data-dt-emoticon][data-dt-emoticon] > :not(.dt-received-emoticon){display:none!important}
  .dt-received-emoticon{visibility:visible!important;display:inline-flex!important;align-items:center;justify-content:center;vertical-align:middle;flex-wrap:wrap;gap:4px;max-width:100%;font:12px/1.4 sans-serif!important;color:var(--dt-text,#333);overflow:hidden}
  .dt-emoticon-imagebox{display:inline-flex;width:160px;height:160px;align-items:center;justify-content:center;flex:none;max-width:100%} .dt-emoticon-text{white-space:pre-wrap;font-size:14px;line-height:1.5}
  .dt-received-emoticon img{display:block;width:100%;height:100%;object-fit:contain}
  .dt-received-emoticon button{font:inherit;color:inherit;background:transparent;border:0;cursor:pointer;max-width:100%}
  `;document.head.append(css);
  const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){observer.unobserve(entry.target);entry.target.__dtLoadEmoticon?.();}},{rootMargin:'160px'});
  function lazy(target,load){target.__dtLoadEmoticon=load;observer.observe(target)}
  function fillPicker(popup,state,data){
    if(!popup.isConnected||disposed)return;state.select.replaceChildren();state.data=data;
    for(const [i,pack]of data.packs.entries()){const option=document.createElement('option');option.value=i;option.textContent=pack.name;state.select.append(option)}
    state.status.textContent=data.warnings?.length?'일부 팩을 읽지 못했습니다. '+data.warnings[0]:'이모티콘을 누르면 바로 전송됩니다.';
    state.select.onchange=()=>drawPack(popup,state);drawPack(popup,state);
  }
  function drawPack(popup,state){
    for(const child of state.grid.children)observer.unobserve(child);state.grid.replaceChildren();const pack=state.data?.packs[Number(state.select.value)||0];if(!pack)return;
    for(const item of pack.items){const b=document.createElement('button');b.type='button';b.title=item.label;b.setAttribute('aria-label',item.label+' 보내기');b.textContent=item.label;b.disabled=true;state.grid.append(b);
      lazy(b,()=>image(item).then(src=>{if(!b.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.src=src;img.onload=()=>{b.disabled=false};img.onerror=()=>{b.textContent='이미지 로딩 실패';};b.replaceChildren(img);b.onclick=()=>insert(popup,item,state.status)}).catch(e=>{b.textContent='불러오기 실패';b.title=e.message}));
    }
  }
  async function loadPicker(popup,state,refresh=false){state.status.textContent='이모티콘 목록을 불러오는 중…';state.refresh.disabled=true;try{if(refresh)catalog=null;if(!catalog){loading ||= rpc('emoticon-catalog',{refresh}).finally(()=>{loading=null});catalog=await loading}fillPicker(popup,state,catalog)}catch(e){state.status.textContent=e.message+' 목록 준비 후 새로고침을 눌러 주세요.'}finally{state.refresh.disabled=false}}
  function mount(popup){
    if(popups.has(popup))return;const tabs=popup.querySelector(':scope > .lcdHJ');if(!tabs)return;
    const tabSlot=document.createElement('div');tabSlot.className='M306H';tabSlot.dataset.dtCustomTab='true';const tab=document.createElement('button');tab.type='button';tab.className=tabs.querySelector('button')?.className||'';const label=document.createElement('div');label.className=tabs.querySelector('button > div')?.className||'';label.textContent='커스텀';tab.append(label);tab.setAttribute('aria-selected','false');tabSlot.append(tab);tabs.append(tabSlot);let selectedNative=[];const selectTab=selected=>{if(selected){selectedNative=[...tabs.children].filter(n=>n!==tabSlot&&n.classList.contains('LOqnd'));for(const n of selectedNative)n.classList.remove('LOqnd');}else{for(const n of selectedNative)if(n.isConnected)n.classList.add('LOqnd');selectedNative=[];}tabSlot.classList.toggle('LOqnd',selected);tab.setAttribute('aria-selected',String(selected));};
    const panel=document.createElement('div');panel.className='dt-emoticon-custom';panel.hidden=true;const shadow=panel.attachShadow({mode:'open'});shadow.innerHTML=`<style>:host{display:block;width:360px;max-width:80vw;color:var(--dt-text,#333);background:var(--dt-bg,#fff);font:12px sans-serif}*{box-sizing:border-box}.tools{display:flex;gap:6px;padding:10px}select{min-width:0;flex:1}button,select{color:inherit;background:var(--dt-surface,#eee);border:1px solid var(--dt-border,#bbb);border-radius:4px;padding:6px;font:inherit}button{cursor:pointer}button:disabled{opacity:.5;cursor:default}#status{padding:0 10px;margin:0 0 8px;font-size:11px;line-height:1.5;overflow-wrap:anywhere}#grid{height:280px;overflow:auto;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));align-content:start;gap:6px;padding:8px}#grid button{height:78px;overflow:hidden;padding:3px}img{width:100%;height:100%;object-fit:contain}button:focus-visible{outline:2px solid #278ac2}</style><div class="tools"><select id="packs" aria-label="이모티콘 팩"></select><button id="refresh">새로고침</button></div><p id="status" role="status"></p><div id="grid"></div>`;
    popup.append(panel);const state={panel,tab,grid:shadow.getElementById('grid'),select:shadow.getElementById('packs'),status:shadow.getElementById('status'),refresh:shadow.getElementById('refresh')};
    const nativeClick=e=>{if(e.target.closest('button')===tab)return;panel.hidden=true;popup.removeAttribute('data-dt-custom-open');selectTab(false)};tabs.addEventListener('click',nativeClick);state.detach=()=>{selectTab(false);tabs.removeEventListener('click',nativeClick);tabSlot.remove();panel.remove();popup.removeAttribute('data-dt-custom-open')};
    tab.onclick=()=>{panel.hidden=false;popup.setAttribute('data-dt-custom-open','');if(!tabSlot.classList.contains('LOqnd'))selectTab(true);loadPicker(popup,state)};state.refresh.onclick=()=>loadPicker(popup,state,true);popups.set(popup,state);
  }
  // Dooray may leave markdown spacing entities as literal text after a message.
  const normalizeSpacing=text=>text.replace(/&(?:#x(?:20|a0)|#(?:32|160)|nbsp);/gi,' ');
  function messageText(node){return normalizeSpacing([...node.childNodes].filter(n=>!(n.nodeType===1&&n.classList.contains('dt-received-emoticon'))).map(n=>n.textContent).join('')).trim()}
  const tokenPattern=()=>/\[\[dooray-\s*emoji:v1:[A-Za-z0-9_\-\s\u200B-\u200D\uFEFF]+\]\]/g;
  function messageCandidates(){
    const candidates=new Set([...decorated.keys()].filter(n=>n.isConnected));
    // The first scroll area can be a channel list. Search every rendered message area,
    // including side-panel conversations, without relying on generated CSS classes.
    const root=document.body;
    const skip='textarea,input,script,style,noscript,.dt-received-emoticon,.dt-emoticon-custom,.js-sticker-emotion';
    const excluded=node=>!node||node.isContentEditable||node.closest(skip);
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>excluded(n.parentElement)?NodeFilter.FILTER_REJECT:/\[\[|dooray-|emoji:v1:/.test(n.nodeValue||'')?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});
    for(let text=walker.nextNode();text;text=walker.nextNode()){
      const existing=text.parentElement?.closest('[data-dt-emoticon]');if(existing){candidates.add(existing);continue;}
      for(let node=text.parentElement,depth=0;node&&node!==root&&depth<12;node=node.parentElement,depth++){
        if(excluded(node)||node.querySelector('[contenteditable]:not([contenteditable="false"]),textarea,input'))break;const value=messageText(node);if(value.length>16000)break;
        if([...value.matchAll(tokenPattern())].some(m=>decode(m[0]))){candidates.add(node);break;}
      }
    }
    // Prefer the smallest matching text container; do not decorate a message twice.
    const nodes=[...candidates];return nodes.filter(n=>!nodes.some(other=>other!==n&&n.contains(other)));
  }
  function decorate(node,segments,key){
    const previous=decorated.get(node);if(previous?.key===key&&previous.view.parentNode===node)return;
    const state=scrollState(node),scroll=state?.scroll,oldTop=scroll?.scrollTop,above=scroll&&node.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,oldHeight=node.getBoundingClientRect().height;
    if(previous){resized.unobserve(previous.view);for(const box of previous.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(previous.view);previous.view.remove()}
    const view=document.createElement('span');view.className='dt-received-emoticon';view.setAttribute('aria-label','커스텀 이모티콘 메시지');node.setAttribute('data-dt-emoticon','');node.append(view);decorated.set(node,{key,view});
    for(const segment of segments){if(typeof segment==='string'){const text=document.createElement('span');text.className='dt-emoticon-text';text.textContent=segment;view.append(text);continue;}const item=segment,box=document.createElement('span');box.className='dt-emoticon-imagebox';box.textContent='이모티콘 불러오는 중…';view.append(box);const load=()=>image(item).then(src=>{if(!box.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.src=src;img.onerror=failed;box.replaceChildren(img)}).catch(failed);function failed(){if(!box.isConnected)return;const retry=document.createElement('button');retry.textContent=item.label+' · 다시 불러오기';retry.onclick=load;box.replaceChildren(retry)}lazy(box,load);}
    if(state?.follow)followBottom(state);else if(above)scroll.scrollTop=oldTop+node.getBoundingClientRect().height-oldHeight;
    resized.observe(view);

  }
  function scan(){scheduled=0;if(disposed)return;for(const popup of document.querySelectorAll('.js-sticker-emotion'))mount(popup);for(const[p,state]of popups)if(!p.isConnected){state.detach();popups.delete(p)}
    for(const node of messageCandidates()){if(node.closest('[contenteditable="true"]'))continue;const text=messageText(node),segments=[];let at=0,count=0;for(const match of text.matchAll(tokenPattern())){const item=decode(match[0]);if(!item||count>=8)continue;if(match.index>at)segments.push(text.slice(at,match.index));segments.push(item);at=match.index+match[0].length;count++;}if(at<text.length)segments.push(text.slice(at));if(count)decorate(node,segments,text);else if(decorated.has(node)){const d=decorated.get(node);resized.unobserve(d.view);for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(d.view);d.view.remove();node.removeAttribute('data-dt-emoticon');decorated.delete(node)}}
    for(const[n,d]of decorated)if(!n.isConnected){resized.unobserve(d.view);observer.unobserve(d.view);decorated.delete(n)}
    for(const[scroll,state]of scrollStates)if(!scroll.isConnected){state.dispose();scrollStates.delete(scroll)}
  }
  const changes=new MutationObserver(()=>{if(!scheduled)scheduled=setTimeout(scan,120)});changes.observe(document.body,{subtree:true,childList:true,characterData:true});scan();
  return ()=>{disposed=true;clearTimeout(scheduled);changes.disconnect();observer.disconnect();resized.disconnect();for(const state of scrollStates.values())state.dispose();scrollStates.clear();css.remove();for(const[p,s]of popups)s.detach();for(const[n,d]of decorated){d.view.remove();n.removeAttribute('data-dt-emoticon')}popups.clear();decorated.clear();assetPromises.clear()};
}

// Versioned update supervisor: delivered and replaced with every signed user release.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,checkRemote,atomicJSON,newer} from './update-store.mjs';
const root=process.env.DOORAY_INSTALL_ROOT;
const ownVersion=path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
if(process.argv.includes('--check')){console.log(JSON.stringify({controller:ownVersion,mode:'per-user-signed-updates',runtime:process.version}));process.exit(0);}
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(19351,'127.0.0.1',()=>r(true))}))process.exit(0);
await fs.mkdir(data,{recursive:true});
const store=await new UpdateStore({data,publicKey}).init();
const disabled=path.join(userData,'theme-disabled.flag'),stopFlag=path.join(userData,'stop-agent.flag'),healthy=path.join(userData,'healthy.flag'),releaseError=path.join(userData,'release-error.json');
const exists=async p=>{try{await fs.access(p);return true}catch{return false}};
const log=async message=>{try{const file=path.join(userData,'updater.log');if((await fs.stat(file).catch(()=>({size:0}))).size>1048576)await fs.rename(file,file+'.previous');await fs.appendFile(file,new Date().toISOString()+' '+message+'\n')}catch{}};
const expectedExit=new WeakSet();let mayActivate=false;let child=null,busy=false,remoteBusy=false,closing=false,holdUntilClose=false,started=0,wasPresent=false,lastCheck=0,crashed=false;
async function activate(){
  await store.activate();
  if(store.state.active!==ownVersion)process.exit(75);
}
process.on('disconnect',()=>shutdown());
setInterval(()=>{if(process.connected)process.send({type:'supervisor-alive',version:ownVersion})},2000).unref();
if(process.connected)process.send({type:'supervisor-alive',version:ownVersion});
async function shutdown(){if(closing)return;closing=true;if(child){try{child.send({type:'shutdown'})}catch{}const old=child;setTimeout(()=>{try{old.kill()}catch{}},2500).unref();}setTimeout(()=>process.exit(0),3000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);process.on('exit',()=>{try{child?.kill()}catch{}});
async function fail(reason){await log('Release failed: '+store.state.active+' '+reason);const old=child;child=null;if(old){try{old.send({type:'shutdown'})}catch{}setTimeout(()=>{try{old.kill()}catch{}},1500).unref();}
  if(old)try{old.kill()}catch{}
  const previous=await store.rollback();await fs.unlink(releaseError).catch(()=>{});holdUntilClose=true;
  if(previous)process.exit(75);
  await log('No healthy release; retry on next launch');await shutdown();
}
let remotePromise=null,lastResult={status:'idle'};
const updateStatus=()=>({...lastResult,active:store.state.active,pending:store.state.pending,checkedAt:lastCheck});
async function remote(force=false,download=true){
 if(remotePromise){await remotePromise;if(!download||store.state.pending)return updateStatus();}
 if(!force&&Date.now()-lastCheck<1800000)return updateStatus();
 lastCheck=Date.now();lastResult={status:download?'downloading':'checking'};
 remotePromise=(async()=>{try{const result=await checkRemote(store,fetch,{download});lastResult={status:store.state.pending?'ready':result?.available?'available':'current',available:result?.available||null};if(store.state.pending)await log('Update staged: '+store.state.pending);}catch(e){lastResult={status:'error',error:e.message};await log('Update check deferred: '+e.message)}return updateStatus()})().finally(()=>{remotePromise=null});
 return remotePromise;
}
function connectUpdates(running){running.on('message',async m=>{
 if(running!==child||!['update-check','update-status','update-install'].includes(m?.type)||typeof m.id!=='string'||m.id.length>80)return;
 const result=m.type==='update-check'?await remote(true,false):m.type==='update-install'?await remote(true,true):updateStatus();
 if(running===child&&running.connected)try{running.send({type:'update-result',id:m.id,result})}catch{}
});}
async function targets(){try{const list=await(await fetch('http://127.0.0.1:19347/json/list',{signal:AbortSignal.timeout(1000)})).json();return Array.isArray(list)?list.some(t=>{try{const u=new URL(t.url);return t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)&&u.pathname.startsWith('/messenger')}catch{return false}}):null}catch(e){return e.cause?.code==='ECONNREFUSED'?false:null}}
async function tick(){if(busy||closing)return;busy=true;try{
  if(await exists(disabled)||await exists(stopFlag)){await shutdown();return;}
  const present=await targets();if(present===null)return;
  if(!present){holdUntilClose=false;crashed=false;mayActivate=true;if(wasPresent&&child){expectedExit.add(child);try{child.send({type:'shutdown'})}catch{}}wasPresent=false;
    if(!child&&store.state.pending)await activate();return;
  }
  if(!wasPresent){await remote(true);if(!child){if(store.state.pending)await activate();mayActivate=false;}}
  wasPresent=true;void remote();if(holdUntilClose)return;
  if(child){
    if(await exists(releaseError)){await fail('runtime-error');return;}
    let health=null;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
    if(health?.version===store.state.active&&health.at>=started){if(store.state.trial)await store.confirm();return;}
    if(Date.now()-started>45000)await fail('startup-timeout');return;
  }
  if(!child&&mayActivate){if(store.state.pending)await activate();mayActivate=false;}
  if(crashed){crashed=false;await fail('helper-exited');return;}
  if(!store.state.active){await fail('missing-active-release');return;}
  try{await store.validate(store.state.active)}catch(e){await fail(e.message);return;}
  await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});started=Date.now();if(store.state.trial){store.state.trialStarted=true;await store.persist();}
  const running=spawn(process.execPath,[path.join(store.dir(store.state.active),'app/launcher.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],cwd:store.dir(store.state.active)});child=running;connectUpdates(running);
  running.once('error',()=>{if(child===running){child=null;crashed=true}});running.once('exit',()=>{if(child===running){child=null;crashed=wasPresent&&!closing&&!expectedExit.has(running)}});
  await log('Loaded user release '+store.state.active);
}catch(e){await log('Bootstrap error: '+e.message);if(child)await fail('bootstrap-error');}finally{busy=false}}
try{if(store.state.active!==ownVersion)process.exit(75);await tick();setInterval(tick,2000);}catch(e){await log('Initialization deferred: '+e.message);await shutdown();}

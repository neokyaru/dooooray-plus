// API tokens never enter the webview. Native password entry and DPAPI operate
// in a bounded child; only get() returns a transient token over its stdout pipe.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const SCRIPT=fileURLToPath(new URL('./drive-credentials.ps1',import.meta.url));
const COMMAND="$ErrorActionPreference='Stop';[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false);&([ScriptBlock]::Create([IO.File]::ReadAllText($env:DOORAY_PLUS_DRIVE_SCRIPT,[Text.Encoding]::UTF8)))";
const ENCODED=Buffer.from(COMMAND,'utf16le').toString('base64');
const MAX_RECORD=64*1024,MAX_REPLY=16*1024;
const failure=(code='DRIVE_CREDENTIALS_FAILED')=>Object.assign(new Error({DRIVE_CREDENTIALS_BUSY:'인증 정보 창이 처리 중입니다.',DRIVE_CREDENTIALS_UNSUPPORTED:'Windows에서만 인증 정보를 저장할 수 있습니다.',DRIVE_CREDENTIALS_INVALID_SCOPE:'두레이 계정 정보를 확인하지 못했습니다.',DRIVE_CREDENTIALS_CLOSED:'인증 정보 처리가 종료됐습니다.'}[code]||'인증 정보를 처리하지 못했습니다.'),{code});
const aborted=()=>Object.assign(new Error('인증 정보 처리가 취소되었습니다.'),{name:'AbortError',code:'ABORT_ERR'});
const hash=scope=>crypto.createHash('sha256').update(scope,'utf8').digest('hex');
const tokenValid=token=>typeof token==='string'&&/^[\x21-\x7e]{1,4096}$/.test(token);
export function normalizeDriveScope(scope){
  if(typeof scope!=='string'||scope.length>320)throw failure('DRIVE_CREDENTIALS_INVALID_SCOPE');
  const parts=scope.split('|');if(parts.length!==2||!/^\d{1,64}$/.test(parts[1]))throw failure('DRIVE_CREDENTIALS_INVALID_SCOPE');
  let url;try{url=new URL(parts[0])}catch{throw failure('DRIVE_CREDENTIALS_INVALID_SCOPE')}
  if(url.protocol!=='https:'||url.username||url.password||url.port||url.pathname!=='/'||url.search||url.hash||!/^https:\/\/[a-z0-9-]+\.(?:dooray|gov-dooray)\.com\/?$/i.test(parts[0])||!new RegExp('^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.(?:dooray|gov-dooray)\\.com$').test(url.hostname))throw failure('DRIVE_CREDENTIALS_INVALID_SCOPE');
  return url.origin+'|'+parts[1];
}
function exactKeys(value,keys){return value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===[...keys].sort().join(',');}
function validRecord(value,scopeHash){return exactKeys(value,['schema','scopeHash','protected'])&&value.schema===1&&value.scopeHash===scopeHash&&typeof value.protected==='string'&&value.protected.length>=16&&value.protected.length<=48*1024&&/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value.protected);}
async function regularFile(filesystem,file){
  let info;try{info=await filesystem.lstat(file)}catch(error){if(error?.code==='ENOENT')return null;throw failure()}
  if(info.isSymbolicLink()||!info.isFile()||info.size>MAX_RECORD||info.size<1)throw failure();
  for(let current=path.dirname(file);;){const entry=await filesystem.lstat(current);if(entry.isSymbolicLink()||!entry.isDirectory())throw failure();const parent=path.dirname(current);if(parent===current)break;current=parent;}
  return info;
}
function nativeRunner({spawnProcess,environment}){
  let owned=null,disposed=false;
  const system=environment.SystemRoot||environment.WINDIR;
  return {
    get busy(){return !!owned;},
    run(request,{signal}={}){
      if(disposed)return Promise.reject(failure('DRIVE_CREDENTIALS_CLOSED'));
      if(owned)return Promise.reject(failure('DRIVE_CREDENTIALS_BUSY'));
      if(signal?.aborted)return Promise.reject(aborted());
      if(typeof system!=='string'||!path.isAbsolute(system))return Promise.reject(failure());
      return new Promise((resolve,reject)=>{
        let child,settled=false,ending=false,bytes=0,parts=[],timeout,grace,ceiling;
        const erase=()=>{for(const part of parts)part.fill(0);parts=[];};
        const settle=(error,result)=>{if(settled)return;settled=true;clearTimeout(timeout);signal?.removeEventListener('abort',onAbort);erase();error?reject(error):resolve(result);};
        const stop=(error)=>{
          if(ending)return;ending=true;clearTimeout(timeout);
          // EOF cancels the native form. Never kill another process or launch a
          // replacement until this exact owned child has actually exited.
          try{child.stdin.end()}catch{}
          grace=setTimeout(()=>{try{child.kill()}catch{}},500);grace.unref?.();
          ceiling=setTimeout(()=>settle(error),1800);ceiling.unref?.();
          if(owned)owned.error=error;
        };
        const onAbort=()=>stop(aborted());
        try{child=spawnProcess(path.join(system,'System32','WindowsPowerShell','v1.0','powershell.exe'),['-NoProfile','-NonInteractive','-WindowStyle','Hidden','-STA','-EncodedCommand',ENCODED],{windowsHide:true,stdio:['pipe','pipe','pipe'],env:{...environment,DOORAY_PLUS_DRIVE_SCRIPT:SCRIPT}})}catch{settle(failure());return;}
        owned={child,error:null,stop};
        const onData=chunk=>{if(settled||ending)return;const copy=Buffer.from(chunk);bytes+=copy.length;if(bytes>MAX_REPLY){copy.fill(0);stop(failure());return}parts.push(copy)};
        child.stdout.on('data',onData);
        // Native errors are not logged or returned verbatim; they might include
        // a value from an external library. Drain the pipe without retaining it.
        const drain=()=>{},onError=()=>stop(failure());
        child.stderr.on('data',drain);
        child.stdin.on('error',onError);
        child.on('error',onError);
        child.once('close',code=>{
          child.stdout.removeListener('data',onData);child.stderr.removeListener('data',drain);child.stdin.removeListener('error',onError);child.removeListener('error',onError);
          clearTimeout(grace);clearTimeout(ceiling);const error=owned?.child===child?owned.error:null;if(owned?.child===child)owned=null;
          if(ending){settle(error||failure());return;}
          if(code!==0){settle(failure());return;}
          let result;try{const all=Buffer.concat(parts);try{result=JSON.parse(all.toString('utf8').replace(/^\uFEFF/,''))}finally{all.fill(0)}}catch{settle(failure());return;}
          settle(null,result);
        });
        signal?.addEventListener('abort',onAbort,{once:true});
        timeout=setTimeout(()=>stop(failure()),request.op==='configure'?185000:15000);timeout.unref?.();
        if(signal?.aborted){onAbort();return;}
        try{child.stdin.write(JSON.stringify(request)+'\n')}catch{stop(failure())}
      });
    },
    dispose(){disposed=true;owned?.stop(aborted());}
  };
}

export function createDriveCredentials({root,runner,filesystem=fs,platform=process.platform,spawnProcess=spawn,environment=process.env}={}){
  const base=path.resolve(root||path.join(environment.LOCALAPPDATA||'', 'DoorayTheme'));
  const native=runner?null:nativeRunner({spawnProcess,environment});
  let disposed=false,active=null;
  function checked(scope,signal){if(disposed)throw failure('DRIVE_CREDENTIALS_CLOSED');if(signal?.aborted)throw aborted();if(platform!=='win32')throw failure('DRIVE_CREDENTIALS_UNSUPPORTED');return normalizeDriveScope(scope);}
  function file(scope){return path.join(base,'drive-credentials',hash(scope)+'.json');}
  async function readStatus(scope,signal){
    const target=file(scope),before=await regularFile(filesystem,target);if(!before)return false;
    let record;try{record=JSON.parse(await filesystem.readFile(target,{encoding:'utf8',signal}))}catch(error){if(signal?.aborted)throw aborted();throw failure()}
    const after=await regularFile(filesystem,target);
    if(!after||['dev','ino','size','mtimeMs','ctimeMs'].some(key=>before[key]!==after[key])||!validRecord(record,hash(scope)))throw failure();
    if(signal?.aborted)throw aborted();return true;
  }
  async function execute(op,scope,signal){
    if(disposed)throw failure('DRIVE_CREDENTIALS_CLOSED');
    if(signal?.aborted)throw aborted();
    if(active||native?.busy)throw failure('DRIVE_CREDENTIALS_BUSY');
    const controller=new AbortController(),abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});
    const entry={scope,controller,promise:null};active=entry;
    entry.promise=(async()=>{
      try{
        if(signal?.aborted)controller.abort();
        const result=await (runner||native.run)({schema:1,op,scope,root:base},{signal:controller.signal});
        if(controller.signal.aborted||disposed)throw aborted();
        if(!result||result.schema!==1||result.op!==op||result.scopeHash!==hash(scope)||result.ok!==true)throw failure();
        const allowed=['schema','op','scopeHash','ok','configured',...(op==='configure'?['cancelled']:op==='get'?['token']:[])];
        if(!exactKeys(result,allowed)||typeof result.configured!=='boolean')throw failure();
        if(op==='configure'){if(typeof result.cancelled!=='boolean')throw failure();return result.cancelled?{configured:result.configured,cancelled:true}:{configured:result.configured};}
        if(op==='forget'){if(result.configured)throw failure();return;}
        if(result.token===null&&!result.configured)return null;
        if(!result.configured||!tokenValid(result.token))throw failure();return result.token;
      }catch(error){if(controller.signal.aborted||error?.name==='AbortError')throw aborted();throw failure(error?.code==='DRIVE_CREDENTIALS_BUSY'?error.code:undefined)}
      finally{signal?.removeEventListener('abort',abort);if(active===entry)active=null;}
    })();
    return entry.promise;
  }
  return {
    async status(scope,{signal}={}){scope=checked(scope,signal);try{const present=await readStatus(scope,signal);checked(scope,signal);return present}catch(error){if(signal?.aborted)throw aborted();throw failure()}},
    async configure(scope,{signal}={}){scope=checked(scope,signal);return execute('configure',scope,signal);},
    async get(scope,{signal}={}){scope=checked(scope,signal);const present=await readStatus(scope,signal);checked(scope,signal);if(!present)return null;return execute('get',scope,signal);},
    async forget(scope,{signal}={}){scope=checked(scope,signal);if(active?.scope===scope){const previous=active;previous.controller.abort();await previous.promise.catch(()=>{});}if(signal?.aborted)throw aborted();return execute('forget',scope,signal);},
    get busy(){return !!active||!!native?.busy;},
    async dispose(){if(disposed)return;disposed=true;const previous=active;previous?.controller.abort();native?.dispose();await previous?.promise.catch(()=>{});}
  };
}

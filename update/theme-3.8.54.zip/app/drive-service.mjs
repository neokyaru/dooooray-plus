import fs from 'node:fs/promises';
import path from 'node:path';
import {randomUUID, createHash} from 'node:crypto';
import {commitDownloadFile} from './download-paths.mjs';
import {normalizeDriveShareOptions, validateDriveItemName} from './drive-api.mjs';

const chunkSize = 512 * 1024;
const transferLimit = 1024 * 1024 * 1024;
const previewLifetime = 120_000;
const numericId = /^\d{1,64}$/;
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const previewFormats = new Map(Object.entries({
  '.png': ['image', 'image/png'], '.jpg': ['image', 'image/jpeg'],
  '.jpeg': ['image', 'image/jpeg'], '.gif': ['image', 'image/gif'],
  '.webp': ['image', 'image/webp'], '.bmp': ['image', 'image/bmp'],
  '.mp4': ['video', 'video/mp4'], '.m4v': ['video', 'video/mp4'],
  '.webm': ['video', 'video/webm'], '.pdf': ['pdf', 'application/pdf'],
  ...Object.fromEntries(['.txt','.md','.csv','.tsv','.log','.json','.xml'].map(ext => [ext, ['text', 'text/plain']]))
}));

// Executed in the current main Messenger frame. The RPC payload never selects
// an organization or a member. Resolve the native account again after a switch.
function currentMember() {
  if (window !== window.top || !/^\/messenger(?:\/|$)/.test(location.pathname)) return null;
  const root = document.getElementById('root');
  if (!root) return null;
  const sources = [...root.querySelectorAll('.js-main-editor,.js-scroll-area,.js-channel-list')].slice(0, 16);
  sources.push(...Array.from(root.children).slice(0, 8));
  for (const element of sources) {
    const key = Object.keys(element).find(name => name.startsWith('__reactFiber'));
    for (let f = element[key], n=0; f && n < 60; f=f.return, n++) {
      const stores = f.memoizedProps?.actions?.stores;
      if (stores?.uiState?.isMainView === false) continue;
      const value = String(stores?.userStore?.id ?? '');
      if (/^\d{1,64}$/.test(value)) return value;
    }
  }
  return null;
}

async function contextScope(session, contextId, signal) {
  signal?.throwIfAborted();
  const epoch = session.preflightEpoch;
  const context = session.contexts.get(contextId);
  if (!context) throw Error('두레이 기본 창에서 드라이브를 열어 주세요.');
  const tree = await session.send('Page.getFrameTree', {}, {signal});
  const frame = tree?.frameTree?.frame;
  if (!frame?.id || frame.id !== context.frameId) throw Error('두레이 기본 창에서 드라이브를 열어 주세요.');
  const response = await session.send('Runtime.evaluate', {
    contextId, expression: '('+currentMember.toString()+')()', returnByValue:true
  }, {signal});
  const member = response?.result?.value;
  if (response?.exceptionDetails || typeof member !== 'string' || !numericId.test(member) ||
      !session.active() || session.preflightEpoch !== epoch || session.contexts.get(contextId) !== context) {
    throw Error('현재 두레이 계정을 확인하지 못했습니다. 대화방을 연 후 다시 시도해 주세요.');
  }
  return {scope:session.origin+'|'+member, member};
}

function safeFilename(name) {
  const sanitized = String(name || '파일').replace(/[<>:"/\\|?*\x00-\x1f\x7f]/g, '_')
    .slice(0, 150).replace(/[. ]+$/, '').replace(/^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?=\.|$)/i, '_$1');
  return sanitized || '파일';
}

async function readBody(response, cap, signal, write) {
  const reader = response.body?.getReader();
  if (!reader) throw Error('두레이에서 파일을 받지 못했습니다.');
  let length = 0;
  try {
    for (;;) {
      signal.throwIfAborted();
      const {done, value} = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > cap) throw Error('파일이 지원 크기를 초과합니다.');
      await write(value);
    }
    return length;
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

function previewType(name) {
  const format = previewFormats.get(path.extname(name).toLowerCase());
  if (!format) throw Error('이 파일 형식은 미리보기를 지원하지 않습니다.');
  const [kind,mime] = format;
  return {kind,mime,limit:kind==='text'?256*1024:(kind==='video'?64:16)*1024*1024};
}

export function createDriveService({apiForOrigin, credentials, jobs, folder, blocked, getScope=contextScope, io=fs}) {
  const completed = new Map();
  const checks = new Map();
  let preview = null;
  let preparingPreview = null;
  let disposed = false;
  let keyQueue = Promise.resolve();
  let keyRequests = 0;
  let editing = null;

  function clearPreview() {
    if (preview) clearTimeout(preview.timer);
    preview = null;
  }
  function invalidate(session) {
    if (preview?.session === session) clearPreview();
    if (preparingPreview?.session === session) preparingPreview.controller.abort();
    if (editing?.session === session) editing.controller.abort();
    for (const [id,job] of completed) if (job.session === session) completed.delete(id);
  }
  async function validToken(identity, signal) {
    if (keyRequests >= 6) throw Error('드라이브 요청이 많습니다. 잠시 후 다시 시도해 주세요.');
    keyRequests++;
    const request = keyQueue.then(() => {
      signal.throwIfAborted();
      return credentials.get(identity.scope,{signal});
    });
    keyQueue = request.then(()=>{},()=>{});
    let token;
    try { token = await request; }
    finally { keyRequests--; }
    if (!token) throw Error('개인 API 키를 먼저 등록해 주세요.');
    const hash = createHash('sha256').update(token).digest('hex');
    const saved = checks.get(identity.scope);
    if (saved?.hash === hash && saved.until > Date.now()) return token;
    const result = await identity.api.identity(token, {signal});
    if (String(result?.id ?? result) !== identity.member) throw Error('현재 두레이 계정에서 발급한 API 키를 입력해 주세요.');
    if (checks.size >= 16) checks.clear();
    checks.set(identity.scope, {hash, until:Date.now()+120_000});
    return token;
  }
  function coordinates(request, file=false) {
    const {driveId, fileId, parentId} = request;
    if (typeof driveId !== 'string' || !numericId.test(driveId) ||
        file && (typeof fileId !== 'string' || !numericId.test(fileId)) ||
        parentId != null && (typeof parentId !== 'string' || !numericId.test(parentId))) {
      throw Error('드라이브 항목을 다시 선택해 주세요.');
    }
    return {driveId,fileId,parentId};
  }
  async function runWrite(session, contextId, who, signal, apply) {
    if (blocked()) throw Error('업데이트가 끝난 후 다시 시도해 주세요.');
    if (editing || jobs.size >= 16) throw Error('진행 중인 드라이브 작업이 끝난 뒤 다시 시도해 주세요.');
    const controller = new AbortController();
    const jobId = randomUUID();
    const job = {session,scope:who.scope,controller,done:null};
    const operationSignal = AbortSignal.any([signal,controller.signal,AbortSignal.timeout(23_000)]);
    const assertCurrent = async () => {
      operationSignal.throwIfAborted();
      if (disposed || (await getScope(session,contextId,operationSignal)).scope !== who.scope) {
        throw Error('두레이 계정이 변경되었습니다.');
      }
      operationSignal.throwIfAborted();
      if (blocked()) throw Error('업데이트가 끝난 후 다시 시도해 주세요.');
    };
    editing = job;
    jobs.set(jobId,job);
    job.done = (async () => {
      const token = await validToken(who,operationSignal);
      await assertCurrent();
      return apply(token,operationSignal,assertCurrent);
    })();
    try {
      return await job.done;
    } catch (error) {
      if (operationSignal.aborted && !signal.aborted && !controller.signal.aborted) {
        throw Error('변경 결과를 확인하지 못했습니다. 새로고침으로 현재 상태를 확인해 주세요.');
      }
      throw error;
    } finally {
      controller.abort();
      jobs.delete(jobId);
      if (editing === job) editing = null;
    }
  }
  async function editEntry(session, contextId, who, request, op, signal) {
    const {driveId,fileId,parentId} = coordinates(request, op !== 'create-folder');
    const destinationId = request.destinationId;
    const name = op === 'create-folder' || op === 'rename' ? validateDriveItemName(request.name) : null;
    if (op === 'trash' && request.confirmed !== true) throw Error('휴지통 이동을 확인해 주세요.');
    if (op === 'move' && destinationId !== null &&
        (typeof destinationId !== 'string' || !numericId.test(destinationId) || destinationId === fileId)) {
      throw Error('이동할 폴더를 다시 선택해 주세요.');
    }
    return runWrite(session,contextId,who,signal,async (token,operationSignal,assertCurrent) => {
      const options = {driveId,signal:operationSignal};
      const hasDestination = op === 'create-folder' || op === 'move';
      const folderId = op === 'create-folder' ? parentId : op === 'move' ? destinationId : null;
      const [entry,folder,resolvedFolderId] = await Promise.all([
        op === 'create-folder' ? null : who.api.metadata(token,{...options,fileId}),
        folderId ? who.api.metadata(token,{...options,fileId:folderId}) : null,
        hasDestination && !folderId ? who.api.rootFolder(token,options) : folderId
      ]);
      if (folderId && (!folder?.isFolder || !['root','users'].includes(folder.subType))) {
        throw Error('드라이브에서 사용할 수 있는 폴더를 선택해 주세요.');
      }
      if (op === 'move' && entry?.isFolder !== false) throw Error('이동할 파일을 다시 선택해 주세요.');
      if (['rename','trash'].includes(op) && entry?.isFolder !== false &&
          (!entry?.isFolder || entry.subType !== 'users')) {
        throw Error('이 폴더에서는 해당 작업을 할 수 없습니다.');
      }
      await assertCurrent();
      try {
        if (op === 'create-folder') return await who.api.createFolder(token,{...options,parentId:resolvedFolderId,name});
        if (op === 'rename') return await who.api.rename(token,{...options,fileId,name});
        if (op === 'trash') return await who.api.trash(token,{...options,fileId});
        return await who.api.move(token,{...options,fileId,destinationId:resolvedFolderId});
      } catch (error) {
        if (['NETWORK','CANCELLED','INVALID_RESPONSE','UNSAFE_REDIRECT'].includes(error?.code) || error?.status >= 500) {
          throw Error('변경 결과를 확인하지 못했습니다. 새로고침으로 목록을 확인해 주세요.');
        }
        throw error;
      }
    });
  }
  async function preparePreview(session, contextId, who, request, signal) {
    // Limit retained media to one preview across the helper; never cache it on disk.
    if (preparingPreview) throw Error('미리보기를 불러오는 중입니다.');
    clearPreview();
    const controller = new AbortController();
    const active = {session,controller};
    preparingPreview = active;
    const operationSignal = AbortSignal.any([signal,controller.signal]);
    try {
      const ids = coordinates(request,true);
      const token = await validToken(who,operationSignal);
      const {api} = who;
      const item = await api.metadata(token,{...ids,signal:operationSignal});
      if (item.isFolder) throw Error('폴더는 미리볼 수 없습니다.');
      const format = previewType(item.name);
      if (Number.isSafeInteger(item.size) && item.size > format.limit) throw Error('미리보기 크기를 초과합니다. 파일을 다운로드해 주세요.');
      const response = await api.content(token,{...ids,signal:operationSignal});
      const chunks = [];
      const size = await readBody(response,format.limit,operationSignal,value => chunks.push(value));
      if ((await getScope(session,contextId,operationSignal)).scope !== who.scope) throw Error('두레이 계정이 변경되었습니다.');
      const bytes = Buffer.concat(chunks,size);
      if (format.kind === 'text') {
        let text;
        try {
          const encoding = bytes[0]===0xff&&bytes[1]===0xfe ? 'utf-16le' :
            bytes[0]===0xfe&&bytes[1]===0xff ? 'utf-16be' : 'utf-8';
          text = new TextDecoder(encoding,{fatal:true}).decode(bytes);
          if (text.includes('\0')) throw Error('binary');
        } catch { throw Error('UTF-8 또는 UTF-16 텍스트만 미리볼 수 있습니다.'); }
        return {kind:'text',text};
      }
      if (format.kind==='pdf' && bytes.subarray(0,5).toString()!=='%PDF-') throw Error('올바른 PDF 파일이 아닙니다.');
      const id = randomUUID();
      preview = {id,session,contextId,scope:who.scope,bytes,timer:setTimeout(clearPreview,previewLifetime)};
      preview.timer.unref?.();
      return {kind:format.kind,mime:format.mime,size,id};
    } finally {
      if (preparingPreview === active) preparingPreview = null;
    }
  }

  function begin(session, contextId, who, request, direction) {
    if (blocked()) throw Error('업데이트가 끝난 후 다시 시도해 주세요.');
    if (jobs.size >= 16 || [...jobs.values()].filter(job => job.drive).length >= 2) throw Error('진행 중인 파일 전송이 많습니다.');
    const ids = coordinates(request,direction==='download');
    const id = randomUUID(), controller = new AbortController();
    const signal = AbortSignal.any([controller.signal,AbortSignal.timeout(600_000)]);
    const job = {id,session,contextId,scope:who.scope,controller,drive:true,state:'running',bytes:0,total:0,name:'파일'};
    const destinationFolder = direction==='download' ? folder() : null;
    if (direction==='upload') {
      if (!uuid.test(request.fileKey ?? '') || typeof request.name!=='string' || !request.name.trim() ||
          request.name.length>255 || /[\\/\x00-\x1f\x7f]/.test(request.name) ||
          !Number.isSafeInteger(request.size) || request.size<0 || request.size>transferLimit) throw Error('올바른 파일을 선택해 주세요. 최대 1 GiB까지 전송할 수 있습니다.');
      job.name=request.name;job.total=request.size;
    }
    jobs.set(id,job);
    const sameAccount = async () => {
      if ((await getScope(session,contextId,signal)).scope !== who.scope) throw Error('두레이 계정이 변경되었습니다.');
    };
    job.done = (async () => {
      let temporary;
      let output;
      try {
        const token = await validToken(who,signal);
        const {api} = who;
        await sameAccount();
        if (direction==='upload') {
          const body = async function* () {
            for (let offset=0;offset<job.total;) {
              await sameAccount();
              const length=Math.min(chunkSize,job.total-offset);
              const expression='window.__doorayDriveReadFile?.('+JSON.stringify(request.fileKey)+','+offset+','+length+')';
              const result=await session.send('Runtime.evaluate',{contextId,expression,awaitPromise:true,returnByValue:true},{signal});
              const base64=result?.result?.value;
              if (result?.exceptionDetails || typeof base64!=='string' || base64.length!==Math.ceil(length/3)*4) {
                throw Error('선택한 파일을 더 이상 읽을 수 없습니다.');
              }
              const bytes=Buffer.from(base64,'base64');
              if(bytes.length!==length || bytes.toString('base64')!==base64) throw Error('파일을 읽는 중 오류가 발생했습니다.');
              offset+=length;job.bytes=offset;
              yield bytes;
            }
          };
          await api.upload(token,{...ids,name:job.name,size:job.total,body:body(),signal});
        } else {
          const metadata=await api.metadata(token,{...ids,signal});
          if(metadata.isFolder) throw Error('파일을 선택해 주세요.');
          job.name=safeFilename(metadata.name);
          const hasSize=Number.isSafeInteger(metadata.size)&&metadata.size>=0;
          if(hasSize)job.total=metadata.size;
          if(job.total>transferLimit) throw Error('최대 1 GiB까지 다운로드할 수 있습니다.');
          const response=await api.content(token,{...ids,signal});
          temporary=path.join(destinationFolder,'.dooray-drive-'+id+'.part');
          try { output=await io.open(temporary,'wx'); }
          catch(error){await response.body?.cancel().catch(()=>{});temporary=undefined;throw error;}
          await readBody(response,hasSize?job.total:transferLimit,signal,async chunk=>{
            for(let offset=0;offset<chunk.byteLength;) {
              const result=await output.write(chunk,offset,chunk.byteLength-offset);
              if(!result.bytesWritten) throw Error('파일을 저장하지 못했습니다.');
              offset+=result.bytesWritten;
            }
            job.bytes+=chunk.byteLength;
          });
          if(hasSize&&job.bytes!==job.total)throw Error('파일 크기가 달라 저장하지 못했습니다.');
          await output.close();output=null;
          await sameAccount();
          job.committing=true;
          const file=await commitDownloadFile(temporary,destinationFolder,job.name,{io});
          job.name=path.basename(file);
        }
        job.state='done';
      } catch(error) {
        job.state=controller.signal.aborted?'cancelled':'failed';
        job.error=error?.code?.startsWith?.('E')?'파일을 읽거나 저장하지 못했습니다.':String(error?.message||'파일 전송에 실패했습니다.').slice(0,180);
      } finally {
        if(output)await output.close().catch(()=>{});
        if(temporary)await io.unlink(temporary).catch(()=>{});
        jobs.delete(id);
        if (session.active()&&!disposed) {
          if(completed.size>=32)completed.delete(completed.keys().next().value);
          completed.set(id,job);
        }
      }
    })();
    return {id};
  }

  async function command(session, request, {signal,contextId}) {
    if(disposed || signal.aborted)throw Error('드라이브 연결이 종료됐습니다.');
    const who={...await getScope(session,contextId,signal),api:apiForOrigin(session.origin)};
    const op=request.op.slice('drive-'.length);
    const credentialOptions={signal};
    const accountTag=createHash('sha256').update(who.scope).digest('hex');
    if(op==='status'){
      // The panel may reuse its own listing only after the current account matches.
      if(request.reuseAccountTag===accountTag)return {accountTag,reused:true};
      return {configured:await credentials.status(who.scope,credentialOptions),accountTag};
    }
    if(request.accountTag!==accountTag)throw Error('두레이 계정이 변경되었습니다. 드라이브 목록을 새로고침해 주세요.');
    if((op==='credentials'||op==='forget-key')&&editing?.scope===who.scope){
      throw Error('진행 중인 드라이브 작업이 끝난 뒤 키를 변경해 주세요.');
    }
    if(op==='credentials'){
      checks.delete(who.scope);
      return credentials.configure(who.scope,credentialOptions);
    }
    if(op==='forget-key'){
      if([...jobs.values()].some(job=>job.drive&&job.scope===who.scope))throw Error('파일 전송이 끝난 후 키를 삭제해 주세요.');
      checks.delete(who.scope);clearPreview();
      await credentials.forget(who.scope,credentialOptions);
      return {configured:false};
    }
    if(op==='job'||op==='cancel'){
      const job=jobs.get(request.id)||completed.get(request.id);
      if(job?.drive&&job.session===session&&job.contextId===contextId&&job.scope===who.scope){
        if(op==='cancel'){if(!job.committing)job.controller.abort();return true;}
        return {state:job.state,bytes:job.bytes,total:job.total,name:job.name,error:job.error};
      }
      if(op==='cancel'&&preview?.id===request.id&&preview.scope===who.scope&&preview.session===session&&preview.contextId===contextId){
        clearPreview();return true;
      }
      throw Error('이미 종료된 드라이브 작업입니다.');
    }
    if(op==='preview-chunk'){
      const offset=request.offset;
      if(!preview||preview.session!==session||preview.contextId!==contextId||preview.scope!==who.scope||
        request.id!==preview.id||!Number.isSafeInteger(offset)||offset<0||offset>preview.bytes.length)throw Error('미리보기를 다시 열어 주세요.');
      const base64=preview.bytes.subarray(offset,offset+chunkSize).toString('base64');
      const done=offset+chunkSize>=preview.bytes.length;
      if(done)clearPreview();
      return {base64,done};
    }
    if(op==='preview')return preparePreview(session,contextId,who,request,signal);
    if(op==='upload'||op==='download')return begin(session,contextId,who,request,op);
    if(['create-folder','rename','move','trash'].includes(op))return editEntry(session,contextId,who,request,op,signal);
    if(!['drives','files','share'].includes(op))throw Error('지원하지 않는 드라이브 작업입니다.');
    if(op==='files'&&request.type!==undefined&&!['folder','file'].includes(request.type)){
      throw Error('파일 목록 필터를 다시 선택해 주세요.');
    }
    if(op==='share'&&request.create===true){
      if(request.confirmed!==true||typeof request.scope!=='string'||typeof request.expiredAt!=='string'){
        throw Error('공유 범위와 만료 일시를 확인해 주세요.');
      }
      const target=coordinates(request,true);
      const options=normalizeDriveShareOptions({scope:request.scope,expiredAt:request.expiredAt});
      return runWrite(session,contextId,who,signal,(token,operationSignal)=>
        who.api.share(token,{...target,...options,create:true,signal:operationSignal})
      );
    }
    const token=await validToken(who,signal);
    if((await getScope(session,contextId,signal)).scope!==who.scope)throw Error('두레이 계정이 변경되었습니다.');
    const page=Number.isSafeInteger(request.page)&&request.page>=0&&request.page<10_000?request.page:0;
    if(op==='drives')return who.api.drives(token,{page,signal});
    if(op==='files')return who.api.files(token,{...coordinates(request),page,...(request.type===undefined?{}:{type:request.type}),signal});
    const result=await who.api.sharedLinks(token,{...coordinates(request,true),signal});
    signal.throwIfAborted();
    if((await getScope(session,contextId,signal)).scope!==who.scope)throw Error('두레이 계정이 변경되었습니다.');
    return result;
  }
  return {command,invalidate,dispose(){
    disposed=true;
    clearPreview();
    preparingPreview?.controller.abort();
    editing?.controller.abort();
    completed.clear();
    checks.clear();
    credentials.dispose?.();
  }};
}

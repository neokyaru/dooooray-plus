﻿# This script accepts only a nonsecret request on stdin. Configure never returns
# a token; get returns it exclusively through the owned stdout pipe. No logging.
$ErrorActionPreference = 'Stop'

function Test-DriveCredentialKeys($Value, [string[]]$Keys) {
    if ($null -eq $Value -or $Value -is [array] -or $Value -is [string]) { return $false }
    return ((@($Value.PSObject.Properties.Name | Sort-Object) -join ',') -ceq (@($Keys | Sort-Object) -join ','))
}
function Get-DriveCredentialScope([string]$Scope) {
    if ($Scope.Length -gt 320 -or $Scope -cnotmatch '^https://([A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.(?:dooray|gov-dooray)\.com)\|([0-9]{1,64})$') { throw 'invalid-scope' }
    return ('https://' + $Matches[1].ToLowerInvariant() + '|' + $Matches[2])
}
function Get-DriveCredentialHash([string]$Scope) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Scope)))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
}
function Get-DriveCredentialEntropy([string]$Scope) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ,$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('DoorayPlus.DriveCredentials.v1|' + $Scope)) } finally { $sha.Dispose() }
}
function Test-DriveCredentialToken($Token) {
    return ($Token -is [string] -and $Token.Length -ge 1 -and $Token.Length -le 4096 -and $Token -cmatch '^[\x21-\x7e]+$')
}
function Assert-DriveCredentialPath([string]$Path, [bool]$AllowMissing = $false) {
    if ($Path -cnotmatch '^[A-Za-z]:\\' -or $Path.Substring(2).Contains(':') -or $Path.Contains('/') -or $Path.Contains([char]0)) { throw 'invalid-path' }
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if (-not [string]::Equals($full, $Path.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-path' }
    $current = $full
    while ($current) {
        try {
            $attrs = [IO.File]::GetAttributes($current)
            if (($attrs -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'linked-path' }
        } catch [IO.FileNotFoundException] { if (-not $AllowMissing) { throw } } catch [IO.DirectoryNotFoundException] { if (-not $AllowMissing) { throw } }
        $parent = [IO.Path]::GetDirectoryName($current)
        if (-not $parent -or $parent -eq $current) { break }
        $current = $parent
    }
    return $full
}
function Get-DriveCredentialLocation([string]$Root, [string]$Scope) {
    $expected = [IO.Path]::Combine([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData), 'DoorayTheme')
    if (-not [string]::Equals($expected, $Root, [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-root' }
    $null = Assert-DriveCredentialPath $Root $true
    return [IO.Path]::Combine([IO.Path]::Combine($Root, 'drive-credentials'), ((Get-DriveCredentialHash $Scope) + '.json'))
}
function Read-DriveCredentialRecord([string]$File, [string]$Scope) {
    $null = Assert-DriveCredentialPath $File $true
    if (-not [IO.File]::Exists($File)) { return $null }
    $info = New-Object IO.FileInfo($File)
    if ($info.Length -lt 1 -or $info.Length -gt 65536) { throw 'invalid-record' }
    $stream = [IO.File]::Open($File, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        if ($stream.Length -ne $info.Length) { throw 'changed-record' }
        $bytes = New-Object byte[] ([int]$stream.Length)
        $offset = 0
        while ($offset -lt $bytes.Length) { $n = $stream.Read($bytes, $offset, $bytes.Length - $offset); if ($n -lt 1) { throw 'short-record' }; $offset += $n }
        $record = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
    } finally { $stream.Dispose() }
    $null = Assert-DriveCredentialPath $File
    if (-not (Test-DriveCredentialKeys $record @('schema','scopeHash','protected')) -or $record.schema -ne 1 -or $record.scopeHash -cne (Get-DriveCredentialHash $Scope) -or $record.protected -isnot [string] -or $record.protected.Length -lt 16 -or $record.protected.Length -gt 49152 -or $record.protected -cnotmatch '^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$') { throw 'invalid-record' }
    return $record
}
function Protect-DriveCredentialToken([string]$Scope, [string]$Token) {
    if (-not (Test-DriveCredentialToken $Token)) { throw 'invalid-token' }
    $plain = $null; $entropy = $null; $cipher = $null
    try {
        $plain = [Text.Encoding]::UTF8.GetBytes(([ordered]@{schema=1;scope=$Scope;token=$Token} | ConvertTo-Json -Compress))
        $entropy = Get-DriveCredentialEntropy $Scope
        $cipher = [Security.Cryptography.ProtectedData]::Protect($plain, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        return [ordered]@{schema=1;scopeHash=(Get-DriveCredentialHash $Scope);protected=[Convert]::ToBase64String($cipher)}
    } finally {
        if ($plain) { [Array]::Clear($plain,0,$plain.Length) }; if ($entropy) { [Array]::Clear($entropy,0,$entropy.Length) }; if ($cipher) { [Array]::Clear($cipher,0,$cipher.Length) }
        $Token = $null
    }
}
function Unprotect-DriveCredentialToken([string]$Scope, $Record) {
    $plain = $null; $entropy = $null; $cipher = $null; $inside = $null
    try {
        $entropy = Get-DriveCredentialEntropy $Scope
        $cipher = [Convert]::FromBase64String($Record.protected)
        $plain = [Security.Cryptography.ProtectedData]::Unprotect($cipher, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        if ($plain.Length -gt 16384) { throw 'invalid-plaintext' }
        $inside = [Text.Encoding]::UTF8.GetString($plain) | ConvertFrom-Json
        if (-not (Test-DriveCredentialKeys $inside @('schema','scope','token')) -or $inside.schema -ne 1 -or $inside.scope -cne $Scope -or -not (Test-DriveCredentialToken $inside.token)) { throw 'invalid-plaintext' }
        return $inside.token
    } finally {
        if ($plain) { [Array]::Clear($plain,0,$plain.Length) }; if ($entropy) { [Array]::Clear($entropy,0,$entropy.Length) }; if ($cipher) { [Array]::Clear($cipher,0,$cipher.Length) }
        if ($inside) { $inside.token = $null }; $inside = $null
    }
}
function Write-DriveCredentialRecord([string]$File, $Record) {
    $null = Assert-DriveCredentialPath $File $true
    $directory = [IO.Path]::GetDirectoryName($File)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $null = Assert-DriveCredentialPath $directory
    $temporary = [IO.Path]::Combine($directory, ([IO.Path]::GetFileNameWithoutExtension($File) + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'))
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Record | ConvertTo-Json -Compress))
    if ($bytes.Length -gt 65536) { throw 'oversized-record' }
    try {
        $stream = [IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        $null = Assert-DriveCredentialPath $File $true
        $null = Assert-DriveCredentialPath $temporary
        if ([IO.File]::Exists($File)) { [IO.File]::Replace($temporary,$File,[NullString]::Value) } else { [IO.File]::Move($temporary,$File) }
    } finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
}
function Initialize-DriveCredentialNative {
    Add-Type -AssemblyName System.Security
    if (-not ('DoorayDriveCredentialParent' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Threading;
public sealed class DoorayDriveCredentialParent {
    private volatile bool gone;
    public bool Gone { get { return gone; } }
    public DoorayDriveCredentialParent(TextReader input) {
        Thread thread = new Thread(delegate() { try { input.ReadLine(); } catch {} finally { gone = true; } });
        thread.IsBackground = true;
        thread.Start();
    }
}
'@
    }
}
function Assert-DriveCredentialUser {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if ($identity.User.Value -notmatch '^S-1-5-21-[0-9-]+$' -or (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or [Diagnostics.Process]::GetCurrentProcess().SessionId -le 0) { throw 'invalid-user' }
    } finally { $identity.Dispose() }
}
function Get-DriveCredentialWindowOwner {
    try {
        if (-not ('DoorayWindowFocus' -as [type])) {
            $focus = [IO.Path]::Combine([IO.Path]::GetDirectoryName($env:DOORAY_PLUS_DRIVE_SCRIPT), 'window-focus.ps1')
            . ([ScriptBlock]::Create([IO.File]::ReadAllText($focus,[Text.Encoding]::UTF8)))
        }
        $handle = [DoorayWindowFocus]::Owner()
        if ($handle -ne [IntPtr]::Zero) { return (New-Object DoorayWindowOwner -ArgumentList $handle) }
    } catch { }
    return $null
}
function Set-DriveCredentialWindowForeground($Form) {
    try {
        if ('DoorayWindowFocus' -as [type]) { [DoorayWindowFocus]::Activate($Form.Handle) }
        else { $Form.Activate() }
    } catch { }
}
function Show-DriveCredentialWindow($Form, $Owner) {
    if ($null -ne $Owner) { return $Form.ShowDialog($Owner) }
    return $Form.ShowDialog()
}
function Show-DriveCredentialDialog([string]$Scope, [string]$File, $ParentWatch) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form = New-Object Windows.Forms.Form
    $form.Text = '두레이 플러스 · 드라이브 인증'
    $form.ClientSize = New-Object Drawing.Size(440,224)
    $form.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
    $form.MaximizeBox = $false; $form.MinimizeBox = $false
    $owner = Get-DriveCredentialWindowOwner
    $form.StartPosition = if ($null -ne $owner) { [Windows.Forms.FormStartPosition]::CenterParent } else { [Windows.Forms.FormStartPosition]::CenterScreen }
    $form.Font = New-Object Drawing.Font('맑은 고딕',9)
    $label = New-Object Windows.Forms.Label
    $label.Text = "두레이 개인 API 키를 입력하세요.`r`n이 Windows 사용자 계정으로 암호화하여 저장합니다."
    $label.Location = New-Object Drawing.Point(18,16); $label.Size = New-Object Drawing.Size(404,42)
    $account = New-Object Windows.Forms.Label
    $account.Text = $Scope.Replace('|', '  ·  계정 ')
    $account.Location = New-Object Drawing.Point(18,62); $account.Size = New-Object Drawing.Size(404,22)
    # $input is a PowerShell automatic variable and is replaced when a callback
    # runs; it must never be used for this control.
    $tokenBox = New-Object Windows.Forms.TextBox
    $tokenBox.UseSystemPasswordChar = $true; $tokenBox.MaxLength = 4096
    $tokenBox.Location = New-Object Drawing.Point(18,91); $tokenBox.Size = New-Object Drawing.Size(404,26)
    $status = New-Object Windows.Forms.Label
    $status.ForeColor = [Drawing.Color]::Firebrick
    $status.Location = New-Object Drawing.Point(18,128); $status.Size = New-Object Drawing.Size(404,32)
    $save = New-Object Windows.Forms.Button
    $save.Text = '저장'; $save.Location = New-Object Drawing.Point(246,177); $save.Size = New-Object Drawing.Size(84,30)
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = '취소'; $cancel.Location = New-Object Drawing.Point(338,177); $cancel.Size = New-Object Drawing.Size(84,30)
    $cancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    $form.AcceptButton = $save; $form.CancelButton = $cancel
    $form.Controls.AddRange(@($label,$account,$tokenBox,$status,$save,$cancel))
    $state = @{saved=$false}
    $timer = New-Object Windows.Forms.Timer; $timer.Interval=250
    $watch = [Diagnostics.Stopwatch]::StartNew()
    # ShowDialog is synchronous. Retain this script/function scope while its
    # handlers run: GetNewClosure creates a module that loses script-local
    # validation/protection functions under the actual encoded entry wrapper.
    $shown = { Set-DriveCredentialWindowForeground $form; $null=$tokenBox.Focus() }
    $tick = { if ($ParentWatch.Gone -or $watch.Elapsed.TotalSeconds -ge 180) { $form.DialogResult=[Windows.Forms.DialogResult]::Cancel; $form.Close() } }
    $click = {
        if ($ParentWatch.Gone) { $form.Close(); return }
        $token = $tokenBox.Text.Trim()
        if (-not (Test-DriveCredentialToken $token)) { $status.Text='공백이나 줄바꿈이 없는 개인 API 키를 입력해 주세요.'; $token=$null; return }
        try {
            $record = Protect-DriveCredentialToken $Scope $token
            if ($ParentWatch.Gone) { $form.Close(); return }
            Write-DriveCredentialRecord $File $record
            $state.saved=$true; $tokenBox.Clear(); $form.DialogResult=[Windows.Forms.DialogResult]::OK; $form.Close()
        } catch { $status.Text='개인 API 키를 저장하지 못했습니다. 다시 시도해 주세요.' }
        finally { $token=$null; $record=$null }
    }
    $form.Add_Shown($shown); $save.Add_Click($click); $timer.Add_Tick($tick)
    try { $timer.Start(); $null=Show-DriveCredentialWindow $form $owner; return [bool]$state.saved }
    finally { $timer.Stop(); $timer.Remove_Tick($tick); $form.Remove_Shown($shown); $save.Remove_Click($click); $tokenBox.Clear(); $timer.Dispose(); $form.Dispose(); $watch.Stop() }
}
function Invoke-DriveCredentialMain {
    $reply = $null; $request = $null; $scopeHash=''; $op=''; $token=$null
    try {
        [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
        $line = [Console]::In.ReadLine()
        if (-not $line -or $line.Length -gt 4096) { throw 'invalid-request' }
        $request = $line | ConvertFrom-Json
        if (-not (Test-DriveCredentialKeys $request @('schema','op','scope','root')) -or $request.schema -ne 1 -or $request.op -cnotin @('configure','get','forget') -or $request.scope -isnot [string] -or $request.root -isnot [string]) { throw 'invalid-request' }
        $op=$request.op; $scope=Get-DriveCredentialScope $request.scope
        if ($scope -cne $request.scope) { throw 'invalid-scope' }
        $scopeHash=Get-DriveCredentialHash $scope
        Assert-DriveCredentialUser
        $file=Get-DriveCredentialLocation $request.root $scope
        Initialize-DriveCredentialNative
        $parentWatch=New-Object DoorayDriveCredentialParent([Console]::In)
        if ($parentWatch.Gone) { throw 'cancelled' }
        $reply=[ordered]@{schema=1;op=$op;scopeHash=$scopeHash;ok=$true;configured=$false}
        if ($op -ceq 'configure') {
            $saved=Show-DriveCredentialDialog $scope $file $parentWatch
            $reply.configured=($null -ne (Read-DriveCredentialRecord $file $scope))
            $reply.cancelled=(-not $saved)
        } elseif ($op -ceq 'get') {
            $record=Read-DriveCredentialRecord $file $scope
            $reply.token=$null
            if ($record) { $token=Unprotect-DriveCredentialToken $scope $record; $reply.token=$token; $reply.configured=$true }
        } else {
            $null=Assert-DriveCredentialPath $file $true
            if ($parentWatch.Gone) { throw 'cancelled' }
            if ([IO.File]::Exists($file)) { [IO.File]::Delete($file) }
        }
        if ($parentWatch.Gone) { throw 'cancelled' }
        [Console]::Out.Write(($reply | ConvertTo-Json -Compress -Depth 4))
    } catch { [Console]::Out.Write((@{schema=1;op=$op;scopeHash=$scopeHash;ok=$false;code='credential-operation-failed'} | ConvertTo-Json -Compress)) }
    finally { if ($reply -and $reply.Contains('token')) { $reply.token=$null }; $token=$null; $request=$null; $line=$null }
}
if ($MyInvocation.InvocationName -ne '.') { Invoke-DriveCredentialMain }

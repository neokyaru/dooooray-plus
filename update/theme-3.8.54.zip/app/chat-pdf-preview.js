// Chat attachments use the current Messenger session; Drive credentials are not involved.
function createChatPdfViewer(doc = document) {
  const win = doc.defaultView, maxBytes = 24 * 1024 * 1024;
  let active = null, disposed = false, serial = 0;
  const quietly = action => { try { Promise.resolve(action()).catch(() => {}); } catch {} };

  function validURL(value) {
    if (typeof value !== 'string' || value.length > 512 || /[\s\\\x00-\x1f\x7f]/.test(value)) throw Error('첨부파일 주소를 확인하지 못했습니다.');
    const origin = win.location.origin, parsed = new win.URL(value, origin + '/');
    if (!/^https?:$/.test(parsed.protocol) || origin === 'null' || parsed.origin !== origin || parsed.username || parsed.password || parsed.search || parsed.hash ||
        !/^\/messenger\/v2\/api\/channel\/\d{1,64}\/file\/\d{1,64}$/.test(parsed.pathname) ||
        (value !== parsed.pathname && value !== origin + parsed.pathname)) throw Error('첨부파일 주소를 확인하지 못했습니다.');
    return {url: parsed.href, origin};
  }
  function current(attempt) {
    return !disposed && active === attempt && attempt.serial === serial && (!attempt.controller.signal.aborted || attempt.loaded === true) &&
      win.location.origin === attempt.origin && (!attempt.opener || (attempt.opener.ownerDocument === doc && attempt.opener.isConnected));
  }
  function release(attempt, restoreFocus) {
    if (!attempt) return;
    win.clearTimeout(attempt.timer);
    attempt.controller.abort();
    if (attempt.reader) quietly(() => attempt.reader.cancel());
    attempt.frame?.removeAttribute('src');
    attempt.dialog.remove();
    if (attempt.blobURL) quietly(() => win.URL.revokeObjectURL(attempt.blobURL));
    attempt.blobURL = null;
    if (restoreFocus && attempt.opener?.isConnected) quietly(() => attempt.opener.focus({preventScroll: true}));
  }
  function close() { const old = active; active = null; serial++; release(old, true); }
  function closeIfOpenedFrom(opener) { if (active?.opener === opener) close(); }

  function createDialog(name) {
    const dialog = doc.createElement('dialog');
    dialog.setAttribute('data-dp-extension', 'chat-pdf');
    dialog.setAttribute('aria-label', name + ' PDF 미리보기');
    dialog.setAttribute('aria-modal', 'true');
    // The dialog is a native modal; its shadow tree keeps unrelated theme rules away.
    dialog.style.cssText = 'padding:0!important;border:1px solid var(--dt-border,#697586)!important;border-radius:12px!important;width:min(1120px,94vw)!important;max-width:94vw!important;height:min(900px,92vh)!important;max-height:92vh!important;overflow:hidden!important;background:var(--dt-bg,#fff)!important;color:var(--dt-text,#202733)!important;box-shadow:0 18px 70px #0007!important;';
    const container = doc.createElement('div'); container.setAttribute('data-pdf-content', ''); container.style.cssText = 'height:100%;width:100%;';
    dialog.append(container);
    const shadow = container.attachShadow({mode: 'open'});
    shadow.innerHTML = `<style>
      :host{font:14px/1.5 'Malgun Gothic',sans-serif}*{box-sizing:border-box}[hidden]{display:none!important}
      .shell{display:flex;flex-direction:column;width:100%;height:100%;min-height:0;background:var(--dt-bg,#fff);color:var(--dt-text,#202733)}
      header{display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--dt-border,#d0d6df);background:var(--dt-surface,#f4f6f9);flex:none}
      strong{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:14px}
      button{flex:none;border:1px solid var(--dt-border,#c3cad4);border-radius:7px;padding:7px 12px;color:inherit;background:var(--dt-bg,#fff);font:inherit;cursor:pointer}
      button:hover{background:var(--dt-hover,#e9eef5)}button:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:2px}
      .content{position:relative;display:flex;flex:1;min-height:0;flex-direction:column}
      p{margin:0;padding:16px;overflow-wrap:anywhere;color:var(--dt-muted,#64748b)}
      p[data-error]{color:var(--dt-text,#202733)}iframe{display:block;border:0;width:100%;height:100%;flex:1;min-height:0;background:#525659}
      footer{padding:8px 16px;flex:none;border-top:1px solid var(--dt-border,#d0d6df);font-size:12px;color:var(--dt-muted,#64748b)}
    </style><section class="shell"><header><strong data-pdf-title></strong><button type="button" data-pdf-close aria-label="PDF 미리보기 닫기">닫기 ×</button></header><div class="content"><p data-pdf-status role="status" aria-live="polite">PDF를 불러오는 중…</p></div><footer>페이지 이동·확대는 PDF 도구 모음을 이용하세요. 표시되지 않으면 창을 닫고 기존 다운로드 버튼을 이용해 주세요.</footer></section>`;
    shadow.querySelector('[data-pdf-title]').textContent = name;
    return {dialog, shadow, status: shadow.querySelector('[data-pdf-status]'), content: shadow.querySelector('.content'), closeButton: shadow.querySelector('[data-pdf-close]')};
  }
  // Abort must also release the pending caller when a delayed transport ignores its signal.
  function wait(attempt, promise) {
    return new Promise((resolve, reject) => {
      const signal = attempt.controller.signal;
      const abort = () => reject(Error('미리보기가 취소되었습니다.'));
      if (signal.aborted) { Promise.resolve(promise).catch(() => {}); abort(); return; }
      signal.addEventListener('abort', abort, {once: true});
      Promise.resolve(promise).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
    });
  }
  async function open({url, name, opener} = {}) {
    if (disposed || !win || !doc.body) return false;
    const old = active; active = null; serial++; release(old, false);
    const title = typeof name === 'string' && name.trim() ? name.replace(/[\x00-\x1f\x7f]/g, '').slice(0, 512) : 'PDF 첨부파일';
    const view = createDialog(title), controller = new win.AbortController();
    const attempt = {...view, controller, serial, origin: win.location.origin, opener, reader: null, blobURL: null, timer: null, timedOut: false, abortStream: null};
    active = attempt;
    view.closeButton.onclick = () => { if (active === attempt) close(); };
    view.dialog.addEventListener('cancel', event => { event.preventDefault(); if (active === attempt) close(); });
    view.dialog.addEventListener('close', () => { if (active === attempt) close(); });
    // Escape still works when focus is in the host/shadow controls. Native dialog handles its own cancel as well.
    view.dialog.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); if (active === attempt) close(); } });
    doc.body.append(view.dialog);
    try {
      if (typeof view.dialog.showModal !== 'function') throw Error('이 환경에서는 PDF 미리보기 창을 지원하지 않습니다.');
      view.dialog.showModal();
      view.closeButton.focus({preventScroll: true});
      const safe = validURL(url); attempt.origin = safe.origin;
      if (!current(attempt)) { if (active === attempt) close(); return false; }
      if (typeof win.fetch !== 'function' || typeof win.URL.createObjectURL !== 'function' || typeof win.ReadableStream !== 'function' || typeof win.Response !== 'function') throw Error('이 환경에서는 PDF 미리보기를 지원하지 않습니다.');
      attempt.timer = win.setTimeout(() => { if (active === attempt) { attempt.timedOut = true; controller.abort(); if (attempt.reader) quietly(() => attempt.reader.cancel()); } }, 45_000);
      const response = await wait(attempt, win.fetch(safe.url, {credentials: 'same-origin', mode: 'same-origin', redirect: 'error', cache: 'no-store', signal: controller.signal}).then(result => {
        if (!current(attempt)) quietly(() => result.body?.cancel());
        return result;
      }));
      if (!current(attempt)) return false;
      if (!response.ok) throw Error(response.status === 401 || response.status === 403 ? '파일을 열 권한이 없거나 로그인이 만료되었습니다.' : '첨부파일을 불러오지 못했습니다. 파일 만료 여부를 확인해 주세요.');
      if (response.redirected || response.type === 'opaque' || (response.url && response.url !== safe.url)) throw Error('첨부파일 응답 주소를 확인하지 못했습니다.');
      const mime = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
      if (!['application/pdf', 'application/octet-stream'].includes(mime)) throw Error('PDF 형식의 응답이 아닙니다.');
      const declared = response.headers.get('content-length');
      if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) < 5 || Number(declared) > maxBytes)) throw Error('PDF 미리보기는 24MB까지 지원합니다.');
      if (!response.body || typeof response.body.getReader !== 'function') throw Error('이 환경에서는 PDF를 안전하게 불러올 수 없습니다.');
      attempt.reader = response.body.getReader();
      const signature = new Uint8Array(5), now = () => win.performance.now();
      let total = 0, reads = 0, lastProgress = now();
      // Let the browser build its Blob directly. Retain only the signature and
      // current source chunk in JavaScript, with no whole-file array or manual copy.
      const checked = new win.ReadableStream({
        start(output) {
          attempt.abortStream = () => {
            quietly(() => output.error(Error('미리보기가 취소되었습니다.')));
            if (attempt.reader) quietly(() => attempt.reader.cancel());
          };
          controller.signal.addEventListener('abort', attempt.abortStream, {once: true});
          if (controller.signal.aborted) attempt.abortStream();
        },
        async pull(output) {
          try {
            if (!current(attempt)) throw Error('미리보기가 취소되었습니다.');
            if (++reads > 100_000) throw Error('PDF 응답을 안전하게 읽을 수 없습니다.');
            const part = await wait(attempt, attempt.reader.read());
            if (!current(attempt)) throw Error('미리보기가 취소되었습니다.');
            if (part.done) {
              if (total < 5) throw Error('PDF 파일이 비어 있거나 완전히 도착하지 않았습니다.');
              output.close(); return;
            }
            const value = part.value;
            if (!value || Object.prototype.toString.call(value) !== '[object Uint8Array]') throw Error('PDF 데이터를 확인하지 못했습니다.');
            if (total + value.byteLength > maxBytes) throw Error('PDF 미리보기는 24MB까지 지원합니다.');
            for (let i = 0; i < value.byteLength && total + i < 5; i++) signature[total + i] = value[i];
            total += value.byteLength;
            if (total >= 5 && String.fromCharCode(...signature) !== '%PDF-') throw Error('올바른 PDF 파일이 아닙니다.');
            output.enqueue(value);
            const time = now();
            if (time - lastProgress >= 250) {
              lastProgress = time;
              const label = 'PDF를 불러오는 중… ' + (total / (1024 * 1024)).toFixed(1) + 'MB / 최대 24MB';
              if (view.status.textContent !== label) view.status.textContent = label;
            }
          } catch (error) {
            quietly(() => output.error(error));
            if (attempt.reader) quietly(() => attempt.reader.cancel());
          }
        },
        cancel() { if (attempt.reader) quietly(() => attempt.reader.cancel()); }
      }, {highWaterMark: 0});
      const blob = await wait(attempt, new win.Response(checked, {headers: {'Content-Type': 'application/pdf'}}).blob());
      if (!current(attempt)) return false;
      if (blob.type !== 'application/pdf' || blob.size !== total || blob.size < 5 || blob.size > maxBytes) throw Error('PDF 데이터를 확인하지 못했습니다.');
      attempt.blobURL = win.URL.createObjectURL(blob);
      if (!current(attempt)) { release(attempt, false); return false; }
      const frame = doc.createElement('iframe');
      frame.setAttribute('data-pdf-frame', ''); frame.title = title + ' PDF 미리보기'; frame.referrerPolicy = 'no-referrer';
      // Chromium's native PDF viewer is blocked by iframe sandbox. This frame accepts ONLY our validated, fixed-MIME Blob, never remote URLs or HTML.
      frame.src = attempt.blobURL; attempt.frame = frame;
      frame.addEventListener('error', () => { if (current(attempt)) { view.status.hidden = false; view.status.textContent = 'PDF를 표시하지 못했습니다. 창을 닫고 기존 다운로드 버튼을 이용해 주세요.'; } });
      view.status.hidden = true; view.content.append(frame); attempt.loaded = true;
      return true;
    } catch (error) {
      if (active === attempt && !disposed) {
        view.status.hidden = false; view.status.setAttribute('data-error', '');
        view.status.textContent = attempt.timedOut ? 'PDF를 불러오는 시간이 초과되었습니다. 기존 다운로드 버튼을 이용해 주세요.' :
          controller.signal.aborted ? 'PDF 미리보기가 취소되었습니다.' :
          (error instanceof Error && /^(첨부파일|파일을|이 환경에서는|PDF|올바른 PDF)/.test(error.message) ? error.message : 'PDF를 불러오지 못했습니다. 기존 다운로드 버튼을 이용해 주세요.');
      }
      return false;
    } finally {
      win.clearTimeout(attempt.timer);
      if (attempt.abortStream) controller.signal.removeEventListener('abort', attempt.abortStream);
      attempt.abortStream = null;
      if (attempt.reader) { quietly(() => attempt.reader.cancel()); quietly(() => attempt.reader.releaseLock()); attempt.reader = null; }
      controller.abort();
    }
  }
  const pageHidden = () => close();
  win?.addEventListener('pagehide', pageHidden);
  return {open, close, closeIfOpenedFrom, dispose() { if (disposed) return; disposed = true; close(); win?.removeEventListener('pagehide', pageHidden); }};
}

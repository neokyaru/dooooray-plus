// Official API references (checked 2026-11-18):
// https://helpdesk.dooray.com/share/pages/9wWo-xwiR66BO5LGshgVTg/2939987647631384419
// https://helpdesk.dooray.com/share/pages/9wWo-xwiR66BO5LGshgVTg/2939993203869661812
// https://helpdesk.dooray.com/share/pages/9wWo-xwiR66BO5LGshgVTg/3817617091196252578
// Credentials stay in the native helper. No browser cookies, automatic redirects,
// upload retries or arbitrary URLs are accepted by this client.
import {randomBytes} from 'node:crypto';

const ORIGINS = new Set(['https://api.dooray.com', 'https://api.gov-dooray.com', 'https://api.gov-dooray.co.kr', 'https://api.dooray.co.kr']);
const MAX_JSON = 2 * 1024 * 1024, PAGE_SIZE = 50, MAX_ITEMS = 2000;
const SCOPES = new Set(['member', 'memberAndGuest', 'memberAndGuestAndExternal']);
const ERRORS = {
  INVALID_INPUT: '드라이브 요청 정보가 올바르지 않습니다.',
  AUTH: 'API 인증 키를 확인해 주세요.',
  FORBIDDEN: '이 드라이브 작업에 대한 권한이 없습니다.',
  NOT_FOUND: '드라이브 항목을 찾을 수 없습니다.',
  CONFLICT: '같은 이름의 파일이 있거나 항목 상태가 변경되었습니다.',
  RATE_LIMIT: '드라이브 요청이 많습니다. 잠시 후 다시 시도해 주세요.',
  CANCELLED: '드라이브 작업이 취소되었거나 시간이 초과되었습니다.',
  NETWORK: '드라이브 서버에 연결하지 못했습니다.',
  API_ERROR: '드라이브 요청을 처리하지 못했습니다.',
  INVALID_RESPONSE: '드라이브 서버 응답을 확인하지 못했습니다.',
  UNSAFE_REDIRECT: '확인되지 않은 파일 서버로 연결하지 않았습니다.',
  UNSUPPORTED_MEDIA: '이 환경의 파일 전송 주소는 아직 지원하지 않습니다.',
  ROOT_NOT_FOUND: '대상 최상위 폴더를 확인하지 못했습니다.',
  UPLOAD_SIZE: '선택한 파일 크기가 전송 내용과 일치하지 않습니다.',
  UPLOAD_UNCERTAIN: '업로드 결과를 확인하지 못했습니다. 다시 올리기 전에 파일 목록을 확인해 주세요.',
  SHARE_SETTINGS_REJECTED: '공유 범위나 만료일이 허용되지 않았습니다. 설정과 조직 정책을 확인해 주세요.',
  SHARE_UNCERTAIN: '공유 링크 생성 결과를 확인하지 못했습니다. 기존 링크를 다시 확인해 주세요.'
};
export class DriveApiError extends Error {
  constructor(code, status) { super(ERRORS[code] || ERRORS.API_ERROR); this.name = 'DriveApiError'; this.code = code; if (Number.isInteger(status)) this.status = status; }
}
const fail = (code, status) => { throw new DriveApiError(code, status); };
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const id = value => { if (typeof value !== 'string' || !/^[1-9]\d{0,39}$/.test(value)) fail('INVALID_INPUT'); return value; };
const responseId = value => { try { return id(value); } catch { fail('INVALID_RESPONSE'); } };
const text = (value, limit = 1024) => { if (typeof value !== 'string' || value.length > limit || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/u.test(value)) fail('INVALID_RESPONSE'); return value; };
const checkAbort = signal => { if (signal?.aborted) fail('CANCELLED'); };
const abortError = (error, signal) => signal?.aborted || error?.name === 'AbortError' || error?.name === 'TimeoutError';
const headerToken = token => { if (typeof token !== 'string' || token.length < 1 || token.length > 4096 || !/^[\x21-\x7e]+$/.test(token)) fail('INVALID_INPUT'); return 'dooray-api ' + token; };
const statusError = status => fail(({401:'AUTH',403:'FORBIDDEN',404:'NOT_FOUND',409:'CONFLICT',429:'RATE_LIMIT'})[status] || 'API_ERROR', status);
const cancelBody = response => { try { Promise.resolve(response?.body?.cancel()).catch(() => {}); } catch {} };
const integer = (value, max) => { if (!Number.isSafeInteger(value) || value < 0 || value > max) fail('INVALID_INPUT'); return value; };

// UI/service may share this input contract. Preserve valid names verbatim:
// JSON encoding handles quotes; no trimming or Unicode normalization is applied.
export function validateDriveItemName(value) {
  if (typeof value !== 'string' || !value.length || value.length > 255 || !value.trim() || value === '.' || value === '..' || /[\u0000-\u001f\u007f-\u009f/\\]/u.test(value) || /[\ud800-\udfff]/u.test(value)) fail('INVALID_INPUT');
  return value;
}

function shareExpiryTime(value) {
  if (typeof value !== 'string' || value.length > 64) fail('INVALID_INPUT');
  const match = /^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.\d{1,3})?(?:Z|([+-])(\d\d):(\d\d))$/.exec(value);
  if (!match) fail('INVALID_INPUT');
  const [year,month,day,hour,minute,second] = match.slice(1,7).map(Number);
  const days = [31,year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28,31,30,31,30,31,31,30,31,30,31];
  if (month < 1 || month > 12 || day < 1 || day > days[month - 1] || hour > 23 || minute > 59 || second > 59 || match[7] && (Number(match[8]) > 23 || Number(match[9]) > 59)) fail('INVALID_INPUT');
  const at = Date.parse(value); if (!Number.isFinite(at)) fail('INVALID_INPUT');
  return at;
}

// Public API supports these three scopes and a finite expiration only. The
// native website's password/allowlist controls have no documented API payload.
export function normalizeDriveShareOptions(options = {}, {now = Date.now()} = {}) {
  if (!record(options) || !Number.isFinite(now)) fail('INVALID_INPUT');
  const scope = options.scope === undefined ? 'member' : options.scope;
  if (!SCOPES.has(scope)) fail('INVALID_INPUT');
  const at = options.expiredAt === undefined ? now + 7 * 86400000 : shareExpiryTime(options.expiredAt);
  if (!Number.isFinite(at) || at <= now || at < 0 || at > 253402300799999) fail('INVALID_INPUT');
  return {scope, expiredAt:new Date(at).toISOString()};
}

// Waiting on a caller-owned stream/reader must also respond to cancellation.
async function abortable(promise, signal) {
  checkAbort(signal);
  if (!signal) return promise;
  let abort;
  try { return await Promise.race([promise, new Promise((_, reject) => { abort = () => reject(new DriveApiError('CANCELLED')); signal.addEventListener('abort', abort, {once:true}); if (signal.aborted) abort(); })]); }
  finally { signal.removeEventListener('abort', abort); }
}
async function jsonResponse(response, signal) {
  if (!response || typeof response.status !== 'number') fail('INVALID_RESPONSE');
  if (response.status < 200 || response.status >= 300) { cancelBody(response); statusError(response.status); }
  const length = response.headers.get('content-length');
  if (length !== null && (!/^\d+$/.test(length) || Number(length) > MAX_JSON)) { cancelBody(response); fail('INVALID_RESPONSE'); }
  const type = response.headers.get('content-type') || '';
  if (!/^application\/(?:[a-z0-9!#$&^_.+-]+\+)?json(?:\s*;|$)/i.test(type)) { cancelBody(response); fail('INVALID_RESPONSE'); }
  const reader = response.body?.getReader(); if (!reader) fail('INVALID_RESPONSE');
  // One bounded buffer also bounds bookkeeping for arbitrarily small chunks.
  const bytes = Buffer.allocUnsafe(MAX_JSON); let size = 0, complete = false;
  try {
    for (;;) {
      const chunk = await abortable(reader.read(), signal);
      if (chunk.done) { complete = true; break; }
      if (!(chunk.value instanceof Uint8Array)) fail('INVALID_RESPONSE');
      if (size + chunk.value.byteLength > MAX_JSON) fail('INVALID_RESPONSE'); bytes.set(chunk.value, size); size += chunk.value.byteLength;
    }
    checkAbort(signal);
    let value; try { value = JSON.parse(new TextDecoder('utf-8', {fatal:true}).decode(bytes.subarray(0, size))); } catch { fail('INVALID_RESPONSE'); }
    if (!record(value) || !record(value.header) || typeof value.header.isSuccessful !== 'boolean') fail('INVALID_RESPONSE');
    if (!value.header.isSuccessful) fail('API_ERROR');
    return value;
  } catch (error) { if (error instanceof DriveApiError) throw error; fail(abortError(error, signal) ? 'CANCELLED' : 'INVALID_RESPONSE'); }
  finally { if (!complete) { try { Promise.resolve(reader.cancel()).catch(() => {}); } catch {} } try { reader.releaseLock(); } catch {} }
}
function fileInfo(raw) {
  if (!record(raw) || !['folder','file'].includes(raw.type)) fail('INVALID_RESPONSE');
  const value = {id:responseId(raw.id), name:text(raw.name), isFolder:raw.type === 'folder'};
  if (raw.size !== undefined && raw.size !== null) { if (!Number.isSafeInteger(raw.size) || raw.size < 0) fail('INVALID_RESPONSE'); value.size = raw.size; }
  if (raw.updatedAt !== undefined && raw.updatedAt !== null) { const stamp = text(raw.updatedAt, 64); if (!Number.isFinite(Date.parse(stamp))) fail('INVALID_RESPONSE'); value.modifiedAt = stamp; }
  if (raw.mimeType !== undefined && raw.mimeType !== null) value.mimeType = text(raw.mimeType, 256);
  return value;
}
function listInfo(envelope, transform, page = 0, size = PAGE_SIZE) {
  if (!Array.isArray(envelope.result) || envelope.result.length > MAX_ITEMS) fail('INVALID_RESPONSE');
  const items = envelope.result.map(transform); const unique = new Set(items.map(item => item.id)); if (unique.size !== items.length) fail('INVALID_RESPONSE');
  let hasNext = items.length >= size;
  if (envelope.totalCount !== undefined) {
    const total = typeof envelope.totalCount === 'string' && /^\d+$/.test(envelope.totalCount) ? Number(envelope.totalCount) : envelope.totalCount;
    if (!Number.isSafeInteger(total) || total < items.length || total < 0) fail('INVALID_RESPONSE');
    hasNext = (page + 1) * size < total;
  }
  return {items, hasNext};
}

export function createDriveApi({fetch: fetcher = globalThis.fetch, origin = 'https://api.dooray.com'} = {}) {
  if (typeof fetcher !== 'function' || !ORIGINS.has(origin)) fail('INVALID_INPUT');
  const baseDomain = new URL(origin).hostname.slice(4);
  const mediaOrigin = origin === 'https://api.dooray.com' ? 'https://file-api.dooray.com' : null;
  async function request(token, url, {signal, method = 'GET', headers = {}, body} = {}) {
    const auth = headerToken(token); checkAbort(signal);
    try {
      const response = await fetcher(url, {method, headers:{...headers, Authorization:auth}, signal, body, ...(body && typeof body !== 'string' ? {duplex:'half'} : {}), credentials:'omit', redirect:'manual', cache:'no-store'});
      if (signal?.aborted) { cancelBody(response); fail('CANCELLED'); }
      // A test adapter or a fetch implementation must not silently follow redirects.
      if (response?.redirected || response?.url && response.url !== url) { cancelBody(response); fail('UNSAFE_REDIRECT'); }
      return response;
    } catch (error) { if (error instanceof DriveApiError) throw error; fail(abortError(error, signal) ? 'CANCELLED' : 'NETWORK'); }
  }
  async function json(token, pathname, options = {}) {
    const response = await request(token, origin + pathname, options);
    if (response.status >= 300 && response.status < 400) { cancelBody(response); fail('UNSAFE_REDIRECT'); }
    return jsonResponse(response, options.signal);
  }
  const drivePath = driveId => '/drive/v1/drives/' + id(driveId) + '/files';
  const filePath = (driveId, fileId) => drivePath(driveId) + '/' + id(fileId);
  const parent = parentId => parentId === undefined || parentId === null || parentId === 'root' ? 'root' : id(parentId);
  async function resolveParent(token, driveId, parentId, signal) {
    const target = parent(parentId);
    if (target !== 'root') return target;
    // The documented literal root is for listing. Writes use the actual root ID.
    const roots = (await json(token, drivePath(driveId) + '?type=folder&subTypes=root', {signal})).result;
    if (!Array.isArray(roots) || roots.length > MAX_ITEMS) fail('INVALID_RESPONSE');
    const matches = roots.filter(raw => record(raw) && raw.type === 'folder' && raw.subType === 'root');
    if (matches.length !== 1) fail('ROOT_NOT_FOUND');
    if (matches[0].driveId !== undefined && matches[0].driveId !== driveId) fail('INVALID_RESPONSE');
    return responseId(matches[0].id);
  }
  function linkInfo(raw, created = false) {
    if (!record(raw) || !SCOPES.has(raw.scope)) fail('INVALID_RESPONSE');
    let url; try { url = new URL(raw.sharedLink); } catch { fail('INVALID_RESPONSE'); }
    if (typeof raw.sharedLink !== 'string' || raw.sharedLink.length > 4096 || /[\s\\\u0000-\u001f\u007f]/u.test(raw.sharedLink) || url.protocol !== 'https:' || url.port || url.username || url.password || url.hash || !(url.hostname === baseDomain || url.hostname.endsWith('.' + baseDomain))) fail('INVALID_RESPONSE');
    const value = {id:responseId(raw.id), url:url.href, scope:raw.scope, created};
    if (raw.expiredAt !== undefined && raw.expiredAt !== null) { const expires = text(raw.expiredAt, 64); if (!Number.isFinite(Date.parse(expires))) fail('INVALID_RESPONSE'); value.expiredAt = expires; }
    return value;
  }
  return Object.freeze({
    async identity(token, {signal} = {}) {
      const result = (await json(token, '/common/v1/members/me', {signal})).result;
      if (!record(result)) fail('INVALID_RESPONSE'); return {id:responseId(result.id), name:text(result.name || '', 256)};
    },
    async drives(token, {signal, type, scope} = {}) {
      if (type !== undefined && !['private','project'].includes(type) || scope !== undefined && (!['private','public'].includes(scope) || type !== 'project')) fail('INVALID_INPUT');
      const queries = type ? [type === 'private' ? 'type=private' : 'type=project&scope=' + (scope || 'private')] : ['type=private','type=project&scope=private','type=project&scope=public'];
      const items = new Map();
      for (const query of queries) {
        const envelope = await json(token, '/drive/v1/drives?' + query, {signal});
        const list = listInfo(envelope, raw => { if (!record(raw) || !['private','project'].includes(raw.type)) fail('INVALID_RESPONSE'); return {id:responseId(raw.id), name:raw.name === null ? (raw.type === 'private' ? '내 드라이브' : '프로젝트 드라이브') : text(raw.name, 512), rootId:'root'}; }, 0, MAX_ITEMS);
        if (list.hasNext) fail('INVALID_RESPONSE');
        for (const item of list.items) items.set(item.id, item);
        if (items.size > MAX_ITEMS) fail('INVALID_RESPONSE');
      }
      return {items:[...items.values()], hasNext:false};
    },
    async files(token, {driveId, parentId = 'root', page = 0, type, signal} = {}) {
      if (type !== undefined && !['folder','file'].includes(type)) fail('INVALID_INPUT');
      integer(page, 1000000);
      return listInfo(await json(token, drivePath(driveId) + '?parentId=' + parent(parentId) + '&page=' + page + '&size=' + PAGE_SIZE + (type === undefined ? '' : '&type=' + type), {signal}), fileInfo, page);
    },
    async metadata(token, {driveId, fileId, signal} = {}) {
      const result = (await json(token, filePath(driveId, fileId) + '?media=meta', {signal})).result;
      const value = fileInfo(result); if (value.id !== fileId || result.driveId !== undefined && result.driveId !== driveId) fail('INVALID_RESPONSE');
      if (value.isFolder && ['root','trash','users'].includes(result.subType)) value.subType = result.subType;
      return value;
    },
    async rootFolder(token, {driveId, signal} = {}) {
      return resolveParent(token, driveId, 'root', signal);
    },
    async createFolder(token, {driveId, parentId, name, signal} = {}) {
      const pathname = drivePath(driveId), folderName = validateDriveItemName(name);
      const target = await resolveParent(token, driveId, parentId, signal);
      const result = (await json(token, pathname + '/' + target + '/create-folder', {signal, method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name:folderName})})).result;
      if (!record(result)) fail('INVALID_RESPONSE');
      return {id:responseId(result.id)};
    },
    async rename(token, {driveId, fileId, name, signal} = {}) {
      const pathname = filePath(driveId, fileId), itemName = validateDriveItemName(name);
      const result = (await json(token, pathname + '?media=meta', {signal, method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name:itemName})})).result;
      if (result !== null) fail('INVALID_RESPONSE');
      return true;
    },
    async move(token, {driveId, fileId, destinationId, signal} = {}) {
      const pathname = filePath(driveId, fileId);
      // The service verifies source/destination metadata and account immediately
      // before this write. Never substitute copy+delete or another drive's route.
      const target = await resolveParent(token, driveId, destinationId, signal);
      if (target === fileId) fail('INVALID_INPUT');
      const result = (await json(token, pathname + '/move', {signal, method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({destinationFileId:target})})).result;
      if (result !== null) fail('INVALID_RESPONSE');
      return true;
    },
    async trash(token, {driveId, fileId, signal} = {}) {
      // An explicit trash operation, not DELETE (which permanently removes files).
      const result = (await json(token, filePath(driveId, fileId) + '/move', {signal, method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({destinationFileId:'trash'})})).result;
      if (result !== null) fail('INVALID_RESPONSE');
      return true;
    },
    async content(token, {driveId, fileId, signal} = {}) {
      if (!mediaOrigin) fail('UNSUPPORTED_MEDIA');
      const pathname = filePath(driveId, fileId) + '?media=raw';
      let response = await request(token, origin + pathname, {signal});
      if (response.status === 307) {
        const location = response.headers.get('location'); cancelBody(response);
        // The documented redirect is exact, not a wildcard credential destination.
        const expected = mediaOrigin + '/downloads' + pathname;
        if (location !== expected) fail('UNSAFE_REDIRECT');
        response = await request(token, expected, {signal});
      }
      if (response.status >= 300 && response.status < 400) { cancelBody(response); fail('UNSAFE_REDIRECT'); }
      if (response.status !== 200 || !response.body) { cancelBody(response); statusError(response.status); }
      return response;
    },
    async upload(token, {driveId, parentId = 'root', name, size, body, signal} = {}) {
      if (!mediaOrigin) fail('UNSUPPORTED_MEDIA');
      headerToken(token); checkAbort(signal);
      const pathname = drivePath(driveId); const requestedParent = parent(parentId);
      if (typeof name !== 'string' || !name.length || name.length > 255 || name === '.' || name === '..' || /[\u0000-\u001f\u007f-\u009f/\\]/u.test(name) || /[\ud800-\udfff]/u.test(name)) fail('INVALID_INPUT');
      integer(size, Number.MAX_SAFE_INTEGER - 8192);
      if (!body || typeof body[Symbol.asyncIterator] !== 'function' && typeof body.getReader !== 'function') fail('INVALID_INPUT');
      const target = await resolveParent(token, driveId, requestedParent, signal);
      const boundary = '----DoorayPlus' + randomBytes(24).toString('hex');
      // RFC7578 uses UTF-8 multipart filename; quotes are percent encoded, never headers.
      const prefix = Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="' + name.replace(/"/g, '%22') + '"\r\nContent-Type: application/octet-stream\r\n\r\n');
      const suffix = Buffer.from('\r\n--' + boundary + '--\r\n');
      let streamError = null, sent = false, streamedComplete = false;
      async function* multipart() {
        let iterator, reader, complete = false, count = 0;
        try {
          checkAbort(signal); yield prefix;
          if (typeof body[Symbol.asyncIterator] === 'function') iterator = body[Symbol.asyncIterator]();
          else { reader = body.getReader(); iterator = {next:() => reader.read(), return:() => reader.cancel()}; }
          for (;;) {
            const chunk = await abortable(iterator.next(), signal); checkAbort(signal);
            if (chunk.done) break;
            if (!(chunk.value instanceof Uint8Array)) fail('INVALID_INPUT');
            count += chunk.value.byteLength; if (count > size) fail('UPLOAD_SIZE');
            yield chunk.value;
          }
          if (count !== size) fail('UPLOAD_SIZE'); complete = true; streamedComplete = true; yield suffix;
        } catch (error) { streamError = error instanceof DriveApiError ? error : new DriveApiError(abortError(error, signal) ? 'CANCELLED' : 'UPLOAD_UNCERTAIN'); throw streamError; }
        finally { if (!complete) { try { Promise.resolve(iterator?.return?.()).catch(() => {}); } catch {} } try { reader?.releaseLock(); } catch {} }
      }
      const stream = multipart();
      try {
        // Official file API step2. Never replay a consumed stream after a redirect.
        sent = true;
        const response = await request(token, mediaOrigin + '/uploads' + pathname + '?parentId=' + target, {signal, method:'POST', headers:{'Content-Type':'multipart/form-data; boundary=' + boundary, 'Content-Length':String(prefix.length + size + suffix.length)}, body:stream});
        if (response.status >= 300 && response.status < 400) { cancelBody(response); fail('UNSAFE_REDIRECT'); }
        const result = (await jsonResponse(response, signal)).result;
        if (!record(result) || !streamedComplete) fail('UPLOAD_UNCERTAIN');
        const uploaded = {id:responseId(result.id), name, isFolder:false, size};
        if (result.name !== undefined && result.name !== name || result.type !== undefined && result.type !== 'file' || result.size !== undefined && result.size !== size) fail('UPLOAD_UNCERTAIN');
        return uploaded;
      } catch (error) {
        if (streamError) throw streamError;
        if (error instanceof DriveApiError && ['AUTH','FORBIDDEN','NOT_FOUND','CONFLICT','RATE_LIMIT','CANCELLED','UNSAFE_REDIRECT'].includes(error.code)) throw error;
        if (sent) fail('UPLOAD_UNCERTAIN'); throw error;
      } finally { try { Promise.resolve(stream.return()).catch(() => {}); } catch {} }
    },
    async sharedLinks(token, {driveId, fileId, signal} = {}) {
      const envelope = await json(token, filePath(driveId, fileId) + '/shared-links?valid=true', {signal});
      if (!Array.isArray(envelope.result) || envelope.result.length > MAX_ITEMS) fail('INVALID_RESPONSE');
      const links = new Map(), conflicts = new Set(); let invalid = false, unsupportedCount = 0;
      const now = Date.now();
      for (const raw of envelope.result) {
        if (!record(raw) || typeof raw.scope !== 'string') { invalid = true; continue; }
        if (!SCOPES.has(raw.scope)) { unsupportedCount++; continue; }
        try {
          const link = linkInfo(raw);
          if (link.expiredAt && shareExpiryTime(link.expiredAt) <= now) continue;
          if (conflicts.has(link.id)) continue;
          const existing = links.get(link.id);
          if (existing && (existing.url !== link.url || existing.scope !== link.scope || existing.expiredAt !== link.expiredAt)) {
            links.delete(link.id); conflicts.add(link.id); invalid = true; continue;
          }
          links.set(link.id, link);
        } catch (error) {
          if (!(error instanceof DriveApiError)) throw error;
          invalid = true;
        }
      }
      // An unsafe/malformed response is not evidence that no link exists. Avoid
      // offering duplicate creation because the only existing links were rejected.
      if (!links.size && invalid) fail('INVALID_RESPONSE');
      return {links:[...links.values()], ...(unsupportedCount ? {unsupportedCount} : {})};
    },
    async share(token, {driveId, fileId, signal, create = false, scope = 'member', expiredAt} = {}) {
      if (typeof create !== 'boolean' || !SCOPES.has(scope)) fail('INVALID_INPUT');
      headerToken(token); checkAbort(signal);
      const pathname = filePath(driveId, fileId) + '/shared-links';
      if (!create) {
        const envelope = await json(token, pathname + '?valid=true', {signal});
        if (!Array.isArray(envelope.result) || envelope.result.length > MAX_ITEMS) fail('INVALID_RESPONSE');
        // Do not silently return a broader existing public link for an internal share.
        for (const raw of envelope.result) if (raw?.scope === scope) {
          const link = linkInfo(raw); if (!link.expiredAt || Date.parse(link.expiredAt) > Date.now()) return link;
        }
        return {url:null, created:false};
      }
      const shareOptions = normalizeDriveShareOptions({scope, expiredAt});
      const explicitExpiry = expiredAt !== undefined;
      let created;
      try { created = await json(token, pathname, {signal, method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(shareOptions)}); }
      catch (error) {
        if (error instanceof DriveApiError && error.status === 400) fail('SHARE_SETTINGS_REJECTED', 400);
        if (error instanceof DriveApiError && ['AUTH','FORBIDDEN','NOT_FOUND','CONFLICT','RATE_LIMIT'].includes(error.code)) throw error;
        fail('SHARE_UNCERTAIN');
      }
      try {
        const linkId = responseId(created.result?.id);
        const link = linkInfo((await json(token, pathname + '/' + linkId, {signal})).result, true);
        if (link.id !== linkId || link.scope !== scope) fail('INVALID_RESPONSE');
        if (explicitExpiry && (!link.expiredAt || shareExpiryTime(link.expiredAt) !== Date.parse(shareOptions.expiredAt))) fail('INVALID_RESPONSE');
        return link;
      } catch { fail('SHARE_UNCERTAIN'); }
    }
  });
}

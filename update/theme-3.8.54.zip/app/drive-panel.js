// Personal Drive UI. Credentials and network requests belong to the local helper.
function installDoorayDrivePanel({document=globalThis.document,rpc,downloads}={}){
  const win=document.defaultView||globalThis,MiB=1024*1024,chunkLimit=512*1024,queueLimit=20,historyLimit=100,transferLimit=1024*MiB;
  const connectionLifetime=2*60*60*1000;
  if(typeof rpc!=='function')throw Error('Drive RPC is required');
  const host=document.createElement('div');host.id='dooray-theme-drive';host.setAttribute('data-dp-extension','drive');
  const shadow=host.attachShadow({mode:'open'});
  shadow.innerHTML=`<style>
  :host{display:block;position:relative;width:48px;height:56px;flex:0 0 56px;font:12px/1.5 'Malgun Gothic',sans-serif;color:var(--dt-text,#202733)}*{box-sizing:border-box}[hidden]{display:none!important}button,select,input{font:inherit;color:inherit}button{cursor:pointer;border:1px solid var(--dt-border,#d0d6df);border-radius:6px;background:var(--dt-surface,#f4f6f9);padding:5px 9px}button:hover{background:var(--dt-hover,#e9eef5)}button:disabled{opacity:.45;cursor:default}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:2px}a{color:var(--dt-accent,#1769bb)}#toggle{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;width:44px;height:52px;margin:2px;padding:2px;border:0;background:transparent;font-size:10px}#toggle svg{width:23px;height:23px}#toggle[aria-expanded=true]{background:var(--dt-selection,#e5f1ff)}
  #panel{position:fixed;z-index:5061;right:60px;top:12px;display:flex;flex-direction:column;width:590px;max-width:calc(100vw - 72px);max-height:calc(100vh - 24px);overflow:hidden;border:1px solid var(--dt-border,#cbd2da);border-radius:12px;background:var(--dt-bg,#fff);box-shadow:0 14px 45px #0004}.head{display:flex;align-items:center;gap:9px;padding:14px 16px 9px}.head strong{font-size:16px;flex:1}.chip{font-size:10px;border:1px solid var(--dt-border,#cbd2da);border-radius:20px;padding:2px 7px;color:var(--dt-muted,#657080)}.icon{width:28px;height:28px;padding:0;font-size:18px;flex:none}.help{padding:0 16px 10px;margin:0;color:var(--dt-muted,#657080);font-size:11px}.help a{white-space:nowrap}.toolbar{display:flex;gap:6px;align-items:center;padding:8px 16px;border-block:1px solid var(--dt-border,#d0d6df);background:var(--dt-surface,#f4f6f9)}select{min-width:0;flex:1;border:1px solid var(--dt-border,#cbd2da);border-radius:6px;background:var(--dt-bg,#fff);padding:6px}.body{min-height:0;overflow:auto;overscroll-behavior:contain}.crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:10px 16px}.crumbs button{border:0;background:transparent;padding:2px 5px;max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.crumbs span{color:var(--dt-muted,#657080)}.list{min-height:80px;max-height:350px;overflow:auto;padding:0 10px}.empty{margin:15px 6px;color:var(--dt-muted,#657080)}.file{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;padding:9px 6px;border-bottom:1px solid var(--dt-border,#e1e5eb)}.name{display:block;min-width:0;max-width:100%;overflow-wrap:anywhere;text-align:left;border:0;background:transparent;padding:0;color:var(--dt-text,#202733)}.name .glyph{margin-right:7px;color:var(--dt-accent,#278ac2)}.metadata{font-size:10px;color:var(--dt-muted,#657080);margin-top:2px}.actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}.actions button{padding:4px 7px;font-size:11px}.pager{display:flex;justify-content:center;align-items:center;gap:12px;padding:9px 16px}.pager span{color:var(--dt-muted,#657080);font-size:11px}
  .upload{margin:4px 16px 12px;border:1px dashed var(--dt-border,#9aa8ba);border-radius:8px;padding:12px;text-align:center;background:var(--dt-surface,#f4f6f9)}.upload[data-drag]{border-color:var(--dt-accent,#278ac2);background:var(--dt-selection,#e5f1ff)}.upload p{margin:0 0 7px;color:var(--dt-muted,#657080);font-size:11px}.upload input{max-width:100%}.queue{padding:0 16px 12px}.queue-head{display:flex;align-items:center;gap:6px;margin-bottom:6px}.queue-head strong{flex:1;font-size:12px}.job{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;border-top:1px solid var(--dt-border,#d0d6df);padding:7px 0}.job-name{overflow-wrap:anywhere}.job small{display:block;color:var(--dt-muted,#657080)}progress{display:block;width:100%;height:5px;margin-top:5px;accent-color:var(--dt-accent,#278ac2)}
  .subpanel{margin:0 16px 12px;padding:10px;border:1px solid var(--dt-border,#cbd2da);border-radius:8px;background:var(--dt-surface,#f4f6f9)}.subhead{display:flex;align-items:center;gap:6px;margin-bottom:7px}.subhead strong{flex:1;min-width:0;overflow-wrap:anywhere}.preview-content img,.preview-content video{display:block;max-width:100%;max-height:350px;margin:auto}.preview-content video{width:100%}.preview-content iframe{display:block;width:100%;height:350px;border:0;background:#fff}.preview-content pre{margin:0;max-height:350px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 monospace}.subpanel p{margin:6px 0;font-size:11px;color:var(--dt-muted,#657080)}#shareUrl{width:100%;min-width:0;padding:7px;border:1px solid var(--dt-border,#cbd2da);border-radius:5px;background:var(--dt-bg,#fff)}.confirm{border:1px solid var(--dt-accent,#278ac2)}.confirm .actions{margin-top:10px}.primary{background:var(--dt-selection,#e5f1ff);border-color:var(--dt-accent,#278ac2)}.status{padding:9px 16px;border-top:1px solid var(--dt-border,#cbd2da);font-size:11px;color:var(--dt-muted,#657080);min-height:35px;overflow-wrap:anywhere}.status[data-error]{color:var(--dt-accent,#a93131)}
  @media(max-width:600px){#panel{right:8px;top:8px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px)}.file{grid-template-columns:minmax(0,1fr)}.file .actions{justify-content:flex-start}.toolbar{flex-wrap:wrap}}
  #panel[data-checking-account] :is(.toolbar,.body,.status){visibility:hidden}
  </style><button id="toggle" type="button" aria-label="두레이 드라이브" aria-expanded="false" aria-controls="panel" title="두레이 드라이브"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 6.5h7l2 2h9v11H3z"/><path d="M3 8.5V4.5h7l2 2h7v2"/><path d="M8 14h8m-4-3v6"/></svg><span>드라이브</span></button>
  <section id="panel" aria-label="두레이 드라이브" hidden><div class="head"><strong>드라이브</strong><span id="connection" class="chip">연결 확인 전</span><button id="close" class="icon" type="button" aria-label="드라이브 닫기">×</button></div><p class="help">API 키 입력은 별도의 Windows 창에서 진행합니다. <a id="issueKey" href="https://gravity.dooray.com/setting/api/token" target="_blank" rel="noopener noreferrer">API 키 발급</a></p><div class="toolbar"><button id="credentials" type="button">키 등록 / 변경</button><button id="forget" type="button" disabled>키 삭제</button><select id="drives" aria-label="드라이브 선택" disabled><option value="">드라이브를 선택하세요</option></select><button id="moreDrives" type="button" hidden>더 보기</button><button id="refresh" type="button" aria-label="드라이브 새로고침">↻</button></div><div class="body"><nav id="crumbs" class="crumbs" aria-label="폴더 이동 경로"></nav><div id="files" class="list" aria-label="폴더와 파일 목록"></div><div class="pager"><span id="fileCount"></span><button id="moreFiles" type="button" hidden>더 불러오기</button></div><section id="confirm" class="subpanel confirm" role="alertdialog" aria-label="작업 확인" hidden><strong id="confirmTitle"></strong><p id="confirmText"></p><div class="actions"><button id="confirmCancel" type="button">취소</button><button id="confirmAccept" class="primary" type="button">확인</button></div></section><section id="share" class="subpanel" aria-label="공유 링크" hidden><div class="subhead"><strong id="shareName">공유 링크</strong><button id="shareClose" class="icon" type="button" aria-label="공유 링크 닫기">×</button></div><input id="shareUrl" type="text" readonly aria-label="공유 주소"><div class="actions"><button id="copy" type="button">링크 복사</button></div></section><section id="preview" class="subpanel" aria-label="파일 미리보기" hidden><div class="subhead"><strong id="previewName"></strong><button id="previewClose" class="icon" type="button" aria-label="미리보기 닫기">×</button></div><p id="previewNote"></p><div id="previewContent" class="preview-content"></div><div class="actions"><button id="previewDownload" type="button">다운로드</button></div></section><div id="drop" class="upload" aria-label="파일 업로드 영역"><p>현재 폴더에 올릴 파일을 놓거나 선택하세요. 최대 20개를 대기열에 담을 수 있습니다.</p><input id="picker" type="file" multiple hidden><button id="choose" type="button">파일 선택</button></div><section id="queue" class="queue" aria-label="파일 전송 대기열" hidden><div class="queue-head"><strong>전송 대기열 <span id="queueCount"></span></strong><button id="clearQueue" type="button">완료 항목 정리</button><button id="start" class="primary" type="button">업로드 시작</button></div><div id="jobs"></div></section></div><div id="status" class="status" role="status" aria-live="polite">API 키를 등록하면 드라이브를 볼 수 있습니다.</div></section>`;
  const $=id=>shadow.getElementById(id),files=new Map(),jobs=new Map(),queue=[];
  const shareInfo=document.createElement('p');shareInfo.id='shareInfo';$('shareUrl').after(shareInfo);
  const shareChoices=document.createElement('select');
  shareChoices.id='shareChoices';shareChoices.hidden=true;
  shareChoices.setAttribute('aria-label','기존 공유 링크 선택');
  shareChoices.style.cssText='width:100%;margin-bottom:6px';
  $('shareUrl').before(shareChoices);
  const shareNotice=document.createElement('p');
  shareNotice.id='shareNotice';
  shareInfo.after(shareNotice);
  const shareSettings=document.createElement('div');shareSettings.className='share-settings';shareSettings.innerHTML='<p id="shareKind">기존 공유 링크</p><strong>새 링크 설정</strong><div class="share-fields"><label for="shareScope">공개 범위<select id="shareScope"><option value="member">조직 내 구성원</option><option value="memberAndGuest">조직 내 구성원 및 손님</option><option value="memberAndGuestAndExternal">링크가 있는 누구나</option></select></label><label for="shareExpiry">만료 일시<input id="shareExpiry" type="datetime-local" required step="60"></label></div><p id="shareAccess" class="share-access"></p><p>만료 일시는 이 컴퓨터의 시간을 기준으로 표시합니다.</p><p id="shareError" role="status"></p><div class="actions"><button id="shareCreate" type="button" class="primary">새 링크 생성</button></div><p><a id="advancedShare" target="_blank" rel="noopener noreferrer" hidden>두레이에서 고급 공유</a></p><p>선택한 부서·구성원과 비밀번호는 두레이 드라이브의 공유하기에서 설정할 수 있습니다.</p>';$('share').append(shareSettings);$('shareChoices').before($('shareKind'));
  const shareStyle=document.createElement('style');shareStyle.textContent='.share-settings{border-top:1px solid var(--dt-border,#cbd2da);margin-top:10px;padding-top:10px}.share-fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-top:7px}.share-fields label{min-width:0;font-size:11px}.share-fields select,.share-fields input{display:block;width:100%;min-width:0;margin-top:4px;padding:6px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:5px}.share-access[data-public]{padding:8px;border:1px solid #bb8934;border-radius:5px;background:#bb89341a;color:inherit;font-weight:600}#shareError{color:var(--dt-accent,#a93131)}';shadow.append(shareStyle);
  try{const origin=win.location.origin;if(/^https:\/\/[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.(?:dooray|gov-dooray)\.com$/i.test(origin)){$('advancedShare').href=new win.URL('/drive/',origin).href;$('advancedShare').hidden=false;}}catch{}
  const uploadDisclosure=document.createElement('details'),uploadSummary=document.createElement('summary');uploadDisclosure.id='uploadDisclosure';uploadSummary.textContent='업로드';uploadSummary.style.cssText='margin:8px 16px;padding:7px 10px;cursor:pointer;border:1px solid var(--dt-border,#cbd2da);border-radius:6px';$('drop').before(uploadDisclosure);uploadDisclosure.append(uploadSummary,$('drop'));
  const downloadTools=document.createElement('section');downloadTools.id='downloadFolderTools';downloadTools.className='subpanel';downloadTools.setAttribute('aria-label','다운로드 저장 위치');downloadTools.innerHTML='<div class="subhead"><strong>다운로드 저장 위치</strong><button id="openDownloadFolder" type="button">폴더 열기</button><button id="downloadSettings" type="button" aria-expanded="false" aria-controls="downloadFolderSettings">설정</button></div><p id="downloadFolderPath"></p><div id="downloadFolderSettings" class="actions" hidden><button id="chooseDownloadFolder" type="button">저장 폴더 변경</button><button id="resetDownloadFolder" type="button">기본 다운로드 폴더</button></div><p id="downloadFolderStatus" role="status" aria-live="polite"></p>';
  uploadDisclosure.before(downloadTools);const transferStyle=document.createElement('style');transferStyle.textContent='#downloadFolderPath{overflow-wrap:anywhere}.job .history-remove{align-self:start;padding:1px 7px;font-size:17px;line-height:22px}';shadow.append(transferStyle);
  const folderTools=document.createElement('div');folderTools.className='folder-tools';folderTools.innerHTML='<button id="newFolder" type="button">＋ 새 폴더</button>';$('crumbs').after(folderTools);
  const fileViews=document.createElement('div');
  fileViews.className='file-views';
  fileViews.innerHTML='<label for="fileView">보기</label><select id="fileView"><option value="all">전체</option><option value="folders">폴더만</option><option value="files">파일만</option><option value="extensions">확장자별</option></select>';
  folderTools.prepend(fileViews);
  const folderActions=document.createElement('div');
  folderActions.className='actions';
  $('refresh').textContent='새로고침';
  $('refresh').title='현재 폴더 새로고침';
  folderActions.append($('refresh'),$('newFolder'));
  folderTools.append(folderActions);
  const nameEditor=document.createElement('section');nameEditor.id='nameEditor';nameEditor.className='subpanel';nameEditor.hidden=true;nameEditor.setAttribute('role','dialog');nameEditor.setAttribute('aria-label','항목 이름 설정');nameEditor.innerHTML='<div class="subhead"><strong id="nameTitle"></strong></div><p id="nameLocation"></p><label for="entryName">이름</label><input id="entryName" type="text" maxlength="255" autocomplete="off"><p id="nameError" role="status"></p><div class="actions"><button id="nameCancel" type="button">취소</button><button id="nameSave" class="primary" type="button">저장</button></div>';
  const destinationPicker=document.createElement('section');destinationPicker.id='destinationPicker';destinationPicker.className='subpanel';destinationPicker.hidden=true;destinationPicker.setAttribute('role','dialog');destinationPicker.setAttribute('aria-label','파일 이동 위치');destinationPicker.innerHTML='<div class="subhead"><strong id="moveTitle">파일 이동</strong></div><p id="moveSource"></p><nav id="moveCrumbs" class="crumbs" aria-label="이동할 폴더 경로"></nav><div id="moveFolders" class="list" aria-label="이동할 폴더 목록"></div><div class="pager"><button id="movePrevious" type="button">이전</button><span id="movePage"></span><button id="moveNext" type="button">다음</button></div><p id="moveNote" role="status"></p><div class="actions"><button id="moveCancel" type="button">취소</button><button id="moveSave" class="primary" type="button">여기로 이동</button></div>';$('confirm').before(nameEditor,destinationPicker);
  const managementStyle=document.createElement('style');
  managementStyle.textContent=`
    #files{min-height:120px;max-height:min(480px,60vh)}
    #files .actions{align-items:flex-start}
    .folder-tools{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;padding:0 16px 8px}
    .file-views{display:flex;align-items:center;gap:6px}
    .extension-group{padding:5px 0;border-bottom:1px solid var(--dt-border,#cbd2da)}
    .extension-group>summary{cursor:pointer;padding:5px 6px;font-weight:600;overflow-wrap:anywhere}
    .item-menu{max-width:100%}
    .item-menu summary{width:fit-content;margin-left:auto;list-style:none;cursor:pointer;padding:3px 9px;border:1px solid var(--dt-border,#cbd2da);border-radius:6px}
    .item-menu summary::-webkit-details-marker{display:none}
    .item-menu .menu{display:grid;gap:3px;min-width:112px;margin-top:4px;padding:5px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:6px}
    .item-menu .menu button{text-align:left;white-space:nowrap}
    .item-menu .trash{color:var(--dt-accent,#a93131)}
    #entryName{display:block;width:100%;margin-top:5px;padding:7px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:5px}
    #nameError{color:var(--dt-accent,#a93131)}
    #moveCrumbs{padding:3px 0 8px}
    #moveFolders{max-height:230px;padding:0}
    #moveFolders button{display:block;width:100%;margin-bottom:4px;text-align:left;overflow-wrap:anywhere}
  `;
  shadow.append(managementStyle);
  let disposed=false,anchor=null,generation=0,listSerial=0,previewSerial=0,shareSerial=0,initialized=false,configured=false,accountTag=null,checking=false,verifiedAt=null,readFlights=0,drives=[],drive=null,drivePage=0,driveHasNext=false,crumbs=[],listBusy=false,keyBusy=false,pollTimer=0,pollBusy=false,uploadBusy=false,currentUpload=null,activePreview=null,blobURL=null,previewFile=null,confirmResolve=null,writeBusy=false,pendingWrite=null,nameDraft=null,moveDraft=null,moveSerial=0,shareState=null;
  const folderListings=new Map();
  const extensionGroups=new Map();
  const fileTypes=new Map([['all',null],['folders','folder'],['files','file'],['extensions','file']]);
  let activeListing=null,fileView='all',renderedView=null,lastFileScroll=0;
  let folderBusy=false,folderSerial=0;
  const text=value=>typeof value==='string'?value:typeof value==='number'?String(value):'';
  const errorText=error=>(typeof error?.message==='string'?error.message:'요청을 처리하지 못했습니다.').replace(/[\x00-\x1f\x7f]/g,' ').slice(0,400);
  const id=value=>{const valueText=text(value);return valueText&&valueText.length<=128?valueText:null};
  const size=value=>Number.isSafeInteger(value)&&value>=0?value:0;
  const formatSize=value=>{value=size(value);return value>=1024**3?(value/1024**3).toFixed(1)+' GB':value>=MiB?(value/MiB).toFixed(1)+' MB':value>=1024?Math.ceil(value/1024)+' KB':value+' B'};
  const setStatus=(message,error=false)=>{if(disposed)return;$('status').textContent=message;$('status').toggleAttribute('data-error',error)};
  const validTag=value=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\x00-\x20\x7f]/.test(value);
  const invoke=(op,args={})=>{const tag=args.accountTag||accountTag;if(disposed)return Promise.reject(Error('드라이브 창이 종료되었습니다.'));if(op!=='status'&&(!validTag(tag)||tag!==accountTag))return Promise.reject(Error('계정 연결을 다시 확인해 주세요.'));return Promise.resolve().then(()=>{if(disposed)throw Error('드라이브 창이 종료되었습니다.');if(op!=='status'&&tag!==accountTag)throw Error('계정 연결이 변경되었습니다.');return rpc(op,op==='status'?args:{...args,accountTag:tag})})};
  const abandon=(jobId,tag=accountTag)=>{if(jobId&&validTag(tag))try{Promise.resolve(rpc('cancel',{id:jobId,accountTag:tag})).catch(()=>{})}catch{}};
  const parentId=()=>{const value=crumbs[crumbs.length-1]?.id;return value&&value!=='root'?value:null};
  const locationArgs=()=>({driveId:drive?.id,...(parentId()?{parentId:parentId()}:{})});
  const transferActive=()=>uploadBusy||[...jobs.values()].some(entry=>entry.state==='running'||entry.state==='starting');
  function controls(){if(disposed)return;const busy=checking||keyBusy||writeBusy;$('connection').textContent=checking?'연결 확인 중':configured?'키 설정됨':'키 미등록';$('credentials').disabled=busy||!accountTag||transferActive();$('forget').disabled=!configured||busy||!accountTag||transferActive();$('drives').disabled=!configured||busy||listBusy||!drives.length;$('refresh').disabled=busy||listBusy;$('moreDrives').hidden=!driveHasNext;$('moreDrives').disabled=busy||listBusy;$('choose').disabled=!configured||busy||!drive;$('newFolder').disabled=!configured||!drive||busy||listBusy;$('start').disabled=busy||uploadBusy||!queue.some(entry=>entry.state==='queued');fileControls();shareControls();}
  function empty(message){$('files').replaceChildren();const node=document.createElement('p');node.className='empty';node.textContent=message;$('files').append(node);}
  function closeConfirmation(value=false){const resolve=confirmResolve;confirmResolve=null;$('confirm').hidden=true;resolve?.(value);}
  function confirmAction(title,message,accept){closeConfirmation();$('confirmTitle').textContent=title;$('confirmText').textContent=message;$('confirmAccept').textContent=accept;$('confirm').hidden=false;$('confirm').scrollIntoView?.({block:'nearest'});$('confirmCancel').focus({preventScroll:true});return new Promise(resolve=>{confirmResolve=resolve})}
  function closeShare(){
    shareSerial++;
    shareState=null;
    $('share').hidden=true;
    $('shareChoices').replaceChildren();
    $('shareChoices').hidden=true;
    $('shareUrl').value='';
    $('shareUrl').hidden=true;
    for(const key of ['shareInfo','shareNotice','shareError'])$(key).textContent='';
    $('shareName').textContent='공유 링크';
    $('shareScope').value='member';
    $('shareExpiry').value='';
    $('copy').disabled=true;
    $('copy').hidden=true;
  }
  function closePreview(){previewSerial++;if(activePreview){abandon(activePreview.id,activePreview.accountTag);activePreview=null}const media=$('previewContent').querySelector('video');if(media){try{media.pause()}catch{}media.removeAttribute('src');try{media.load()}catch{}}$('previewContent').replaceChildren();if(blobURL){win.URL.revokeObjectURL(blobURL);blobURL=null}previewFile=null;$('preview').hidden=true;}
  function navigation(){closeConfirmation();closePreview();closeShare();closeManagement();}
  function resetSession(nextTag){generation++;listSerial++;verifiedAt=null;pendingWrite=null;writeBusy=false;closeManagement(true);navigation();for(const [jobId,entry]of jobs){if(entry.id&&['running','starting'].includes(entry.state))abandon(entry.id,entry.accountTag);entry.state='cancelled';releaseFile(entry)}for(const entry of queue){entry.state='cancelled';releaseFile(entry)}queue.splice(0);jobs.clear();files.clear();clearListings();currentUpload=null;uploadBusy=false;if(pollTimer)win.clearTimeout(pollTimer);pollTimer=0;drives=[];drive=null;crumbs=[];driveHasNext=false;listBusy=false;accountTag=nextTag;$('files').replaceChildren();renderQueue();renderDrives();renderCrumbs();}
  function renderCrumbs(){$('crumbs').replaceChildren();crumbs.forEach((crumb,index)=>{if(index){const separator=document.createElement('span');separator.textContent='›';separator.setAttribute('aria-hidden','true');$('crumbs').append(separator)}const button=document.createElement('button');button.type='button';button.textContent=crumb.name;button.title=crumb.name;button.disabled=listBusy||writeBusy||index===crumbs.length-1;button.onclick=()=>{if(writeBusy)return;navigation();crumbs=crumbs.slice(0,index+1);loadFiles()};$('crumbs').append(button)})}
  function renderDrives(){const select=$('drives');select.replaceChildren();if(!drives.length){const option=document.createElement('option');option.value='';option.textContent='드라이브가 없습니다.';select.append(option)}for(const entry of drives){const option=document.createElement('option');option.value=entry.id;option.textContent=entry.name;select.append(option)}select.value=drive?.id||'';controls();}
  async function loadDrives(more=false) {
    const stamp = ++listSerial, epoch = generation;
    const current = () => !disposed && epoch === generation && stamp === listSerial;
    let accepted = false;
    listBusy = true;
    controls();
    try {
      const response = await invoke('drives', {page:more ? drivePage + 1 : 0});
      if (!current()) return false;
      if (!Array.isArray(response?.items)) throw Error('드라이브 목록 응답을 확인하지 못했습니다.');
      const fresh = response.items.filter(entry=>id(entry?.id)).slice(0,2000).map(entry=>({id:id(entry.id),name:text(entry.name).slice(0,500)||'드라이브',rootId:entry.rootId==='root'?null:id(entry.rootId)}));
      const known = new Map((more ? drives : []).map(entry => [entry.id,entry]));
      for (const entry of fresh) known.set(entry.id, entry);
      drives = [...known.values()].slice(0,2000);
      drivePage = more ? drivePage + 1 : 0;
      driveHasNext = response.hasNext === true && drives.length < 2000;
      const selected = drive && drives.find(entry => entry.id === drive.id);
      if (!selected) {
        drive = drives[0] || null;
        crumbs = drive ? [{id:drive.rootId,name:drive.name}] : [];
      } else drive = selected;
      accepted = true;
      renderDrives();
    } catch (error) {
      if (current()) {
        verifiedAt = null;
        clearListings();
        setStatus(errorText(error), true);
        empty('드라이브 목록을 불러오지 못했습니다.');
      }
    } finally {
      if (current()) {
        listBusy = false;
        controls();
        renderCrumbs();
      }
    }
    if (!current() || !accepted) return false;
    if (!more && drive) {
      invalidateListings(drive.id,parentId());
      return loadFiles();
    }
    if (!drive) {
      clearListings();
      empty('사용 가능한 드라이브가 없습니다.');
      setStatus('사용 가능한 드라이브가 없습니다.');
      controls();
    }
    return true;
  }
  async function connect(reuse=false) {
    if (disposed || checking || keyBusy || writeBusy) return;
    const age = verifiedAt === null ? Infinity : win.Date.now() - verifiedAt;
    const cachedTag = reuse && age >= 0 && age < connectionLifetime ? accountTag : null;
    const panel = $('panel');
    const epoch = generation;
    checking = true;
    if (accountTag) panel.setAttribute('data-checking-account', '');
    controls();
    if (!cachedTag) setStatus('연결 상태를 확인하는 중…');
    try {
      const response = await invoke('status', cachedTag ? {reuseAccountTag:cachedTag} : {});
      if (disposed || epoch !== generation) return;
      if (cachedTag && response?.reused === true && response.accountTag === cachedTag) return;
      if (!validTag(response?.accountTag) || typeof response.configured !== 'boolean') {
        throw Error('현재 두레이 계정 연결을 확인하지 못했습니다.');
      }
      verifiedAt = null;
      if (accountTag !== response.accountTag || configured && !response.configured) resetSession(response.accountTag);
      configured = response.configured;
      initialized = true;
      if (configured) {
        setStatus('드라이브 목록을 불러오는 중…');
        if (await loadDrives() && !disposed) verifiedAt = win.Date.now();
      } else {
        empty('API 키를 등록해 주세요.');
        setStatus('API 키 발급 후 키 등록 / 변경을 눌러 주세요.');
        verifiedAt = win.Date.now();
      }
    } catch (error) {
      if (!disposed) {
        resetSession(null);
        configured = false;
        initialized = false;
        setStatus(errorText(error), true);
        empty('연결 상태를 확인하지 못했습니다. 새로고침해 주세요.');
      }
    } finally {
      if (!disposed) {
        panel.removeAttribute('data-checking-account');
        checking = false;
        controls();
        runUpload();
      }
    }
  }
  function revealItemMenu(items){
    const list=$('files');
    for(const scroller of [list,list.closest('.body')]){
      const visibleHeight=scroller.clientHeight;
      if(!visibleHeight)continue;
      const top=scroller.getBoundingClientRect().top+scroller.clientTop;
      const bottom=top+visibleHeight;
      const bounds=items.getBoundingClientRect();
      if(bounds.top<top||bounds.height>visibleHeight)scroller.scrollTop+=bounds.top-top;
      else if(bounds.bottom>bottom)scroller.scrollTop+=bounds.bottom-bottom;
    }
    lastFileScroll=list.scrollTop;
  }
  function fileRow(entry){
    const row=document.createElement('div');row.className='file';
    const left=document.createElement('div'),name=document.createElement('button'),glyph=document.createElement('span');name.type='button';name.className='name';glyph.className='glyph';glyph.textContent=entry.isFolder?'▱':'▤';glyph.setAttribute('aria-hidden','true');name.append(glyph,document.createTextNode(entry.name));name.title=entry.name;
    name.onclick=()=>{if(checking||keyBusy||listBusy||writeBusy)return;if(entry.isFolder){navigation();crumbs.push({id:entry.id,name:entry.name});loadFiles()}else showPreview(entry)};
    left.append(name);const metadata=document.createElement('div');metadata.className='metadata';const values=[];if(!entry.isFolder&&Number.isSafeInteger(entry.size))values.push(formatSize(entry.size));if(entry.modifiedAt){const date=new Date(entry.modifiedAt);if(Number.isFinite(date.getTime()))values.push(date.toLocaleString())}metadata.textContent=values.join(' · ');left.append(metadata);row.append(left);
    const actions=document.createElement('div');actions.className='actions';
    if(!entry.isFolder)for(const [label,action]of [['미리보기',()=>showPreview(entry)],['다운로드',()=>download(entry)],['공유',()=>share(entry)]]){const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('aria-label',entry.name+' '+label);button.onclick=()=>{if(!checking&&!keyBusy&&!listBusy&&!writeBusy)action()};actions.append(button)}
    const menu=document.createElement('details'),summary=document.createElement('summary'),items=document.createElement('div');menu.className='item-menu';summary.textContent='⋯';summary.setAttribute('aria-label',entry.name+' 더보기');summary.setAttribute('aria-haspopup','menu');items.className='menu';items.setAttribute('role','menu');summary.addEventListener('click',()=>{for(const other of shadow.querySelectorAll('.item-menu[open]'))if(other!==menu)other.open=false});
    menu.addEventListener('toggle',()=>{if(menu.open&&menu.isConnected&&!$('panel').hidden)revealItemMenu(items)});
    const options=[['이름 변경',()=>openName('rename',entry)],...(!entry.isFolder?[['이동',()=>openMove(entry)]]:[]),['휴지통',()=>trash(entry)]];
    for(const [label,action]of options){const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('role','menuitem');button.setAttribute('aria-label',entry.name+' '+label);if(label==='휴지통')button.className='trash';button.onclick=()=>{menu.open=false;if(managementReady())action()};items.append(button)}menu.append(summary,items);actions.append(menu);row.append(actions);return row;
  }
  function clearListings(){
    folderListings.clear();
    extensionGroups.clear();
    activeListing=null;
    renderedView=null;
    lastFileScroll=0;
  }
  function invalidateListings(driveId,...parents){
    for(const [key,state] of folderListings){
      if(state.driveId!==driveId||parents.length&&!parents.includes(state.parentId))continue;
      folderListings.delete(key);
      if(state===activeListing)state.hasNext=false;
    }
  }
  function trimListings(){
    let itemCount=[...folderListings.values()].reduce((count,state)=>count+state.entries.length,0);
    for(const [key,state] of folderListings){
      if(folderListings.size<=12&&itemCount<=8000)break;
      if(state===activeListing)continue;
      folderListings.delete(key);
      itemCount-=state.entries.length;
    }
  }
  function fileControls(){
    const state=activeListing;
    const busy=checking||keyBusy||writeBusy||listBusy;
    $('fileView').disabled=!configured||!drive||busy;
    $('fileCount').textContent=state?.loadedAt!=null?state.entries.length+'개 불러옴':'';
    $('moreFiles').hidden=!state?.hasNext;
    $('moreFiles').disabled=busy||!!state?.pending;
    $('moreFiles').textContent=state?.pending?'불러오는 중…':state?.failed?'다시 불러오기':'더 불러오기';
  }
  function appendFileRows(entries){
    const list=$('files');
    if(!entries.length)return;
    list.querySelector('.empty')?.remove();
    for(const entry of entries){
      if(fileView!=='extensions'){
        list.append(fileRow(entry));
        continue;
      }
      const dot=entry.name.lastIndexOf('.');
      const extension=dot>0&&dot<entry.name.length-1?entry.name.slice(dot).toLowerCase():'확장자 없음';
      let group=extensionGroups.get(extension);
      if(!group){
        const section=document.createElement('details'),title=document.createElement('summary');
        section.className='extension-group';
        section.open=true;
        section.append(title);
        list.append(section);
        group={section,title,count:0};
        extensionGroups.set(extension,group);
      }
      group.section.append(fileRow(entry));
      group.title.textContent=extension+' · '+(++group.count)+'개';
    }
  }
  function showListing(state){
    const list=$('files');
    if(activeListing!==state||renderedView!==fileView){
      if(activeListing)activeListing.scrolls.set(renderedView,list.scrollTop);
      activeListing=state;
      renderedView=fileView;
      list.replaceChildren();
      extensionGroups.clear();
      appendFileRows(state.entries);
      list.scrollTop=state.scrolls.get(fileView)||0;
      lastFileScroll=list.scrollTop;
    }
    if(!state.entries.length){
      if(state.failed)empty('폴더 목록을 불러오지 못했습니다.');
      else if(state.loadedAt===null)empty('폴더를 불러오는 중…');
      else if(fileView==='folders')empty('이 위치에 폴더가 없습니다.');
      else if(fileView==='all')empty('이 폴더는 비어 있습니다.');
      else empty('이 위치에 파일이 없습니다.');
    }
    if(state.loadedAt!==null&&!state.failed)setStatus(state.entries.length+'개 항목 · '+(crumbs[crumbs.length-1]?.name||drive.name));
    fileControls();
  }
  function loadMoreFiles(state){
    if(!state||disposed||!state.hasNext)return Promise.resolve(false);
    if(state.pending)return state.pending;
    const epoch=generation;
    const current=()=>!disposed&&epoch===generation&&folderListings.get(state.key)===state;
    const initial=state.loadedAt===null;
    state.failed=false;
    if(initial&&activeListing===state){
      listBusy=true;
      setStatus('폴더를 불러오는 중…');
    }
    state.pending=(async()=>{
      try{
        const args={driveId:state.driveId,page:state.nextPage};
        if(state.parentId)args.parentId=state.parentId;
        if(state.type)args.type=state.type;
        const response=await invoke('files',args);
        if(!current())return false;
        if(!Array.isArray(response?.items))throw Error('폴더 목록 응답을 확인하지 못했습니다.');
        const fresh=[];
        for(const entry of response.items.slice(0,2000)){
          const fileId=id(entry?.id);
          if(!fileId||state.ids.has(fileId)||typeof entry.name!=='string')continue;
          state.ids.add(fileId);
          fresh.push({id:fileId,name:entry.name.slice(0,1000),isFolder:entry.isFolder===true,
            size:entry.size,modifiedAt:entry.modifiedAt});
        }
        state.entries.push(...fresh);
        if(initial)state.loadedAt=win.Date.now();
        state.nextPage++;
        state.hasNext=response.hasNext===true&&fresh.length>0&&state.nextPage<10000;
        if(activeListing===state){
          appendFileRows(fresh);
          showListing(state);
        }
        trimListings();
        return true;
      }catch(error){
        if(current()){
          state.failed=true;
          if(activeListing===state){
            if(initial)verifiedAt=null;
            showListing(state);
            setStatus(errorText(error),true);
          }
        }
        return false;
      }finally{
        state.pending=null;
        if(current()&&activeListing===state){
          if(initial)listBusy=false;
          controls();
          renderCrumbs();
        }
      }
    })();
    controls();
    return state.pending;
  }
  function loadFiles(){
    if(!drive||disposed)return Promise.resolve(false);
    const parent=parentId(),type=fileTypes.get(fileView);
    const key=JSON.stringify([drive.id,parent,type]);
    let state=folderListings.get(key);
    if(state?.loadedAt!=null){
      const age=win.Date.now()-state.loadedAt;
      if(age<0||age>=connectionLifetime)state=null;
    }
    if(!state)state={key,driveId:drive.id,parentId:parent,type,entries:[],ids:new Set(),scrolls:new Map(),nextPage:0,hasNext:true,loadedAt:null,pending:null,failed:false};
    folderListings.delete(key);
    folderListings.set(key,state);
    if(activeListing!==state)listBusy=false;
    showListing(state);
    trimListings();
    renderCrumbs();
    if(state.loadedAt!==null){controls();return Promise.resolve(true);}
    if(state.pending&&activeListing===state){listBusy=true;controls();}
    return loadMoreFiles(state);
  }
  function refreshFolder(){
    if(disposed||checking||keyBusy||writeBusy||listBusy)return;
    if(!configured||!drive||!validTag(accountTag)||verifiedAt===null)return connect();
    navigation();
    invalidateListings(drive.id,parentId());
    return loadFiles();
  }
  function managementReady(){return !disposed&&configured&&drive&&validTag(accountTag)&&!checking&&!keyBusy&&!listBusy&&!writeBusy;}
  function managementOwner(entry){return {epoch:generation,accountTag,driveId:drive.id,parentId:parentId(),view:fileView,root:crumbs.length===1,path:crumbs.map(crumb=>crumb.name).join(' / '),...(entry?{fileId:entry.id,name:entry.name,isFolder:entry.isFolder}:{})};}
  function ownsManagement(owner){return !disposed&&owner.epoch===generation&&owner.accountTag===accountTag&&owner.driveId===drive?.id&&owner.parentId===parentId()&&owner.view===fileView;}
  function closeManagement(force=false){if(writeBusy&&!force)return;nameDraft=null;moveDraft=null;moveSerial++;$('nameEditor').hidden=true;$('entryName').value='';$('nameError').textContent='';$('destinationPicker').hidden=true;$('moveFolders').replaceChildren();$('moveCrumbs').replaceChildren();for(const menu of shadow.querySelectorAll('.item-menu[open]'))menu.open=false;}
  function managementControls(){for(const key of ['entryName','nameSave','nameCancel','moveCancel'])$(key).disabled=writeBusy;const picker=moveDraft,root=picker?.crumbs.length===1,selected=picker?.crumbs[picker.crumbs.length-1]?.id??null,same=picker&&(picker.root&&root||!root&&selected===picker.parentId);$('moveSave').disabled=writeBusy||!picker||picker.busy||same;$('movePrevious').disabled=writeBusy||!picker||picker.busy||picker.page===0;$('moveNext').disabled=writeBusy||!picker||picker.busy||!picker.hasNext;}
  function openName(kind,entry){if(!managementReady())return;navigation();nameDraft={...managementOwner(entry),kind};$('nameTitle').textContent=kind==='create-folder'?'새 폴더':'이름 변경';$('nameLocation').textContent=nameDraft.path;$('entryName').value=entry?.name||'';$('nameSave').textContent=kind==='create-folder'?'폴더 만들기':'이름 변경';$('nameEditor').hidden=false;$('nameEditor').scrollIntoView?.({block:'nearest'});managementControls();$('entryName').focus({preventScroll:true});const end=entry&&!entry.isFolder&&entry.name.lastIndexOf('.')>0?entry.name.lastIndexOf('.'):entry?.name.length||0;$('entryName').setSelectionRange(0,end);}
  async function saveName(){const owner=nameDraft;if(!owner||!ownsManagement(owner)||!managementReady())return;const value=$('entryName').value;if(!value.trim()||value.length>255||/^[.]{1,2}$/.test(value)||/[\\/\x00-\x1f\x7f-\x9f]/.test(value)||[...value].some(char=>{const point=char.codePointAt(0);return point>=0xd800&&point<=0xdfff})){$('nameError').textContent='경로 구분자 없이 1~255자의 이름을 입력해 주세요.';return}if(owner.kind==='rename'&&value===owner.name){closeManagement();return}await writeManagement(owner,owner.kind,{driveId:owner.driveId,...(owner.kind==='create-folder'?(owner.parentId?{parentId:owner.parentId}:{}):{fileId:owner.fileId}),name:value});}
  async function writeManagement(owner,op,args){
    if(!ownsManagement(owner)||writeBusy||checking||keyBusy)return;
    const oldVerifiedAt=verifiedAt;verifiedAt=null;writeBusy=true;pendingWrite=owner;controls();renderCrumbs();managementControls();setStatus({rename:'이름을 변경하는 중…',move:'파일을 이동하는 중…',trash:'휴지통으로 이동하는 중…','create-folder':'폴더를 만드는 중…'}[op]);
    const parents=owner.isFolder?[]:op==='move'?[owner.parentId,args.destinationId]:[owner.parentId];
    try{
      const result=await invoke(op,{...args,accountTag:owner.accountTag});
      if(!ownsManagement(owner))return;
      if(op==='create-folder'?!id(result?.id):result!==true)throw Error('처리 결과를 확인하지 못했습니다. 새로고침 후 확인해 주세요.');
      closeManagement(true);
      invalidateListings(owner.driveId,...parents);
      const refreshed=await loadFiles();if(!ownsManagement(owner))return;
      if(refreshed){verifiedAt=oldVerifiedAt;setStatus({rename:'이름을 변경했습니다.',move:'파일을 이동했습니다.',trash:'휴지통으로 이동했습니다.','create-folder':'폴더를 만들었습니다.'}[op]);}
      else setStatus('변경은 적용했지만 목록을 새로 불러오지 못했습니다. 새로고침해 주세요.',true);
    }catch(error){if(ownsManagement(owner)){invalidateListings(owner.driveId,...parents);setStatus(errorText(error),true);if(nameDraft===owner)$('nameError').textContent=errorText(error);if(moveDraft===owner)$('moveNote').textContent=errorText(error);}}
    finally{if(pendingWrite===owner){pendingWrite=null;writeBusy=false;if(!disposed){controls();renderCrumbs();managementControls();runUpload();}}}
  }
  function openMove(entry){if(!managementReady()||entry.isFolder)return;navigation();moveDraft={...managementOwner(entry),crumbs:[{id:null,name:drive.name}],page:0,hasNext:false,busy:false};$('moveSource').textContent=entry.name+' · 현재 위치: '+moveDraft.path;$('moveNote').textContent='같은 드라이브 안에서 이동할 폴더를 연 뒤 여기로 이동을 눌러 주세요.';$('destinationPicker').hidden=false;$('destinationPicker').scrollIntoView?.({block:'nearest'});loadMoveFolders();}
  async function loadMoveFolders(){
    const picker=moveDraft;if(!picker||!ownsManagement(picker)||writeBusy)return;const serial=++moveSerial;picker.busy=true;managementControls();$('moveFolders').textContent='폴더를 불러오는 중…';$('movePage').textContent=(picker.page+1)+'페이지';$('moveCrumbs').replaceChildren();
    picker.crumbs.forEach((crumb,index)=>{const button=document.createElement('button');button.type='button';button.textContent=crumb.name;button.disabled=index===picker.crumbs.length-1;button.onclick=()=>{if(moveDraft!==picker||writeBusy)return;picker.crumbs=picker.crumbs.slice(0,index+1);picker.page=0;loadMoveFolders()};$('moveCrumbs').append(button)});
    try{
      const destination=picker.crumbs[picker.crumbs.length-1]?.id,response=await invoke('files',{driveId:picker.driveId,...(destination?{parentId:destination}:{}),page:picker.page,accountTag:picker.accountTag});
      if(moveDraft!==picker||serial!==moveSerial||!ownsManagement(picker))return;if(!Array.isArray(response?.items))throw Error('폴더 목록을 확인하지 못했습니다.');picker.hasNext=response.hasNext===true;$('moveFolders').replaceChildren();
      const folders=response.items.filter(entry=>entry?.isFolder===true&&id(entry.id)&&typeof entry.name==='string').slice(0,2000);
      for(const folder of folders){const button=document.createElement('button');button.type='button';button.textContent='▱ '+folder.name;button.onclick=()=>{if(moveDraft!==picker||writeBusy||picker.busy)return;picker.crumbs.push({id:id(folder.id),name:folder.name.slice(0,1000)});picker.page=0;loadMoveFolders()};$('moveFolders').append(button)}
      if(!folders.length)$('moveFolders').textContent=picker.hasNext?'이 페이지에는 폴더가 없습니다. 다음 페이지를 확인해 주세요.':'이 위치에는 하위 폴더가 없습니다.';
    }catch(error){if(moveDraft===picker&&serial===moveSerial&&ownsManagement(picker)){$('moveFolders').textContent='폴더 목록을 불러오지 못했습니다.';$('moveNote').textContent=errorText(error);picker.hasNext=false;}}
    finally{if(moveDraft===picker&&serial===moveSerial){picker.busy=false;managementControls();$('destinationPicker').scrollIntoView?.({block:'nearest'});}}
  }
  async function saveMove(){const picker=moveDraft;if(!picker||picker.busy||!ownsManagement(picker)||!managementReady())return;const root=picker.crumbs.length===1,destinationId=root?null:picker.crumbs[picker.crumbs.length-1].id;if(picker.root&&root||!root&&destinationId===picker.parentId)return;await writeManagement(picker,'move',{driveId:picker.driveId,fileId:picker.fileId,destinationId});}
  async function trash(entry){if(!managementReady())return;navigation();const owner=managementOwner(entry),accepted=await confirmAction('휴지통으로 이동할까요?',entry.name+(entry.isFolder?' 폴더와 그 안의 모든 항목을':' 파일을')+' 휴지통으로 이동합니다. 두레이 휴지통에서 복원할 수 있습니다.','휴지통으로 이동');if(!accepted||!ownsManagement(owner)||!managementReady())return;await writeManagement(owner,'trash',{driveId:owner.driveId,fileId:owner.fileId,confirmed:true});}
  function encode(bytes){let binary='';for(let offset=0;offset<bytes.length;offset+=32768)binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));return win.btoa(binary)}
  const readFile=async(key,offset,length)=>{const entry=files.get(key);if(disposed||typeof key!=='string'||!entry||entry.state!=='running'||entry.accountTag!==accountTag||!entry.file||readFlights>=2||!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset<0||length<0||length>chunkLimit||offset+length>entry.file.size)throw Error('허용되지 않은 파일 읽기 요청입니다.');readFlights++;try{const data=await entry.file.slice(offset,offset+length).arrayBuffer();if(data.byteLength!==length)throw Error('파일 읽기 크기가 올바르지 않습니다.');if(disposed||files.get(key)!==entry||entry.state!=='running'||entry.accountTag!==accountTag)throw Error('파일 전송이 취소되었습니다.');return encode(new Uint8Array(data));}finally{readFlights--}};
  win.__doorayDriveReadFile=readFile;
  function removeHistory(entry){if(disposed||!['done','failed','cancelled'].includes(entry.state)||currentUpload===entry)return;entry.historyRemoved=true;const index=queue.indexOf(entry);if(index>=0)queue.splice(index,1);for(const [key,value]of jobs)if(value===entry)jobs.delete(key);releaseFile(entry);renderQueue();}
  function renderQueue(){if(disposed)return;const all=[...queue,...[...jobs.values()].filter(entry=>entry.kind==='download')];$('queue').hidden=!all.length;$('queueCount').textContent=String(all.length);$('jobs').replaceChildren();for(const entry of all){const row=document.createElement('div');row.className='job';row.dataset.state=entry.state;row.dataset.kind=entry.kind;const info=document.createElement('div'),name=document.createElement('div'),note=document.createElement('small');name.className='job-name';name.textContent=(entry.kind==='download'?'↓ ':'↑ ')+entry.name;const labels={queued:'대기',starting:'준비 중',running:'전송 중',done:'완료',failed:'실패',cancelled:'취소됨'};note.textContent=(labels[entry.state]||'확인 중')+' · '+formatSize(entry.bytes||0)+' / '+formatSize(entry.total)+(entry.destination?' · '+entry.destination:'')+(entry.error?' · '+entry.error:'');info.append(name,note);if(entry.state==='running'||entry.state==='starting'){const progress=document.createElement('progress');progress.max=entry.total||1;if(entry.total)progress.value=Math.min(entry.total,entry.bytes||0);progress.setAttribute('aria-label',entry.name+' 전송 진행률');info.append(progress)}row.append(info);if(['queued','starting','running'].includes(entry.state)){const cancel=document.createElement('button');cancel.type='button';cancel.textContent='취소';cancel.onclick=()=>cancelEntry(entry);row.append(cancel)}else if(['done','failed','cancelled'].includes(entry.state)&&currentUpload!==entry){const remove=document.createElement('button');remove.type='button';remove.className='history-remove';remove.textContent='×';remove.title='이 기록만 삭제 (파일은 유지)';remove.setAttribute('aria-label',entry.name+' 전송 기록 삭제');remove.onclick=()=>removeHistory(entry);row.append(remove)}$('jobs').append(row)}controls();}
  function updateDownloads(state){if(disposed||typeof state?.folder!=='string'||!state.folder||state.folder.length>32767||/[\x00-\x1f\x7f]/.test(state.folder))return false;$('downloadFolderPath').textContent='저장 위치: '+state.folder;return true;}
  function folderControls(){for(const key of ['openDownloadFolder','chooseDownloadFolder','resetDownloadFolder'])$(key).disabled=folderBusy||typeof downloads!=='function';}
  async function folderAction(op){
    if(disposed||folderBusy||typeof downloads!=='function'||!['list','open-current-folder','choose-folder','reset-folder'].includes(op))return;
    const serial=++folderSerial;folderBusy=true;folderControls();$('downloadFolderStatus').textContent=op==='choose-folder'?'폴더 선택 창에서 저장 위치를 선택해 주세요…':op==='list'?'저장 위치를 확인하는 중…':'처리 중…';
    try{const result=await downloads(op);if(disposed||serial!==folderSerial)return;if(op==='open-current-folder'){if(result!==true)throw Error('폴더 열기 결과를 확인하지 못했습니다.');$('downloadFolderStatus').textContent='폴더 열기를 요청했습니다.';}else{if(!updateDownloads(result))throw Error('다운로드 저장 위치를 확인하지 못했습니다.');$('downloadFolderStatus').textContent=op==='list'?'':'새 다운로드부터 이 위치에 저장합니다.';}}
    catch(error){if(!disposed&&serial===folderSerial)$('downloadFolderStatus').textContent=errorText(error);}
    finally{if(!disposed&&serial===folderSerial){folderBusy=false;folderControls();}}
  }
  function releaseFile(entry){if(entry.key)files.delete(entry.key);entry.file=null;}
  function finishUpload(entry){if(currentUpload!==entry)return;currentUpload=null;uploadBusy=false;runUpload();}
  function trimHistory(){while(queue.length>historyLimit){const index=queue.findIndex(entry=>['done','failed','cancelled'].includes(entry.state));if(index<0)break;const [entry]=queue.splice(index,1);releaseFile(entry);if(entry.id)jobs.delete(entry.id)}while(jobs.size>historyLimit){const old=[...jobs].find(([,entry])=>['done','failed','cancelled'].includes(entry.state));if(!old)break;jobs.delete(old[0]);}}
  function cancelEntry(entry){if(entry.state==='done'||entry.state==='failed'||entry.state==='cancelled')return;entry.state='cancelled';if(entry.id)abandon(entry.id,entry.accountTag);releaseFile(entry);if(entry.kind==='upload'&&entry.id)finishUpload(entry);renderQueue();}
  function schedulePoll(){if(disposed||pollTimer||pollBusy||![...jobs.values()].some(entry=>entry.state==='running'))return;pollTimer=win.setTimeout(pollJobs,700);}
  async function pollJobs(){pollTimer=0;if(disposed||pollBusy)return;pollBusy=true;try{for(const [jobId,entry]of [...jobs]){if(disposed)return;if(entry.state!=='running')continue;try{const result=await invoke('job',{id:jobId,accountTag:entry.accountTag});if(disposed||jobs.get(jobId)!==entry||entry.state!=='running')continue;if(!['running','done','failed','cancelled'].includes(result?.state))throw Error('전송 상태를 확인하지 못했습니다.');entry.bytes=Math.max(entry.bytes||0,size(result.bytes));entry.total=size(result.total)||entry.total;if(typeof result.name==='string'&&result.name)entry.name=result.name.slice(0,1000);entry.state=result.state;if(entry.state==='failed')entry.error=errorText({message:result.error});if(entry.state!=='running'){releaseFile(entry);if(entry.kind==='upload'){if(entry.state==='done'){invalidateListings(entry.driveId,entry.parentId);if(drive?.id===entry.driveId&&parentId()===entry.parentId)loadFiles();}finishUpload(entry)}}}catch(error){if(disposed)return;if(jobs.get(jobId)!==entry||entry.state!=='running')continue;entry.state='failed';entry.error=errorText(error);abandon(jobId,entry.accountTag);releaseFile(entry);if(entry.kind==='upload')finishUpload(entry)}}trimHistory();renderQueue();}finally{pollBusy=false;schedulePoll()}}
  function addFiles(selected){if(!configured||!drive||checking||keyBusy||writeBusy){setStatus('먼저 드라이브 연결을 확인해 주세요.',true);return}const pending=queue.filter(entry=>['queued','starting','running'].includes(entry.state)).length,available=Math.max(0,queueLimit-pending),chosen=[...selected].slice(0,available);let added=0,rejected=0;for(const file of chosen){if(!file||typeof file.name!=='string'||file.name.length>1000||!Number.isSafeInteger(file.size)||file.size<0||file.size>transferLimit||typeof file.slice!=='function'){rejected++;continue}queue.push({kind:'upload',file,name:file.name,total:file.size,bytes:0,state:'queued',accountTag,driveId:drive.id,parentId:parentId(),destination:crumbs.map(crumb=>crumb.name).join(' / ')});added++}trimHistory();setStatus(added+'개 파일을 대기열에 추가했습니다. 업로드 시작을 눌러 주세요.'+([...selected].length>available?' 대기열은 최대 20개입니다.':'')+(rejected?' 올릴 수 없는 파일은 제외했습니다. 파일당 최대 1GB입니다.':''));renderQueue();}
  async function runUpload(){if(disposed||uploadBusy||checking||keyBusy||writeBusy)return;const entry=queue.find(item=>item.state==='queued'&&item.startRequested);if(!entry)return;if(entry.accountTag!==accountTag){entry.state='cancelled';releaseFile(entry);runUpload();renderQueue();return}uploadBusy=true;currentUpload=entry;entry.state='running';entry.key=win.crypto.randomUUID();files.set(entry.key,entry);renderQueue();try{const result=await invoke('upload',{driveId:entry.driveId,...(entry.parentId?{parentId:entry.parentId}:{}),fileKey:entry.key,name:entry.name,size:entry.total,accountTag:entry.accountTag});const jobId=id(result?.id);if(disposed||entry.state==='cancelled'||entry.accountTag!==accountTag){abandon(jobId,entry.accountTag);finishUpload(entry);return}if(!jobId)throw Error('업로드를 시작하지 못했습니다.');entry.id=jobId;jobs.set(jobId,entry);schedulePoll();}catch(error){if(disposed)return;if(entry.state!=='cancelled'&&entry.accountTag===accountTag){entry.state='failed';entry.error=errorText(error)}releaseFile(entry);finishUpload(entry);renderQueue();}}
  async function download(entry,driveId=drive?.id){if(!driveId||checking||keyBusy||writeBusy)return;if([...jobs.values()].filter(job=>['running','starting'].includes(job.state)).length>=20){setStatus('진행 중인 전송을 마친 뒤 다시 시도해 주세요.',true);return}const epoch=generation,tag=accountTag,target={driveId,fileId:entry.id,accountTag:tag},job={kind:'download',name:entry.name,total:size(entry.size),bytes:0,state:'starting',accountTag:tag};const key=win.crypto.randomUUID();jobs.set(key,job);trimHistory();renderQueue();try{const result=await invoke('download',target);jobs.delete(key);const jobId=id(result?.id);if(disposed||epoch!==generation||job.state==='cancelled'){abandon(jobId,tag);return}if(!jobId)throw Error('다운로드를 시작하지 못했습니다.');job.id=jobId;job.state='running';jobs.set(jobId,job);schedulePoll();renderQueue();}catch(error){if(disposed||epoch!==generation||job.historyRemoved)return;if(job.state!=='cancelled'){job.state='failed';job.error=errorText(error)}jobs.set(key,job);renderQueue();setStatus(job.error||'다운로드를 취소했습니다.',job.state==='failed')}}
  async function showPreview(entry){if(!drive||checking||keyBusy||writeBusy)return;closePreview();closeShare();const stamp=previewSerial,epoch=generation,tag=accountTag,target={driveId:drive.id,fileId:entry.id,accountTag:tag};previewFile={...entry,driveId:drive.id,accountTag:tag};$('preview').hidden=false;$('previewName').textContent=entry.name;$('previewNote').textContent='미리보기를 준비하는 중…';let session=null;try{const result=await invoke('preview',target);session=id(result?.id);if(disposed||epoch!==generation||stamp!==previewSerial){abandon(session,tag);return}if(result?.kind==='text'){if(typeof result.text!=='string'||new win.TextEncoder().encode(result.text).length>256*1024)throw Error('텍스트 미리보기는 256KB까지 지원합니다.');const pre=document.createElement('pre');pre.textContent=result.text;$('previewContent').append(pre);$('previewNote').textContent='텍스트 미리보기 · 최대 256KB';return}const kind=result?.kind,mime=text(result?.mime).split(';')[0].toLowerCase(),allowed={image:['image/png','image/jpeg','image/gif','image/webp','image/bmp','image/avif'],video:['video/mp4','video/webm','video/ogg'],pdf:['application/pdf']},limit=kind==='video'?64*MiB:16*MiB;if(!session||!allowed[kind]?.includes(mime)||!Number.isSafeInteger(result.size)||result.size<0||result.size>limit)throw Error('미리보기는 이미지·PDF 16MB, 영상 64MB까지 지원합니다.');activePreview={id:session,accountTag:tag};const chunks=[];let offset=0,done=false;while(!done){const part=await invoke('preview-chunk',{id:session,offset,accountTag:tag});if(disposed||epoch!==generation||stamp!==previewSerial)return;const base64=part?.base64;if(typeof base64!=='string'||base64.length>Math.ceil(chunkLimit/3)*4||base64.length%4||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(base64))throw Error('미리보기 데이터를 확인하지 못했습니다.');const binary=win.atob(base64),bytes=Uint8Array.from(binary,char=>char.charCodeAt(0));if(bytes.length>chunkLimit||offset+bytes.length>result.size||!bytes.length&&!part.done)throw Error('미리보기 데이터 크기가 올바르지 않습니다.');chunks.push(bytes);offset+=bytes.length;done=part.done===true;$('previewNote').textContent='미리보기 준비 중 · '+formatSize(offset)+' / '+formatSize(result.size);}if(offset!==result.size)throw Error('미리보기 파일이 완전히 도착하지 않았습니다.');const blob=new win.Blob(chunks,{type:mime});if(typeof win.URL.createObjectURL!=='function')throw Error('이 환경에서는 미리보기를 지원하지 않습니다. 다운로드를 이용해 주세요.');blobURL=win.URL.createObjectURL(blob);let media;if(kind==='image'){media=document.createElement('img');media.alt=entry.name}else if(kind==='video'){media=document.createElement('video');media.controls=true;media.preload='metadata';media.playsInline=true}else{media=document.createElement('iframe');media.title=entry.name+' PDF 미리보기';media.setAttribute('sandbox','');media.referrerPolicy='no-referrer'}media.src=blobURL;$('previewContent').append(media);$('previewNote').textContent=kind==='pdf'?'PDF가 표시되지 않으면 다운로드해 주세요.':'미리보기';media.addEventListener('error',()=>{if(stamp===previewSerial)$('previewNote').textContent='미리보기를 표시하지 못했습니다. 다운로드를 이용해 주세요.'},{once:true});}catch(error){if(!disposed&&epoch===generation&&stamp===previewSerial)$('previewNote').textContent=errorText(error);}finally{if(session)abandon(session,tag);if(activePreview?.id===session&&activePreview.accountTag===tag)activePreview=null}}
  const shareScopes={member:'조직 내 구성원',memberAndGuest:'조직 내 구성원 및 손님',memberAndGuestAndExternal:'링크가 있는 누구나'};
  const localDateTime=value=>{const date=new win.Date(value),pad=value=>String(value).padStart(2,'0');return date.getFullYear()+'-'+pad(date.getMonth()+1)+'-'+pad(date.getDate())+'T'+pad(date.getHours())+':'+pad(date.getMinutes());};
  function currentShare(state){return !!state&&shareState===state&&state.serial===shareSerial&&ownsManagement(state.owner);}
  function shareScopeNote(){const external=$('shareScope').value==='memberAndGuestAndExternal';$('shareAccess').toggleAttribute('data-public',external);$('shareAccess').textContent=external?'링크를 전달받은 외부인도 파일에 접근할 수 있습니다. 공개 범위를 확인한 뒤 생성해 주세요.':$('shareScope').value==='memberAndGuest'?'조직 내 구성원과 손님이 접근할 수 있는 링크를 만듭니다.':'조직 내 구성원에게 공유할 링크를 만듭니다.';}
  function shareControls(){
    const state=shareState,busy=!currentShare(state)||!state?.ready||state.loading||state.creating||checking||keyBusy||writeBusy;
    $('shareScope').disabled=busy;
    $('shareExpiry').disabled=busy;
    $('shareCreate').disabled=busy;
    $('shareChoices').disabled=busy;
    $('copy').disabled=!$('shareUrl').value;
  }
  function normalizeShareLink(result,created=false){
    const url=new win.URL(text(result?.url));
    if(url.protocol!=='https:'||url.username||url.password||url.href.length>4096||!Object.hasOwn(shareScopes,result?.scope))throw Error('공유 링크 응답을 확인하지 못했습니다.');
    const expiry=typeof result.expiredAt==='string'?new win.Date(result.expiredAt):null;
    return {url:url.href,scope:result.scope,created,expiry:expiry&&Number.isFinite(expiry.getTime())?expiry:null};
  }
  function showShareLink(link){
    $('shareKind').textContent=link.created?'생성한 링크':'기존 공유 링크';
    $('shareUrl').value=link.url;
    $('shareUrl').hidden=false;
    $('copy').hidden=false;
    $('shareInfo').textContent=shareScopes[link.scope]+' · '+(link.expiry?'만료: '+link.expiry.toLocaleString():'만료 정보가 제공되지 않았습니다.');
  }
  function renderShareChoices(state,selected){
    const choices=$('shareChoices');
    choices.replaceChildren();
    for(const [index,link] of state.links.entries()){
      const option=document.createElement('option');
      option.value=String(index);
      option.textContent=shareScopes[link.scope]+' · '+(link.expiry?link.expiry.toLocaleString():'링크 '+(index+1));
      choices.append(option);
    }
    choices.hidden=state.links.length<2;
    if(selected>=0){
      choices.value=String(selected);
      showShareLink(state.links[selected]);
    }
  }
  async function share(entry){
    if(!drive||checking||keyBusy||writeBusy)return;
    navigation();const state={owner:managementOwner(entry),serial:shareSerial,loading:true,ready:false,creating:false,links:[]};shareState=state;
    $('shareName').textContent=entry.name+' · 공유 링크';$('shareKind').textContent='기존 공유 링크';$('shareInfo').textContent='기존 공유 링크를 확인하는 중…';
    $('shareExpiry').value=localDateTime(win.Date.now()+7*24*60*60*1000);$('shareExpiry').min=localDateTime(win.Date.now()+60000);shareScopeNote();$('share').hidden=false;shareControls();$('share').scrollIntoView?.({block:'nearest'});
    try{
      const result=await invoke('share',{driveId:state.owner.driveId,fileId:state.owner.fileId,create:false,accountTag:state.owner.accountTag});
      if(!currentShare(state))return;
      if(!Array.isArray(result?.links)||result.links.length>2000)throw Error('공유 링크 응답을 확인하지 못했습니다.');
      state.links=result.links.map(link=>normalizeShareLink(link));
      const preferred=['member','memberAndGuest','memberAndGuestAndExternal'].find(scope=>state.links.some(link=>link.scope===scope));
      const selected=state.links.findIndex(link=>link.scope===preferred);
      const advanced=Number.isSafeInteger(result.unsupportedCount)&&result.unsupportedCount>0;
      renderShareChoices(state,selected);
      if(advanced)$('shareNotice').textContent='고급 공유 링크는 두레이의 공식 공유 화면에서 확인할 수 있습니다.';
      if(selected<0)$('shareInfo').textContent=advanced?'두레이에서 확인할 기존 링크가 있습니다.':'현재 사용할 수 있는 공유 링크가 없습니다.';
      state.ready=true;
      setStatus(selected>=0?'공개 범위를 확인한 뒤 링크 복사를 눌러 주세요.':advanced?'두레이에서 고급 공유를 열어 링크를 확인해 주세요.':'공개 범위와 만료 일시를 선택한 뒤 새 링크 생성을 눌러 주세요.');
    }catch(error){if(currentShare(state)){$('shareError').textContent=errorText(error);$('shareInfo').textContent='기존 공유 링크를 확인하지 못했습니다.';setStatus(errorText(error),true);}}
    finally{if(currentShare(state)){state.loading=false;shareControls();}}
  }
  async function createShareLink(){
    const state=shareState;if(!currentShare(state)||!state.ready||state.loading||state.creating||checking||keyBusy||writeBusy)return;
    const scope=$('shareScope').value,expiry=new win.Date($('shareExpiry').value);
    if(!Object.hasOwn(shareScopes,scope)||!$('shareExpiry').value||!Number.isFinite(expiry.getTime())||expiry.getTime()<=win.Date.now()){$('shareError').textContent='현재 시각 이후의 만료 일시를 입력해 주세요.';return;}
    const expiredAt=expiry.toISOString();$('shareError').textContent='';
    const owner=state.owner;state.creating=true;writeBusy=true;pendingWrite=owner;controls();renderCrumbs();managementControls();setStatus('공유 링크를 만드는 중…');
    try{
      const result=await invoke('share',{driveId:owner.driveId,fileId:owner.fileId,create:true,scope,expiredAt,confirmed:true,accountTag:owner.accountTag});
      if(!currentShare(state))return;
      const link=normalizeShareLink(result,true);
      state.links=[link,...state.links.filter(existing=>existing.url!==link.url)];
      renderShareChoices(state,0);
      $('shareError').textContent='';
      setStatus('공유 링크를 만들었습니다. 공개 범위와 만료 일시를 확인한 뒤 복사해 주세요.');
    }catch(error){if(currentShare(state)){$('shareError').textContent=errorText(error);setStatus(errorText(error),true);}}
    finally{state.creating=false;if(pendingWrite===owner){pendingWrite=null;writeBusy=false;if(!disposed){controls();renderCrumbs();managementControls();runUpload();}}if(currentShare(state))shareControls();}
  }
  async function changeCredentials(forget=false) {
    if (keyBusy || checking || writeBusy || disposed) return;
    if (transferActive()) {
      setStatus('진행 중인 전송을 마친 뒤 키를 변경해 주세요.', true);
      return;
    }
    if (forget && !await confirmAction('API 키를 삭제할까요?', '이 컴퓨터에 저장한 API 키를 지웁니다. 대기 중인 업로드 목록도 비웁니다.', '키 삭제')) return;
    if (disposed || keyBusy || checking || writeBusy || transferActive()) return;
    keyBusy = true;
    controls();
    setStatus(forget ? '저장한 API 키를 삭제하는 중…' : 'Windows 인증 창을 여는 중… 열린 창에서 키를 입력하거나 취소해 주세요.');
    try {
      const response = await invoke(forget ? 'forget-key' : 'credentials');
      if (disposed) return;
      if (response?.cancelled) {
        setStatus('키 입력을 취소했습니다.');
        return;
      }
      if (response?.configured !== !forget) throw Error('API 키 처리 결과를 확인하지 못했습니다. 다시 시도해 주세요.');
      resetSession(null);
      configured = response.configured;
      initialized = false;
      setStatus(forget ? '저장한 API 키를 삭제했습니다.' : 'API 키를 저장했습니다.');
    } catch (error) {
      setStatus(errorText(error), true);
    } finally {
      if (!disposed) {
        keyBusy = false;
        controls();
        if (!initialized) connect();
      }
    }
  }
  function closePanel(){closeManagement();$('panel').hidden=true;$('toggle').setAttribute('aria-expanded','false');closeConfirmation();closePreview();closeShare();}
  function position(){if(!anchor)return;const floating=anchor.hasAttribute('data-floating');host.toggleAttribute('data-floating',floating);for(const [key,value]of Object.entries({position:floating?'fixed':'',right:floating?'0px':'',top:floating?Math.max(0,anchor.getBoundingClientRect().bottom+2)+'px':'',zIndex:floating?'5058':''}))host.style[key]=value;}
  $('toggle').onclick=()=>{const opening=$('panel').hidden;if(!opening){closePanel();return}$('panel').hidden=false;$('toggle').setAttribute('aria-expanded','true');connect(true)};$('close').onclick=closePanel;$('credentials').onclick=()=>changeCredentials();$('forget').onclick=()=>changeCredentials(true);$('refresh').onclick=refreshFolder;$('moreDrives').onclick=()=>loadDrives(true);$('drives').onchange=()=>{const selected=drives.find(entry=>entry.id===$('drives').value);if(!selected)return;navigation();drive=selected;crumbs=[{id:drive.rootId,name:drive.name}];loadFiles()};$('confirmCancel').onclick=()=>closeConfirmation();$('confirmAccept').onclick=()=>closeConfirmation(true);$('shareClose').onclick=closeShare;$('previewClose').onclick=closePreview;$('previewDownload').onclick=()=>{if(previewFile&&previewFile.accountTag===accountTag)download(previewFile,previewFile.driveId)};$('copy').onclick=async()=>{const value=$('shareUrl').value;if(!value)return;try{if(typeof win.navigator.clipboard?.writeText!=='function')throw Error('Clipboard unavailable');await win.navigator.clipboard.writeText(value);setStatus('공유 링크를 복사했습니다.')}catch{if(!disposed){$('shareUrl').focus();$('shareUrl').select();setStatus('공유 주소가 선택되었습니다. Ctrl+C로 복사해 주세요.')}}};$('choose').onclick=()=>$('picker').click();$('picker').onchange=()=>{addFiles($('picker').files||[]);$('picker').value=''};$('start').onclick=()=>{for(const entry of queue)if(entry.state==='queued')entry.startRequested=true;runUpload()};$('clearQueue').onclick=()=>{for(let index=queue.length-1;index>=0;index--)if(['done','failed','cancelled'].includes(queue[index].state)){releaseFile(queue[index]);queue.splice(index,1)}for(const [key,entry]of jobs)if(['done','failed','cancelled'].includes(entry.state))jobs.delete(key);renderQueue()};
  $('fileView').onchange=()=>{
    const next=$('fileView').value;
    if(!fileTypes.has(next)||next===fileView||!managementReady())return;
    navigation();
    fileView=next;
    loadFiles();
  };
  $('moreFiles').onclick=()=>{if(activeListing&&!checking&&!keyBusy&&!writeBusy)loadMoreFiles(activeListing);};
  $('files').addEventListener('scroll',()=>{
    const list=$('files'),top=list.scrollTop,down=top>lastFileScroll;
    lastFileScroll=top;
    if(down&&!$('panel').hidden&&!checking&&!keyBusy&&!writeBusy&&!activeListing?.failed&&
       list.scrollHeight-top-list.clientHeight<=80)loadMoreFiles(activeListing);
  },{passive:true});
  $('shareScope').onchange=shareScopeNote;$('shareCreate').onclick=createShareLink;
  $('shareChoices').onchange=()=>{
    const state=shareState,selected=state?.links[$('shareChoices').selectedIndex];
    if(currentShare(state)&&selected)showShareLink(selected);
  };
  for(const [key,op]of [['openDownloadFolder','open-current-folder'],['chooseDownloadFolder','choose-folder'],['resetDownloadFolder','reset-folder']])$(key).onclick=()=>folderAction(op);
  $('downloadSettings').onclick=()=>{const open=$('downloadFolderSettings').hidden;$('downloadFolderSettings').hidden=!open;$('downloadSettings').setAttribute('aria-expanded',String(open));};
  $('toggle').addEventListener('click',()=>{if(!$('panel').hidden)folderAction('list');});folderControls();if(typeof downloads!=='function')$('downloadFolderStatus').textContent='다운로드 연결을 확인해 주세요.';
  $('newFolder').onclick=()=>openName('create-folder');$('nameSave').onclick=saveName;$('nameCancel').onclick=()=>closeManagement();$('moveCancel').onclick=()=>closeManagement();$('moveSave').onclick=saveMove;$('movePrevious').onclick=()=>{if(moveDraft&&!moveDraft.busy&&!writeBusy&&moveDraft.page>0){moveDraft.page--;loadMoveFolders()}};$('moveNext').onclick=()=>{if(moveDraft&&!moveDraft.busy&&!writeBusy&&moveDraft.hasNext){moveDraft.page++;loadMoveFolders()}};
  const drag=event=>{event.preventDefault();event.stopPropagation();if(event.type==='dragover')$('drop').setAttribute('data-drag','');else $('drop').removeAttribute('data-drag');if(event.type==='drop'){const items=[...(event.dataTransfer?.items||[])];if(items.some(item=>item.webkitGetAsEntry?.()?.isDirectory)){setStatus('폴더 대신 파일을 선택해 주세요.',true);return}addFiles(event.dataTransfer?.files||[])}};for(const type of ['dragover','dragleave','drop'])$('drop').addEventListener(type,drag);for(const type of ['dragover','drop'])shadow.addEventListener(type,drag);
  const isolate=event=>{
    event.stopPropagation();
    if(event.type!=='keydown')return;
    if(event.isComposing||event.keyCode===229)return;
    if(event.key==='Enter'&&event.target===$('entryName')){
      event.preventDefault();
      if(!event.repeat&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey)saveName();
      return;
    }
    if(event.key!=='Escape')return;
    event.preventDefault();
    const menu=shadow.querySelector('.item-menu[open]');
    if(confirmResolve)closeConfirmation();
    else if(!$('nameEditor').hidden||!$('destinationPicker').hidden)closeManagement();
    else if(!$('preview').hidden)closePreview();
    else if(menu){
      menu.open=false;
      menu.querySelector('summary').focus({preventScroll:true});
    }else closePanel();
  };
  for(const type of ['keydown','keyup','keypress'])shadow.addEventListener(type,isolate,true);
  const dismiss=event=>{if(!$('panel').hidden&&!event.composedPath().includes(host))closePanel()};document.addEventListener('pointerdown',dismiss,true);win.addEventListener('resize',position);empty('API 키를 등록하면 드라이브를 볼 수 있습니다.');controls();
  return {updateDownloads,mount(downloadHost){if(disposed||!downloadHost?.isConnected||downloadHost.ownerDocument!==document)return;anchor=downloadHost;if(host.previousElementSibling!==anchor)anchor.insertAdjacentElement('afterend',host);position();return host;},dispose(){if(disposed)return;generation++;listSerial++;pendingWrite=null;writeBusy=false;closeManagement(true);closeConfirmation();closePreview();closeShare();disposed=true;if(pollTimer)win.clearTimeout(pollTimer);pollTimer=0;for(const [jobId,entry]of jobs){if(entry.state==='running'||entry.state==='starting')abandon(entry.id||jobId,entry.accountTag);releaseFile(entry)}for(const entry of queue)releaseFile(entry);files.clear();clearListings();jobs.clear();queue.splice(0);drives=[];drive=null;crumbs=[];anchor=null;document.removeEventListener('pointerdown',dismiss,true);win.removeEventListener('resize',position);for(const type of ['keydown','keyup','keypress'])shadow.removeEventListener(type,isolate,true);if(win.__doorayDriveReadFile===readFile)delete win.__doorayDriveReadFile;host.remove();}};
}

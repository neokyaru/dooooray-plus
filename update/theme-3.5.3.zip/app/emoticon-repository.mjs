// Public, read-only GitLab access. No Dooray cookies or messages leave this helper.
const PROJECT='neokyaru/dooooraytheme';
const API='https://gitlab.com/api/v4/projects/'+encodeURIComponent(PROJECT);
const MAX_IMAGE=8*1024*1024, MAX_JSON=1024*1024;
const IMAGE=/\.(png|gif|jpe?g|webp)$/i;
export function repositoryPath(value){
  if(typeof value!=='string'||value.length>1000||value.startsWith('/')||/[\\\x00-\x1f]/.test(value)||value.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('잘못된 이모티콘 경로입니다.');
  return value;
}
export function imageType(bytes){
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';
  if(/^GIF8[79]a$/.test(bytes.subarray(0,6).toString()))return 'image/gif';
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
  if(bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP')return 'image/webp';
  throw Error('지원하지 않는 이미지 파일입니다.');
}
export function normalizePack(manifest,manifestPath,ref){
  const base=manifestPath.slice(0,manifestPath.lastIndexOf('/')+1);
  const resolve=f=>repositoryPath(f.startsWith('packs/')?f:base+f);
  if(!manifest||!Array.isArray(manifest.items||manifest.emoticons))throw Error(manifestPath+': items 목록이 필요합니다.');
  const seen=new Set();const items=(manifest.items||manifest.emoticons).slice(0,500).map((item,index)=>{
    if(typeof item==='string')item={file:item};
    const path=resolve(item.file||item.path||'');if(!path.startsWith('packs/')||!IMAGE.test(path))throw Error('PNG/GIF/JPG/WebP만 등록할 수 있습니다.');
    const id=String(item.id||index+1);if(seen.has(id))throw Error('팩 안에 중복 ID가 있습니다.');seen.add(id);
    return {id,path,ref,label:String(item.label||item.name||path.split('/').pop()).slice(0,100)};
  });
  const icon=manifest.icon?resolve(manifest.icon):items[0]?.path;
  return {id:String(manifest.id||base),name:String(manifest.name||manifest.id||base.split('/').filter(Boolean).pop()).slice(0,100),icon,ref,items};
}
export function createEmoticonRepository({fetcher=fetch}={}){
  let catalogCache=null,catalogAt=0,catalogPending=null,cacheBytes=0,active=0;const waiting=[],assets=new Map(),inflight=new Map();
  async function limited(fn){if(active>=4)await new Promise(r=>waiting.push(r));else active++;try{return await fn()}finally{const next=waiting.shift();if(next)next();else active--;}}
  async function request(route,max=MAX_JSON){
    const response=await fetcher(API+route,{signal:AbortSignal.timeout(20000),redirect:'error',credentials:'omit'});
    if(!response.ok){const error=Error(response.status===404?'저장소 또는 목록 파일이 아직 없거나 공개되지 않았습니다.':response.status===429?'GitLab 요청이 많습니다. 잠시 후 다시 시도해 주세요.':'GitLab 읽기 실패 ('+response.status+')');error.status=response.status;throw error;}
    if(Number(response.headers.get('content-length'))>max)throw Error('이모티콘 파일이 너무 큽니다.');
    let size=0;const chunks=[];for await(const chunk of response.body){size+=chunk.length;if(size>max)throw Error('이모티콘 파일이 너무 큽니다.');chunks.push(Buffer.from(chunk));}
    return Buffer.concat(chunks);
  }
  const raw=(p,ref,max)=>request('/repository/files/'+encodeURIComponent(repositoryPath(p))+'/raw?ref='+encodeURIComponent(ref),max);
  const json=async(p,ref)=>JSON.parse((await raw(p,ref,MAX_JSON)).toString('utf8').replace(/^\uFEFF/,''));
  async function readCatalog(){
    const commit=JSON.parse((await request('/repository/commits/HEAD')).toString());const ref=commit.id;
    if(!/^[a-f\d]{40}$/i.test(ref))throw Error('GitLab 버전 정보를 읽지 못했습니다.');
    let catalog;try{catalog=await json('catalog.json',ref)}catch(e){if(e.status!==404)throw e;catalog=await json('packs.json',ref)}
    if(typeof catalog.packs==='string')catalog={...catalog,packs:await json(catalog.packs,ref)};
    const entries=Array.isArray(catalog)?catalog:Array.isArray(catalog.packs)?catalog.packs:catalog.packs?.packs;
    if(!Array.isArray(entries))throw Error('catalog.json에 packs 배열이 필요합니다.');
    const packs=[],warnings=[];
    for(const entry of entries.slice(0,100)){
      try{
        let file,manifest;
        if(typeof entry==='string')file=entry.endsWith('.json')?entry:entry.replace(/\/$/,'')+'/pack.json';
        else {file=entry.manifest||((entry.path||entry.folder||('packs/'+entry.id)).replace(/\/$/,'')+'/pack.json');if(Array.isArray(entry.items||entry.emoticons))manifest=entry;}
        file=repositoryPath(file);if(!file.startsWith('packs/'))throw Error('팩은 packs 폴더 아래에 두어 주세요.');
        if(!manifest){try{manifest=await json(file,ref)}catch(e){if(e.status!==404||!file.endsWith('/pack.json'))throw e;file=file.replace(/\/pack.json$/,'/packs.json');manifest=await json(file,ref)}}
        packs.push(normalizePack(manifest,file,ref));
      }catch(e){warnings.push(e.message)}
    }
    if(!packs.length)throw Error(warnings[0]||'등록된 이모티콘 팩이 없습니다.');
    return {repository:PROJECT,ref,packs,warnings};
  }
  async function catalog(refresh=false){
    if(!refresh&&catalogCache&&Date.now()-catalogAt<300000)return catalogCache;
    if(catalogPending)return catalogPending;
    catalogPending=readCatalog().then(x=>{catalogCache=x;catalogAt=Date.now();return x}).finally(()=>{catalogPending=null});return catalogPending;
  }
  async function image(p,ref){
    p=repositoryPath(p);if(!p.startsWith('packs/')||!IMAGE.test(p)||!/^[a-f\d]{40}$/i.test(ref))throw Error('유효하지 않은 이모티콘입니다.');
    const key=ref+'/'+p;if(assets.has(key))return assets.get(key).result;if(inflight.has(key))return inflight.get(key);
    const promise=limited(async()=>{const bytes=await raw(p,ref,MAX_IMAGE),type=imageType(bytes);const result={data:'data:'+type+';base64,'+bytes.toString('base64')};
      while(cacheBytes+bytes.length>32*1024*1024&&assets.size){const k=assets.keys().next().value;cacheBytes-=assets.get(k).size;assets.delete(k)}
      assets.set(key,{result,size:bytes.length});cacheBytes+=bytes.length;return result;
    }).finally(()=>inflight.delete(key));inflight.set(key,promise);return promise;
  }
  return {catalog,image};
}

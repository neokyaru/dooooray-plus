// Legacy envelope entry; execution is delegated to the signed modern engine.

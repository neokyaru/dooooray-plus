// Fixed, offline boot contract. Network policy and update UI live in signed user releases.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,newer} from './boot-store.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
if(process.argv.includes('--check')){console.log(JSON.stringify({bootProtocol:1,mode:'offline-capsule-boot',mutableController:true}));process.exit(0)}
const lock=net.createServer(s=>s.end());
if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(19352,'127.0.0.1',()=>r(true))}))process.exit(0);
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
const openStore=()=>new UpdateStore({data,publicKey}).init();
const log=async s=>fs.appendFile(path.join(userData,'boot.log'),new Date().toISOString()+' '+s+'\n').catch(()=>{});
let child=null,closing=false;
function stop(){if(closing)return;closing=true;try{child?.send({type:'shutdown'})}catch{}setTimeout(()=>{try{child?.kill()}catch{}process.exit(0)},3500).unref()}
process.on('message',m=>{if(m?.type==='shutdown')stop()});process.on('disconnect',stop);
const pulse=setInterval(()=>{if(process.connected&&!closing)process.send({type:'bridge-alive'})},2000);pulse.unref();
if(process.connected)process.send({type:'bridge-alive'});
process.on('SIGTERM',stop);process.on('SIGINT',stop);process.on('exit',()=>{try{child?.kill()}catch{}});
async function disabled(){for(const n of ['stop-agent.flag','theme-disabled.flag'])try{await fs.access(path.join(userData,n));return true}catch{}return false}
try{
 let store=await openStore();
 const envelope=JSON.parse(await fs.readFile(path.join(root,'seed/latest.json'),'utf8'));
 const seed=verifyManifest(envelope,publicKey);
 await store.stage(envelope,await fs.readFile(path.join(root,'seed',seed.archive)));
 if(store.state.trial&&store.state.trialStarted){
  let health;try{health=JSON.parse(await fs.readFile((process.env.DOORAY_ENGINE_HEALTH||path.join(userData,'healthy.flag')),'utf8'))}catch{}
  if(health?.version===store.state.active)await store.confirm();else await store.rollback();
 }
 if(store.state.active&&newer(seed.version,store.state.active)&&!store.state.failed.includes(seed.version)){store.state.pending=seed.version;await store.activate()}
 if(!store.state.active&&store.state.failed.includes(seed.version))throw Error('No healthy bridge seed');
 if(!store.state.active){store.state.active=seed.version;store.state.trial=false;await store.persist()}
 let failures=0;
 while(!closing&&!await disabled()){
  store=await openStore();
  let manifest;
  try{manifest=await store.validate(store.state.active)}catch(e){await log('Validation failed: '+e.message);if(!await store.rollback())break;continue}
  const version=store.state.active;
  if(store.state.trial){store.state.trialStarted=true;await store.persist()}
  let heartbeat=Date.now();
  const runtime=manifest.files['app/runtime/node.exe']?path.join(store.dir(version),'app/runtime/node.exe'):process.execPath;
  const running=spawn(runtime,[path.join(store.dir(version),'app/update-supervisor.mjs')],{cwd:store.dir(version),windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],env:{...process.env,DOORAY_INSTALL_ROOT:root}});
  child=running;
  running.on('message',m=>{if(m?.type==='supervisor-alive'&&m.version===version)heartbeat=Date.now()});
  const watchdog=setInterval(()=>{if(Date.now()-heartbeat>60000)running.kill();void disabled().then(v=>{if(v)stop()})},2000);
  const code=await new Promise(r=>{running.once('error',()=>r(-1));running.once('exit',r)});
  clearInterval(watchdog);child=null;
  if(closing)break;
  store=await openStore();
  if(code===75&&store.state.active!==version){failures=0;continue}
  if(code===0)break;
  await log('Supervisor failed: '+version+' code='+code);
  if(++failures>3||!await store.rollback())break;
 }
}catch(e){await log('Boot failed: '+e.message)}
lock.close();

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {inflateRawSync} from 'node:zlib';
export const BOOT_PROTOCOL=1;
const MAX_ARCHIVE=256*1024*1024,MAX_EXPANDED=512*1024*1024;
export const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export const validVersion=v=>typeof v==='string'&&/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(v);
export function newer(a,b){if(!validVersion(a)||!validVersion(b))throw Error('Invalid version');const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i];return false;}
export function safeFile(name){if(typeof name!=='string'||!/^app\/[a-zA-Z0-9_./-]+$/.test(name)||name.split('/').some(x=>!x||x==='.'||x==='..'||/[. ]$/.test(x))||!/\.(js|mjs|json|ps1|css|exe|dll|pem|dat)$/.test(name))throw Error('Invalid release path');return name;}
export function verifyManifest(envelope,key){
  const m=envelope?.manifest;if(!m||!crypto.verify(null,Buffer.from(JSON.stringify(m)),key,Buffer.from(envelope.signature||'','base64')))throw Error('Update signature invalid');
  if(m.schema!==2||m.bootProtocol!==BOOT_PROTOCOL||!validVersion(m.version))throw Error('Unsupported update format');
  if(m.archive!=='theme-'+m.version+'.zip'||!Number.isInteger(m.size)||m.size<=0||m.size>MAX_ARCHIVE||!/^[a-f0-9]{64}$/.test(m.sha256))throw Error('Invalid archive metadata');
  if(!m.files||typeof m.files!=='object'||Array.isArray(m.files)||Object.keys(m.files).length>1000)throw Error('Invalid file manifest');
  for(const [name,digest]of Object.entries(m.files)){safeFile(name);if(!/^[a-f0-9]{64}$/.test(digest))throw Error('Invalid file hash');}
  for(const file of ['app/update-supervisor.mjs','app/update-store.mjs'])if(!m.files[file])throw Error('Required release file missing');
  return m;
}
export function unpack(bytes,m){
  if(bytes.length!==m.size||hash(bytes)!==m.sha256)throw Error('Archive verification failed');
  let end=-1;for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(bytes.readUInt32LE(i)===0x06054b50){end=i;break;}
  if(end<0||bytes.readUInt16LE(end+4)||bytes.readUInt16LE(end+6))throw Error('Invalid ZIP');
  const count=bytes.readUInt16LE(end+10);let at=bytes.readUInt32LE(end+16),total=0;const result=new Map(),folded=new Set();
  if(count!==Object.keys(m.files).length)throw Error('ZIP file count mismatch');
  for(let i=0;i<count;i++){
    if(bytes.readUInt32LE(at)!==0x02014b50)throw Error('Invalid ZIP directory');
    const flags=bytes.readUInt16LE(at+8),method=bytes.readUInt16LE(at+10),compressed=bytes.readUInt32LE(at+20),size=bytes.readUInt32LE(at+24),n=bytes.readUInt16LE(at+28),extra=bytes.readUInt16LE(at+30),comment=bytes.readUInt16LE(at+32),attributes=bytes.readUInt32LE(at+38),offset=bytes.readUInt32LE(at+42);
    const name=safeFile(bytes.subarray(at+46,at+46+n).toString('utf8'));at+=46+n+extra+comment;
    if(flags&1||![0,8].includes(method)||((attributes>>>16)&0xf000)===0xa000||folded.has(name.toLowerCase())||!m.files[name])throw Error('Unsupported ZIP entry');
    folded.add(name.toLowerCase());total+=size;if(total>MAX_EXPANDED||size>MAX_EXPANDED||bytes.readUInt32LE(offset)!==0x04034b50)throw Error('Invalid ZIP entry size');
    const localNameSize=bytes.readUInt16LE(offset+26),dataAt=offset+30+localNameSize+bytes.readUInt16LE(offset+28);
    if(bytes.subarray(offset+30,offset+30+localNameSize).toString('utf8')!==name||dataAt+compressed>bytes.length)throw Error('ZIP entry mismatch');
    const raw=bytes.subarray(dataAt,dataAt+compressed),content=method===8?inflateRawSync(raw,{maxOutputLength:MAX_EXPANDED}):raw;
    if(content.length!==size||hash(content)!==m.files[name])throw Error('Release file verification failed');result.set(name,content);
  }
  return result;
}
export async function atomicJSON(file,value){const temp=file+'.'+crypto.randomUUID()+'.tmp';await fs.writeFile(temp,JSON.stringify(value,null,2),{flag:'wx'});await fs.rename(temp,file);}
const exists=async p=>{try{await fs.access(p);return true}catch{return false}};
export class UpdateStore {
  constructor({data,publicKey}){this.data=data;this.key=publicKey;this.releases=path.join(data,'releases');this.statePath=path.join(data,'update-state.json');this.state={schema:1,active:null,previous:null,pending:null,trial:false,trialStarted:false,failed:[]};}
  async init(){await fs.mkdir(this.releases,{recursive:true});try{const s=JSON.parse(await fs.readFile(this.statePath,'utf8'));if(s.schema===1&&['active','previous','pending'].every(k=>s[k]===null||validVersion(s[k]))&&Array.isArray(s.failed)){this.state={...this.state,...s,failed:s.failed.filter(validVersion).slice(-20)};}}catch{}return this;}
  dir(version){if(!validVersion(version))throw Error('Invalid release version');return path.join(this.releases,version);}
  async persist(){const snapshot=JSON.parse(JSON.stringify(this.state));this.writes=(this.writes||Promise.resolve()).catch(()=>{}).then(()=>atomicJSON(this.statePath,snapshot));await this.writes;}
  async validate(version){const root=this.dir(version),envelope=JSON.parse(await fs.readFile(path.join(root,'release.json'),'utf8')),m=verifyManifest(envelope,this.key);if(m.version!==version)throw Error('Release version mismatch');
    const walk=async dir=>{for(const e of await fs.readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isSymbolicLink())throw Error('Linked release path');if(e.isDirectory())await walk(p);else if(path.relative(root,p).replaceAll('\\','/')!=='release.json'&&!m.files[path.relative(root,p).replaceAll('\\','/')])throw Error('Unexpected release file');}};
    if((await fs.lstat(root)).isSymbolicLink())throw Error('Linked release directory');await walk(root);
    for(const [name,digest]of Object.entries(m.files))if(hash(await fs.readFile(path.join(root,name)))!==digest)throw Error('Installed release hash mismatch');return m;
  }
  async stage(envelope,bytes){const m=verifyManifest(envelope,this.key),files=unpack(bytes,m),target=this.dir(m.version);
    if(await exists(target)){try{await this.validate(m.version);return m.version}catch{await fs.rename(target,target+'.invalid-'+crypto.randomUUID())}}
    const temp=path.join(this.releases,'.stage-'+crypto.randomUUID());await fs.mkdir(temp);
    for(const [name,content]of files){const file=path.join(temp,name);await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file,content,{flag:'wx'});}
    await atomicJSON(path.join(temp,'release.json'),envelope);await fs.rename(temp,target);await this.validate(m.version);return m.version;
  }
  async queue(envelope,bytes){const m=verifyManifest(envelope,this.key);if(this.state.failed.includes(m.version)||this.state.active&&!newer(m.version,this.state.active)||this.state.pending&&!newer(m.version,this.state.pending))return false;await this.stage(envelope,bytes);this.state.pending=m.version;await this.persist();return true;}
  async activate(){if(!this.state.pending)return false;await this.validate(this.state.pending);this.state.previous=this.state.active;this.state.active=this.state.pending;this.state.pending=null;this.state.trial=true;this.state.trialStarted=false;await this.persist();return true;}
  async confirm(){this.state.trial=false;this.state.trialStarted=false;await this.persist();}
  async rollback(){const failed=this.state.active;if(failed)this.state.failed=[...new Set([...this.state.failed,failed])].slice(-20);const previous=this.state.previous;this.state.active=null;this.state.previous=null;this.state.trial=false;this.state.trialStarted=false;if(previous&&!this.state.failed.includes(previous)){try{await this.validate(previous);this.state.active=previous}catch{}}await this.persist();return this.state.active;}
}

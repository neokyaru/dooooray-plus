// Signed schema-1 bridge, run ONLY by the existing non-elevated legacy loader.
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {verifyManifest,unpack} from './boot-store.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const version=path.basename(path.dirname(here));
const data=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const root=path.join(data,'bridge-runtime');
const installed=path.dirname(path.dirname(process.execPath));
const publicKey=await fs.readFile(path.join(installed,'app/update-public.pem'),'utf8');
const seed=JSON.parse(await fs.readFile(path.join(here,'bridge-seed.json'),'utf8'));
const manifest=verifyManifest(seed.envelope,publicKey),archive=Buffer.from(seed.archive,'base64');unpack(archive,manifest);
await fs.mkdir(path.join(root,'app'),{recursive:true});await fs.mkdir(path.join(root,'seed'),{recursive:true});
// Materialize only authenticated boot code and the separately verified modern seed.
for(const [from,to]of [['bridge-bootstrap.mjs','launcher.mjs'],['boot-store.mjs','boot-store.mjs']])await fs.copyFile(path.join(here,from),path.join(root,'app',to));
await fs.writeFile(path.join(root,'app/update-public.pem'),publicKey);
await fs.writeFile(path.join(root,'seed/latest.json'),JSON.stringify(seed.envelope));
await fs.writeFile(path.join(root,'seed',manifest.archive),archive);
const health=path.join(data,'healthy.flag');
let closing=false,child=null;
async function stop(){if(closing)return;closing=true;try{child?.send({type:'shutdown'})}catch{}setTimeout(()=>{try{child?.kill()}catch{}process.exit(0)},5000).unref()}
process.on('message',m=>{if(m?.type==='shutdown')void stop()});process.on('disconnect',()=>void stop());process.on('SIGTERM',()=>void stop());
process.on('exit',()=>{try{child?.kill()}catch{}});
const env={...process.env,DOORAY_LEGACY_BRIDGE:version,DOORAY_ENGINE_HEALTH:path.join(data,'engine-v1','healthy.flag'),DOORAY_ENGINE_ERROR:path.join(data,'engine-v1','release-error.json')};
child=spawn(process.execPath,[path.join(root,'app/launcher.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],env});
// This flag describes bridge liveness, not the health of the independently supervised feature release.
child.on('message',m=>{if(m?.type==='bridge-alive'&&!closing)void fs.writeFile(health,JSON.stringify({version,at:Date.now()})).catch(()=>{})});
child.once('error',()=>process.exit(1));child.once('exit',()=>process.exit(closing?0:1));

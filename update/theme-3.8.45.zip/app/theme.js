(() => {
  const VERSION='3.8.45',KEY='local.dooray-theme.v2',OLD='local.dooray-theme.v1';
  if(window.__doorayTheme?.version===VERSION)return 'already installed';
  if(!document.querySelector('#root'))return 'not ready';
  window.__doorayTheme?.remove();
  const cleanup=[];let faulted=false;
  const nativeDOM=installDoorayNativeDOM();nativeDOM.refresh();cleanup.push(()=>nativeDOM.dispose());
  const chatScroll=installChatScroll({document,getTargets:()=>nativeDOM.conversations()});cleanup.push(()=>chatScroll.dispose());
  const stop=(reason)=>{if(faulted)return;faulted=true;window.__doorayThemeBootstrapDispose?.();window.__doorayThemeBlocked=reason;for(const fn of cleanup.reverse()){try{fn()}catch{}}for(const id of ['dooray-theme-styles','dooray-theme-palette','dooray-theme-menu','dooray-theme-startup'])document.getElementById(id)?.remove();delete document.documentElement.dataset.dtDark;delete document.documentElement.dataset.dtPalette;delete document.documentElement.dataset.dtExcel;delete window.__doorayTheme;};
  window.__doorayThemeEmergencyStop=stop;
  const safe=fn=>(...args)=>{if(faulted)return;try{return fn(...args)}catch{stop('extension-error')}};
  const groups={
    basic:[['darkBrightness','다크 테마 밝기',50,170,5,100,'%'],['size','본문 글자 크기',11,28,1,14,'px'],['line','본문 줄 간격',.5,3,.01,1.45,'배'],['letter','자간',-1,3,.1,0,'px'],['gap','메시지 묶음 간격',0,48,1,20,'px'],['padding','말풍선 세로 여백',0,24,1,8,'px']],
    text:[['weight','본문 글자 굵기',100,900,100,400,''],['word','단어 사이 간격',-2,12,.5,0,'px'],['nameSize','보낸 사람 이름 크기',10,24,1,14,'px'],['nameWeight','이름 굵기',100,900,100,700,''],['timeSize','시간 표시 크기',9,18,1,12,'px'],['listSize','대화 목록 글자 크기',10,18,1,14,'px']],
    bubble:[['padX','말풍선 좌우 여백',0,40,1,12,'px'],['radius','말풍선 모서리 둥글기',0,32,1,4,'px'],['bubbleWidth','말풍선 최대 너비',200,1200,10,700,'px'],['bubbleBorder','말풍선 테두리 두께',0,4,.5,0,'px'],['messageInset','대화 영역 좌우 여백',4,64,1,20,'px'],['nameGap','이름 아래 간격',0,24,1,6,'px']],
    editor:[['inputSize','입력창 글자 크기',11,28,1,14,'px'],['inputLine','입력창 줄 간격',1.1,2.5,.05,1.45,'배'],['inputPadding','입력창 추가 여백',0,24,1,0,'px'],['panelWidth','설정 패널 너비',320,560,10,380,'px']]
  };
  const colorSpecs=[['downloadBadge','다운로드 진행 배지','#278ac2'],['downloadBadgeText','다운로드 진행 숫자','#ffffff'],['downloadDone','미확인 다운로드 표시','#e53935'],['chatFlash','대화로 가기 강조','#3c526b'],['bg','전체 배경','#151b25'],['surface','받은 말풍선 / 보조 배경','#263141'],['own','내 말풍선','#203e58'],['selection','선택 항목','#203e58'],['actionIcon','말풍선 위 아이콘','#ffffff'],['newBadge','새 메시지 N 배경','#e53935'],['newBadgeText','새 메시지 N 글자','#ffffff'],['newChat','새 대화하기 배경','#278ac2'],['newChatIcon','새 대화하기 아이콘','#ffffff'],['org','조직도 배경','#278ac2'],['orgIcon','조직도 아이콘','#ffffff'],['reply','답장 원본 메시지 배경','#1e2938'],['notice','공지 배경','#423a26'],['text','본문 글자','#e4eaf3'],['muted','보조 글자','#a2afc1'],['accent','링크','#85bfff'],['border','구분선 / 말풍선 테두리','#3b4658'],['hover','목록 마우스 올림','#2e4055']];
  const lightDefaults={downloadBadge:'#278ac2',downloadBadgeText:'#ffffff',downloadDone:'#e53935',chatFlash:'#fff4d3',newBadge:'#e53935',newBadgeText:'#ffffff',newChat:'#278ac2',newChatIcon:'#ffffff',org:'#278ac2',orgIcon:'#ffffff',bg:'#ffffff',surface:'#eeeeee',own:'#e5f1ff',selection:'#e5f1ff',actionIcon:'#333333',reply:'#f3f5f7',notice:'#fff5d6',text:'#111111',muted:'#666666',accent:'#1769bb',border:'#cbd2da',hover:'#edf2f7'};
  const specs=Object.values(groups).flat();
  const defaults={toastCustom:false,toastSeconds:5,toastBg:'#1675e8',toastText:'#ffffff',dark:true,font:'original',detail:false,customColors:false,excel:false,vscode:false,fileView:'list',excelShortcut:'Ctrl+F8',vscodeShortcut:'Ctrl+F9',sidebarCollapsed:false,excelBrightness:100,vscodeBrightness:100,lightColors:{...lightDefaults},...Object.fromEntries(specs.map(s=>[s[0],s[5]])),...Object.fromEntries(colorSpecs.map(s=>[s[0],s[2]]))};
  function clean(o){o=o&&typeof o==='object'?o:{};const v={...defaults};v.toastSeconds=Number.isFinite(o.toastSeconds)?Math.max(1,Math.min(30,Math.round(o.toastSeconds))):5;for(const k of ['toastBg','toastText'])if(/^#[a-f0-9]{6}$/i.test(o[k]))v[k]=o[k];v.toastCustom=typeof o.toastCustom==='boolean'?o.toastCustom:v.toastBg!==defaults.toastBg||v.toastText!==defaults.toastText;for(const k of ['dark','detail','customColors','excel','vscode','sidebarCollapsed'])if(typeof o[k]==='boolean')v[k]=o[k];if(typeof o.font==='string'&&o.font.length<=120)v.font=o.font;for(const[k,,min,max,step]of specs){if(typeof o[k]==='number'&&Number.isFinite(o[k]))v[k]=Math.round(Math.min(max,Math.max(min,o[k]))/step)*step}for(const[k]of colorSpecs)if(/^#[\da-f]{6}$/i.test(o[k]))v[k]=o[k];for(const k of ['excelShortcut','vscodeShortcut'])if(/^(Ctrl|Alt|Shift)\+(F[6-9]|F10|[A-Z0-9])$/.test(o[k]))v[k]=o[k];if(['list','tiles'].includes(o.fileView))v.fileView=o.fileView;if(v.excel)v.vscode=false;v.excelBrightness=Number.isFinite(o.excelBrightness)?Math.max(35,Math.min(170,o.excelBrightness)):100;v.vscodeBrightness=Number.isFinite(o.vscodeBrightness)?Math.max(50,Math.min(170,o.vscodeBrightness)):100;v.lightColors={...lightDefaults};for(const[k]of colorSpecs)if(/^#[\da-f]{6}$/i.test(o.lightColors?.[k]))v.lightColors[k]=o.lightColors[k];if(!o.selection&&o.own)v.selection=v.own;return v}
  let saved={...defaults};try{saved=clean(JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(OLD)||'{}'))}catch{}
  let current={...saved},baseline={...saved},open=false,disposed=false;
  const sheet=document.createElement('style');sheet.id='dooray-theme-styles';document.head.append(sheet);
  const host=document.createElement('div');host.id='dooray-theme-menu';document.body.append(host);const shadow=host.attachShadow({mode:'open'});
  const controls=list=>list.map(([id,label,min,max,step,,unit])=>`<div class="row"><label for="${id}">${label}</label><div class="number"><input id="${id}Number" aria-label="${label} 숫자" type="number" min="${min}" max="${max}" step="${step}"><span>${unit}</span></div></div><input id="${id}" aria-label="${label}" type="range" min="${min}" max="${max}" step="${step}">`).join('');
  shadow.innerHTML=`<style>
  :host{all:initial;display:block;position:relative;width:48px;height:56px;flex:0 0 56px;z-index:auto;font:13px 'Malgun Gothic',sans-serif;color:var(--menu-color,#e6edf7);color-scheme:dark}:host([data-floating]){position:fixed;right:0;top:6px;z-index:5059}*{box-sizing:border-box}[hidden]{display:none!important}button,input,select{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #93b7ff;outline-offset:2px}
  .bar{height:38px;display:flex;align-items:center;gap:12px;padding:0 14px;background:#171d28;border-bottom:1px solid #343e50}.brand{font-weight:700}.badge{font-size:11px;color:#a8b5c9}.spacer{flex:1}button{border:1px solid #465269;border-radius:7px;padding:7px 11px;color:#eef3ff;background:#293447}button:hover{background:#3b4a63}button:disabled{opacity:.4;cursor:default}.bar button{padding:4px 12px;font-size:12px}.primary{background:#486fea;border-color:#6488f9}
  .panel{position:fixed;z-index:5060;right:60px;top:12px;color:#e6edf7;width:var(--panel-width,380px);max-width:calc(100vw - 72px);max-height:calc(100vh - 24px);display:flex;flex-direction:column;border:1px solid #414d63;border-radius:14px;background:#1b2331;box-shadow:0 18px 60px #0008;overflow:hidden}.head{padding:18px 20px 12px;border-bottom:1px solid #344053}.scroll{padding:0 20px 12px;overflow:auto;overscroll-behavior:contain}.foot{padding:12px 20px;border-top:1px solid #344053;background:#202a3b}.buttons{display:flex;gap:8px;justify-content:flex-end}
  h2{margin:0;font-size:18px}.sub,.note{font-size:11px;line-height:1.65;color:#a9b6cb;margin:6px 0}.row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:14px 0 4px}label{font-size:12px}.number{display:flex;align-items:center;gap:4px;color:#a7c3ff;font-size:11px}.number input{width:65px;padding:4px;text-align:right}.number span{width:16px}
  input[type=range]{width:100%;accent-color:#85a6ff;margin:7px 0 9px}input[type=checkbox]{width:18px;height:18px;accent-color:#779aff}select,input[type=text],input[type=number]{border:1px solid #48556b;border-radius:6px;background:#252f40;color:#eef3ff}select{width:100%;padding:9px}input[type=text]{width:100%;padding:8px;min-width:0}.inline{display:flex;gap:6px;margin:8px 0}.inline button{white-space:nowrap;font-size:11px}details{border-top:1px solid #344053;margin-top:14px;padding-top:12px}summary{cursor:pointer;font-weight:600;font-size:12px}.mode{background:#26344b;border:1px solid #425878;border-radius:9px;padding:8px 12px;margin-top:18px}.mode .row{margin:0}input[type=color]{width:48px;height:28px;border:1px solid #4a5871;background:transparent;padding:2px;border-radius:5px}.colorcode{font-size:11px;color:#a7c3ff}.status{font-size:11px;color:#b4cdfc;min-height:16px;line-height:1.5;margin-top:7px}input[type=file]{max-width:100%;font-size:11px;margin:8px 0}.fontnote{padding:8px 10px;border-radius:7px;background:#121c2b;font-size:11px;line-height:1.6;color:#a9b6cb}
  #toggle{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;width:44px;height:52px;margin:2px;border:0;border-radius:8px;background:transparent;color:inherit;font-size:11px;padding:4px 0}#toggle:hover,#toggle[aria-expanded="true"]{background:var(--menu-hover,#263141)}#toggle svg{width:22px;height:22px;flex-shrink:0}
  :host([data-excel]) .panel{border-radius:2px;border-color:#217346;background:var(--excel-panel);color:var(--excel-text)}:host([data-excel]){--excel-panel:#203729;--excel-text:#ecf5ef}:host([data-excel][data-light]){--excel-panel:#f3f8f4;--excel-text:#20382a}
  :host([data-excel]) .head{background:#217346;color:#fff}:host([data-excel]) .foot,:host([data-excel]) .mode,:host([data-excel]) .fontnote{background:var(--excel-panel);color:var(--excel-text)}:host([data-excel]) :is(.note,.status,.number,.colorcode){color:var(--excel-text)}:host([data-excel]) :is(button,select,input){border-radius:2px}:host([data-excel]) :is(select,input[type=number],input[type=text]){background:var(--excel-panel);color:var(--excel-text);border-color:#6e947c}:host([data-excel]) button:not(#toggle){background:#217346;color:#fff;border-color:#519069}:host([data-excel]) input{accent-color:#217346}
  :host([data-vscode]){--vs-panel:#252526;--vs-text:#d4d4d4;--vs-input:#3c3c3c}:host([data-vscode][data-light]){--vs-panel:#f3f3f3;--vs-text:#333;--vs-input:#fff}
  :host([data-vscode]) .panel{border-radius:2px;background:var(--vs-panel);color:var(--vs-text);border-color:#007acc}:host([data-vscode]) .head{border-bottom:2px solid #007acc}:host([data-vscode]) :is(.foot,.mode,.fontnote){background:var(--vs-panel);color:var(--vs-text)}:host([data-vscode]) :is(.note,.status,.number,.colorcode){color:var(--vs-text)}:host([data-vscode]) :is(select,input[type=number],input[type=text]){background:var(--vs-input);color:var(--vs-text);border-color:#777;border-radius:2px}:host([data-vscode]) button:not(#toggle){background:#007acc;color:white;border-radius:2px}:host([data-vscode]) input{accent-color:#007acc}
  #updateBadge{position:absolute;right:3px;top:2px;width:10px;height:10px;border-radius:50%;background:#ed3345;box-shadow:0 0 0 2px var(--dt-bg,#fff);pointer-events:none}
  </style><button id="toggle" aria-label="두레이 플러스 설정" aria-expanded="false" aria-controls="panel" title="두레이 플러스 설정"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1.5-3.3 1.4 1.4 0 0 1 1.1-2.3H18a3 3 0 0 0 3-3.2A9 9 0 0 0 12 3Z"/><circle cx="7.5" cy="9" r="1"/><circle cx="11" cy="6.5" r="1"/><circle cx="16" cy="7.5" r="1"/><circle cx="6.5" cy="13.5" r="1"/></svg><span>두레이<br>플러스</span><span id="updateBadge" hidden aria-hidden="true"></span></button>
  <section id="panel" class="panel" aria-label="두레이 플러스 설정" hidden><div class="head"><h2>두레이 플러스</h2></div><div class="scroll">
  <div class="row"><label for="dark">다크 테마</label><input id="dark" type="checkbox"></div><div class="row"><label for="themeStyle">테마 스타일</label></div><select id="themeStyle"><option value="default">기본</option><option value="excel">Excel</option><option value="vscode">VS Code</option></select><input id="excel" type="checkbox" hidden><p class="note">위의 다크 테마 스위치로 기본(라이트)·다크를 전환합니다. 지정 테마에서도 글꼴·크기·줄 간격과 디테일의 글자 설정을 조절할 수 있습니다.</p><div id="demoSettings" hidden><div class="row"><label for="demoModifier">샘플 화면 토글 단축키</label></div><div class="inline"><select id="demoModifier" aria-label="조합키"><option>Ctrl</option><option>Alt</option><option>Shift</option></select><span>＋</span><select id="demoKey" aria-label="두 번째 키">${['F6','F7','F8','F9','F10',...'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'].map(k=>`<option>${k}</option>`).join('')}</select></div><p class="note">두 키를 함께 누르면 가상 게임 데이터/코드 화면을 켜고 끕니다. 실제 데이터는 변경하지 않습니다.</p><button id="demoPreview">샘플 화면 열기 / 닫기</button></div><div id="excelBrightnessBox" hidden><div class="row"><label for="excelBrightness">엑셀 모드 밝기</label><span id="excelBrightnessValue"></span></div><input id="excelBrightness" type="range" min="35" max="170" step="1"><p class="note">엑셀 전용 색상과 레이아웃을 사용하며 글꼴 설정은 직접 조절할 수 있습니다.</p></div><div id="vscodeBrightnessBox" hidden><div class="row"><label for="vscodeBrightness">VS Code 배경 밝기</label><span id="vscodeBrightnessValue"></span></div><input id="vscodeBrightness" type="range" min="50" max="170" step="1" aria-label="VS Code 배경 밝기"></div><div class="row"><label for="font">글꼴</label></div><select id="font"></select>
  <details id="fontManager"><summary>＋ 폰트 직접 추가 / 관리</summary><div class="inline"><input id="localFont" type="text" maxlength="100" placeholder="설치된 글꼴 이름 · 예: Pretendard" aria-label="설치된 글꼴 이름"><button id="addLocal">이름으로 추가</button></div><label for="fontFile">또는 폰트 파일 선택</label><input id="fontFile" type="file" accept=".ttf,.otf,.woff,.woff2" multiple><div class="inline"><button id="removeFont">선택한 추가 폰트 삭제</button></div><div class="fontnote">파일당 최대 20MB, 합계 100MB. PC에 설치하지 않고 이 Dooray에서만 사용합니다. 폰트 추가·삭제는 즉시 보관됩니다. 선택한 글꼴과 설정은 자동 저장됩니다.</div><div id="fontStatus" class="status" role="status"></div></details>
  ${controls(groups.basic)}
  <div class="mode"><div class="row"><label for="detail">디테일 모드</label><input id="detail" type="checkbox"></div><p class="note">체크하면 세부 옵션을 표시하고 적용합니다.<br>끄면 세부 값은 보관하고 기본 모드로 돌아갑니다.</p></div>
  <div id="advanced" hidden><details open><summary>글자 · 이름 · 시간 · 목록</summary>${controls(groups.text)}<p class="note">목록 행 높이는 고정이며 큰 글꼴은 말줄임될 수 있습니다.</p></details><details><summary>말풍선 · 레이아웃</summary>${controls(groups.bubble)}</details><details><summary>입력창 · 설정 패널</summary>${controls(groups.editor)}</details><details><summary>색상 직접 지정</summary><div class="row"><label for="customColors">사용자 색상 적용 (현재 모드)</label><input id="customColors" type="checkbox"></div>${colorSpecs.map(([id,label])=>`<div class="row"><label for="${id}">${label}</label><span id="${id}Code" class="colorcode"></span><input type="color" id="${id}"></div>`).join('')}<p class="note">라이트·다크 색상은 따로 저장됩니다. 사용자 색상을 끄면 현재 모드의 기본 색상을 사용합니다.</p></details></div>
  <details><summary>설정 파일 가져오기 / 내보내기</summary><div class="inline"><button id="export">설정 JSON 내보내기</button><button id="import">가져오기</button></div><input id="importFile" type="file" accept=".json" hidden><p class="note">폰트 파일은 포함하지 않습니다. 가져온 값도 자동 저장됩니다.</p></details>
  <details><summary>다운로드 알림</summary><div class="row"><label for="toastSeconds">알림 표시 시간 (초)</label><input id="toastSeconds" type="number" min="1" max="30" step="1" style="width:70px"></div><div class="row"><label for="toastCustom">알림 색 직접 지정</label><input id="toastCustom" type="checkbox"></div><p class="note">기본은 현재 테마의 라이트·다크 색상을 따릅니다. 시작과 완료를 다른 색으로 표시합니다.</p><div id="toastCustomColors" hidden><div class="row"><label for="toastBg">말풍선 배경색</label><input id="toastBg" type="color"></div><div class="row"><label for="toastText">말풍선 글자색</label><input id="toastText" type="color"></div></div><p class="note">오른쪽 아래에 표시합니다. 다운로드 버튼이나 알림을 누르면 즉시 닫힙니다. 1~30초 후 자동으로 사라집니다.</p><button id="toastStartPreview" type="button">시작 알림 미리보기</button><button id="toastPreview" type="button">완료 알림 미리보기</button></details>
  <details open><summary>커스텀 이모티콘 복구</summary><button id="repairEmoticons" type="button">이모티콘 다시 불러오기</button><p id="emoticonHealth" class="status" role="status">문자열이 남거나 이미지가 안 보일 때 다시 검사합니다.</p></details>
  <details open><summary>두레이 플러스 업데이트</summary><p class="note">현재 버전 ${VERSION} · 두레이를 켜면 자동으로 확인합니다.</p><div class="inline"><button id="checkUpdate" type="button">업데이트 확인</button><button id="installUpdate" type="button" class="primary" hidden>업데이트하기</button></div><p id="updateStatus" class="status" role="status" aria-live="polite">새 버전을 확인한 뒤 업데이트하기를 누르세요. 업데이트하기를 누르면 검증 후 두레이를 자동으로 종료·재실행합니다.</p></details>
  <p class="note">두레이 플러스 사용으로 발생하는 모든 문제에 대한 책임은 사용자 본인에게 있습니다.</p></div><div class="foot"><div class="buttons"><button id="reset">기본값</button><button id="cancel">취소</button><button id="save" class="primary">저장</button></div><div id="status" class="status" role="status" aria-live="polite"></div></div></section>`;
  const $=id=>shadow.getElementById(id),status=s=>$('status').textContent=s;
  installDooraySettingsTabs(shadow);let roomExtension,bubbleTheme={mode:'default'};
  // Compile visual overrides from source CSS. Never disable live styles or measure
  // message layout: doing so invalidates Dooray's scroll and resize calculations.
  const paletteSheet=document.createElement('style');paletteSheet.id='dooray-theme-palette';document.head.append(paletteSheet);
  const namedPaletteColors=new Map();let colorParser;
  function rgb(value){
    value=value.trim();
    // CSSOM preserves named colors (notably invitation background:white).
    // Normalize valid color keywords without changing or measuring live DOM.
    if(/^[a-z]+$/i.test(value)&&CSS.supports('color',value)&&!['inherit','initial','unset','revert','revert-layer','currentcolor'].includes(value.toLowerCase())){
      const key=value.toLowerCase();if(!namedPaletteColors.has(key)){colorParser||=document.createElement('canvas').getContext('2d');if(colorParser){colorParser.fillStyle='#010203';colorParser.fillStyle=key;namedPaletteColors.set(key,colorParser.fillStyle)}}
      value=namedPaletteColors.get(key)||value;
    }
    if(/^#[\da-f]{3,8}$/i.test(value)){let h=value.slice(1);if(h.length===3||h.length===4)h=[...h].map(c=>c+c).join('');return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16)).concat(h.length===8?parseInt(h.slice(6),16)/255:1)}
    if(!/^rgba?\(/i.test(value))return null;const n=value.match(/[\d.]+/g)?.map(Number);return n?.length>=3?n:null;
  }
  let nativeRootStyle;
  function mapColor(value,kind){for(let i=0;i<4&&value.includes('var(');i++)value=value.replace(/var\((--[\w-]+)(?:,\s*([^()]+))?\)/g,(_,name,fallback)=>nativeRootStyle?.getPropertyValue(name).trim()||fallback||'');const c=rgb(value);if(!c||c[3]===0)return null;const[r,g,b]=c;let key;
    if(kind==='background'){if(Math.min(r,g,b)>175)key=b-r>12?'selection':r-b>20?'notice':Math.min(r,g,b)>247?'bg':'surface'}
    else if(kind==='border'){if(Math.min(r,g,b)>170)key='border'}
    else if(Math.max(r,g,b)-Math.min(r,g,b)<35)key=r<105?'text':r<200?'muted':null;
    else if(b>r+35)key='accent';return key?'var(--dt-'+key+')':null;
  }
  let compileQueued=false,compiling=false,compileCount=0;
  function splitSelectors(value){const result=[];let start=0,depth=0,quote='';for(let i=0;i<value.length;i++){const c=value[i];if(c==='\\'){i++;continue}if(quote){if(c===quote)quote='';continue}if(c==='"'||c==="'"){quote=c;continue}if(c==='('||c==='[')depth++;if(c===')'||c===']')depth--;if(c===','&&depth===0){result.push(value.slice(start,i));start=i+1}}result.push(value.slice(start));return result}
  function compilePalette(){if(disposed||compiling)return;compiling=true;try{
    nativeRootStyle=getComputedStyle(document.documentElement);
    const dark=':where(html[data-dt-palette="true"]) ';
    function rules(list){let out='';for(const r of list){if(r.type===1&&r.selectorText){
      let declarations='';const st=r.style;
      // Verified reply original card and editor reference preview in the supported build.
      const replyPreview=st.lineHeight==='20px'&&st.gap==='8px';const replyCard=st.borderRadius==='4px'&&['8px 12px','10px 12px'].includes(st.padding);
      const actionToolbar=st.height==='28px'&&st.padding==='2px 4px'&&st.gap==='2px'&&st.display==='flex';
      const actionSelectors=splitSelectors(r.selectorText).map(x=>dark+x.trim());
      const actionOverride=actionToolbar?actionSelectors.map(x=>x+'{background:var(--dt-action-bg)!important;color:var(--dt-actionIcon)!important;outline:1px solid var(--dt-border)!important;box-shadow:0 4px 16px #0006!important;}'+x+' > div:not(.emoticon) :is(button,i,svg),'+x+' > div:not(.emoticon) i::before{color:var(--dt-actionIcon)!important;}'+x+' > div:not(.emoticon) svg{fill:currentColor;}'+x+' > div:is(:hover,.open),'+x+' button:is(:hover,:focus-visible){background-color:var(--dt-hover)!important;}'+x+' > span{background-color:var(--dt-border)!important;}').join(''):'';
      if(/^\.ch-c-icon__log-[\w-]+$/.test(r.selectorText)&&st.backgroundImage&&st.backgroundImage!=='none')out+=dark+r.selectorText+'{background-image:none!important;background-color:var(--dt-actionIcon)!important;mask-image:'+st.backgroundImage+';mask-position:'+st.backgroundPosition+';mask-size:'+st.backgroundSize+';mask-repeat:no-repeat;filter:none!important;}';
      const replyOverride=replyCard?splitSelectors(r.selectorText).map(x=>dark+x.trim()+(replyPreview?'':'[role="button"]')).join(',')+'{background-color:var(--dt-reply)!important;}':'';
      for(const prop of ['background-color','color','border-top-color','border-right-color','border-bottom-color','border-left-color','outline-color','fill','stroke']){
        const v=st.getPropertyValue(prop);if(!v)continue;const mapped=mapColor(v,prop==='background-color'?'background':/border|outline/.test(prop)?'border':'text');if(mapped)declarations+=prop+':'+mapped+'!important;';
      }
      for(const prop of [...st])if(prop.startsWith('--')&&/background/.test(prop)){const mapped=mapColor(st.getPropertyValue(prop),'background');if(mapped)declarations+=prop+':'+mapped+';'}
      if(declarations){const selectors=splitSelectors(r.selectorText).map(x=>dark+x.trim()).join(',');out+=selectors+'{'+declarations+'}';}
      out+=replyOverride+actionOverride;
      if(mapColor(st.backgroundColor,'background')==='var(--dt-selection)')for(const selector of splitSelectors(r.selectorText).map(x=>x.trim()))if(/^\.[\w-]+$/.test(selector))out+=dark+':is([data-dp-native~="message-bubble"],.sc-iyvyFf)'+selector+'{background-color:var(--dt-own)!important;}html[data-dt-excel="true"] :is([data-dp-native~="message-bubble"],.sc-iyvyFf)'+selector+'{background-color:var(--dt-own)!important;}';
      // Preserve the native 4px consecutive / 20px group spacing ratio.
      const margin=parseFloat(st.marginTop);if(margin>0&&margin<=48&&/^\.[\w-]+$/.test(r.selectorText))out+=':is([data-dp-native~="message-group"],.sc-drKuOJ)'+r.selectorText+'{margin-top:calc(var(--dt-gap)*'+(margin/20)+')!important;}';
    }else if(r.cssRules&&/^@(media|supports|layer|container)\b/.test(r.cssText)){out+=r.cssText.slice(0,r.cssText.indexOf('{')+1)+rules(r.cssRules)+'}'} }return out}
    let css='';for(const native of document.styleSheets){if(native===sheet.sheet||native===paletteSheet.sheet||native.ownerNode?.id?.startsWith('dooray-theme-'))continue;try{css+=rules(native.cssRules)}catch{}}
    if(paletteSheet.textContent!==css)paletteSheet.textContent=css;compileCount++;
  }finally{compiling=false}}
  function scheduleCompile(){if(compileQueued||disposed)return;compileQueued=true;queueMicrotask(safe(()=>{compileQueued=false;compilePalette()}))}
  const originalInsert=CSSStyleSheet.prototype.insertRule;
  function insertRule(...args){const result=originalInsert.apply(this,args);if(this!==sheet.sheet&&this!==paletteSheet.sheet){try{scheduleCompile()}catch{stop('stylesheet-hook-error')}}return result}
  CSSStyleSheet.prototype.insertRule=insertRule;cleanup.push(()=>{if(CSSStyleSheet.prototype.insertRule===insertRule)CSSStyleSheet.prototype.insertRule=originalInsert});
  function mountMenu(){const rail=nativeDOM.rail();if(rail){if(host.parentElement!==rail||rail.firstElementChild!==host)rail.prepend(host);host.removeAttribute('data-floating')}else{if(host.parentElement!==document.body)document.body.append(host);host.setAttribute('data-floating','')}}
  mountMenu();
  const observer=new MutationObserver(safe(records=>{scheduleFiles();if(current.excel&&records.some(m=>[...m.addedNodes,...m.removedNodes].some(n=>n.nodeType===1&&(n.matches?.(':is([data-dp-native~="message-group"],.sc-drKuOJ),:is([data-dp-native~="message-bubble"],.sc-iyvyFf),.dt-received-emoticon')||n.querySelector?.(':is([data-dp-native~="message-group"],.sc-drKuOJ),:is([data-dp-native~="message-bubble"],.sc-iyvyFf),.dt-received-emoticon')))))scheduleCells();if(current.excel&&excelScroll!==document.querySelector('.js-scroll-area'))scheduleExcel();if(!host.isConnected||host.parentElement===document.body||host.parentElement.firstElementChild!==host)mountMenu();if(records.some(m=>{
    const owner=m.target.nodeType===3?m.target.parentElement:m.target;
    if(owner===sheet||owner===paletteSheet||owner===host||host.contains(owner))return false;
    return owner?.matches?.('style,link[rel="stylesheet"]')||[...m.addedNodes,...m.removedNodes].some(n=>n.nodeType===1&&(n.matches('style,link[rel="stylesheet"]')||n.querySelector('style,link[rel="stylesheet"]')));
  }))scheduleCompile()}));cleanup.push(()=>observer.disconnect());
  observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  const onStyleLoad=e=>{if(e.target?.matches?.('link[rel="stylesheet"]'))scheduleCompile()};document.addEventListener('load',onStyleLoad,true);cleanup.push(()=>document.removeEventListener('load',onStyleLoad,true));
  compilePalette();
  let excelScroll,excelLayer,excelFrame=0,excelResize;
  const scheduleExcel=()=>{if(!excelFrame&&!disposed)excelFrame=requestAnimationFrame(drawExcel)};
  function drawExcel(){excelFrame=0;if(disposed)return;const sc=current.excel?document.querySelector('.js-scroll-area'):null;
    if(sc!==excelScroll){excelScroll?.removeEventListener('scroll',scheduleExcel);excelResize?.disconnect();excelLayer?.remove();excelLayer=null;excelScroll=sc;
      if(sc){excelLayer=document.createElement('div');excelLayer.setAttribute('aria-hidden','true');excelLayer.id='dooray-theme-excel';excelLayer.style.cssText='position:absolute;pointer-events:none;z-index:11;overflow:hidden';sc.parentElement.append(excelLayer);sc.addEventListener('scroll',scheduleExcel,{passive:true});excelResize=new ResizeObserver(()=>{scheduleExcel();scheduleCells()});excelResize.observe(sc);}}
    if(!sc||!excelLayer)return;const r=sc.getBoundingClientRect(),pr=sc.parentElement.getBoundingClientRect(),dark=current.dark,bg=dark?brighten('#24272b',current.excelBrightness):'#f3f3f3',line=dark?brighten('#3b4046',current.excelBrightness):'#dedede',fg=dark?'#acb0b5':'#929a96',notice=sc.parentElement.querySelector(':scope > .sc-jdeSqf'),inset=notice?Math.max(0,Math.min(80,notice.getBoundingClientRect().bottom-r.top)):0,offset=(sc.scrollTop+inset)%24,first=Math.floor((sc.scrollTop+inset)/24)+1;
    Object.assign(excelLayer.style,{left:(r.left-pr.left)+'px',top:(r.top-pr.top+inset)+'px',width:sc.clientWidth+'px',height:Math.max(0,sc.clientHeight-inset)+'px'});
    const cells=Array.from({length:Math.ceil(sc.clientWidth/72)},(_,i)=>'<span style="flex:0 0 72px;border-right:1px solid '+line+';box-sizing:border-box">'+(i<26?String.fromCharCode(65+i):'A'+String.fromCharCode(65+i-26))+'</span>').join('');
    const rows=Array.from({length:Math.ceil(sc.clientHeight/24)+1},(_,i)=>'<div style="height:24px;box-sizing:border-box;border-bottom:1px solid '+line+'">'+(first+i)+'</div>').join('');
    excelLayer.innerHTML='<div style="position:absolute;left:0;top:24px;bottom:0;width:32px;background:'+bg+';border-right:1px solid '+line+';overflow:hidden;color:'+fg+';font:12px/24px Segoe UI;text-align:center"><div style="transform:translateY(-'+offset+'px)">'+rows+'</div></div><div style="position:absolute;left:0;top:0;right:0;height:24px;display:flex;background:'+bg+';color:'+fg+';font:12px/24px Segoe UI;text-align:center;border-bottom:1px solid '+line+'"><span style="flex:0 0 68px;border-right:1px solid '+line+';box-sizing:border-box">◩</span>'+cells+'</div>';
  }
  window.addEventListener('resize',scheduleExcel);cleanup.push(()=>{cancelAnimationFrame(excelFrame);excelScroll?.removeEventListener('scroll',scheduleExcel);excelResize?.disconnect();excelLayer?.remove();window.removeEventListener('resize',scheduleExcel)});
  let sideRoot,sideRail,sideToggle,sideBadge;let cellsFrame=0;
  function updateSidebar(){if(disposed)return;const list=document.querySelector('.js-channel-list'),root=list?.parentElement;if(!root)return;
    if(root!==sideRoot){sideRail?.remove();sideRoot?.removeAttribute('data-dt-collapsed');sideRoot=root;sideRail=document.createElement('div');sideRail.id='dooray-theme-sidebar';sideRail.style.cssText='flex:0 0 28px;width:28px;position:relative;background:var(--dt-surface);border-right:1px solid var(--dt-border);align-self:stretch';sideToggle=document.createElement('button');sideToggle.style.cssText='position:relative;width:28px;height:48px;border:0;background:transparent;color:var(--dt-text);cursor:pointer';sideBadge=document.createElement('span');sideBadge.textContent='N';sideBadge.style.cssText='position:absolute;right:0;top:3px;min-width:14px;height:14px;border-radius:50%;font:bold 10px/14px Segoe UI;text-align:center';sideToggle.append(sideBadge);sideRail.append(sideToggle);root.after(sideRail);sideToggle.onclick=()=>{current.sidebarCollapsed=!current.sidebarCollapsed;persist();updateSidebar();scheduleExcel();scheduleCells();positionDemo()};}
    sideRoot.toggleAttribute('data-dt-collapsed',current.sidebarCollapsed);
    const tabs=sideRoot.querySelector('[role="tablist"]')||sideRoot.querySelector('.sc-kEYyzF');const docked=!current.sidebarCollapsed&&tabs;
    if(docked){if(sideRail.parentElement!==tabs)tabs.append(sideRail);sideRail.style.cssText='flex:0 0 28px;width:28px;margin-left:auto;position:relative;align-self:stretch';sideToggle.style.height='36px';}
    else{if(sideRail.parentElement!==sideRoot.parentElement)sideRoot.after(sideRail);sideRail.style.cssText='flex:0 0 28px;width:28px;position:relative;background:var(--dt-surface);border-right:1px solid var(--dt-border);align-self:stretch';sideToggle.style.height='48px';}
    sideToggle.setAttribute('aria-expanded',String(!current.sidebarCollapsed));sideToggle.title=current.sidebarCollapsed?'대화 목록 펼치기':'대화 목록 접기';sideToggle.setAttribute('aria-label',sideToggle.title);sideToggle.style.setProperty('--side-arrow',current.sidebarCollapsed?'"›"':'"‹"');
    const colors=current.dark?current:current.lightColors,custom=current.detail&&current.customColors&&!current.excel;sideBadge.style.background=custom?colors.newBadge:'#e53935';sideBadge.style.color=custom?colors.newBadgeText:'#fff';
    let unread=false;try{let fiber=list[Object.keys(list).find(k=>k.startsWith('__reactFiber'))];for(let i=0;fiber&&i<30;i++,fiber=fiber.return){const store=fiber.memoizedProps?.data?.channelsStore;if(store){unread=Boolean(store.hasUnreadChannel||store.unreadCount>0);break}}}catch{}sideBadge.hidden=!unread;
  }
  const sideTimer=setInterval(updateSidebar,1000);cleanup.push(()=>{clearInterval(sideTimer);sideRail?.remove();sideRoot?.removeAttribute('data-dt-collapsed')});
  const cellOwned=new Map();
  function scheduleCells(){if(!cellsFrame&&!disposed)cellsFrame=requestAnimationFrame(alignCells)}
  function alignCells(){cellsFrame=0;if(disposed)return;if(!current.excel){for(const[e,style]of cellOwned){if(style===null)e.removeAttribute('style');else e.setAttribute('style',style)}cellOwned.clear();return;}
    const sc=document.querySelector('.js-scroll-area');if(!sc)return;const scrollLayout=chatScroll.beforeLayout(sc);
    for(const e of sc.querySelectorAll(':is([data-dp-native~="message-bubble"],.sc-iyvyFf):has(>:is([data-dp-native~="message-text"],.sc-chbbiW))')){if(!cellOwned.has(e))cellOwned.set(e,e.getAttribute('style'));e.style.removeProperty('width');
      // Emoji rendering owns intrinsic width, not the original token/grid width.
      if(e.matches('[data-dt-emoticon]')||e.querySelector('[data-dt-emoticon]'))continue;
      const available=Math.max(72,Math.floor((sc.clientWidth-84)/72)*72),width=Math.min(available,Math.ceil(e.getBoundingClientRect().width/72)*72);e.style.setProperty('width',width+'px','important');}
    for(const e of sc.querySelectorAll(':is([data-dp-native~="message-group"],.sc-drKuOJ)')){if(!cellOwned.has(e))cellOwned.set(e,e.getAttribute('style'));e.style.removeProperty('min-height');const h=e.getBoundingClientRect().height;e.style.setProperty('min-height',Math.ceil(h/24)*24+'px','important');}
    for(const[e]of cellOwned)if(!e.isConnected)cellOwned.delete(e);
    chatScroll.afterLayout(scrollLayout);
  }
  cleanup.push(()=>{cancelAnimationFrame(cellsFrame);for(const[e,style]of cellOwned){if(style===null)e.removeAttribute('style');else e.setAttribute('style',style)}cellOwned.clear()});
  function vscodeBackground(hex){return current.dark?brighten(hex,current.vscodeBrightness):'#'+rgb(hex).slice(0,3).map(n=>Math.max(0,Math.min(255,Math.round(n*current.vscodeBrightness/100))).toString(16).padStart(2,'0')).join('')}
  function brighten(hex,amount){const channels=rgb(hex);return '#'+channels.slice(0,3).map((n,i)=>{const target=[132,145,166][i];const v=amount<=100?n*amount/100:n+(target-n)*(amount-100)/220;return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')}).join('')}
  let demoHost,demoShadow,demoMode='',demoFocus,demoObserver,demoObserved,demoSeed=0;
  const demoKind=()=>current.excel?'excel':current.vscode?'vscode':'';
  const demoShortcut=()=>current[demoKind()==='excel'?'excelShortcut':'vscodeShortcut'];
  function closeDemo(){demoHost?.remove();demoObserver?.disconnect();demoHost=null;demoShadow=null;demoObserved=null;demoMode='';if(demoFocus?.isConnected)demoFocus.focus({preventScroll:true});demoFocus=null;}
  function positionDemo(){if(!demoHost)return;const sc=document.querySelector('.js-scroll-area');if(!sc){closeDemo();return}if(demoObserver&&demoObserved!==sc){demoObserver.disconnect();demoObserver.observe(document.documentElement);demoObserver.observe(sc);const header=document.querySelector('.BNJ0V');if(header)demoObserver.observe(header);demoObserved=sc;}const r=sc.getBoundingClientRect(),head=document.querySelector('.BNJ0V')?.getBoundingClientRect();Object.assign(demoHost.style,{left:r.left+'px',top:(head?.top??0)+'px',width:r.width+'px',height:(innerHeight-(head?.top??0))+'px'});}
  function paintDemo(){if(!demoHost)return;const dark=current.dark,excel=demoMode==='excel',bg=dark?(excel?brighten('#151719',current.excelBrightness):vscodeBackground('#1e1e1e')):(excel?'#fff':vscodeBackground('#ffffff')),fg=dark?'#d4d4d4':'#333',surface=dark?'#252526':'#f3f3f3',border=dark?'#41454a':'#dadada',accent=excel?'#217346':'#007acc';
    demoShadow.innerHTML=`<style>:host{color:${fg};font:13px/1.5 'Consolas','Malgun Gothic',monospace}*{box-sizing:border-box}.app{height:100%;display:flex;flex-direction:column;background:${bg}}.bar{display:flex;align-items:center;gap:16px;padding:7px 12px;background:${accent};color:white;flex:none}.bar strong{flex:1}button{cursor:pointer;font:inherit;border:0;background:transparent;color:inherit;padding:5px 12px}button:hover{background:#ffffff24}button:focus-visible{outline:2px solid #75beff;outline-offset:-2px}.scroll{overflow:auto;flex:1;min-height:0}.foot{background:${accent};color:white;padding:3px 12px;font:11px/1.5 'Segoe UI';flex:none}table{border-collapse:separate;border-spacing:0;font:12px/23px 'Consolas','Malgun Gothic';min-width:100%;white-space:nowrap}td,th{padding:0 10px;border-right:1px solid ${border};border-bottom:1px solid ${border};text-align:right;min-width:82px}thead th{position:sticky;top:0;background:${surface};color:${fg};font-weight:400;z-index:1}th:first-child{min-width:34px;width:34px;color:#999}.field{background:${dark?'#254436':'#e2efda'};font-weight:bold}.tabs{display:flex;background:${surface};overflow:auto;flex:none}.tabs button{white-space:nowrap;border-right:1px solid ${border};color:${fg};border-top:2px solid transparent}.tabs button.active{background:${bg};border-top-color:#007acc}.workspace{display:flex;flex:1;min-height:0}.files{width:170px;flex:none;background:${surface};padding:12px;color:${fg};font:12px/26px 'Segoe UI'}.editor{overflow:auto;flex:1;min-width:0}.line{display:flex;white-space:pre;font:12px/20px Consolas,monospace}.num{width:48px;flex:none;text-align:right;padding-right:16px;color:#858585;user-select:none}.code{padding-right:30px}.comment{color:${dark?'#6a9955':'#008000'}}.keyword{color:${dark?'#569cd6':'#0000ff'}}.string{color:${dark?'#ce9178':'#a31515'}}@media(max-width:650px){.files{display:none}.bar{font-size:11px;gap:4px}}</style><div class="app"><div class="bar"><strong>${excel?'Game Balance — Workbook':'game-server — Visual Studio Code'}</strong><span>${demoShortcut()} · 토글</span><button id="back" aria-label="대화 화면으로 돌아가기">돌아가기 ×</button></div>${excel?'<div class="scroll" id="data"></div>':'<div class="tabs" id="tabs"></div><div class="workspace"><aside class="files">EXPLORER<br>⌄ GAME-SERVER<br>　⌄ src<br>　　balance.ts<br>　　combat.ts<br>　　inventory.ts<br>　　matchmaking.ts<br>　　rewards.ts<br>　　telemetry.ts<br>　⌄ tests<br>　　combat.spec.ts<br>　 package.json</aside><div class="editor" id="data"></div></div>'}<div class="foot">${excel?'Sheet1　　Balance　　LootTable　　Simulation':'main　✓　　TypeScript　　UTF-8　　LF'}<span style="float:right">가상 샘플 · 실제 대화/파일과 무관</span></div></div>`;
    demoShadow.getElementById('back').onclick=closeDemo;
    let seed=demoSeed;const rand=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n};
    if(excel){const fields=['Item ID','Class','Level','HP','ATK','DEF','SPD','Crit %','Drop %','Gold','XP','Power'];let html='<table><thead><tr><th>◩</th>'+fields.map((_,i)=>'<th>'+String.fromCharCode(65+i)+'</th>').join('')+'</tr></thead><tbody><tr class="field"><th>1</th>'+fields.map(x=>'<td>'+x+'</td>').join('')+'</tr>';for(let i=0;i<300;i++){const level=1+rand(99),atk=50+rand(1800),hp=1000+rand(25000);const row=['UNIT-'+String(10000+i),['Warrior','Mage','Ranger','Knight','Healer'][rand(5)],level,hp,atk,50+rand(900),80+rand(90),(5+rand(350)/10).toFixed(1),(rand(1000)/100).toFixed(2),100+rand(9000),500+rand(20000),Math.round(hp*.3+atk*4+level*80)];html+='<tr><th>'+(i+2)+'</th>'+row.map(x=>'<td>'+x+'</td>').join('')+'</tr>'}demoShadow.getElementById('data').innerHTML=html+'</tbody></table>';}
    else{const files=['balance.ts','combat.ts','inventory.ts','matchmaking.ts','rewards.ts','telemetry.ts'];const tabs=demoShadow.getElementById('tabs');const esc=x=>x.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');const openFile=(name)=>{for(const b of tabs.children)b.classList.toggle('active',b.textContent===name);const lines=[`// ${name} — deterministic game simulation`,"import { Entity, SimulationContext } from './types';","import { clamp, seededRandom } from './math';",'',`export const UPDATE_INTERVAL_MS = ${16+rand(16)};`,"export interface SimulationResult { id: string; score: number; active: boolean; }",''];for(let i=0;i<22;i++)lines.push(`export function ${name.split('.')[0]}Phase${i}(entity: Entity, ctx: SimulationContext): SimulationResult {`,`  const multiplier = ${1+rand(9)}.${rand(99)};`,`  const base = clamp(entity.level * multiplier, 1, ${100+rand(900)});`,`  const bonus = ctx.modifiers.reduce((sum, mod) => sum + mod.value, 0);`,`  const score = Math.round((base + bonus) * (1 + entity.criticalRate));`,`  ctx.metrics.record('${name.split('.')[0]}.phase.${i}', score);`,`  return { id: entity.id, score, active: score > ${rand(100)} };`,'}','');demoShadow.getElementById('data').innerHTML=lines.map((line,i)=>'<div class="line"><span class="num">'+(i+1)+'</span><span class="code '+(line.startsWith('//')?'comment':'')+'">'+esc(line).replace(/\b(export|function|const|return|import|from|interface|number|boolean|string)\b/g,'<span class="keyword">$1</span>')+'</span></div>').join('');demoShadow.getElementById('data').scrollTop=0;};for(const name of files){const b=document.createElement('button');b.textContent=name;b.onclick=()=>openFile(name);tabs.append(b)}openFile(files[0]);}}
  function toggleDemo(){const kind=demoKind();if(!kind)return;if(demoHost){closeDemo();return}demoMode=kind;demoSeed=crypto.getRandomValues(new Uint32Array(1))[0];demoFocus=document.activeElement;demoHost=document.createElement('div');demoHost.id='dooray-theme-demo';demoHost.tabIndex=-1;demoHost.style.cssText='position:fixed;z-index:5059;overflow:hidden';demoShadow=demoHost.attachShadow({mode:'open'});document.body.append(demoHost);positionDemo();if(!demoHost)return;paintDemo();demoHost.focus({preventScroll:true});demoObserver=new ResizeObserver(positionDemo);positionDemo();}
  const onDemoKey=e=>{if(e.repeat||e.isComposing||e.key==='Process'||!demoKind())return;if(e.key==='Escape'&&demoHost&&e.composedPath().includes(demoHost)){e.preventDefault();e.stopImmediatePropagation();closeDemo();return}if(e.metaKey||Number(e.ctrlKey)+Number(e.altKey)+Number(e.shiftKey)!==1)return;const combo=(e.ctrlKey?'Ctrl':e.altKey?'Alt':'Shift')+'+'+e.key.toUpperCase();if(combo===demoShortcut()){e.preventDefault();e.stopImmediatePropagation();toggleDemo()}};
  window.addEventListener('keydown',onDemoKey,true);window.addEventListener('resize',positionDemo);cleanup.push(()=>{closeDemo();window.removeEventListener('keydown',onDemoKey,true);window.removeEventListener('resize',positionDemo)});

  let filesFrame=0,filesBar,filesList,filesDialog;const fileDecorations=new Map();
  function scheduleFiles(){if(!filesFrame&&!disposed)filesFrame=requestAnimationFrame(updateFiles)}
  function clearFileDecoration(card,entry){entry.button.onclick=null;for(const img of entry.button.querySelectorAll('img')){img.onload=null;img.onerror=null;img.removeAttribute('src')}entry.button.remove();card.removeAttribute('data-dt-image-file');fileDecorations.delete(card)}
  function fileData(card){if(!card)return null;const props=card[Object.keys(card).find(k=>k.startsWith('__reactProps'))];if(props?.file)return props.file;let f=card[Object.keys(card).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<40;i++,f=f.return)if(f.memoizedProps?.file)return f.memoizedProps.file;return null;}
  function fileOrigin(card){for(let n=card?.parentElement;n&&!n.matches('.hXel9');n=n.parentElement){const props=n[Object.keys(n).find(k=>k.startsWith('__reactProps'))];if(typeof props?.onClick==='function')return n;}return card?.closest('.sc-esoVGF')||null;}
  function previewFile(file,url,origin){filesDialog?.remove();const dialog=document.createElement('dialog');filesDialog=dialog;dialog.style.cssText='padding:0;border:1px solid #666;border-radius:6px;background:#202124;color:white;max-width:92vw;max-height:92vh;width:960px';const bar=document.createElement('div');bar.style.cssText='display:flex;gap:16px;align-items:center;padding:10px 14px';const title=document.createElement('span');title.textContent=file.fileName||file.title||'이미지 미리보기';title.style.cssText='flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';const close=document.createElement('button');close.textContent='닫기 ×';close.style.cssText='background:#34383d;color:white;border:1px solid #666;padding:6px 12px;cursor:pointer';close.onclick=()=>dialog.close();const go=document.createElement('button');go.textContent='대화로 가기';go.dataset.dtGoto='true';if(/^\d+$/.test(String(file.channelId)))go.dataset.dtNavigationChannel=String(file.channelId);go.style.cssText=close.style.cssText;go.disabled=!origin;go.onclick=()=>{if(!origin?.isConnected){go.disabled=true;go.textContent='파일 목록에서 다시 열어 주세요';return}dialog.close();origin.click()};const pic=document.createElement('img');pic.alt=title.textContent;pic.style.cssText='display:block;max-width:100%;max-height:78vh;object-fit:contain;margin:auto';pic.src=url;const error=document.createElement('p');error.textContent='이미지를 불러오지 못했습니다. 파일 만료 여부를 확인해 주세요.';error.hidden=true;pic.onerror=()=>{pic.hidden=true;error.hidden=false};bar.append(title,go,close);dialog.append(bar,pic,error);dialog.addEventListener('close',()=>{dialog.remove();if(filesDialog===dialog)filesDialog=null});document.body.append(dialog);dialog.showModal();}
  function updateFiles(){filesFrame=0;if(disposed)return;const row=[...document.querySelectorAll('.hXel9')].find(x=>x.querySelector(':is([data-dp-native~="file-card"],.sc-RcBXQ)'));const list=row?.parentElement||[...document.querySelectorAll('.sc-gYtlsd')].find(x=>x.querySelector(':is([data-dp-native~="file-card"],.sc-RcBXQ)'));
    if(list!==filesList){filesBar?.remove();filesList?.removeAttribute('data-dt-file-view');filesList=list;filesBar=null;}
    // Closed panels and recycled cards must release their thumbnail, handlers
    // and native React/card references even when no file list remains visible.
    for(const[card,entry]of fileDecorations)if(!card.isConnected||!list?.contains(card))clearFileDecoration(card,entry);
    if(!list)return;
    list.setAttribute('data-dt-file-view',current.fileView);
    if(!filesBar){filesBar=document.createElement('div');filesBar.id='dooray-theme-file-view';filesBar.style.cssText='display:flex;align-items:center;gap:6px;padding:8px 12px;flex:none;background:var(--dt-surface);color:var(--dt-text)';const label=document.createElement('span');label.textContent='보기';label.style.marginRight='auto';filesBar.append(label);for(const[value,text]of [['list','☰ 리스트'],['tiles','▦ 타일']]){const b=document.createElement('button');b.textContent=text;b.dataset.view=value;b.style.cssText='padding:5px 10px;border:1px solid var(--dt-border);border-radius:4px;background:transparent;color:inherit;cursor:pointer';b.onclick=()=>{current.fileView=value;persist();updateFiles()};filesBar.append(b)}const area=list.closest('.sc-hZhUor');if(area)area.before(filesBar);else list.parentElement.before(filesBar);}
    for(const b of filesBar.querySelectorAll('button')){b.setAttribute('aria-pressed',String(b.dataset.view===current.fileView));b.style.background=b.dataset.view===current.fileView?'var(--dt-selection)':'transparent'}
    for(const card of list.querySelectorAll(':is([data-dp-native~="file-card"],.sc-RcBXQ)')){const file=fileData(card),old=fileDecorations.get(card);if(!file||!/^image\/(png|jpe?g|gif|webp|bmp|avif)$/i.test(file.mimeType||'')||!/^\d+$/.test(String(file.id))||!/^\d+$/.test(String(file.channelId))){if(old)clearFileDecoration(card,old);continue}const key=String(file.channelId)+'/'+String(file.id);if(old?.key===key)continue;if(old)clearFileDecoration(card,old);const url='/messenger/v2/api/channel/'+file.channelId+'/file/'+file.id+'?isThumb=true';const button=document.createElement('button');button.type='button';button.className='dt-file-thumbnail';button.setAttribute('aria-label',(file.fileName||'이미지')+' 미리보기');const img=document.createElement('img');img.alt=file.fileName||'이미지 미리보기';img.loading='lazy';img.decoding='async';img.src=url;button.append(img);img.onerror=()=>{img.remove();button.textContent='미리보기 불가';button.classList.add('dt-file-failed')};button.onclick=e=>{e.preventDefault();e.stopPropagation();previewFile(file,url,fileOrigin(card))};card.prepend(button);card.setAttribute('data-dt-image-file','true');fileDecorations.set(card,{key,button});}
  }
  const filesCSS=document.createElement('style');filesCSS.id='dooray-theme-files';filesCSS.textContent=`
  [data-dt-file-view] .dt-file-thumbnail{flex:0 0 72px;width:72px;height:60px;display:flex;align-items:center;justify-content:center;padding:0;border:1px solid var(--dt-border,#ccc);background:var(--dt-bg,#fff);overflow:hidden;border-radius:4px;cursor:zoom-in;color:var(--dt-muted,#666);font-size:10px}
  [data-dt-file-view] .dt-file-thumbnail img{display:block;width:100%;height:100%;object-fit:contain}
  [data-dt-file-view] :is([data-dp-native~="file-card"],.sc-RcBXQ)[data-dt-image-file]>i{display:none!important}
  [data-dt-file-view] :is([data-dp-native~="file-card"],.sc-RcBXQ){gap:8px!important;min-width:0!important}
  [data-dt-file-view] .sc-fZwumE{min-width:0!important;flex:1!important}
  [data-dt-file-view="tiles"]{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px!important;padding:8px!important}
  [data-dt-file-view="tiles"]>.hXel9{display:flex!important;flex-direction:column!important;min-width:0!important;margin:0!important;padding:8px!important;border:1px solid var(--dt-border,#ccc);border-radius:5px;background:var(--dt-bg,#fff)}
  [data-dt-file-view="tiles"] :is(.Kghbf,.sc-esoVGF,.DlyCJ,.sc-fcdeBU,:is([data-dp-native~="message-bubble"],.sc-iyvyFf)){width:100%!important;max-width:100%!important;min-width:0!important;margin-left:0!important;padding-left:0!important;padding-right:0!important}
  [data-dt-file-view="tiles"] :is([data-dp-native~="file-card"],.sc-RcBXQ){flex-wrap:wrap!important;width:100%!important}
  [data-dt-file-view="tiles"] .dt-file-thumbnail{flex:0 0 100%;width:100%;height:120px}
  [data-dt-file-view="tiles"] .sc-fZwumE{flex:0 0 100%!important;width:100%!important}
  [data-dt-file-view="tiles"] .sc-fQejPQ{white-space:normal!important;overflow-wrap:anywhere;line-height:1.4!important}
  [data-dt-file-view="tiles"] .sc-iSDuPN{margin-left:auto}
  `;document.head.append(filesCSS);scheduleFiles();cleanup.push(()=>{cancelAnimationFrame(filesFrame);filesBar?.remove();filesList?.removeAttribute('data-dt-file-view');filesCSS.remove();filesDialog?.remove();for(const[card,entry]of fileDecorations)clearFileDecoration(card,entry);filesBar=null;filesList=null;filesDialog=null});

  const downloadKey='local.dooray-download-history.v1';let downloadItems=[];try{const items=JSON.parse(localStorage.getItem(downloadKey)||'[]');if(Array.isArray(items))downloadItems=items.filter(x=>x&&typeof x.id==='string'&&typeof x.name==='string').slice(0,500)}catch{}
  let downloadHost,downloadShadow,lastDownload,drivePanel;
  const downloadPersist=()=>{try{localStorage.setItem(downloadKey,JSON.stringify(downloadItems))}catch{}};
  function downloadLog(card){let f=card?.[Object.keys(card).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<60;i++,f=f.return){const p=f.memoizedProps;if(p?.log&&p?.actions)return {logId:String(p.log.id),channelId:String(p.log.channelId),actions:p.actions};}return null;}
  function goDownload(item){const source=fileOrigin([...document.querySelectorAll('[data-dt-file-view] :is([data-dp-native~="file-card"],.sc-RcBXQ)')].find(card=>String(fileData(card)?.id)===item.fileId));if(source){source.click();return true;}const any=document.querySelector(':is([data-dp-native~="file-card"],.sc-RcBXQ)'),context=downloadLog(any);if(!context?.actions||!item.logId)return false;const a=context.actions;try{a.channelActions.selectChannel(item.channelId);a.logActions.fetchHighlightLogs({channelId:item.channelId,logId:item.logId});return true}catch{return false}}
  const downloadPending=new Map();
  function downloadRPC(op,args={}){return new Promise((resolve,reject)=>{const preview=op.startsWith('emoticon-')&&typeof window.__doorayEmoticonCommand==='function'&&Date.now()-(window.__doorayEmoticonsReady||0)<5000;const binding=preview?window.__doorayEmoticonCommand:window.__doorayDownloadCommand;const ready=preview?window.__doorayEmoticonsReady:window.__doorayDownloadsReady;if(typeof binding!=='function'||Date.now()-(ready||0)>5000){reject(Error('다운로드 연결이 끊겼습니다.'));return}const requestId=crypto.randomUUID(),timer=setTimeout(()=>{downloadPending.delete(requestId);reject(Error('다운로드 응답 시간 초과'));},op==='update-install'?780000:['choose-folder','drive-credentials'].includes(op)?195000:op==='drive-preview'?125000:(op.startsWith('emoticon-')||op.startsWith('update-'))?120000:30000);downloadPending.set(requestId,{resolve,reject,timer});binding(JSON.stringify({requestId,op,...args}));});}
  window.__doorayDownloadReply=(id,result,error)=>{const p=downloadPending.get(id);if(!p)return;clearTimeout(p.timer);downloadPending.delete(id);error?p.reject(Error(error)):p.resolve(result)};
  let downloadCompletionId=null,downloadStartId=null,downloadToastTimer;
  function dismissDownloadToast(){clearTimeout(downloadToastTimer);if(downloadShadow)downloadShadow.getElementById('downloadToast').hidden=true;}
  function downloadToastColors(settings,kind='start'){
    if(settings.toastCustom)return {background:settings.toastBg,text:settings.toastText};
    const palettes={default:{light:['#1769c2','#187047'],dark:['#244e78','#245c49']},excel:{light:['#217346','#145c36'],dark:['#285943','#1f4939']},vscode:{light:['#0070b5','#18706b'],dark:['#264f78','#23574e']}};
    const theme=settings.excel?'excel':settings.vscode?'vscode':'default';
    return {background:palettes[theme][settings.dark?'dark':'light'][kind==='complete'?1:0],text:'#ffffff'};
  }
  function styleDownloadToast(){const toast=downloadShadow?.getElementById('downloadToast');if(toast){const colors=downloadToastColors(current,toast.dataset.kind);toast.style.background=colors.background;toast.style.color=colors.text;}}
  function showDownloadToast(message){if(!downloadShadow)mountDownloads();const toast=downloadShadow?.getElementById('downloadToast');if(!toast)return;clearTimeout(downloadToastTimer);toast.dataset.kind=message.startsWith('다운로드 완료')?'complete':'start';styleDownloadToast();downloadShadow.getElementById('toastMessage').textContent=message;toast.setAttribute('aria-label',message);toast.hidden=false;downloadToastTimer=setTimeout(dismissDownloadToast,current.toastSeconds*1000);}
  cleanup.push(()=>clearTimeout(downloadToastTimer));
 let downloadStateSignature='';window.__doorayDownloadsChanged=state=>{const completion=state.completionId||'';const start=state.startId||'';if(downloadStartId!==null&&start&&start!==downloadStartId)showDownloadToast('다운로드 중..');downloadStartId=start;if(downloadCompletionId!==null&&completion&&completion!==downloadCompletionId)showDownloadToast('다운로드 완료');downloadCompletionId=completion;const signature=JSON.stringify(state.items);downloadItems=state.items;if(signature!==downloadStateSignature){downloadStateSignature=signature;renderDownloads();}ackDownloads();if(downloadShadow)downloadShadow.getElementById('connection').textContent='저장 위치: '+state.folder;drivePanel?.updateDownloads(state);};
  cleanup.push(()=>{delete window.__doorayDownloadReply;delete window.__doorayDownloadsChanged;for(const p of downloadPending.values()){clearTimeout(p.timer);p.reject(Error('두레이 플러스 연결 종료'));}downloadPending.clear()});
  let acknowledgingDownloads=false;
  function ackDownloads(){if(acknowledgingDownloads||!downloadShadow||downloadShadow.getElementById('panel').hidden)return;const ids=downloadItems.filter(i=>i.status==='complete'&&!i.seen).map(i=>i.id);if(!ids.length)return;acknowledgingDownloads=true;downloadRPC('seen',{ids}).catch(()=>{}).finally(()=>{acknowledgingDownloads=false});}
  const closeDownloadsOutside=e=>{if(downloadShadow&&!e.composedPath().includes(downloadHost))downloadShadow.getElementById('panel').hidden=true;};document.addEventListener('pointerdown',closeDownloadsOutside,true);cleanup.push(()=>document.removeEventListener('pointerdown',closeDownloadsOutside,true));
// Shared, content-free adapter for native Dooray DOM. Generated CSS names are
// compatibility hints only; they never establish a toolbar's identity.
function installDoorayNativeDOM({document=globalThis.document}={}){
  const win=document.defaultView||globalThis,attribute='data-dp-native',owned=new Map(),listeners=new Set();
  let disposed=false,dirty=true,scheduled=0,lastScan=-Infinity,scans=0,currentRail=null,appReady=false,railReason='not-scanned';
  const now=()=>win.performance?.now?.()??Date.now();
  const injected='[id^="dooray-theme-"],[id^="dooray-custom-"],.dt-received-emoticon,[data-dp-extension]';
  const excluded='[contenteditable="true"],.js-main-editor,[role="dialog"],[aria-modal="true"]';
  const tokens=el=>new Set((el.getAttribute(attribute)||'').split(/\s+/).filter(Boolean));
  const reactProps=el=>{try{const key=Object.keys(el).find(k=>k.startsWith('__reactProps'));return key?el[key]:null}catch{return null}};
  const fiber=el=>{try{const key=Object.keys(el).find(k=>k.startsWith('__reactFiber'));return key?el[key]:null}catch{return null}};
  function propsWhere(el,predicate,limit=24){
    const direct=reactProps(el);if(direct&&predicate(direct))return direct;
    let f=fiber(el);const seen=new Set();for(let i=0;f&&i<limit&&!seen.has(f);i++,f=f.return){seen.add(f);const p=f.memoizedProps;if(p&&predicate(p))return p;}return null;
  }
  const foreign=el=>!el||el.nodeType!==1||!!el.closest(injected);
  function visible(el){
    if(!el?.isConnected||el.closest('[hidden],[aria-hidden="true"]'))return false;
    for(let p=el;p&&p!==document.documentElement;p=p.parentElement){const style=win.getComputedStyle(p);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||style.opacity==='0')return false;}
    const r=el.getBoundingClientRect();return r.width>0&&r.height>0;
  }
  const semantic=value=>{
    const s=String(value||'').trim().toLowerCase().replace(/[\s_-]+/g,'');
    if(/^(search|searchlog|searchmessage|messagesearch|검색|대화검색|메시지검색)$/.test(s))return 'search';
    if(/^(mention|mentions|searchmention|at|멘션|언급)$/.test(s))return 'mention';
    if(/^(attach|attachment|attachments|clip|paperclip|file|files|searchfile|첨부|첨부파일|파일)$/.test(s))return 'attach';
    if(/^(link|links|searchlink|링크)$/.test(s))return 'link';
    return '';
  };
  function iconRole(el){
    const labels=[el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-icon'),el.getAttribute('name')];
    const p=propsWhere(el,p=>typeof p.name==='string'&&!!semantic(p.name),8);if(p)labels.unshift(p.name);
    return labels.map(semantic).find(Boolean)||'';
  }
  function discoverRail(root){
    const hits=[];
    for(const el of root.querySelectorAll('svg,button,[role="button"],[aria-label],[data-icon]')){
      if(foreign(el)||el.closest(excluded+',.js-scroll-area,.js-channel-list')||!visible(el))continue;
      const role=iconRole(el);if(!role)continue;
      // An icon and its button are one control, never two independent votes.
      const control=el.closest('button,[role="button"]')||el;
      if(!hits.some(h=>h.control===control&&h.role===role))hits.push({control,role});
    }
    const candidates=new Map(),bounds=root.getBoundingClientRect(),right=bounds.width?bounds.right:win.innerWidth;
    for(const hit of hits){let p=hit.control.parentElement;for(let depth=0;p&&p!==root&&depth<6;depth++,p=p.parentElement){
      if(foreign(p)||p.closest(excluded+',.js-scroll-area,.js-channel-list'))break;
      const r=p.getBoundingClientRect();if(r.width<=0||r.width>128||r.height<90||r.height<r.width*1.6||r.bottom<=0||r.top>=win.innerHeight||r.right>right+8||r.left<right-Math.max(180,(bounds.width||win.innerWidth)*.2))continue;
      if(!visible(p))continue;
      if(!candidates.has(p))candidates.set(p,new Set());candidates.get(p).add(hit.role);
    }}
    const trusted=[...candidates].filter(([,roles])=>roles.size>=3&&roles.has('search')&&(roles.has('mention')||roles.has('attach'))).map(([el])=>el);
    // Nested wrappers describe one toolbar. Keep its narrowest semantic owner;
    // disjoint qualifying toolbars are ambiguous and must not receive our UI.
    const leaves=trusted.filter(el=>!trusted.some(other=>other!==el&&el.contains(other)));
    railReason=leaves.length===1?'semantic-toolbar':leaves.length?'ambiguous-toolbar':'toolbar-unavailable';
    return leaves.length===1?leaves[0]:null;
  }
  function reconcile(next){
    let changed=false;
    for(const [el,added] of owned){const wanted=next.get(el)||new Set(),current=tokens(el);for(const token of [...added])if(!wanted.has(token)){if(current.delete(token))changed=true;added.delete(token);}
      const value=[...current].join(' ');if(value!==el.getAttribute(attribute)){if(value)el.setAttribute(attribute,value);else el.removeAttribute(attribute);}if(!added.size)owned.delete(el);
    }
    for(const [el,wanted] of next){const current=tokens(el);let added=owned.get(el);for(const token of wanted)if(!current.has(token)){current.add(token);if(!added){added=new Set();owned.set(el,added)}added.add(token);changed=true;}
      const value=[...current].join(' ');if(value!==el.getAttribute(attribute))el.setAttribute(attribute,value);
    }
    return changed;
  }
  function chunkRenderer(el){
    // Current renderer: DOM text span -> chunks components -> {log,chunks}
    // component -> DOM bubble. Stop at the first enclosing DOM node so nested
    // links, usernames and controls cannot inherit the whole message identity.
    let f=fiber(el),message=false;const seen=new Set();
    for(let i=0;f&&i<24&&!seen.has(f);i++,f=f.return){
      seen.add(f);const p=f.memoizedProps;
      if(f.stateNode?.nodeType===1&&f.stateNode!==el)return message?f.stateNode:null;
      if(p?.log?.id!=null&&p.log.channelId!=null&&p.log.senderId!=null&&Object.prototype.hasOwnProperty.call(p,'chunks'))message=true;
    }
    return null;
  }
  function ownsFileModel(el){
    let f=fiber(el);const direct=reactProps(el),isFile=p=>p?.file?.id!=null&&(typeof p.file.fileName==='string'||typeof p.file.title==='string');
    if(isFile(direct))return true;
    const seen=new Set();for(let i=0;f&&i<20&&!seen.has(f);i++,f=f.return){seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==el)return false;if(isFile(f.memoizedProps))return true;}return false;
  }
  function ownsLogModel(el){
    const isLog=p=>p?.log?.id!=null&&p.log.channelId!=null&&p.log.senderId!=null;
    if(isLog(reactProps(el)))return true;
    let f=fiber(el);const seen=new Set();for(let i=0;f&&i<24&&!seen.has(f);i++,f=f.return){seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==el)return false;if(isLog(f.memoizedProps))return true;}return false;
  }
  function scan(){
    if(disposed)return;dirty=false;lastScan=now();scans++;
    const root=document.querySelector('#root'),next=new Map(),previousRail=currentRail,previousReady=appReady;
    const mark=(el,role)=>{if(!el||foreign(el)||!root?.contains(el))return;if(!next.has(el))next.set(el,new Set());next.get(el).add(role)};
    currentRail=null;appReady=false;
    if(root){
      const editors=[...root.querySelectorAll('.js-main-editor,[contenteditable="true"][role="textbox"]')].filter(el=>!foreign(el));
      const scrolls=[...root.querySelectorAll('.js-scroll-area')].filter(el=>!foreign(el));
      const nativeActions=editors.some(el=>propsWhere(el,p=>p.actions?.stores,60))||[...root.children].some(el=>propsWhere(el,p=>p.actions?.stores,60));
      appReady=!!(editors.length||scrolls.length||nativeActions);
      for(const el of editors)mark(el,'editor');for(const el of scrolls)mark(el,'scroll');
      for(const el of root.querySelectorAll('.js-channel-list'))mark(el,'sidebar');
      currentRail=discoverRail(root);if(currentRail){mark(currentRail,'rail');appReady=true;}
      // Message boundaries have stable per-log classes. Never inspect or log the
      // message string: React prop shape identifies the renderer, not its value.
      for(const group of root.querySelectorAll('[data-logid]'))if(!group.closest(excluded))mark(group,'message-group');
      for(const section of root.querySelectorAll('[class*="js-log-right-content-"]')){
        if(foreign(section)||section.closest(excluded))continue;mark(section,'message-content');mark(section.parentElement,'message-group');
        for(const el of section.querySelectorAll('*')){
          if(foreign(el)||el.closest(excluded))continue;
          const direct=reactProps(el)||fiber(el)?.memoizedProps;
          const bubble=chunkRenderer(el);if(bubble&&section.contains(bubble)){mark(el,'message-text');mark(bubble,'message-bubble');continue;}
          const html=direct?.dangerouslySetInnerHTML;
          if(ownsLogModel(el)&&html&&typeof html==='object'&&Object.prototype.hasOwnProperty.call(html,'__html')){mark(el,'message-text');mark(el.parentElement,'message-bubble');}
        }
      }
      // Old renderer compatibility. Restrict to the native conversation scope;
      // these hints do not permit unrelated pages or toolbar spoofing.
      const messageScopes=scrolls.length?scrolls:[root];
      for(const scope of messageScopes){for(const el of scope.querySelectorAll('.sc-chbbiW')){if(el.closest(excluded)||foreign(el))continue;const log=propsWhere(el,p=>p.log?.id!=null&&p.log.channelId!=null,30);if(!log&&!el.closest('[class*="js-log-right-content-"]'))continue;mark(el,'message-text');const bubble=el.closest('.sc-iyvyFf');if(bubble)mark(bubble,'message-bubble');const group=el.closest('.sc-drKuOJ');if(group)mark(group,'message-group');}}
      // A file prop is a native model boundary. Prefer the innermost element
      // carrying its own file prop rather than all React ancestors/descendants.
      const fileCandidates=[];
      for(const el of root.querySelectorAll('div,article,section')){
        if(foreign(el)||el.closest(excluded))continue;
        if(ownsFileModel(el))fileCandidates.push(el);
      }
      for(const el of fileCandidates)if(!fileCandidates.some(other=>other!==el&&el.contains(other)))mark(el,'file-card');
    }else railReason='root-unavailable';
    const changed=reconcile(next);
    if(changed||currentRail!==previousRail||appReady!==previousReady)for(const fn of [...listeners])try{fn()}catch{}
  }
  function conversations(){
    if(disposed)return [];
    const root=document.querySelector('#root');if(!root)return [];
    const id=value=>typeof value==='string'||typeof value==='number'?String(value):'';
    const valid=value=>/^\d{1,64}$/.test(id(value));
    const boundaries=[...root.querySelectorAll('.js-scroll-area,[data-dp-native~="scroll"]')].filter(el=>!foreign(el)&&!el.closest(excluded+',.js-channel-list,[data-dp-native~="sidebar"]'));
    const scrolls=boundaries.filter(el=>visible(el)&&el.clientHeight>0&&/^(auto|scroll|overlay)$/.test(win.getComputedStyle(el).overflowY));
    const editors=[...root.querySelectorAll('.js-main-editor,[data-dp-native~="editor"],[contenteditable="true"][role="textbox"]')].filter(el=>!foreign(el)&&!el.closest('[role="dialog"],[aria-modal="true"]')&&visible(el));
    const outerEditors=editors.filter(el=>!editors.some(other=>other!==el&&other.contains(el)));
    return scrolls.flatMap(scroll=>{
      // Read the closest native pane's channel, never the first global room or
      // a sender/message inherited from another conversation. Account identity
      // is part of the in-memory key so reused DOM cannot carry follow state.
      const pane=propsWhere(scroll,p=>valid(p.channelId),48),context=propsWhere(scroll,p=>valid(p.actions?.stores?.userStore?.id),48);
      if(!pane||!context)return [];
      let editor=null;
      for(let parent=scroll.parentElement,depth=0;parent&&root.contains(parent)&&depth<14;parent=parent.parentElement,depth++){
        if(boundaries.filter(other=>parent.contains(other)).length!==1)break;
        const matches=outerEditors.filter(el=>parent.contains(el));
        if(matches.length===1){editor=matches[0];break;}if(matches.length>1)break;
        if(parent===root)break;
      }
      const roomKey=[win.location?.origin||'',id(context.actions.stores.userStore.id),id(pane.channelId),valid(pane.threadChannelId)?id(pane.threadChannelId):''].join('|');
      // Current Dooray places message groups directly in the scroll viewport;
      // consumers must observe its children rather than assuming a wrapper.
      return [{scroll,content:scroll,editor,roomKey}];
    });
  }
  function schedule(){if(disposed||scheduled)return;scheduled=win.setTimeout(()=>{scheduled=0;if(dirty)scan()},Math.max(0,120-(now()-lastScan)));}
  function refresh(){if(disposed)return false;dirty=true;if(now()-lastScan>=120){if(scheduled){win.clearTimeout(scheduled);scheduled=0}scan()}else schedule();return appReady;}
  const observer=new win.MutationObserver(records=>{if(records.some(record=>!foreign(record.target.nodeType===1?record.target:record.target.parentElement))){dirty=true;schedule()}});
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','id','role','aria-label','title','aria-hidden','hidden','contenteditable']});
  const timer=win.setInterval(refresh,1500),onResize=()=>refresh();win.addEventListener('resize',onResize);scan();
  return {
    rail(){if(disposed)return null;if(currentRail&&!currentRail.isConnected){currentRail=null;dirty=true;schedule()}return currentRail;},
    ready(){return !disposed&&appReady;},refresh,conversations,
    diagnostics(){return {ready:!disposed&&appReady,rail:!!currentRail,railReason,scans,marked:owned.size};},
    subscribe(fn){if(typeof fn!=='function'||disposed)return ()=>{};listeners.add(fn);return ()=>listeners.delete(fn);},
    dispose(){if(disposed)return;disposed=true;observer.disconnect();win.clearInterval(timer);if(scheduled)win.clearTimeout(scheduled);win.removeEventListener('resize',onResize);listeners.clear();currentRail=null;appReady=false;reconcile(new Map());}
  };
}

// One owner for conversation bottom-follow. Never sends messages, replaces a
// native handler or infers a send from composing/modified Enter events.
function installChatScroll({document=globalThis.document,getTargets=()=>[],now=()=>performance.now(),requestFrame,cancelFrame,ResizeObserver,MutationObserver}={}){
  const win=document.defaultView||globalThis;
  requestFrame ||= win.requestAnimationFrame.bind(win);cancelFrame ||= win.cancelAnimationFrame.bind(win);
  ResizeObserver ||= win.ResizeObserver;MutationObserver ||= win.MutationObserver;
  const states=new Map(),observedRefs=new Map(),tokenOwner={};let disposed=false,refreshing=false,writes=0,navigationIntents=new WeakMap();
  const geometry=scroll=>({top:Math.max(0,Number(scroll.scrollTop)||0),height:Number(scroll.scrollHeight)||0,client:Number(scroll.clientHeight)||0});
  const near=m=>Math.max(0,m.height-m.client)-m.top<=3;
  const changed=(a,b)=>Math.abs(a.height-b.height)>.5||Math.abs(a.client-b.client)>.5;
  const hasMessages=scroll=>!!scroll.querySelector('[data-dp-native~="message-group"],[data-logid]');
  const editable=node=>!!node?.closest?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]');
  function relevant(state,node){return !node||node===state.scroll||state.scroll.contains(node)||node.contains?.(state.scroll)||state.editor&&(node===state.editor||state.editor.contains(node)||node.contains?.(state.editor));}
  function current(state){return !disposed&&states.get(state.scroll)===state&&state.scroll.isConnected;}
  function cancel(state){state.follow=false;state.allowRearm=false;state.tailHistory=[];state.revision++;state.remaining=0;state.writtenTop=null;if(state.frame){cancelFrame(state.frame);state.frame=0}}
  function clearNavigation(state){state.navigationLatch=false;navigationIntents.delete(state.scroll);}
  function inputAtBottom(state){if(!state.navigationLatch||!near(geometry(state.scroll)))return;clearNavigation(state);state.follow=true;state.readingHold=null;state.readingNavigation=null;rememberTail(state,geometry(state.scroll));schedule(state);}
  function anchorIdentity(node){
    const id=node.getAttribute?.('data-logid');if(id!==null&&id!==undefined)return 'log:'+id;
    const section=node.matches?.('[class*="js-log-right-content-"]')?node:node.querySelector?.('[class*="js-log-right-content-"]');
    const token=[...(section?.classList||[])].find(value=>value.startsWith('js-log-right-content-'));
    return token?'content:'+token:null;
  }
  const validAnchor=(state,anchor,requireIdentity=false)=>!!(anchor?.node.isConnected&&state.scroll.contains(anchor.node)&&(!requireIdentity||anchor.identity!==null)&&(anchor.identity===null||anchorIdentity(anchor.node)===anchor.identity));
  function measureAnchor(state){
    const viewport=state.scroll.getBoundingClientRect();
    const candidates=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');
    for(const node of candidates.length?candidates:state.content.children){const rect=node.getBoundingClientRect();if(rect.height>0&&rect.bottom>viewport.top&&rect.top<viewport.bottom)return {node,offset:rect.top-viewport.top,identity:anchorIdentity(node)};}
    return null;
  }
  // A native composer handler can scroll its conversation even when the reader
  // is far above the tail. Capture before that handler runs, then keep the real
  // visible message (not the subsequently forced scrollTop) as the reading intent.
  function captureReading(state){return {anchor:measureAnchor(state),top:geometry(state.scroll).top};}
  function holdReading(state){if(!state.follow&&!state.readingHold)state.readingHold=captureReading(state);}
  function readingGesture(state,direction){
    state.tailHistory=[];
    if(state.readingHold){state.readingHold=captureReading(state);state.readingNavigation={direction,at:now()};}
  }
  function readingNavigation(state,value,old){
    if(state.drag||state.touchMoving)return true;
    const intent=state.readingNavigation,age=intent?now()-intent.at:Infinity;
    if(!intent||age<0||age>900){state.readingNavigation=null;return false;}
    const delta=value.top-old.top;
    if(Math.abs(delta)<.5)return false;
    return intent.direction===0||Math.sign(delta)===intent.direction;
  }
  function acceptReadingNavigation(state,value,old){
    if(!readingNavigation(state,value,old))return false;
    state.readingHold=captureReading(state);state.revision++;
    if(!state.navigationLatch&&near(value)&&!state.drag&&!state.touchMoving){state.follow=true;state.readingHold=null;state.readingNavigation=null;state.allowRearm=false;}
    else if(state.readingNavigation?.direction===0)state.readingNavigation=null;
    state.metrics=value;return true;
  }
  function restoreReading(state){
    const hold=state.readingHold;if(!hold||!current(state))return;
    const value=geometry(state.scroll),anchor=hold.anchor;
    let top=hold.top;
    if(validAnchor(state,anchor,true))top=value.top+anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top-anchor.offset;
    if(Math.abs(value.top-top)>.5)write(state,top);
    // Native history prepending may already have preserved the same anchor.
    // Retain its updated numeric position as the fallback if that row is recycled.
    hold.top=geometry(state.scroll).top;state.metrics=geometry(state.scroll);
  }
  function rememberTail(state,value){
    if(!state.follow||!near(value))return;
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    const previous=state.tailHistory[state.tailHistory.length-1];
    if(!previous||Math.abs(previous.height-value.height)>.5||Math.abs(previous.client-value.client)>.5)state.tailHistory.push({height:value.height,client:value.client,at});
    if(state.tailHistory.length>12)state.tailHistory.shift();
  }
  function restoredTail(state,value){
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    // Dooray can restore either the old scrollTop or its old content extent
    // adjusted for the resized composer. Only these proven tail coordinates
    // qualify; an arbitrary jump elsewhere in history still cancels following.
    return state.tailHistory.some(point=>Math.abs(value.top-Math.max(0,point.height-point.client))<=3||Math.abs(value.top-Math.max(0,point.height-value.client))<=3);
  }
  function write(state,top){
    if(!current(state))return;state.writing=true;
    try{state.scroll.scrollTop=top;writes++;state.metrics=geometry(state.scroll);state.writtenTop=state.metrics.top;}finally{state.writing=false}
  }
  function schedule(state){
    if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    state.remaining=3;state.stable=0;if(!state.frame)state.frame=requestFrame(()=>settle(state));
  }
  function settle(state){
    state.frame=0;refresh();if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    if(!state.follow){
      // A wheel/key can move the browser before its asynchronous scroll event.
      // A layout observer must not restore the pre-gesture reading snapshot.
      acceptReadingNavigation(state,geometry(state.scroll),state.metrics);
      if(!state.follow){restoreReading(state);state.remaining=0;return;}
    }
    const before=geometry(state.scroll);
    // Newly mounted empty panes may still receive Dooray's saved reading
    // position. Measure that native restoration before taking ownership.
    if(state.unsettled){if(before.height>before.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=!state.navigationLatch&&near(before)}state.metrics=before;state.remaining=0;return;}
    if(changed(before,state.metrics))rememberTail(state,state.metrics);
    const gap=Math.max(0,before.height-before.client)-before.top;
    if(gap>.5)write(state,state.scroll.scrollHeight);
    const after=geometry(state.scroll);state.stable=!changed(before,after)&&Math.max(0,after.height-after.client)-after.top<=.5?state.stable+1:0;
    rememberTail(state,after);state.metrics=after;state.remaining--;
    if(state.remaining>0&&state.stable<2)state.frame=requestFrame(()=>settle(state));
  }
  function onScroll(state){
    refresh();if(!current(state))return;const value=geometry(state.scroll),old=state.metrics;
    if(state.writing){state.metrics=value;return;}
    const layoutChanged=changed(value,old),own=state.writtenTop!==null&&Math.abs(value.top-state.writtenTop)<.75;
    if(layoutChanged)rememberTail(state,old);
    const restoring=restoredTail(state,value);
    state.writtenTop=null;
    if(state.readingHold&&!state.follow&&!own){
      if(!acceptReadingNavigation(state,value,old)){restoreReading(state);return;}
    }
    if(state.drag||state.touchMoving){state.follow=false;}
    else if(state.unsettled&&layoutChanged){if(value.height>value.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=!state.navigationLatch&&near(value)}}
    else if(state.follow&&!own&&value.top<old.top-.5&&!layoutChanged&&!near(value)&&!restoring){cancel(state);}
    else if(!state.follow&&!state.readingHold&&!state.navigationLatch&&near(value)&&(value.top>old.top+.5||state.allowRearm)){state.follow=true;state.allowRearm=false;}
    else if(!state.follow&&!layoutChanged&&!own&&Math.abs(value.top-old.top)>.5){state.revision++;}
    state.metrics=value;if(state.follow){if(near(value))rememberTail(state,value);if(layoutChanged||restoring)schedule(state);}
  }
  const resize=ResizeObserver?new ResizeObserver(entries=>{refresh();for(const state of states.values())if(entries.some(entry=>state.observed.has(entry.target)))schedule(state)}):null;
  function observeSize(state){
    if(!state.sizeDirty)return;state.sizeDirty=false;
    const next=new Set([state.scroll,state.content]);if(state.editor)next.add(state.editor);
    // Dooray can put the message groups directly in a fixed-height scroller;
    // observing that viewport alone would miss late fonts and inline images.
    for(const child of [...state.content.children].slice(-512))next.add(child);
    const last=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');if(last.length)next.add(last[last.length-1]);
    for(const node of state.observed)if(!next.has(node))releaseSize(node);
    for(const node of next)if(!state.observed.has(node)){const count=observedRefs.get(node)||0;if(!count)resize?.observe(node);observedRefs.set(node,count+1)}
    state.observed=next;
  }
  function releaseSize(node){const count=observedRefs.get(node)||0;if(count<=1){observedRefs.delete(node);resize?.unobserve(node)}else observedRefs.set(node,count-1);}
  function attach(target){
    const scroll=target.scroll,metrics=geometry(scroll),intent=navigationIntents.get(scroll),navigationLatch=intent?.roomKey===target.roomKey;
    if(intent&&!navigationLatch)navigationIntents.delete(scroll);
    const state={scroll,content:target.content||scroll,editor:target.editor||null,roomKey:target.roomKey,metrics,follow:!navigationLatch&&near(metrics),navigationLatch,frame:0,remaining:0,stable:0,revision:0,writtenTop:null,writing:false,drag:false,touchMoving:false,touchY:null,allowRearm:false,tailHistory:[],readingHold:null,readingNavigation:null,observed:new Set(),sizeDirty:true,unsettled:metrics.height<=metrics.client&&!hasMessages(scroll)};
    state.scrollEvent=()=>onScroll(state);
    state.wheel=event=>{if(event.deltaY<0){clearNavigation(state);readingGesture(state,-1);cancel(state);}else if(event.deltaY>0){clearNavigation(state);readingGesture(state,1);state.allowRearm=true;if(near(geometry(scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}}};
    state.pointer=event=>{const rect=scroll.getBoundingClientRect(),width=Math.max(12,(Number(scroll.offsetWidth)||scroll.clientWidth)-scroll.clientWidth);if(event.target===scroll&&event.pointerType!=='touch'&&event.clientX>=rect.right-width&&event.clientX<=rect.right+1){clearNavigation(state);readingGesture(state,0);state.drag=true;cancel(state)}};
    state.touchStart=event=>{state.touchY=event.touches?.[0]?.clientY??null;state.touchMoving=false;};
    state.touchMove=event=>{const y=event.touches?.[0]?.clientY;if(state.touchY!==null&&Number.isFinite(y)&&Math.abs(y-state.touchY)>2){clearNavigation(state);readingGesture(state,Math.sign(state.touchY-y));state.touchMoving=true;cancel(state)}};
    scroll.addEventListener('scroll',state.scrollEvent,{passive:true});scroll.addEventListener('wheel',state.wheel,{passive:true});scroll.addEventListener('pointerdown',state.pointer,{passive:true});scroll.addEventListener('touchstart',state.touchStart,{passive:true});scroll.addEventListener('touchmove',state.touchMove,{passive:true});
    states.set(scroll,state);observeSize(state);return state;
  }
  function detach(state){
    cancel(state);for(const node of state.observed)releaseSize(node);state.observed.clear();
    for(const [event,handler]of [['scroll',state.scrollEvent],['wheel',state.wheel],['pointerdown',state.pointer],['touchstart',state.touchStart],['touchmove',state.touchMove]])state.scroll.removeEventListener(event,handler);
    states.delete(state.scroll);
  }
  function refresh(){
    if(disposed||refreshing)return;refreshing=true;
    try{
      let targets;try{targets=getTargets()||[]}catch{targets=[]}
      const selected=new Map();for(const target of targets){if(!target?.scroll?.isConnected||target.scroll.clientHeight<=0||target.roomKey===undefined||target.roomKey===null||target.roomKey==='')continue;if(!selected.has(target.scroll))selected.set(target.scroll,target);}
      for(const state of states.values()){const target=selected.get(state.scroll);if(!target||target.roomKey!==state.roomKey)detach(state);}
      for(const target of selected.values()){
        let state=states.get(target.scroll);if(!state){attach(target);continue;}
        const content=target.content||target.scroll,editor=target.editor||null;
        if(content!==state.content||editor!==state.editor){state.content=content;state.editor=editor;state.sizeDirty=true;observeSize(state);schedule(state)}else observeSize(state);
      }
    }finally{refreshing=false}
  }
  function notifyLayout(node){if(disposed)return;refresh();for(const state of states.values())if(relevant(state,node))schedule(state);}
  function beforeLayout(node){
    if(disposed)return null;refresh();const records=[];
    for(const state of states.values())if(relevant(state,node))records.push({state,revision:state.revision,roomKey:state.roomKey,follow:state.follow,metrics:geometry(state.scroll),anchor:state.follow?null:measureAnchor(state)});
    return {owner:tokenOwner,records};
  }
  function afterLayout(token){
    if(disposed||token?.owner!==tokenOwner)return;refresh();
    for(const record of token.records){const state=record.state;if(!current(state)||record.roomKey!==state.roomKey||record.revision!==state.revision)continue;
      if(record.follow&&state.follow){
        const value=geometry(state.scroll);
        // Excel temporarily removes row min-heights while measuring. Chromium
        // can clamp top during that owned transaction, then report a scroll only
        // after the final height is restored. Keep the actually observed clamp
        // as evidence, without treating any unrelated history jump as a restore.
        if(value.top<record.metrics.top-.5&&!near(value)){
          state.tailHistory.push({height:value.top+value.client,client:value.client,at:now()});
          if(state.tailHistory.length>12)state.tailHistory.shift();
        }
        schedule(state);continue;
      }
      // Explicit decoration/theme changes can occur above a reader. Preserve
      // a real visible anchor, and avoid doubling the browser's own anchoring.
      const anchor=record.anchor;if(!record.follow&&!state.follow&&validAnchor(state,anchor)){
        const offset=anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top,delta=offset-anchor.offset;
        if(Math.abs(delta)>.5)write(state,state.scroll.scrollTop+delta);
      }
    }
  }
  function eventNodes(event){
    const supplied=event.composedPath?.()||[],nodes=supplied.filter(node=>node?.nodeType===1).slice(0,32);
    if(nodes.length)return nodes;
    for(let node=event.target?.nodeType===1?event.target:event.target?.parentElement;node&&nodes.length<32;node=node.parentElement||node.getRootNode?.().host)nodes.push(node);
    return nodes;
  }
  // Native metadata is optional. A stale React getter or Proxy must not abort
  // the capture listener or prevent a valid accessible control from working.
  const read=(value,key)=>{try{return value?.[key]}catch{return undefined}};
  const readPath=(value,...keys)=>keys.reduce((current,key)=>read(current,key),value);
  function models(node){
    let keys=[];try{keys=Object.keys(node)}catch{}
    const found=[],seen=new Set(),add=value=>{if(value&&typeof value==='object'&&!seen.has(value)){seen.add(value);found.push(value)}};
    add(read(node,keys.find(key=>key.startsWith('__reactProps'))));
    let fiber=read(node,keys.find(key=>key.startsWith('__reactFiber')));
    for(let count=0;fiber&&count<12;count++,fiber=read(fiber,'return')){const host=read(fiber,'stateNode');if(read(host,'nodeType')===1&&host!==node)break;add(read(fiber,'memoizedProps'))}
    return found;
  }
  function navigationLabel(value){
    if(typeof value!=='string'||value.length>160)return false;
    const label=value.replace(/[\s\u200b-\u200d\ufeff_-]/g,'').toLowerCase();
    return /^(?:(?:파일|사진|이미지|영상|동영상)(?:의)?)?(?:(?:원본|해당|이)?)?(?:대화|채팅|메시지|검색결과|인용메시지|답글원문)(?:위치|원문)?(?:로|으로)?(?:바로)?(?:가기|이동|보기)$/.test(label)||/^(?:handle)?(?:go(?:to)?|jump(?:to)?|move(?:to)?|showin)(?:the)?(?:message|conversation|chat|log)$/.test(label)||/^(?:open|select)searchresult$/.test(label);
  }
  function nativeResult(nodes){
    const index=nodes.findIndex(node=>node.getAttribute('data-testid')==='collection-panel-log-frame-clickable');if(index<0||index>=16)return null;
    if(nodes.slice(0,index).some(node=>node.matches('a,button,input,select,textarea,label,[contenteditable]:not([contenteditable="false"]),[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="switch"],[role="textbox"],[role="combobox"],[role="listbox"],[role="menuitem"],[role="option"],[role="slider"],[role="spinbutton"]')))return null;
    const clickable=nodes[index];if(!models(clickable).some(p=>typeof read(p,'onClick')==='function'))return null;
    const frame=nodes.slice(index+1,16).find(node=>node.getAttribute('data-testid')==='collection-panel-log-frame');if(!frame?.contains(clickable))return null;
    for(const p of models(frame)){
      const log=read(p,'log'),id=numeric(read(log,'id')),channel=numeric(read(log,'channelId'));
      if(id&&channel)return {channel,thread:numeric(read(log,'threadChannelId')??read(p,'threadChannelId')),user:numeric(readPath(p,'actions','stores','userStore','id'))};
    }
    return null;
  }
  function navigationAction(nodes,result){
    if(!nodes.length||editable(nodes[0]))return false;
    if(nodes.some(node=>node.matches('button:disabled,input:disabled,[aria-disabled="true"]')))return false;
    const explicit=nodes.some(node=>node.hasAttribute('data-dt-goto')&&node.getAttribute('data-dt-goto')!=='false');
    // Pack names and other Plus UI captions are user data, even when their
    // wording happens to match a native GoTo action. Only owned GoTo controls
    // carry the explicit marker; ordinary native Shadow controls remain valid.
    if(!explicit&&nodes.some(node=>node.matches('[id^="dooray-theme-"],.dt-emoticon-custom,.dt-emoticon-context-menu,.dt-emoticon-hover-preview,.dt-received-emoticon')))return false;
    if(result)return true;
    let childHint=false;
    for(const node of nodes.slice(0,16)){
      if(node===document.body||node===document.documentElement||node.id==='root'||node.matches('[data-dp-native~="scroll"],.js-scroll-area,[contenteditable="true"]'))break;
      if(node.hasAttribute('data-dt-goto')&&node.getAttribute('data-dt-goto')!=='false')return true;
      const control=node.matches('button,[role="button"],a,[role="link"],[role="menuitem"],[role="option"]');
      if(control&&(childHint||[node.getAttribute('aria-label'),node.getAttribute('title'),node.textContent].some(navigationLabel)))return true;
      const props=models(node),hint=[node.getAttribute('data-action'),node.getAttribute('data-testid')];
      for(const p of props){for(const key of ['action','actionName','actionType','command','commandName','name','iconName','aria-label','title'])hint.push(read(p,key));const handler=read(p,'onClick'),name=read(handler,'name');if(typeof handler==='function'&&typeof name==='string')hint.push(name.replace(/^bound /,''))}
      const ownHint=hint.some(navigationLabel);
      if(control&&ownHint)return true;
      if(ownHint&&props.some(p=>typeof read(p,'onClick')==='function'))return true;
      childHint ||= ownHint;
    }
    return false;
  }
  const numeric=value=>(typeof value==='string'||typeof value==='number')&&/^\d+$/.test(String(value))?String(value):null;
  function channelScope(all,{channel,thread,user}){
    const matched=all.filter(state=>{const parts=typeof state.roomKey==='string'?state.roomKey.split('|'):[];return parts.length===4&&parts[0]===win.location?.origin&&numeric(parts[1])&&numeric(parts[2])&&parts[2]===channel&&(!thread||parts[3]===thread)&&(!user||parts[1]===user)});
    return matched.length===1?matched:[];
  }
  function navigationScope(nodes,result){
    const all=[...states.values()];if(result)return channelScope(all,result);
    const owned=all.filter(state=>nodes.some(node=>node===state.scroll||state.scroll.contains(node)||state.editor?.contains(node)));
    if(owned.length)return owned;
    for(const node of nodes){
      if(node===document.body||node===document.documentElement)break;
      const enclosed=all.filter(state=>node.contains(state.scroll)||state.editor&&node.contains(state.editor));
      if(enclosed.length===1)return enclosed;
      if(enclosed.length>1)break;
    }
    let channel=null,thread=null,user=null;
    for(const node of nodes.slice(0,16)){
      const explicit=numeric(node.getAttribute('data-dt-navigation-channel'));
      if(explicit){channel=explicit;thread=numeric(node.getAttribute('data-dt-navigation-thread'));break;}
    }
    if(!channel)for(const node of nodes.slice(0,16)){
      if(node===document.body||node===document.documentElement||node.id==='root')break;
      for(const p of models(node)){
        const target=[read(p,'file'),read(p,'log')].find(value=>value&&numeric(read(value,'channelId')));
        if(target){channel=numeric(read(target,'channelId'));thread=numeric(read(target,'threadChannelId')??read(p,'threadChannelId'));user=numeric(readPath(p,'actions','stores','userStore','id'));break;}
      }
      if(channel)break;
    }
    if(channel)return channelScope(all,{channel,thread,user});
    return all.length===1?all:[];
  }
  function releaseNavigation(state){state.readingHold=null;state.readingNavigation=null;cancel(state);state.navigationLatch=true;navigationIntents.set(state.scroll,{roomKey:state.roomKey});state.metrics=geometry(state.scroll);}
  function explicitNavigation(event,nodes=eventNodes(event)){
    const result=nativeResult(nodes);if(!navigationAction(nodes,result))return false;
    for(const state of navigationScope(nodes,result))releaseNavigation(state);
    return true;
  }
  const key=event=>{
    if(disposed)return;refresh();
    if(!event.isComposing&&event.keyCode!==229&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&['Enter',' '].includes(event.key)&&explicitNavigation(event))return;
    for(const state of states.values())if(relevant(state,event.target)){
      if(editable(event.target)){
        if(!state.editor?.contains(event.target))continue;
        if(!event.isComposing&&event.keyCode!==229&&event.key==='Enter'&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey)inputAtBottom(state);
        holdReading(state);
        if(!event.isComposing&&event.keyCode!==229&&event.key==='Enter'&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&state.follow){state.unsettled=false;rememberTail(state,geometry(state.scroll));schedule(state)}
        continue;
      }
      if(event.isComposing||event.keyCode===229)continue;
      if(['ArrowUp','PageUp','Home'].includes(event.key)||event.key===' '&&event.shiftKey){clearNavigation(state);readingGesture(state,-1);cancel(state);}
      else if(['ArrowDown','PageDown','End'].includes(event.key)||event.key===' '){clearNavigation(state);readingGesture(state,1);state.allowRearm=true;}
      else if(!state.navigationLatch)readingGesture(state,0);
    }
  };
  const editorInput=event=>{if(disposed)return;refresh();for(const state of states.values())if(state.editor?.contains(event.target)){if(event.type!=='compositionstart')inputAtBottom(state);holdReading(state);}};
  // Native search/quote navigation wins over an old restore hint. Clicking or
  // editing a different pane must not release this pane's saved reading intent.
  const pointerIntent=event=>{
    if(disposed)return;refresh();const nodes=eventNodes(event);if(explicitNavigation(event,nodes))return;
    for(const state of navigationScope(nodes)){
      if(nodes.some(node=>state.editor?.contains(node))){holdReading(state);continue;}
      const message=nodes.find(node=>node.matches('[data-logid],[class*="js-log-right-content-"]'));
      const inside=nodes.some(node=>node===state.scroll||state.scroll.contains(node)),jump=!!message&&!inside;
      // Submit buttons can be siblings of the editor. An arbitrary click is
      // not permission to discard a saved reading position. A proven message
      // navigation releases the hold, including asynchronously loaded results.
      if(jump)releaseNavigation(state);
      else if(inside){state.tailHistory=[];state.readingHold=null;state.readingNavigation=null;state.revision++;}
    }
  };
  const pointerUp=()=>{for(const state of states.values())if(state.drag){state.drag=false;state.readingNavigation=null;if(!state.navigationLatch&&near(geometry(state.scroll))){state.follow=true;state.readingHold=null;schedule(state)}else if(state.readingHold)state.readingHold=captureReading(state)}};
  const touchEnd=()=>{for(const state of states.values()){const moved=state.touchMoving;state.touchY=null;state.touchMoving=false;if(moved&&!state.navigationLatch&&near(geometry(state.scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}else if(moved&&state.readingHold)state.readingHold=captureReading(state)}};
  const mutation=MutationObserver?new MutationObserver(records=>{
    if(disposed)return;for(const state of states.values())if(records.some(record=>relevant(state,record.target)))state.sizeDirty=true;
    refresh();for(const state of states.values())if(records.some(record=>relevant(state,record.target)))schedule(state);
  }):null;
  mutation?.observe(document.documentElement||document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class','hidden']});
  const onLoad=event=>notifyLayout(event.target),onResize=()=>notifyLayout(),onFonts=()=>notifyLayout();
  document.addEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.addEventListener(event,editorInput,true);document.addEventListener('pointerdown',pointerIntent,true);document.addEventListener('click',pointerIntent,true);document.addEventListener('pointerup',pointerUp,true);document.addEventListener('pointercancel',pointerUp,true);document.addEventListener('touchend',touchEnd,true);document.addEventListener('touchcancel',touchEnd,true);document.addEventListener('load',onLoad,true);document.addEventListener('loadedmetadata',onLoad,true);win.addEventListener('resize',onResize);
  document.fonts?.addEventListener?.('loadingdone',onFonts);document.fonts?.ready?.then(()=>{if(!disposed)onFonts()}).catch(()=>{});
  refresh();
  return {
    refresh,beforeLayout,afterLayout,notifyLayout,
    isFollowing(node){if(disposed)return false;refresh();return [...states.values()].some(state=>relevant(state,node)&&state.follow)},
    diagnostics(){return {targets:states.size,following:[...states.values()].filter(state=>state.follow).length,pending:[...states.values()].filter(state=>state.frame).length,writes}},
    dispose(){if(disposed)return;disposed=true;mutation?.disconnect();resize?.disconnect();for(const state of [...states.values()])detach(state);navigationIntents=new WeakMap();document.removeEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.removeEventListener(event,editorInput,true);document.removeEventListener('pointerdown',pointerIntent,true);document.removeEventListener('click',pointerIntent,true);document.removeEventListener('pointerup',pointerUp,true);document.removeEventListener('pointercancel',pointerUp,true);document.removeEventListener('touchend',touchEnd,true);document.removeEventListener('touchcancel',touchEnd,true);document.removeEventListener('load',onLoad,true);document.removeEventListener('loadedmetadata',onLoad,true);win.removeEventListener('resize',onResize);document.fonts?.removeEventListener?.('loadingdone',onFonts);}
  };
}

// Bundled inside theme.js; explicit item clicks use Dooray's native message pipeline.
function installCustomEmoticons({rpc,scrollController}){
  let disposed=false,scheduled=0,catalog=null,loading=null;const popups=new Map(),decorated=new Map(),assetPromises=new Map();
  const scrollStates=new Map();
  const atBottom=scroll=>scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<=48;
  function scrollState(node){
    // The shared conversation controller is the sole scroll owner in the
    // bundled app. The local path remains for standalone older integrations.
    if(scrollController)return null;
    let scroll=node.closest('[data-dp-native~="scroll"],.js-scroll-area');
    // Some Dooray layouts put the actual overflow on a wrapper around the message list.
    for(let p=node.parentElement;p&&p!==document.body;p=p.parentElement){if(/auto|scroll/.test(getComputedStyle(p).overflowY)&&p.clientHeight>0){scroll=p;break}}
    if(!scroll)return null;
    if(!scrollStates.has(scroll)){
      const state={scroll,follow:atBottom(scroll),frame:0};
      const changed=()=>{state.follow=atBottom(scroll)};
      const cancel=()=>{state.follow=false};
      const wheel=e=>{if(e.deltaY<0)cancel()};
      const key=e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))cancel()};
      scroll.addEventListener('scroll',changed,{passive:true});scroll.addEventListener('wheel',wheel,{passive:true});
      scroll.addEventListener('touchstart',cancel,{passive:true});scroll.addEventListener('pointerdown',cancel,{passive:true});scroll.addEventListener('keydown',key);
      state.dispose=()=>{cancelAnimationFrame(state.frame);scroll.removeEventListener('scroll',changed);scroll.removeEventListener('wheel',wheel);scroll.removeEventListener('touchstart',cancel);scroll.removeEventListener('pointerdown',cancel);scroll.removeEventListener('keydown',key)};
      scrollStates.set(scroll,state);
    }
    return scrollStates.get(scroll);
  }
  function followBottom(state){
    if(!state||!state.follow||disposed||!state.scroll.isConnected)return;
    state.scroll.scrollTop=state.scroll.scrollHeight;
    cancelAnimationFrame(state.frame);
    state.frame=requestAnimationFrame(()=>{state.frame=0;if(state.follow&&!disposed&&state.scroll.isConnected)state.scroll.scrollTop=state.scroll.scrollHeight});
  }
  const resized=new ResizeObserver(entries=>{for(const entry of entries){if(scrollController)scrollController.notifyLayout(entry.target);else followBottom(scrollState(entry.target))}});
  const prefix='[[dooray-emoji:v1:',suffix=']]';
  const encode=item=>prefix+btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify({p:item.path,r:item.ref,n:item.label})))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')+suffix;
  function decode(text){try{text=text.replace(/[\s\u200B-\u200D\uFEFF]/g,'');if(text.length>5000||!text.startsWith(prefix)||!text.endsWith(suffix))return null;const base=text.slice(prefix.length,-suffix.length).replace(/-/g,'+').replace(/_/g,'/');const obj=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(base),c=>c.charCodeAt(0))));if(typeof obj.p!=='string'||!obj.p.startsWith('packs/')||obj.p.length>1000||!/^([a-f\d]{40})$/i.test(obj.r)||!(/\.(png|gif|jpe?g|webp)$/i.test(obj.p)))return null;return {path:obj.p,ref:obj.r,label:String(obj.n||'커스텀 이모티콘').slice(0,100)}}catch{return null}}
  // This is a picker-use lock, not encryption or an image-access boundary.
  // Grants live only in this feature instance: no password or grant is stored.
  const pickerVersion='3.8.45',unlocked=new Set();let catalogSignature='';
  let packViews=new WeakMap();const packCollator=new Intl.Collator('ko',{numeric:true,sensitivity:'base'});
  const exactOrder=(a,b)=>a<b?-1:a>b?1:0;
  function sortedPacks(data){
    const values=[...(Array.isArray(data?.packs)?data.packs:[]),...(Array.isArray(data?.lockedPacks)?data.lockedPacks:[])];
    return values.map(pack=>{
      const name=String(pack?.name??pack?.id??'').normalize('NFC').trimStart();
      return {pack,name,special:/^[\p{P}\p{S}]/u.test(name)?0:1,path:String(pack?.packPath??'').normalize('NFC'),id:String(pack?.id??'').normalize('NFC')};
    }).sort((a,b)=>a.special-b.special||packCollator.compare(a.name,b.name)||exactOrder(a.name,b.name)||exactOrder(a.path,b.path)||exactOrder(a.id,b.id)).map(row=>row.pack);
  }
  function packList(data){
    if(!data||typeof data!=='object')return [];
    if(!packViews.has(data))packViews.set(data,sortedPacks(data));
    return packViews.get(data);
  }
  function pickerCatalog(data){
    // Rebuild even when a caller reuses its catalog object. Only this copied
    // view is reordered; source arrays, pack/item objects and grants stay intact.
    const packs=sortedPacks(data),view={...data,packs,lockedPacks:[]};
    packViews.set(data,packs);packViews.set(view,packs);return view;
  }
  const validVersion=value=>typeof value==='string'&&/^(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})$/.test(value);
  const versionAtLeast=(value,minimum)=>{if(!validVersion(value)||!validVersion(minimum))return false;const a=value.split('.').map(Number),b=minimum.split('.').map(Number);for(let i=0;i<3;i++)if(a[i]!==b[i])return a[i]>b[i];return true};
  const canonicalPackPath=value=>typeof value==='string'&&value.length<=1000&&value.startsWith('packs/')&&/\.json$/i.test(value)&&!/[\\\x00-\x1f\x7f-\x9f]/.test(value)&&value.split('/').every(x=>x&&x!=='.'&&x!=='..');
  const validPassword=value=>typeof value==='string'&&[...value].length>=1&&[...value].length<=128&&!/[\x00-\x1f\x7f-\x9f]/.test(value)&&![...value].some(c=>c.length===1&&/[\uD800-\uDFFF]/.test(c));
  function currentPack(pack,data=catalog){if(!pack)return null;const matches=packList(data).filter(p=>pack.packPath?p.packPath===pack.packPath:p.id===pack.id);return matches.length===1?matches[0]:null}
  function packGate(candidate){
    const pack=currentPack(candidate);if(!pack)return {allowed:false,reason:'missing'};
    if(pack.accessPending===true)return {pack,allowed:false,reason:'pending'};
    if(pack.accessPending!==undefined)return {pack,allowed:false,reason:'invalid'};
    const protectedPack=pack.password!==undefined;
    if((pack.minVersion!==undefined&&!validVersion(pack.minVersion))||(protectedPack&&(!validPassword(pack.password)||!canonicalPackPath(pack.packPath)||!/^([a-f\d]{40})$/i.test(pack.ref)||!versionAtLeast(pack.minVersion,'3.8.34'))))return {pack,allowed:false,reason:'invalid'};
    if(pack.minVersion!==undefined&&!versionAtLeast(pickerVersion,pack.minVersion))return {pack,allowed:false,reason:'version'};
    if(!protectedPack)return {pack,allowed:true};
    const key=JSON.stringify([pack.packPath,pack.password,pack.minVersion]);return {pack,key,allowed:unlocked.has(key),reason:'locked'};
  }
  function itemGate(item){
    if(!item||typeof item.path!=='string'||!/^([a-f\d]{40})$/i.test(item.ref))return {allowed:false,reason:'missing'};
    // Old favorites keep their original immutable image ref. Current membership
    // supplies the policy; a new image is never substituted for an old favorite.
    const matches=packList(catalog).filter(p=>p.items?.some(x=>x.path===item.path)||(p.accessPending===true&&canonicalPackPath(p.packPath)&&item.path.startsWith(p.packPath.slice(0,p.packPath.lastIndexOf('/')+1))));return matches.length===1?packGate(matches[0]):{allowed:false,reason:'missing'};
  }
  const gateMessage=gate=>gate.reason==='pending'?'이 팩의 새 잠금 설정을 확인 중입니다. 목록을 새로고침해 주세요.':gate.reason==='version'?'이 팩은 두레이 플러스 '+gate.pack.minVersion+' 이상에서 사용할 수 있습니다.':gate.reason==='locked'?'비밀번호를 입력하면 이 팩을 사용할 수 있습니다.':gate.reason==='invalid'?'팩의 잠금 설정을 확인하지 못했습니다. 목록을 새로고침해 주세요.':'현재 목록에서 이 이모티콘 팩을 찾지 못했습니다. 목록을 새로고침해 주세요.';
  function showGate(popup,state,gate){if(gate.pack){state.selected=gate.pack;drawPack(popup,state)}else state.status.textContent=gateMessage(gate)}
  function refreshPickerViews(){for(const [popup,state] of popups){if(!popup.isConnected)continue;state.selection=state.selection.filter(item=>itemGate(item).allowed);if(state.visited){const top=state.grid.scrollTop,restoring=state.restoreTop!==undefined;fillPicker(popup,state,catalog);if(!restoring)state.grid.scrollTop=top;rememberPicker(state);renderSelection(state,false)}else state.data=catalog}}
  function acceptCatalog(next){
    if(!next||!Array.isArray(next.packs)||(next.lockedPacks!==undefined&&!Array.isArray(next.lockedPacks)))throw Error('이모티콘 목록 형식이 올바르지 않습니다.');
    if(disposed)return next;
    next=pickerCatalog(next);
    const signature=JSON.stringify([next.ref,next.warnings,packList(next).map(p=>[p.id,p.name,p.packPath,p.ref,p.password,p.minVersion,p.accessPending,p.items?.map(i=>[i.path,i.ref])])]);
    catalog=next;if(signature!==catalogSignature){catalogSignature=signature;const valid=new Set(packList(next).map(p=>packGate(p).key).filter(Boolean));for(const key of unlocked)if(!valid.has(key))unlocked.delete(key);hidePreview();refreshPickerViews()}return next;
  }
  const memory=new Map(),queue=[];let running=0,memoryBytes=0;
  function pump(){while(!disposed&&running<6&&queue.length){queue.sort((a,b)=>a.priority-b.priority);const job=queue.shift();running++;job.run().finally(()=>{running--;pump()})}}
  function image(item,refresh=false,priority=0){
    const key=item.ref+'/'+item.path;
    if(refresh&&memory.has(key)){memoryBytes-=memory.get(key).length*2;memory.delete(key)}
    if(!refresh&&memory.has(key)){const data=memory.get(key);memory.delete(key);memory.set(key,data);return Promise.resolve(data)}
    if(assetPromises.has(key)){const waiting=queue.find(j=>j.key===key);if(waiting)waiting.priority=Math.min(waiting.priority,priority);return assetPromises.get(key)}
    let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});assetPromises.set(key,promise);
    queue.push({key,priority,run:async()=>{try{const r=await rpc('emoticon-image',{path:item.path,ref:item.ref,refresh});if(!/^data:image\/(png|gif|jpeg|webp);base64,/.test(r.data))throw Error('이미지 응답 오류');
      if(!disposed&&r.data.length*2<=24*1024*1024){memory.set(key,r.data);memoryBytes+=r.data.length*2;while(memory.size>128||memoryBytes>24*1024*1024){const first=memory.keys().next().value;memoryBytes-=memory.get(first).length*2;memory.delete(first)}}resolve(r.data)
    }catch(e){reject(e)}finally{assetPromises.delete(key)}}});pump();return promise;
  }
  let hoverPreview=null,hoverGeneration=0;
  function hidePreview(){hoverGeneration++;hoverPreview?.remove();hoverPreview=null;}
  async function showPreview(item,anchor){
    hidePreview();if(!itemGate(item).allowed)return;const generation=hoverGeneration;
    try{const src=await image(item);if(disposed||generation!==hoverGeneration||!itemGate(item).allowed||!anchor.isConnected||anchor.getRootNode().host?.hidden)return;
      const card=document.createElement('div');card.className='dt-emoticon-hover-preview';card.setAttribute('role','tooltip');card.style.cssText='position:fixed;z-index:2147483647;pointer-events:none;width:220px;height:220px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);padding:8px;box-sizing:border-box;border:1px solid #8793a4;border-radius:12px;box-shadow:0 8px 28px #0004;background:#fff';
      const theme=getComputedStyle(anchor);card.style.background=theme.getPropertyValue('--dt-bg').trim()||'#fff';const shadow=card.attachShadow({mode:'open'}),img=document.createElement('img');img.alt=item.label;img.src=src;img.style.cssText='display:block;width:100%;height:100%;object-fit:contain';shadow.append(img);document.body.append(card);hoverPreview=card;
      const rect=anchor.getBoundingClientRect(),width=card.getBoundingClientRect().width||220,height=card.getBoundingClientRect().height||220;const left=rect.right+12+width<=innerWidth?rect.right+12:rect.left-width-12;card.style.left=Math.max(8,Math.min(left,innerWidth-width-8))+'px';card.style.top=Math.max(8,Math.min(rect.top+(rect.height-height)/2,innerHeight-height-8))+'px';
    }catch{}
  }
  document.addEventListener('scroll',hidePreview,true);window.addEventListener('resize',hidePreview);
  let emojiMenu=null,jumpRequest=null;
  function closeEmojiMenu(){emojiMenu?.remove();emojiMenu=null;}
  function dismissEmojiMenu(event){if(emojiMenu&&!event.composedPath().includes(emojiMenu))closeEmojiMenu()}
  function menuKey(event){if(event.key==='Escape'){closeEmojiMenu();jumpRequest=null}}
  document.addEventListener('pointerdown',dismissEmojiMenu,true);document.addEventListener('keydown',menuKey);
  function emojiOpener(){
    for(const svg of document.querySelectorAll('#root svg')){let f=svg[Object.keys(svg).find(k=>k.startsWith('__reactFiber'))];for(let n=0;f&&n<12;n++,f=f.return)if(f.memoizedProps?.name==='editorEmoticon'){const button=svg.closest('button');if(button&&!button.disabled&&button.getClientRects().length)return button;break}}
    return null;
  }
  function openEmojiPack(item){
    const popup=[...popups.keys()].find(p=>p.isConnected&&p.getClientRects().length);const opener=popup?null:emojiOpener();if(!popup&&!opener)return false;
    jumpRequest={item,expires:Date.now()+10000,popup:null};if(opener)opener.click();if(popup)beginJump(popup,popups.get(popup));return true;
  }
  function beginJump(popup,state){if(!jumpRequest||jumpRequest.popup)return;jumpRequest.popup=popup;state.tab.onclick();applyJump(popup,state)}
  function applyJump(popup,state){
    if(!jumpRequest||jumpRequest.popup!==popup||!state.data)return;const item=jumpRequest.item,pack=packList(state.data).find(p=>p.items.some(x=>x.path===item.path));jumpRequest=null;
    if(!pack){state.status.textContent='현재 목록에서 이 이모티콘 팩을 찾지 못했습니다. 새로고침 후 확인해 주세요.';return}
    state.selected=pack;state.page=Math.floor(packList(state.data).indexOf(pack)/packsPerPage);drawPack(popup,state);
    const cell=[...state.grid.children].find(c=>c.dataset.path===item.path);if(cell){cell.style.outline='2px solid var(--dt-accent,#278ac2)';cell.style.borderRadius='8px';cell.scrollIntoView?.({block:'nearest'});}rememberPicker(state);
  }
  function showEmojiMenu(event,item){
    event.preventDefault();event.stopPropagation();hidePreview();closeEmojiMenu();const menu=document.createElement('div');menu.className='dt-emoticon-context-menu';menu.style.cssText='position:fixed;z-index:2147483647;max-width:calc(100vw - 16px)';const shadow=menu.attachShadow({mode:'open'});shadow.innerHTML='<style>:host{font:13px sans-serif}button{padding:10px 14px;border:1px solid #9ba6b5;border-radius:7px;background:#fff;color:#182638;box-shadow:0 4px 16px #0003;cursor:pointer}button:hover{background:#eaf2fc}</style><button type="button" role="menuitem">해당 이모티콘으로 가기</button>';menu.setAttribute('role','menu');document.body.append(menu);emojiMenu=menu;
    const rect=menu.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(event.clientX,innerWidth-rect.width-8))+'px';menu.style.top=Math.max(8,Math.min(event.clientY,innerHeight-rect.height-8))+'px';const button=shadow.querySelector('button');button.onclick=()=>{if(openEmojiPack(item))closeEmojiMenu();else button.textContent='이모티콘 선택 창을 먼저 열어 주세요.'};button.focus();
  }
  const favoritesKey='dooray-plus-emoticon-favorites-v1';
  const favoritesDefaultKey='dooray-plus-emoticon-favorites-default-v1';
  const pickerKey='dooray-plus-emoticon-picker-v1';
  let lastPicker=null;try{const p=JSON.parse(localStorage.getItem(pickerKey)||'null');if(p&&['packs','items','favorites'].includes(p.mode))lastPicker={mode:p.mode,page:Number.isInteger(p.page)?Math.max(0,p.page):0,packId:typeof p.packId==='string'?p.packId:null,packPath:typeof p.packPath==='string'?p.packPath:null,top:Number.isFinite(p.top)?Math.max(0,p.top):0}}catch{}
  const pickerTabKey='dooray-plus-emoticon-tab-v1';
  let customTabSelected=!!lastPicker;try{const saved=localStorage.getItem(pickerTabKey);if(saved!==null)customTabSelected=saved==='custom'}catch{}
  function rememberTab(custom){customTabSelected=custom;try{localStorage.setItem(pickerTabKey,custom?'custom':'native')}catch{}}
  function rememberPicker(state){if(!state.visited)return;lastPicker={mode:state.mode,page:state.page,packId:state.selected?.id||null,packPath:state.selected?.packPath||null,top:state.grid.scrollTop};try{localStorage.setItem(pickerKey,JSON.stringify(lastPicker))}catch{}}
  function favoritesDefault(){try{return localStorage.getItem(favoritesDefaultKey)==='true'}catch{return false}}
  function readFavorites(){try{const value=JSON.parse(localStorage.getItem(favoritesKey)||'[]');return Array.isArray(value)?value.map(x=>decode(encode(x))).filter(Boolean).filter((x,i,a)=>a.findIndex(y=>y.path===x.path)===i).slice(0,500):[]}catch{return []}}
  let favorites=readFavorites();
  function saveFavorites(next,state){try{localStorage.setItem(favoritesKey,JSON.stringify(next));favorites=next;return true}catch{state.status.textContent='즐겨찾기를 저장하지 못했습니다. 저장 공간을 확인해 주세요.';return false}}
  function updateStars(){for(const state of popups.values())for(const star of state.grid.querySelectorAll('.star')){const selected=favorites.some(x=>x.path===star.dataset.path);star.textContent=selected?'★':'☆';star.setAttribute('aria-pressed',String(selected));star.title=selected?'즐겨찾기 제거':'즐겨찾기 추가';star.setAttribute('aria-label',star.title+' · '+star.dataset.label)}}
  function drawItems(popup,state,items){
    state.pageLabel.textContent=items.length+'개';
    for(const item of items){
      const gate=itemGate(item),cell=document.createElement('div');cell.className='item';cell.dataset.path=item.path;
      const send=document.createElement('button');send.type='button';send.className='send';send.title=item.label;send.setAttribute('aria-label',item.label+' 보내기');send.textContent=item.label;send.disabled=true;
      send.addEventListener('mouseenter',()=>showPreview(item,send));send.addEventListener('mouseleave',hidePreview);send.addEventListener('focus',()=>showPreview(item,send));send.addEventListener('blur',hidePreview);
      const choose=()=>{if(!cell.isConnected||state.panel.hidden||disposed)return;const latest=itemGate(item);if(!latest.allowed){showGate(popup,state,latest);return}if(!state.combined)return insert(popup,item,state.status);if(state.selection.length>=2){state.status.textContent='두 개가 선택되었습니다. 듀얼콘 보내기를 누르거나 선택을 해제해 주세요.';return}state.selection.push(item);renderSelection(state)};
      const star=document.createElement('button');star.type='button';star.className='star';star.dataset.path=item.path;star.dataset.label=item.label;
      star.onclick=()=>{const exists=favorites.some(x=>x.path===item.path);if(!exists){const latest=itemGate(item);if(!latest.allowed){showGate(popup,state,latest);return}}if(!exists&&favorites.length>=500){state.status.textContent='즐겨찾기는 최대 500개까지 저장할 수 있습니다.';return}if(!saveFavorites(exists?favorites.filter(x=>x.path!==item.path):[...favorites,item],state))return;updateStars();if(state.mode==='favorites'){const top=state.grid.scrollTop;drawFavorites(popup,state);state.grid.scrollTop=top}};
      cell.append(send,star);state.grid.append(cell);
      if(state.mode==='favorites'){
        const order=document.createElement('div');order.className='order';
        for(const [label,delta] of [['←',-1],['→',1]]){const move=document.createElement('button');move.type='button';move.textContent=label;move.setAttribute('aria-label',item.label+(delta<0?' 앞으로 이동':' 뒤로 이동'));const index=favorites.findIndex(x=>x.path===item.path);move.disabled=index+delta<0||index+delta>=favorites.length;move.onclick=()=>{const next=[...favorites],at=next.findIndex(x=>x.path===item.path),to=at+delta;if(at<0||to<0||to>=next.length)return;[next[at],next[to]]=[next[to],next[at]];if(saveFavorites(next,state)){const top=state.grid.scrollTop;drawFavorites(popup,state);state.grid.scrollTop=top;state.grid.children[to]?.querySelector('.star').focus()}};order.append(move)}cell.append(order);
      }
      if(!gate.allowed){send.disabled=false;send.textContent=(gate.reason==='locked'?'🔒 ':'⚠ ')+item.label;send.title=gateMessage(gate);send.setAttribute('aria-label',send.title+' · '+item.label);send.onclick=choose;cell.dataset.locked='true';continue}
      lazy(cell,()=>{if(!itemGate(item).allowed||disposed||!cell.isConnected)return;return image(item).then(src=>{if(!cell.isConnected||disposed||!itemGate(item).allowed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{if(cell.isConnected&&!disposed&&itemGate(item).allowed)send.disabled=false};img.onerror=()=>{send.textContent='이미지 로딩 실패'};img.src=src;send.replaceChildren(img);send.onclick=choose}).catch(e=>{send.textContent='불러오기 실패';send.title=e.message})});
    }updateStars();
  }
  function drawFavorites(popup,state){clearGrid(state);state.mode='favorites';state.panel.dataset.view='items';state.back.hidden=false;state.title.textContent='';state.favorite.setAttribute('aria-pressed','true');state.previous.hidden=state.next.hidden=true;state.grid.setAttribute('aria-label','즐겨찾기 이모티콘 목록');state.status.textContent=favorites.length?'별표로 제거 · 화살표로 순서 변경':'이모티콘 모서리의 ☆을 눌러 추가해 주세요.';drawItems(popup,state,favorites);rememberPicker(state)}
  function context(popup){let f=popup[Object.keys(popup).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<35;i++,f=f.return){const p=f.memoizedProps;if(p?.actions?.emoticonStickerActions&&p?.data?.emoticonStickerStore)return p}return null}
  function renderSelection(state,announce=true){
    state.selection=state.selection.filter(item=>itemGate(item).allowed);state.pairSlots.replaceChildren();state.pairSend.hidden=!state.combined;state.pairSend.disabled=state.selection.length!==2;state.pairMode.setAttribute('aria-pressed',String(state.combined));
    state.selection.forEach((item,index)=>{const button=document.createElement('button');button.type='button';button.textContent=(index+1)+'. '+item.label+' ×';button.title=item.path;button.setAttribute('aria-label',(index+1)+'번 선택 해제');button.onclick=()=>{state.selection.splice(index,1);renderSelection(state)};state.pairSlots.append(button)});
    if(announce)state.status.textContent=state.combined?'듀얼콘으로 보낼 이모티콘 두 개를 선택해 주세요. ('+state.selection.length+'/2)':'이모티콘을 누르면 바로 전송됩니다.';
  }
  const sending=new WeakSet();
  async function insert(popup,item,status){
    hidePreview();if(sending.has(popup))return;sending.add(popup);
    try{
      const items=Array.isArray(item)?item:[item];if(items.length<1||items.length>2)throw Error('한 번에 최대 두 개를 보낼 수 있습니다.');
      const check=()=>{for(const value of items){const gate=itemGate(value);if(!gate.allowed){const state=popups.get(popup);if(state)showGate(popup,state,gate);throw Error(gateMessage(gate))}}};
      if(loading)await loading.catch(()=>{});check();
      const p=context(popup),active=p?.data.emoticonStickerStore.activePopperState,stickers=p?.actions.emoticonStickerActions,logs=stickers?.logActions,channel=stickers?.activeChannelId;
      if(!popup.isConnected||!active||!channel||typeof logs?.createAndSendLog!=='function'||typeof logs?.fetchLatestLogsIfNeeded!=='function')throw Error('이모티콘 창을 다시 열어 주세요.');
      status.textContent='전송 중…';await logs.fetchLatestLogsIfNeeded(channel);if(loading)await loading.catch(()=>{});
      if(!popup.isConnected||disposed||stickers.activeChannelId!==channel||p.data.emoticonStickerStore.activePopperState!==active)throw Error('대화방이 변경되어 전송하지 않았습니다.');
      check();logs.createAndSendLog(channel,items.map(encode).join(''));const state=popups.get(popup);if(state){rememberPicker(state);state.selection=[];renderSelection(state)}active.setOpen(false);
    }catch(e){status.textContent=e.message}finally{sending.delete(popup)}
  }
  const css=document.createElement('style');css.id='dooray-custom-emoticons-style';css.textContent=`
  .js-sticker-emotion[data-dt-custom-open] > :not([data-dt-custom-tabs]):not(.dt-emoticon-custom){display:none!important}
  [data-dt-custom-tab] button[aria-selected="true"],button[data-dt-custom-tab][aria-selected="true"]{color:var(--dt-accent,#278ac2)!important;box-shadow:inset 0 -2px var(--dt-accent,#278ac2)}
  .dt-emoticon-custom[hidden]{display:none!important}
  [data-dt-emoticon][data-dt-emoticon]{font-size:0!important;line-height:0!important;letter-spacing:0!important;word-spacing:0!important;visibility:hidden!important;width:fit-content!important;min-width:0!important}
  [data-dp-native~="message-bubble"]:has([data-dt-emoticon]),.sc-iyvyFf:has([data-dt-emoticon]){width:fit-content!important;min-width:0!important}
  [data-dt-emoticon][data-dt-emoticon] > :not(.dt-received-emoticon){display:none!important}
  .dt-received-emoticon{visibility:visible!important;display:inline-flex!important;align-items:center;justify-content:center;vertical-align:middle;flex-wrap:wrap;gap:4px;max-width:100%;font:12px/1.4 sans-serif!important;color:var(--dt-text,#333);overflow:hidden}
  .dt-emoticon-imagebox{display:inline-flex;width:160px;height:160px;align-items:center;justify-content:center;flex:none;max-width:100%} .dt-emoticon-text{white-space:pre-wrap;font-size:14px;line-height:1.5}
  .dt-received-emoticon.dt-dual-emoticon{gap:0;flex-wrap:nowrap;width:320px}.dt-dual-emoticon .dt-emoticon-imagebox{width:50%;max-width:50%;height:auto;aspect-ratio:1;flex:0 0 50%}.dt-dual-emoticon .dt-emoticon-imagebox:first-child img{object-position:right center}.dt-dual-emoticon .dt-emoticon-imagebox:last-child img{object-position:left center}
  .dt-received-emoticon img{display:block;width:100%;height:100%;object-fit:contain}
  .dt-received-emoticon button{font:inherit;color:inherit;background:transparent;border:0;cursor:pointer;max-width:100%}
  `;document.head.append(css);
  const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){observer.unobserve(entry.target);entry.target.__dtLoadEmoticon?.();}},{rootMargin:'160px'});
  function lazy(target,load){target.__dtLoadEmoticon=load;observer.observe(target)}
  const packsPerPage=6;
  function clearGrid(state){hidePreview();for(const child of state.grid.children)observer.unobserve(child);state.grid.replaceChildren();state.grid.scrollTop=0;}
  function thumbnail(pack){return pack.items.find(item=>/^01\.(png|gif|jpe?g|webp)$/i.test(item.path.split('/').pop()))||pack.items.find(item=>String(item.id)==='01'||item.label==='01')||pack.items[0];}
  function fillPicker(popup,state,data){
    if(!popup.isConnected||disposed)return;state.data=data;state.page=Math.min(state.page,Math.max(0,Math.ceil(packList(data).length/packsPerPage)-1));if(state.mode==='favorites')drawFavorites(popup,state);else if(state.mode==='items'&&state.selected&&(state.selected=currentPack(state.selected,data)))drawPack(popup,state);else drawPacks(popup,state);if(state.restoreTop!==undefined){state.grid.scrollTop=state.restoreTop;delete state.restoreTop;}rememberPicker(state);applyJump(popup,state);
  }
  function drawPacks(popup,state){
    clearGrid(state);state.mode='packs';state.grid.setAttribute('aria-label','이모티콘 팩 목록');state.panel.dataset.view='packs';state.back.hidden=true;state.title.textContent='';state.favorite.setAttribute('aria-pressed','false');
    const packs=packList(state.data),pages=Math.max(1,Math.ceil(packs.length/packsPerPage));
    state.previous.hidden=state.next.hidden=false;state.previous.disabled=state.page===0;state.next.disabled=state.page>=pages-1;
    state.pageLabel.textContent=(state.page+1)+' / '+pages;
    state.status.textContent=state.data?.warnings?.length?'일부 팩을 읽지 못했습니다. '+state.data.warnings[0]:'팩을 눌러 열기 · 휠로 페이지 이동';
    for(const pack of packs.slice(state.page*packsPerPage,(state.page+1)*packsPerPage)){
      const button=document.createElement('button');button.type='button';button.className='pack';button.title=pack.name;button.setAttribute('aria-label',pack.name+' 팩 열기');
      const preview=document.createElement('span');preview.className='preview';preview.textContent='…';
      const name=document.createElement('span');name.className='name';name.textContent=pack.name;button.append(preview,name);state.grid.append(button);
      button.onclick=()=>{state.selected=pack;drawPack(popup,state);state.back.focus()};
      const gate=packGate(pack);if(!gate.allowed){button.dataset.locked='true';preview.textContent=gate.reason==='locked'?'🔒':'↑';button.title=gateMessage(gate);continue}const item=thumbnail(pack);if(item)lazy(button,()=>{if(!packGate(pack).allowed||!itemGate(item).allowed)return;return image(item).then(src=>{if(!button.isConnected||disposed||!packGate(pack).allowed||!itemGate(item).allowed)return;const img=document.createElement('img');img.alt='';img.onerror=()=>{preview.textContent='미리보기 없음'};img.src=src;preview.replaceChildren(img)}).catch(()=>{if(button.isConnected)preview.textContent='미리보기 없음'})});else preview.textContent='비어 있음';
    }rememberPicker(state);
  }
  function turnPage(popup,state,direction){
    if(state.mode!=='packs'||!state.data)return;
    const next=Math.max(0,Math.min(state.page+direction,Math.ceil(packList(state.data).length/packsPerPage)-1));
    if(next===state.page||next<0)return;state.page=next;drawPacks(popup,state);
  }
  function drawPack(popup,state){
    clearGrid(state);const pack=currentPack(state.selected);if(!pack){state.selected=null;drawPacks(popup,state);state.status.textContent=gateMessage({reason:'missing'});return}state.selected=pack;
    const position=packList(catalog).indexOf(pack);if(position>=0)state.page=Math.floor(position/packsPerPage);
    state.mode='items';state.grid.setAttribute('aria-label',pack.name+' 이모티콘 목록');state.panel.dataset.view='items';state.back.hidden=false;state.title.textContent=pack.name;
    state.previous.hidden=state.next.hidden=true;state.pageLabel.textContent=pack.items.length+'개';state.status.textContent='이모티콘을 누르면 바로 전송됩니다.';state.favorite.setAttribute('aria-pressed','false');
    const gate=packGate(pack);if(!gate.allowed){
      state.panel.dataset.view='locked';state.pageLabel.textContent='';state.status.textContent=gateMessage(gate);
      const form=document.createElement('form');form.className='unlock';form.autocomplete='off';const title=document.createElement('strong');title.textContent=gate.reason==='locked'?'🔒 '+pack.name:'이 팩을 아직 사용할 수 없습니다.';form.append(title);
      if(gate.reason==='locked'){
        const label=document.createElement('label');label.textContent='팩 비밀번호';const input=document.createElement('input');input.type='password';input.maxLength=256;input.autocomplete='off';input.setAttribute('aria-label','팩 비밀번호');label.append(input);
        const info=document.createElement('p');info.textContent='두레이를 다시 실행하면 비밀번호를 다시 입력합니다.';
        const error=document.createElement('p');error.setAttribute('role','alert');error.className='unlock-error';const button=document.createElement('button');button.type='submit';button.textContent='잠금 해제';form.append(label,info,error,button);
        let composing=false,suppressImeSubmit=false;
        form.addEventListener('compositionstart',event=>{composing=true;event.stopPropagation()});
        form.addEventListener('compositionend',event=>{composing=false;event.stopPropagation()});
        for(const type of ['input','beforeinput','change','paste','copy','cut'])form.addEventListener(type,event=>event.stopPropagation());
        form.addEventListener('keydown',event=>{
          event.stopPropagation();
          if(composing||event.isComposing||event.keyCode===229){if(event.key==='Enter')suppressImeSubmit=true;return}
          suppressImeSubmit=false;if(event.key!=='Enter')return;event.preventDefault();
          if(event.repeat||event.ctrlKey||event.altKey||event.metaKey||event.shiftKey||button.disabled)return;
          form.requestSubmit(button);
        });
        for(const type of ['keypress','keyup'])form.addEventListener(type,event=>{event.stopPropagation();if(event.key==='Enter'&&!composing&&!suppressImeSubmit&&!event.isComposing&&event.keyCode!==229)event.preventDefault()});
        button.addEventListener('pointerdown',()=>{if(!composing)suppressImeSubmit=false});
        form.onsubmit=async event=>{event.preventDefault();event.stopPropagation?.();if(composing||suppressImeSubmit||button.disabled||!form.isConnected||disposed)return;button.disabled=true;try{
          if(loading)await loading.catch(()=>{});if(!form.isConnected||disposed)return;const latest=packGate(pack);
          if(latest.key!==gate.key||latest.reason!=='locked'){drawPack(popup,state);return}
          if(input.value!==latest.pack.password){error.textContent='비밀번호가 일치하지 않습니다.';input.select();return}
          input.value='';unlocked.add(latest.key);refreshPickerViews();
        }finally{button.disabled=false}};
      }
      state.grid.append(form);rememberPicker(state);return;
    }
    drawItems(popup,state,pack.items);rememberPicker(state);
  }
  async function loadPicker(popup,state,refresh=false){
    if(catalog&&!refresh)fillPicker(popup,state,catalog);else state.status.textContent='이모티콘 목록을 불러오는 중…';
    state.refresh.disabled=true;
    try{if(refresh&&loading)await loading.catch(()=>{});loading ||= rpc('emoticon-catalog',{refresh}).then(acceptCatalog).finally(()=>{loading=null});await loading}
    catch(e){state.status.textContent=e.message+(catalog?' 저장된 목록은 계속 사용할 수 있습니다.':' 새로고침을 눌러 다시 시도해 주세요.')}
    finally{state.refresh.disabled=false;applyJump(popup,state)}
  }
  function pickerTabs(popup){
    // The popup's stable hook survives styled-components class regeneration.
    // Its tab strip is a direct child containing tab buttons, not the item grid.
    const strips=[...popup.children].filter(n=>!n.classList.contains('dt-emoticon-custom')&&!n.hasAttribute('data-dt-custom-tab'));
    const slots=strip=>[...strip.children].filter(n=>!n.hasAttribute('data-dt-custom-tab')&&(n.matches('button,[role="tab"]')||n.querySelector(':scope > button,:scope > [role="tab"]')));
    return strips.find(n=>n.matches('[role="tablist"]')&&slots(n).length)||strips.find(n=>slots(n).some(slot=>slot.matches('[role="tab"]')||slot.querySelector('[role="tab"]')))||strips.find(n=>slots(n).length>=2)||strips.find(n=>n.matches('.lcdHJ')&&slots(n).length)||strips.find(n=>slots(n).length);
  }
  function mount(popup){
    const previous=popups.get(popup);if(previous){if(previous.tabs.parentElement===popup&&previous.tab.isConnected&&previous.panel.parentElement===popup)return;previous.detach();popups.delete(popup)}
    const tabs=pickerTabs(popup);if(!tabs)return;
    const nativeSlots=[...tabs.children].filter(n=>n.matches('button,[role="tab"]')||n.querySelector(':scope > button,:scope > [role="tab"]'));
    const nativeButton=slot=>slot.matches('button,[role="tab"]')?slot:slot.querySelector('button,[role="tab"]');
    const selected=slot=>[slot,nativeButton(slot)].some(n=>n?.matches('[aria-selected="true"],[aria-pressed="true"],[data-state="active"],[data-state="selected"]'));
    const commonClasses=nodes=>nodes.length?new Set([...nodes[0].classList].filter(c=>nodes.every(n=>n.classList.contains(c)))):new Set();
    const commonSlots=commonClasses(nativeSlots),buttons=nativeSlots.map(nativeButton),commonButtons=commonClasses(buttons);
    const classSelected=nativeSlots.filter(n=>commonSlots.size&&[...n.classList].some(c=>!commonSlots.has(c)));
    const sample=nativeSlots.find(selected)||(classSelected.length===1?classSelected[0]:nativeSlots[0]),sampleButton=nativeButton(sample);
    const selectedSlotClasses=nativeSlots.length>1?[...sample.classList].filter(c=>!commonSlots.has(c)):[];
    const selectedButtonClasses=nativeSlots.length>1?[...sampleButton.classList].filter(c=>!commonButtons.has(c)):[];
    const tab=document.createElement('button');tab.type='button';tab.className=sampleButton.className;for(const c of selectedButtonClasses)tab.classList.remove(c);
    const tabSlot=sample.matches('button')?tab:document.createElement(sample.tagName.toLowerCase());if(tabSlot!==tab){tabSlot.className=sample.className;for(const c of selectedSlotClasses)tabSlot.classList.remove(c);tabSlot.append(tab)}
    tabSlot.dataset.dtCustomTab='true';tab.setAttribute('role','tab');const label=document.createElement('div');label.className=sampleButton.querySelector(':scope > div')?.className||'';label.textContent='커스텀';tab.append(label);tab.setAttribute('aria-selected','false');
    const priorTabsMarker=tabs.getAttribute('data-dt-custom-tabs');tabs.setAttribute('data-dt-custom-tabs','');tabs.append(tabSlot);let selectedNative=[];
    const selectTab=(custom,restore=true)=>{
      if(custom&&tab.getAttribute('aria-selected')!=='true'){
        selectedNative=nativeSlots.filter(slot=>selected(slot)||selectedSlotClasses.some(c=>slot.classList.contains(c))).map(slot=>({slot,button:nativeButton(slot),classes:selectedSlotClasses.filter(c=>slot.classList.contains(c)),buttonClasses:selectedButtonClasses.filter(c=>nativeButton(slot).classList.contains(c)),attributes:[...new Set([slot,nativeButton(slot)])].flatMap(node=>['aria-selected','aria-pressed','data-state'].map(name=>({node,name,value:node.getAttribute(name)})).filter(a=>['true','active','selected'].includes(a.value)).map(a=>({...a,muted:a.value==='true'?'false':a.value==='active'?'inactive':'unselected'})))}));
        for(const old of selectedNative){for(const c of old.classes)old.slot.classList.remove(c);for(const c of old.buttonClasses)old.button.classList.remove(c);for(const a of old.attributes)a.node.setAttribute(a.name,a.muted)}
      }else if(!custom){for(const old of selectedNative)if(old.slot.isConnected&&restore){for(const c of old.classes)old.slot.classList.add(c);for(const c of old.buttonClasses)old.button.classList.add(c);for(const a of old.attributes)if(a.node.getAttribute(a.name)===a.muted)a.node.setAttribute(a.name,a.value)}selectedNative=[];}
      for(const c of selectedSlotClasses)tabSlot.classList.toggle(c,custom);for(const c of selectedButtonClasses)tab.classList.toggle(c,custom);tab.setAttribute('aria-selected',String(custom));
    };
    const panel=document.createElement('div');panel.className='dt-emoticon-custom';panel.hidden=true;panel.dataset.view='packs';const shadow=panel.attachShadow({mode:'open'});shadow.innerHTML=`<style>
    :host{display:block;width:360px;max-width:80vw;color:var(--dt-text,#333);background:var(--dt-bg,#fff);font:12px sans-serif}*{box-sizing:border-box}[hidden]{display:none!important}
    .tools{display:flex;align-items:center;gap:6px;padding:10px}#title{flex:1;min-width:0;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    button{color:inherit;background:var(--dt-surface,#eee);border:1px solid var(--dt-border,#bbb);border-radius:8px;padding:6px;font:inherit;cursor:pointer}button:hover{background:var(--dt-hover,#ddd)}button:disabled{opacity:.4;cursor:default}button:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:1px}
    #status{padding:0 10px;margin:0 0 6px;font-size:11px;line-height:1.5;overflow-wrap:anywhere;min-height:17px}.browser{display:grid;grid-template-columns:28px minmax(0,1fr) 28px;align-items:center;gap:3px;padding:0 5px}.arrow{padding:8px 0;font-size:22px;line-height:1}
    #grid{height:268px;overflow:auto;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));align-content:start;gap:6px;padding:4px;overscroll-behavior:contain}
    #grid button{min-width:0;overflow:hidden;padding:5px;height:122px}.preview{display:flex;height:78px;align-items:center;justify-content:center;font-size:11px}.name{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:11px;line-height:15px;margin-top:3px;word-break:break-all}img{display:block;width:100%;height:100%;object-fit:contain}
    :host([data-view="items"]) .browser{grid-template-columns:minmax(0,1fr)}:host([data-view="items"]) #grid{grid-template-columns:repeat(4,minmax(0,1fr))}:host([data-view="items"]) #grid button{height:78px}
    .item{position:relative;min-width:0}.item .send{width:100%;padding:9px!important}.item .star{position:absolute;right:1px;top:1px;width:23px;height:23px!important;padding:0!important;font-size:19px;line-height:21px;border:0;background:var(--dt-bg,#fff);border-radius:7px;color:var(--dt-text,#555)}.item .star[aria-pressed="true"]{color:#b77d00;background:#fff2c2}.order{display:flex;gap:3px;margin-top:3px}.order button{height:22px!important;flex:1;padding:0!important}#favorites[aria-pressed="true"]{border-color:var(--dt-accent,#278ac2);background:var(--dt-hover,#ddd)}
    .pair{display:flex;flex-wrap:wrap;align-items:center;gap:5px;padding:5px 10px}.pair button{font-size:11px}#pairSlots{display:flex;gap:4px;min-width:0}#pairSlots button{max-width:105px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#pairMode[aria-pressed="true"]{border-color:var(--dt-accent,#278ac2);background:var(--dt-hover,#ddd)}
    :host([data-view="locked"]) .browser{grid-template-columns:minmax(0,1fr)}:host([data-view="locked"]) #grid{display:block}.unlock{display:flex;flex-direction:column;gap:12px;padding:18px 14px}.unlock strong{font-size:14px;overflow-wrap:anywhere}.unlock label{display:flex;flex-direction:column;gap:7px}.unlock input{width:100%;min-width:0;border:1px solid var(--dt-border,#aaa);border-radius:8px;padding:9px;background:var(--dt-bg,#fff);color:inherit;font:inherit}.unlock p{margin:0;font-size:11px;line-height:1.5}.unlock .unlock-error{min-height:16px;color:var(--dt-accent,#a63030)}#grid .unlock button{height:auto;padding:9px}#grid .pack[data-locked] .preview{font-size:26px}
    .footer{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:5px 10px 9px;font-size:11px}.footer label{display:flex;align-items:center;gap:5px;cursor:pointer}.footer input{margin:0;accent-color:var(--dt-accent,#278ac2)}#page{opacity:.75;white-space:nowrap}
    </style><div class="tools"><button id="back" hidden aria-label="팩 목록으로 뒤로 가기">← 뒤로</button><button id="favorites" aria-pressed="false">★ 즐겨찾기</button><span id="title"></span><button id="refresh" aria-label="이모티콘 목록 새로고침">새로고침</button></div><p id="status" role="status"></p><div class="browser"><button id="previous" class="arrow" aria-label="이전 페이지" title="이전 페이지">‹</button><div id="grid" tabindex="0" aria-label="이모티콘 팩 목록"></div><button id="next" class="arrow" aria-label="다음 페이지" title="다음 페이지">›</button></div><div class="pair"><button id="pairMode" aria-pressed="false">듀얼콘</button><span id="pairSlots"></span><button id="pairSend" hidden disabled>듀얼콘 보내기</button></div><div class="footer"><label><input id="favoritesDefault" type="checkbox">즐겨찾기를 기본으로 보기</label><span id="page" aria-live="polite"></span></div>`;
    popup.append(panel);const get=id=>shadow.getElementById(id);const state={panel,tab,tabs,grid:get('grid'),status:get('status'),refresh:get('refresh'),back:get('back'),title:get('title'),favorite:get('favorites'),previous:get('previous'),next:get('next'),pageLabel:get('page'),page:0,mode:'packs',selected:null,combined:false,selection:[],pairMode:get('pairMode'),pairSlots:get('pairSlots'),pairSend:get('pairSend')};
    state.pairMode.onclick=()=>{state.combined=!state.combined;state.selection=[];renderSelection(state)};state.pairSend.onclick=()=>{if(state.selection.length===2)insert(popup,[...state.selection],state.status)};
    const defaultOption=get('favoritesDefault');defaultOption.checked=favoritesDefault();defaultOption.onchange=()=>{try{localStorage.setItem(favoritesDefaultKey,String(defaultOption.checked));for(const other of popups.values())other.panel.shadowRoot.getElementById('favoritesDefault').checked=defaultOption.checked}catch{defaultOption.checked=favoritesDefault();state.status.textContent='기본 화면 설정을 저장하지 못했습니다.'}};
    state.favorite.onclick=()=>drawFavorites(popup,state);
    state.previous.onclick=()=>turnPage(popup,state,-1);state.next.onclick=()=>turnPage(popup,state,1);
    state.back.onclick=()=>{const selected=currentPack(state.selected,state.data),index=selected?packList(state.data).indexOf(selected):-1;if(index>=0)state.page=Math.floor(index/packsPerPage);drawPacks(popup,state);if(index>=0)state.grid.children[index%packsPerPage]?.focus()};
    let wheelSum=0,lastWheel=0,lastPageTurn=0;
    const wheel=e=>{if(state.mode!=='packs'||e.ctrlKey)return;e.preventDefault();e.stopPropagation();const now=performance.now();if(now-lastWheel>180)wheelSum=0;lastWheel=now;wheelSum+=(Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY)*(e.deltaMode===1?16:e.deltaMode===2?268:1);if(Math.abs(wheelSum)<40||now-lastPageTurn<300)return;turnPage(popup,state,Math.sign(wheelSum));wheelSum=0;lastPageTurn=now};
    shadow.querySelector('.browser').addEventListener('wheel',wheel,{passive:false});
    state.grid.onkeydown=e=>{if(state.mode==='packs'&&['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();turnPage(popup,state,e.key==='ArrowRight'?1:-1)}};
    state.grid.addEventListener('scroll',()=>rememberPicker(state),{passive:true});
    const nativeClick=e=>{const clicked=e.target.closest('button,[role="tab"]');if(!clicked||clicked===tab)return;rememberTab(false);rememberPicker(state);hidePreview();panel.hidden=true;popup.removeAttribute('data-dt-custom-open');selectTab(false,selectedNative.some(old=>old.slot===clicked||old.slot.contains(clicked)))};tabs.addEventListener('click',nativeClick);state.detach=()=>{rememberPicker(state);clearGrid(state);selectTab(false);tabs.removeEventListener('click',nativeClick);if(priorTabsMarker===null)tabs.removeAttribute('data-dt-custom-tabs');else tabs.setAttribute('data-dt-custom-tabs',priorTabsMarker);tabSlot.remove();panel.remove();popup.removeAttribute('data-dt-custom-open')};
    tab.onclick=()=>{rememberTab(true);defaultOption.checked=favoritesDefault();const saved=lastPicker;state.visited=true;state.mode=defaultOption.checked?'favorites':saved?.mode||'packs';state.page=saved?.page||0;state.selected=saved?.packId?{id:saved.packId,packPath:saved.packPath}:null;state.restoreTop=saved?.mode===state.mode?saved.top:0;panel.hidden=false;popup.setAttribute('data-dt-custom-open','');selectTab(true);if(state.mode==='favorites')drawFavorites(popup,state);loadPicker(popup,state)};state.refresh.onclick=()=>loadPicker(popup,state,true);popups.set(popup,state);if(customTabSelected)tab.onclick();
  }
  // Dooray may leave markdown spacing entities as literal text after a message.
  const normalizeSpacing=text=>text.replace(/&(?:#x(?:20|a0)|#(?:32|160)|nbsp);/gi,' ');
  function messageText(node){return normalizeSpacing([...node.childNodes].filter(n=>!(n.nodeType===1&&n.classList.contains('dt-received-emoticon'))).map(n=>n.textContent).join('')).replace(/[\u200B-\u200D\uFEFF]/g,'').trim()}
  const tokenPattern=()=>/\[\s*\[\s*dooray\s*-\s*emoji\s*:\s*v1\s*:\s*[A-Za-z0-9_\-\s]+\]\s*\]/g;
  function messageCandidates(){
    const bubbles='[data-dp-native~="message-bubble"],.sc-iyvyFf',texts='[data-dp-native~="message-text"],.sc-chbbiW',contents='[data-dp-native~="message-content"],[class*="js-log-right-content-"]';
    const skip='textarea,input,script,style,noscript,[contenteditable]:not([contenteditable="false"]),.js-main-editor,.js-channel-list,[data-dp-native~="sidebar"],blockquote,button,[role="button"],.dt-received-emoticon,.dt-emoticon-custom,.js-sticker-emotion';
    const foreignLink=node=>{const link=node.closest('a[href]');return link&&!/^dooray-emoji:/i.test(link.getAttribute('href')||'')};
    const excluded=node=>!node||node.isContentEditable||node.closest(skip)||foreignLink(node);
    // A sidebar, sender, quote or read-count is never a message body. The
    // adapter's semantic boundary also covers renamed classes and side panels.
    const boundary=node=>!excluded(node)&&(node.closest(bubbles)||node.closest(texts));
    const groups=new Map(),checked=new Set();
    function consider(node,owner){
      if(checked.has(node))return;checked.add(node);
      if(excluded(node)||node.closest('a[href]')||node.querySelector('[data-logid]')||[...node.querySelectorAll(skip)].some(child=>!child.closest('.dt-received-emoticon'))||[...node.querySelectorAll('a[href]')].some(foreignLink))return;
      const text=messageText(node);if(text.length>16000)return;
      let count=0;for(const match of text.matchAll(tokenPattern()))if(decode(match[0])&&++count>=8)break;
      if(!count)return;
      const group=groups.get(owner)||[];group.push({node,count});groups.set(owner,group);
    }
    for(const node of document.querySelectorAll(bubbles+','+texts)){
      const owner=boundary(node);if(!owner)continue;consider(node,owner);
      // Dooray can turn the middle of a token into a native link, or split
      // adjacent tokens into separate chunks. Keep examining its own bubble;
      // an incomplete smaller chunk must not suppress a complete parent.
      for(let parent=node.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){consider(parent,owner);if(parent===owner)break;}
      let visited=0;const walker=document.createTreeWalker(node,NodeFilter.SHOW_TEXT);
      for(let text=walker.nextNode();text&&visited++<24000;text=walker.nextNode()){
        if(excluded(text.parentElement)||!/\[\[|dooray-|emoji:v1:/.test(text.nodeValue||''))continue;
        for(let parent=text.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){if(excluded(parent))break;consider(parent,owner);if(parent===owner)break;}
      }
    }
    // If a renderer cannot yet be tagged by the adapter, retain token recovery
    // inside its stable per-log content boundary. Never walk the whole document
    // or combine sibling messages, and prefer semantic bodies whenever present.
    for(const owner of document.querySelectorAll(contents)){
      if(excluded(owner)||owner.querySelector(bubbles+','+texts))continue;
      let visited=0;const walker=document.createTreeWalker(owner,NodeFilter.SHOW_TEXT);
      for(let text=walker.nextNode();text&&visited++<24000;text=walker.nextNode()){
        if(excluded(text.parentElement)||text.parentElement.closest(contents)!==owner||!/[\[\]]|dooray|emoji|v1:/.test(text.nodeValue||''))continue;
        const log=text.parentElement.closest('[data-logid]');
        for(let parent=text.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){
          if(excluded(parent)||parent.closest('[data-logid]')!==log)break;consider(parent,owner);if(parent===owner||parent===log)break;
        }
      }
    }
    // Preserve every token in the same bubble (including a split dual emoticon),
    // then prefer the smallest complete container with that coverage.
    const result=[];for(const group of groups.values()){
      const count=Math.max(...group.map(x=>x.count)),best=group.filter(x=>x.count===count);
      result.push(...best.filter(x=>!best.some(other=>other!==x&&x.node.contains(other.node))).map(x=>x.node));
    }
    return [...new Set(result)];
  }
  function undecorate(node){const d=decorated.get(node);if(!d)return;const layout=scrollController?.beforeLayout(node);resized.unobserve(d.view);for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(d.view);d.view.remove();node.removeAttribute('data-dt-emoticon');decorated.delete(node);if(scrollController)scrollController.afterLayout(layout)}
  function decorate(node,segments,key){
    const previous=decorated.get(node);if(previous?.key===key&&previous.view.parentNode===node&&previous.view.childNodes.length){if(!node.hasAttribute('data-dt-emoticon'))node.setAttribute('data-dt-emoticon','');return;}
    const layout=scrollController?.beforeLayout(node),state=scrollState(node),scroll=state?.scroll,oldTop=scroll?.scrollTop,above=scroll&&node.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,oldHeight=node.getBoundingClientRect().height;
    if(previous){resized.unobserve(previous.view);for(const box of previous.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(previous.view);previous.view.remove()}
    const dual=segments.filter(s=>typeof s!=='string').length===2&&segments.every(s=>typeof s!=='string'||!s.trim());const view=document.createElement('span');view.className='dt-received-emoticon'+(dual?' dt-dual-emoticon':'');view.setAttribute('aria-label','커스텀 이모티콘 메시지');node.setAttribute('data-dt-emoticon','');node.append(view);decorated.set(node,{key,view});
    for(const segment of segments){if(typeof segment==='string'){if(dual)continue;const text=document.createElement('span');text.className='dt-emoticon-text';text.textContent=segment;view.append(text);continue;}const item=segment,box=document.createElement('span');box.className='dt-emoticon-imagebox';box.addEventListener('contextmenu',event=>showEmojiMenu(event,item));box.textContent='이모티콘 불러오는 중…';view.append(box);let loadingImage=false;const load=(refresh=false)=>{if(loadingImage||disposed||!box.isConnected)return;loadingImage=true;box.dataset.loadState='loading';box.textContent='이모티콘 불러오는 중…';return image(item,refresh).then(src=>{if(!box.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{box.dataset.loadState='ready';if(scrollController)scrollController.notifyLayout(box);else followBottom(state)};img.onerror=failed;img.src=src;box.replaceChildren(img)}).catch(failed).finally(()=>{loadingImage=false})};function failed(error){if(!box.isConnected||disposed)return;box.dataset.loadState='failed';box.title=error?.message||'이미지를 표시하지 못했습니다.';const retry=document.createElement('button');retry.textContent=item.label+' · 다시 불러오기';retry.onclick=()=>load(true);box.replaceChildren(retry)}box.__dtReload=load;lazy(box,()=>load());}
    if(scrollController)scrollController.afterLayout(layout);else if(state?.follow)followBottom(state);else if(above)scroll.scrollTop=oldTop+node.getBoundingClientRect().height-oldHeight;
    resized.observe(view);

  }
  function scan(){scheduled=0;if(disposed)return;for(const popup of document.querySelectorAll('.js-sticker-emotion'))mount(popup);if(jumpRequest&&Date.now()>jumpRequest.expires)jumpRequest=null;for(const[p,state]of popups)if(p.isConnected&&jumpRequest&&!jumpRequest.popup)beginJump(p,state);for(const[p,state]of popups)if(!p.isConnected){state.detach();popups.delete(p)}
    const candidates=messageCandidates(),selected=new Set(candidates);
    // Clear obsolete parents before decorating a replacement child, and clear
    // detached nodes too: virtualized native nodes can be inserted again later.
    for(const node of decorated.keys())if(!node.isConnected||!selected.has(node))undecorate(node);
    for(const node of candidates){const text=messageText(node),segments=[];let at=0,count=0;for(const match of text.matchAll(tokenPattern())){const item=decode(match[0]);if(!item||count>=8)continue;if(match.index>at)segments.push(text.slice(at,match.index));segments.push(item);at=match.index+match[0].length;count++;}if(at<text.length)segments.push(text.slice(at));if(count)decorate(node,segments,text);else undecorate(node)}
    for(const[scroll,state]of scrollStates)if(!scroll.isConnected){state.dispose();scrollStates.delete(scroll)}
  }
  let lastError='',lastScan=0;
  const runScan=()=>{try{scan();lastScan=Date.now();lastError=''}catch(e){lastError=e.message;scheduled=0}};
  const changes=new MutationObserver(()=>{if(!scheduled)scheduled=setTimeout(runScan,120)});changes.observe(document,{subtree:true,childList:true,characterData:true});runScan();
  const recoveryTimer=setInterval(()=>{if(!document.hidden)runScan()},2500);
  function diagnostics(){const boxes=[...decorated.values()].flatMap(d=>[...d.view.querySelectorAll('.dt-emoticon-imagebox')]);return {messages:decorated.size,ready:boxes.filter(b=>b.dataset.loadState==='ready').length,failed:boxes.filter(b=>b.dataset.loadState==='failed').length,waiting:boxes.filter(b=>!['ready','failed'].includes(b.dataset.loadState)).length,lastScan,error:lastError}}
  function repair(){runScan();for(const d of decorated.values())for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))if(box.dataset.loadState==='failed')box.__dtReload?.(true);return diagnostics()}

  const dispose=()=>{disposed=true;closeEmojiMenu();jumpRequest=null;document.removeEventListener('pointerdown',dismissEmojiMenu,true);document.removeEventListener('keydown',menuKey);hidePreview();document.removeEventListener('scroll',hidePreview,true);window.removeEventListener('resize',hidePreview);clearInterval(recoveryTimer);clearTimeout(scheduled);changes.disconnect();observer.disconnect();resized.disconnect();for(const state of scrollStates.values())state.dispose();scrollStates.clear();css.remove();for(const[p,s]of popups)s.detach();for(const[n,d]of decorated){d.view.remove();n.removeAttribute('data-dt-emoticon')}popups.clear();decorated.clear();unlocked.clear();catalog=null;catalogSignature='';packViews=new WeakMap();assetPromises.clear();queue.splice(0);memory.clear();memoryBytes=0};
  dispose.repair=repair;dispose.diagnostics=diagnostics;return dispose;
}




// Adds a player above native attachment details without replacing their DOM or handlers.
function installInlineVideos({getFile,resolveURL,scrollController}={}){
  getFile ||= card=>{
    const props=card[Object.keys(card).find(k=>k.startsWith('__reactProps'))];if(props?.file)return props.file;
    let f=card[Object.keys(card).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<40;i++,f=f.return)if(f.memoizedProps?.file)return f.memoizedProps.file;return null;
  };
  resolveURL ||= file=>'/messenger/v2/api/channel/'+file.channelId+'/file/'+file.id;
  const entries=new Map();let disposed=false,timer=0;
  const probe=document.createElement('video');
  const mediaType=file=>{const ext=(file.fileName||file.title||'').split('.').pop().toLowerCase();const types={mp4:'video/mp4',m4v:'video/mp4',webm:'video/webm',ogv:'video/ogg',ogg:'video/ogg',mov:'video/quicktime'};const type=types[ext];return type&&probe.canPlayType(type)?type:null};
  const css=document.createElement('style');css.id='dooray-plus-inline-videos';css.textContent=`
  .dt-inline-video-card{position:relative!important;box-sizing:border-box!important;width:360px!important;max-width:100%!important;height:auto!important;max-height:none!important;padding-top:calc(var(--dt-video-card-width,360px)*.5625 + 12px)!important}
  .dt-inline-video-preview{position:absolute;top:0;left:0;right:0;aspect-ratio:16/9;border-radius:8px 8px 0 0;overflow:hidden;background:radial-gradient(ellipse at 50% 30%,#304860,#111c2b 75%);color:#fff;font:12px/1.4 'Malgun Gothic',sans-serif;isolation:isolate}
  .dt-inline-video-preview video{width:100%;height:100%;display:block;object-fit:contain;background:#10151c}
  .dt-inline-video-preview [hidden]{display:none!important}
  .dt-inline-video-play{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;width:100%;border:0!important;background:transparent!important;color:#fff!important;cursor:pointer;font:inherit}
  .dt-inline-video-play .play-icon{display:grid;place-items:center;width:54px;height:54px;border:1px solid #ffffff80;border-radius:50%;background:#ffffff20;font-size:23px;padding-left:3px;box-shadow:0 4px 16px #0003}
  .dt-inline-video-play:hover .play-icon{background:#ffffff38}.dt-inline-video-play:focus-visible{outline:3px solid #8bc9ff;outline-offset:-3px}
  .dt-inline-video-note{position:absolute;left:10px;right:44px;top:8px;margin:0;padding:5px 8px;border-radius:5px;background:#10151ce8;color:#fff;pointer-events:none;font:11px/1.4 'Malgun Gothic',sans-serif}
  .dt-inline-video-cancel{position:absolute;right:6px;top:6px;display:grid;place-items:center;width:28px;height:28px;padding:0;border:1px solid #ffffff40;border-radius:50%;background:#10151ccc;color:white;cursor:pointer;font-size:18px}
  `;document.head.append(css);
  function layoutChange(card,change){const layout=scrollController?.beforeLayout(card);try{return change()}finally{if(scrollController)scrollController.afterLayout(layout)}}
  const resize=new ResizeObserver(records=>{if(disposed)return;for(const {target}of records){if(!entries.has(target))continue;const width=target.clientWidth;if(width>0&&target.style.getPropertyValue('--dt-video-card-width')!==width+'px')layoutChange(target,()=>target.style.setProperty('--dt-video-card-width',width+'px'))}});
  function remove(card,entry){layoutChange(card,()=>{entry.video.onloadedmetadata=null;entry.video.onresize=null;entry.video.pause();entry.video.removeAttribute('src');entry.video.load();resize.unobserve(card);entry.view.remove();card.classList.remove('dt-inline-video-card');if(entry.width)card.style.setProperty('--dt-video-card-width',entry.width);else card.style.removeProperty('--dt-video-card-width');entries.delete(card)})}
  function mount(card,file){
    const key=file.channelId+'/'+file.id,old=entries.get(card);if(old?.key===key&&old.view.parentNode===card)return;if(old)remove(card,old);
    const layout=scrollController?.beforeLayout(card);
    // The shared controller owns both following and history anchors. Keep the
    // original local fallback only for standalone consumers without it.
    const scroll=scrollController?null:card.closest('[data-dp-native~="scroll"],.js-scroll-area'),top=scroll?.scrollTop,bottom=scroll&&scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<48,above=scroll&&card.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,height=card.getBoundingClientRect().height;
    const view=document.createElement('div');view.className='dt-inline-video-preview';view.setAttribute('aria-label','영상 미리보기');
    const video=document.createElement('video');video.preload='none';video.playsInline=true;video.hidden=true;video.setAttribute('aria-label',(file.fileName||'영상')+' 재생');
    const play=document.createElement('button');play.type='button';play.className='dt-inline-video-play';play.setAttribute('aria-label','채팅방에서 영상 재생');play.innerHTML='<span class="play-icon" aria-hidden="true">▶</span><span>영상 재생</span>';
    const note=document.createElement('p');note.className='dt-inline-video-note';note.setAttribute('role','status');note.hidden=true;
    const cancel=document.createElement('button');cancel.type='button';cancel.className='dt-inline-video-cancel';cancel.textContent='×';cancel.setAttribute('aria-label','영상 재생 중지');cancel.hidden=true;
    view.append(video,play,note,cancel);const entry={key,view,video,width:card.style.getPropertyValue('--dt-video-card-width'),generation:0};
    const notifyLayout=()=>{if(!disposed&&card.isConnected&&entries.get(card)===entry)scrollController?.notifyLayout(card)};video.onloadedmetadata=notifyLayout;video.onresize=notifyLayout;
    const reset=()=>{entry.generation++;video.pause();video.removeAttribute('src');video.load();video.hidden=true;video.controls=false;play.hidden=false;cancel.hidden=true;note.hidden=true};
    const failed=()=>{if(disposed||!view.isConnected||!video.hasAttribute('src'))return;reset();note.textContent='미리보기를 재생할 수 없습니다. 아래 다운로드 버튼을 이용해 주세요.';note.hidden=false};
    play.onclick=e=>{e.preventDefault();for(const other of entries.values())if(other!==entry)other.video.pause();const generation=++entry.generation;video.hidden=false;play.hidden=true;cancel.hidden=false;video.controls=true;note.hidden=false;note.textContent='영상 준비 중… 파일 크기와 형식에 따라 시간이 걸릴 수 있습니다.';video.src=resolveURL(file);video.play().catch(()=>{if(entry.generation===generation)failed()})};
    cancel.onclick=e=>{e.preventDefault();reset()};video.onplaying=()=>{note.hidden=true};video.onwaiting=()=>{if(video.hasAttribute('src')){note.textContent='영상 데이터를 불러오는 중…';note.hidden=false}};video.onerror=failed;
    for(const event of ['click','dblclick','pointerdown'])view.addEventListener(event,e=>e.stopPropagation());
    entries.set(card,entry);card.classList.add('dt-inline-video-card');card.prepend(view);card.style.setProperty('--dt-video-card-width',card.clientWidth+'px');resize.observe(card);
    if(scrollController)scrollController.afterLayout(layout);else if(bottom)scroll.scrollTop=scroll.scrollHeight;else if(above)scroll.scrollTop=top+card.getBoundingClientRect().height-height;
  }
  const validFile=file=>file&&/^\d+$/.test(String(file.id))&&/^\d+$/.test(String(file.channelId));
  function cards(){
    const result=new Set([...entries.keys()].filter(card=>card.isConnected));
    const hinted='[data-dp-native~="file-card"],.sc-RcBXQ',excluded='[data-dt-file-view],.dt-inline-video-preview,.dt-emoticon-custom,.js-sticker-emotion,[contenteditable="true"]';
    for(const card of document.querySelectorAll(hinted))if(!card.closest(excluded))result.add(card);
    const areas=[...document.querySelectorAll('[data-dp-native~="scroll"],.js-scroll-area')],cache=new WeakMap();
    const fileFor=node=>{if(!cache.has(node))cache.set(node,getFile(node));return cache.get(node)};
    for(const area of areas.filter(n=>!areas.some(other=>other!==n&&other.contains(n)))){
      // Inspect only rendered chat descendants. A file prop belongs to its
      // outermost native card, never to every nested label/download button.
      const walker=document.createTreeWalker(area,NodeFilter.SHOW_ELEMENT,{acceptNode:node=>node.matches(excluded)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let visited=0;
      for(let node=walker.nextNode();node&&visited++<4000;node=walker.nextNode()){
        const file=fileFor(node);if(!validFile(file))continue;
        const hintedCard=node.closest(hinted);if(hintedCard&&area.contains(hintedCard)){result.add(hintedCard);continue;}
        let card=node;
        for(let depth=0,parent=card.parentElement;parent&&parent!==area&&depth<16;parent=parent.parentElement,depth++){
          const candidate=fileFor(parent);if(!validFile(candidate)||String(candidate.id)!==String(file.id)||String(candidate.channelId)!==String(file.channelId))break;card=parent;
        }
        result.add(card);
      }
    }
    // Props are inherited through React fibers. Coalesce descendants found by
    // that walk so one attachment receives exactly one player.
    const candidates=[...result];return candidates.filter(card=>!card.closest(excluded)&&!candidates.some(parent=>parent!==card&&parent.contains(card)&&validFile(fileFor(parent))&&String(fileFor(parent).id)===String(fileFor(card)?.id)&&String(fileFor(parent).channelId)===String(fileFor(card)?.channelId)));
  }
  function scan(){timer=0;if(disposed)return;const activeCards=new Set(cards());for(const card of activeCards){
    // Keep the existing file-library layout; this player belongs to chat attachments.
    if(card.closest('[data-dt-file-view]'))continue;
    const file=getFile(card);if(validFile(file)&&mediaType(file))mount(card,file);else if(entries.has(card))remove(card,entries.get(card));
  }for(const[card,entry]of entries)if(!activeCards.has(card)||!card.isConnected||card.closest('[data-dt-file-view]'))remove(card,entry)}
  const changes=new MutationObserver(()=>{if(!timer)timer=setTimeout(scan,120)});changes.observe(document,{childList:true,subtree:true});scan();
  const poll=setInterval(()=>{if(!document.hidden)scan()},2500);
  const dispose=()=>{disposed=true;clearTimeout(timer);clearInterval(poll);changes.disconnect();for(const[card,entry]of entries)remove(card,entry);resize.disconnect();css.remove()};dispose.scan=scan;return dispose;
}

// Per-account room styling and muted-room notification exceptions. No server settings are modified.
function doorayRoomStyle(value){
 const s=value&&typeof value==='object'?value:{};const color=(v,d)=>/^#[a-f\d]{6}$/i.test(v||'')?v:d;
 const result={enabled:s.enabled===true,bg:color(s.bg,'#e8f1ff'),text:color(s.text,'#172c48'),border:color(s.border,'#739bce'),width:Number.isFinite(s.width)?Math.max(0,Math.min(6,s.width)):1,borderStyle:['solid','dashed','dotted'].includes(s.borderStyle)?s.borderStyle:'solid',font:typeof s.font==='string'?s.font.slice(0,120):''};
 if(s.themes&&typeof s.themes==='object'){result.themes={};for(const mode of ['default','excel','vscode'])if(s.themes[mode]&&typeof s.themes[mode]==='object')result.themes[mode]=doorayRoomStyle({...s.themes[mode],themes:undefined});}return result;
}
function doorayRoomConfig(value){
 const s=value&&typeof value==='object'?value:{};const rooms={};
 for(const [id,room] of Object.entries(s.rooms||{}).slice(0,500)){
  if(!/^\d+$/.test(id)||!room||typeof room!=='object')continue;const people={};
  for(const [uid,p] of Object.entries(room.people||{}).slice(0,2000)){if(!/^\d+$/.test(uid)||!p||typeof p!=='object')continue;people[uid]={name:typeof p.name==='string'?p.name.slice(0,120):uid,style:doorayRoomStyle(p.style),notify:p.notify===true};}
  rooms[id]={name:typeof room.name==='string'?room.name.slice(0,120):id,localMuted:room.localMuted===true,people};
 }
 return {version:1,defaults:doorayRoomStyle(s.defaults),ownDefaults:doorayRoomStyle(s.ownDefaults),rooms};
}
function doorayRoomNoticeAllowed({log,roomEnabled,opted,selfId,now,started,main,globalEnabled}){
 const sentAt=log?.sentAt;const at=typeof sentAt==='number'?sentAt:typeof sentAt==='string'?(/^\d{13}$/.test(sentAt)?Number(sentAt):Date.parse(sentAt)):NaN;return main&&globalEnabled&&!roomEnabled&&opted&&log&&[0,2,4,5,8,9,10].includes(Number(log.type))&&String(log.senderId)!==String(selfId)&&/^\d+$/.test(String(log.senderId))&&/^\d+$/.test(String(log.channelId))&&/^\d+$/.test(String(log.id))&&Number.isFinite(at)&&at>=started-2000&&at<=now+30000&&now-at<60000;
}
// Compare server message times against the same origin's HTTP clock, anchored to monotonic time.
function doorayNoticeClock({fetcher=globalThis.fetch,wall=()=>Date.now(),mono=()=>performance.now(),url='/messenger'}={}){
 let anchor=null,pending=null,nextCheck=0;
 const current=()=>anchor?anchor.server+(mono()-anchor.mono):wall();
 async function now(){
  if(typeof fetcher!=='function')return current();
  if(!pending&&mono()>=nextCheck){pending=(async()=>{const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),5000),begin=mono();
   try{const response=await fetcher(url,{method:'HEAD',cache:'no-store',credentials:'same-origin',signal:abort.signal});const end=mono(),date=Date.parse(response.headers.get('date')||'');
    if(!response.ok||!Number.isFinite(date)||end-begin>5000)throw Error('Server clock unavailable');
    anchor={server:date+500+(end-begin)/2,mono:end};nextCheck=end+300000;
   }catch{nextCheck=mono()+30000}finally{clearTimeout(timeout)}
  })().finally(()=>{pending=null});}
  if(pending)await pending;return current();
 }
 return {now};
}
// A style element inside a tab still affects the entire settings shadow root.
// Share only layout rules here; controls inherit the settings panel's own theme.
function doorayRoomSettingsCSS(uiCSS){
 const layout='.dp-editor-actions>*{max-width:100%}.dp-person-editor,.dp-default-editor,.dp-own-editor{min-width:0;max-width:100%}.dp-editor-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:8px 0}.dp-person-editor h3,.dp-room-label{overflow-wrap:anywhere}.dp-room-label{display:block;margin:8px 0}.dp-members{margin-top:8px}.dp-member-search{margin-top:4px}'+uiCSS.slice(uiCSS.indexOf('.grid{'),uiCSS.indexOf('.primary{'))+'input[type=color]{width:52px;height:30px;padding:2px}input[type=number]{width:58px}';
 return layout.replace(/([^{}]+)\{([^{}]*)\}/g,(_,selectors,body)=>selectors.split(',').map(s=>'[data-dp-tab="bubbles"] '+s.trim()).join(',')+'{'+body+'}');
}
function doorayRoomProfile(value,theme){
 const style=doorayRoomStyle(value),mode=theme.mode||'default';
 const saved=style.themes?.[mode]||(mode==='default'&&style.enabled?style:null);
 const profile=doorayRoomStyle(saved||{...theme,enabled:false});
 if(mode==='excel'||mode==='vscode'){profile.width=1;profile.borderStyle='solid';}
 return profile;
}
function doorayRoomSaveProfile(value,theme,profile){
 const style=doorayRoomStyle(value);return {...style,themes:{...style.themes,[theme.mode||'default']:doorayRoomStyle(profile)}};
}
function doorayRoomResetProfile(value,mode){const style=doorayRoomStyle(value);if(mode==='default')style.enabled=false;if(style.themes)delete style.themes[mode];return style;}
function doorayRoomHasStyle(value){return value?.enabled||Object.values(value?.themes||{}).some(s=>s.enabled);}
function doorayMemberRows(root,getProps){
 const result=[];
 for(const row of root.querySelectorAll('div')){
  if(row.closest('.dp-member-notify')||result.some(x=>x.row.contains(row)))continue;
  const p=getProps(row,p=>p.memberId,12),uid=String(p?.memberId||'');
  if(/^\d+$/.test(uid))result.push({row,uid});
 }
 return result;
}
// Semantic markers are supplied by the shared native-DOM adapter. The bounded
// React fallback also supports startup before that adapter has marked the view.
function doorayRoomMessages(root,getProps){
 const result=new Map(),excluded='[contenteditable="true"],.js-main-editor,[role="dialog"],[aria-modal="true"],[data-dp-extension],.dt-received-emoticon';
 const validLog=p=>p?.log&&['channelId','senderId'].every(k=>/^\d+$/.test(String(p.log[k]??'')));
 const fiber=el=>el?.[Object.keys(el).find(k=>k.startsWith('__reactFiber'))];
 const direct=el=>el?.[Object.keys(el).find(k=>k.startsWith('__reactProps'))]||fiber(el)?.memoizedProps;
 const accept=(text,bubble)=>{
  if(!text||!bubble||!root.contains(bubble)||!bubble.contains(text)||text.closest(excluded)||bubble.matches('[data-logid],[class*="js-log-right-content-"],[data-dp-native~="message-content"],[data-dp-native~="message-group"]')||bubble.querySelector('textarea,[contenteditable="true"]'))return;
  const p=getProps(text,validLog);if(p)result.set(text,{text,bubble,log:p.log});
 };
 for(const text of root.querySelectorAll('[data-dp-native~="message-text"],.sc-chbbiW'))accept(text,text.closest('[data-dp-native~="message-bubble"]')||text.closest('.sc-iyvyFf'));
 for(const section of root.querySelectorAll('[class*="js-log-right-content-"],[data-logid]')){
  if(section.closest(excluded)||section.querySelector('[data-dp-native~="message-text"]'))continue;
  for(const text of section.querySelectorAll('span,div,p')){
   if(result.has(text)||text.closest(excluded))continue;
   // Stop at the first enclosing host node. A username, read count or link
   // must not inherit a message model from an unrelated ancestor component.
   let f=fiber(text),message=false,hasLog=validLog(direct(text)),bubble=null;const seen=new Set();
   for(let i=0;f&&i<45&&!seen.has(f);i++,f=f.return){
    seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==text){if(message)bubble=f.stateNode;break;}
    if(validLog(f.memoizedProps)){hasLog=true;if(Object.prototype.hasOwnProperty.call(f.memoizedProps,'chunks'))message=true;}
   }
   const html=direct(text)?.dangerouslySetInnerHTML;
   if(!bubble&&hasLog&&html&&Object.prototype.hasOwnProperty.call(html,'__html'))bubble=text.parentElement;
   if(bubble&&bubble!==section&&section.contains(bubble))accept(text,bubble);
  }
 }
 return [...result.values()];
}
function installDoorayRooms({themeShadow,onError=()=>{},notifyOverride,getTheme=()=>({mode:'default',bg:'#e8f1ff',text:'#172c48',border:'#739bce',width:1,borderStyle:'solid',font:''})}={}){
 const getProps=(node,predicate,limit=45)=>{const direct=node?.[Object.keys(node).find(k=>k.startsWith('__reactProps'))];if(direct&&predicate(direct))return direct;let f=node?.[Object.keys(node).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<limit;i++,f=f.return){const p=f.memoizedProps;if(p&&predicate(p))return p;}return null};
 const discover=()=>{for(const node of [document.querySelector('.js-main-editor,[data-dp-native~="editor"]'),document.querySelector('[data-dp-native~="message-text"],[class*="js-log-right-content-"],[data-logid],.sc-chbbiW'),...document.querySelectorAll('#root > *')]){const p=getProps(node,p=>p.actions?.stores,100);if(p)return p.actions;}return null};
 let actions=null,key='',config=doorayRoomConfig({}),disposed=false,socket=null,started=performance.now(),roomId='',lastRoom='',lastMembers='',timer,scheduled=false,lastList='',themeStamp='';
 const noticeClock=doorayNoticeClock();
 const changed=new Map(),changedTexts=new Map(),rows=new Map(),pendingNotices=new Set(),bellMarks=new Map();let muteDialog=null,noticeHook=null;let settingsRevision=0;
 const css=document.createElement('style');css.textContent='#root [data-dp-bubble][data-dp-bubble]{background:var(--dp-bg)!important;color:var(--dp-text)!important;border:var(--dp-width) var(--dp-border-style) var(--dp-border)!important}#root [data-dp-bubble][data-dp-bubble] :is([data-dp-native~="message-text"],[data-dp-room-text]),#root [data-dp-bubble][data-dp-bubble] :is([data-dp-native~="message-text"],[data-dp-room-text]) :not(img):not(svg){color:var(--dp-text)!important}#root [data-dp-bubble][data-dp-mode=excel]{border:0!important;box-shadow:inset 0 0 0 1px var(--dp-border)!important}#root [data-dp-font][data-dp-font][data-dp-font],#root [data-dp-font][data-dp-font][data-dp-font] :is([data-dp-native~="message-text"],[data-dp-room-text]),#root [data-dp-font][data-dp-font][data-dp-font] :is([data-dp-native~="message-text"],[data-dp-room-text]) :not(img):not(svg){font-family:var(--dp-font)!important}.dp-member-notify{position:absolute!important;right:6px!important;top:50%!important;transform:translateY(-50%);font:11px "Malgun Gothic",sans-serif!important;padding:5px 7px!important;border:1px solid var(--dt-border,#aaa)!important;border-radius:6px!important;background:var(--dt-surface,#eee)!important;color:var(--dt-text,#333)!important;cursor:pointer;z-index:1}.dp-member-notify[aria-pressed="true"]{background:#1768b5!important;color:white!important}.dp-member-notify:disabled{opacity:.5;cursor:default}';document.head.append(css);
 const uiCSS=':host{font:12px "Malgun Gothic",sans-serif;color:var(--dt-text,#24334b)}*{box-sizing:border-box}[hidden]{display:none!important}button,input,select{font:inherit}button{cursor:pointer;border:1px solid var(--dt-border,#6f839b);border-radius:6px;padding:6px 10px;background:var(--dt-surface,#fff);color:inherit}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid #448eff;outline-offset:2px}input,select{min-width:0;color:inherit;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#8c9bb0);border-radius:5px;padding:5px}input[type=color]{width:52px;height:30px;padding:2px}input[type=number]{width:58px}.grid{display:grid;grid-template-columns:minmax(0,1fr);gap:10px;padding:10px 0}.field{display:flex;align-items:center;justify-content:space-between;gap:8px;white-space:nowrap;min-width:0;max-width:100%}.field select{width:160px;max-width:65%;flex:0 1 160px;min-width:0}.wide{grid-column:1/-1}.bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.bar strong{flex:1}.note{font-size:11px;opacity:.8;line-height:1.6}.list{display:grid;gap:8px;max-height:240px;overflow:auto;margin-top:10px}.item{display:flex;align-items:center;gap:10px;border:1px solid var(--dt-border,#bbb);padding:8px;border-radius:8px}.item .who{flex:1;min-width:0;overflow-wrap:anywhere}.sample{padding:7px 12px;border-radius:7px;display:inline-block;max-width:100%;overflow-wrap:anywhere}.primary{background:#236bc1;color:#fff;border-color:#236bc1}label{cursor:pointer}';
 function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e}
 function error(e){onError(e.message||String(e));if(roomHint)roomHint.textContent=e.message||String(e)}
 function theme(uid){const t=getTheme()||{};return {...t,...(String(uid)===String(actions?.stores.userStore.id)&&t.own?{bg:t.own}:{}),mode:t.mode||'default'};}
 function room(){return actions?.stores.channelsStore.getById(roomId)}
 function baseStyle(uid){return String(uid)===String(actions?.stores.userStore.id)?config.ownDefaults:config.defaults}
 function roomEnabled(id){return actions.stores.channelsStore.isChannelNotificationOn(id)&&!config.rooms[id]?.localMuted}
 function roomName(c){return c?.title||c?.members?.map(id=>memberName(String(id))).filter(Boolean).join(', ').slice(0,120)||'현재 대화방'}
 function memberName(id){return actions?.stores.membersStore.getById(id)?.name||id}
 function save(next){try{const clean=doorayRoomConfig(next);const raw=JSON.stringify(clean);if(raw.length>2e6)throw Error('설정 저장 용량을 초과했습니다.');localStorage.setItem(key,raw);config=clean;settingsRevision++;lastList='';refreshList();applyBubbles();updateMemberButtons();return true}catch(e){error(e);return false}}
 function setPerson(cid,uid,patch){if(!key||!/^\d+$/.test(cid)||!/^\d+$/.test(uid))return false;const next=doorayRoomConfig(config);const c=actions.stores.channelsStore.getById(cid);next.rooms[cid]||={name:roomName(c),localMuted:false,people:{}};next.rooms[cid].people[uid]={name:memberName(uid),style:doorayRoomStyle({}),notify:false,...next.rooms[cid].people[uid],...patch};return save(next)}
 function applyStyle(el,s){el.style.background=s.bg;el.style.color=s.text;el.style.border=s.width+'px '+s.borderStyle+' '+s.border;el.style.fontFamily=s.font?JSON.stringify(s.font):(theme().font?JSON.stringify(theme().font):'');el.style.borderRadius=theme().mode==='excel'?'0':theme().mode==='vscode'?'2px':'7px';el.style.boxShadow=theme().mode==='vscode'?'inset 3px 0 #007acc':''}
 function editor(parent,initial,onSave,{defaults=false,own=false,onReset}={}){
  const form=node('form');form.innerHTML='<div class="grid"><label class="wide"><input name="enabled" type="checkbox"> '+(defaults?(own?'내 말풍선 꾸미기 사용':'상대방 기본 말풍선 꾸미기 사용'):'이 사용자의 말풍선 꾸미기 사용')+'</label><label class="field">배경색 <input name="bg" type="color"></label><label class="field">글자색 <input name="text" type="color"></label><label class="field">테두리 색 <input name="border" type="color"></label><label class="field">두께 <input name="width" type="number" min="0" max="6" step="0.5"></label><label class="field">테두리 <select name="borderStyle"><option value="solid">실선</option><option value="dashed">파선</option><option value="dotted">점선</option></select></label><label class="field">폰트 <select name="font"></select></label></div><div class="dp-editor-actions"><span class="sample">테스트</span><button class="primary" type="submit">저장</button></div><p class="note feedback" role="status"></p>';
  form.prepend(node('p','값을 변경하면 꾸미기가 켜지고 즉시 적용·저장됩니다.','note'));
  const fontLabel='테마 기본 ('+(theme().fontLabel||theme().font||'Dooray 기본 글꼴')+')';
  const select=form.elements.font;select.append(new Option(fontLabel,''));for(const option of themeShadow.querySelector('#font')?.options||[]){if(option.value!=='original')select.append(new Option(option.text,option.value))}if(initial.font&&![...select.options].some(o=>o.value===initial.font))select.append(new Option(initial.font,initial.font));
  for(const k of ['enabled','bg','text','border','width','borderStyle','font']){if(k==='enabled')form.elements[k].checked=initial[k];else form.elements[k].value=initial[k]}
  select.addEventListener('focus',()=>{const selected=select.value;select.replaceChildren(new Option(fontLabel,''));for(const option of themeShadow.querySelector('#font')?.options||[])if(option.value!=='original')select.append(new Option(option.text,option.value));if(selected&&![...select.options].some(o=>o.value===selected))select.append(new Option(selected,selected));select.value=selected;});
  const read=()=>doorayRoomStyle(Object.fromEntries(['enabled','bg','text','border','width','borderStyle','font'].map(k=>[k,k==='enabled'?form.elements[k].checked:k==='width'?Number(form.elements[k].value):form.elements[k].value])));
  if(theme().mode!=='default'){for(const k of ['width','borderStyle']){form.elements[k].disabled=true;form.elements[k].title=theme().mode==='excel'?'엑셀 격자선은 1px 실선으로 유지합니다.':'VS Code 카드 테두리는 1px 실선으로 유지합니다.';}form.prepend(node('p',theme().mode==='excel'?'격자선은 1px 실선으로 유지합니다. 색과 글꼴을 변경할 수 있습니다.':'코드 카드 테두리와 왼쪽 강조선은 유지합니다. 색과 글꼴을 변경할 수 있습니다.','note'));}
  if(onReset){const reset=node('button','테마 기본값으로 초기화');reset.type='button';reset.onclick=onReset;form.querySelector('.dp-editor-actions').append(reset);}
  const preview=()=>applyStyle(form.querySelector('.sample'),read());let lastApplied=JSON.stringify(read());
  const applyNow=e=>{if(e?.target?.name&&e.target.name!=='enabled')form.elements.enabled.checked=true;preview();const value=read(),signature=JSON.stringify(value);if(signature===lastApplied)return;if(onSave(value)){lastApplied=signature;form.querySelector('.feedback').textContent=value.enabled?'실시간으로 적용·저장했습니다.':'꾸미기를 해제했습니다.'}else form.querySelector('.feedback').textContent='저장하지 못했습니다.'};
  form.oninput=applyNow;form.onchange=applyNow;form.onsubmit=e=>{e.preventDefault();preview();if(onSave(read())){lastApplied=JSON.stringify(read());form.querySelector('.feedback').textContent='저장했습니다.'}else form.querySelector('.feedback').textContent='저장하지 못했습니다.'};preview();parent.append(form);return form;
 }
 function renderPersonEditor(){
  if(!personBox||!memberList)return;const uid=memberList.value,cid=roomId;personBox.replaceChildren();if(!uid)return;
  const t=theme(uid),specific=config.rooms[cid]?.people[uid]?.style,base=doorayRoomProfile(baseStyle(uid),t);
  const initial=doorayRoomProfile(specific,t);if(!specific?.themes?.[t.mode]&&!(t.mode==='default'&&specific?.enabled)&&base.enabled)Object.assign(initial,{...base,enabled:false});
  const commit=style=>{if(cid!==String(actions.stores.mainDetailUiState.currentChannelId)){error(Error('대화방이 바뀌었습니다. 현재 방의 멤버를 다시 선택해 주세요.'));return false}return setPerson(cid,uid,{style})};
  personBox.append(node('h3',memberName(uid)+'님의 말풍선'));
  editor(personBox,initial,s=>commit(doorayRoomSaveProfile(config.rooms[cid]?.people[uid]?.style,t,s)),{onReset:()=>{if(commit(doorayRoomResetProfile(config.rooms[cid]?.people[uid]?.style,t.mode)))renderPersonEditor()}});
 }
 function refreshPanel(){
  if(!memberList)return;const c=room();if(!c){roomLabel.textContent='대화방을 열어 주세요.';memberList.replaceChildren();personBox.replaceChildren();memberList.disabled=true;lastMembers='';return;}
  const members=(c.members||[]).map(x=>String(typeof x==='string'||typeof x==='number'?x:x.memberId||x.id)).filter(x=>/^\d+$/.test(x));
  const query=memberSearch.value.trim().toLowerCase(),visible=members.filter(id=>memberName(id).toLowerCase().includes(query));
  const signature=roomId+':'+members.map(id=>id+memberName(id)).join(',')+':'+query+':'+themeStamp;
  if(signature!==lastMembers){const selected=memberList.value;roomLabel.textContent=roomName(c);memberList.replaceChildren(...visible.map(id=>new Option(memberName(id),id)));memberList.disabled=!visible.length;if(visible.length)memberList.selectedIndex=0;if(roomId===lastRoom&&visible.includes(selected))memberList.value=selected;roomHint.textContent=visible.length?'선택한 사람의 설정은 이 대화방에만 적용됩니다.':'표시할 멤버가 없습니다.';lastMembers=signature;lastRoom=roomId;renderPersonEditor();}
 }
 function entries(){return Object.entries(config.rooms).flatMap(([cid,r])=>Object.entries(r.people).filter(([,p])=>doorayRoomHasStyle(p.style)||p.notify).map(([uid,p])=>({cid,uid,r,p})))}
 function fillList(target,onlyRoom){target.replaceChildren();let count=0;for(const {cid,uid,r,p}of entries()){if(onlyRoom&&cid!==roomId)continue;count++;const row=node('div',undefined,'item'),who=node('div',undefined,'who');who.append(node('strong',memberName(uid)||p.name),node('div',r.name+(p.notify?' · 알림 켜짐':''),'note'));const sample=node('span','테스트','sample');const t=theme(uid),specific=doorayRoomProfile(p.style,t),base=doorayRoomProfile(baseStyle(uid),t);applyStyle(sample,specific.enabled?specific:base.enabled?base:doorayRoomProfile({},t));const remove=node('button','해제');remove.type='button';remove.setAttribute('aria-label',p.name+' 설정 해제');remove.onclick=()=>{const next=doorayRoomConfig(config);delete next.rooms[cid].people[uid];if(!Object.keys(next.rooms[cid].people).length&&!next.rooms[cid].localMuted)delete next.rooms[cid];if(save(next)&&cid===roomId)renderPersonEditor()};row.append(who,sample,remove);target.append(row)}if(!count)target.append(node('p','저장된 사용자 설정이 없습니다.','note'));}
 function refreshList(){const sig=roomId+':'+settingsRevision;if(sig===lastList)return;lastList=sig;if(globalList)fillList(globalList,false);}
 function restore(el,record){for(const [name,[value,priority]]of record)if(value)el.style.setProperty(name,value,priority);else el.style.removeProperty(name);el.removeAttribute('data-dp-bubble');el.removeAttribute('data-dp-font');el.removeAttribute('data-dp-mode');}
 function restoreText(text,value){if(value===null)text.removeAttribute('data-dp-room-text');else text.setAttribute('data-dp-room-text',value)}
 function applyBubbles(){
  const touched=new Set(),texts=new Set(),root=document.querySelector('#root');for(const {text,bubble,log} of root?doorayRoomMessages(root,getProps):[]){const specific=config.rooms[String(log.channelId)]?.people[String(log.senderId)]?.style;const t=theme(String(log.senderId)),personal=doorayRoomProfile(specific,t),base=doorayRoomProfile(baseStyle(log.senderId),t),s=personal.enabled?personal:base.enabled?base:null;if(!s)continue;touched.add(bubble);texts.add(text);if(!changedTexts.has(text))changedTexts.set(text,text.getAttribute('data-dp-room-text'));if(!text.hasAttribute('data-dp-room-text'))text.setAttribute('data-dp-room-text','');if(!changed.has(bubble))changed.set(bubble,new Map(['--dp-bg','--dp-text','--dp-border','--dp-width','--dp-border-style','--dp-font'].map(k=>[k,[bubble.style.getPropertyValue(k),bubble.style.getPropertyPriority(k)]])));bubble.setAttribute('data-dp-bubble','');if(bubble.getAttribute('data-dp-mode')!==t.mode)bubble.setAttribute('data-dp-mode',t.mode);for(const[k,v]of Object.entries({'--dp-bg':s.bg,'--dp-text':s.text,'--dp-border':s.border,'--dp-width':s.width+'px','--dp-border-style':s.borderStyle,'--dp-font':s.font?JSON.stringify(s.font):'inherit'})){if(bubble.style.getPropertyValue(k)!==v)bubble.style.setProperty(k,v)}bubble.toggleAttribute('data-dp-font',!!s.font);}
  for(const [el,r]of changed)if(!touched.has(el)||!el.isConnected){restore(el,r);changed.delete(el)}
  for(const [text,value]of changedTexts)if(!texts.has(text)||!text.isConnected){restoreText(text,value);changedTexts.delete(text)}
 }
 function updateMemberButtons(){
  const live=new Set(),c=room();if(c&&!roomEnabled(roomId))for(const {row,uid} of [...document.querySelectorAll('.js-user-setting-member-list')].flatMap(root=>doorayMemberRows(root,getProps))){
   if(!/^\d+$/.test(uid)||!c.members?.some(x=>String(typeof x==='string'||typeof x==='number'?x:x.memberId||x.id)===uid))continue;live.add(row);
   let r=rows.get(row);if(!r){const button=node('button');button.className='dp-member-notify';button.type='button';r={button,position:row.style.position,padding:row.style.paddingRight};row.style.position='relative';row.style.paddingRight='88px';row.append(button);rows.set(row,r);button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const cid=button.dataset.room,mid=button.dataset.member;if(roomEnabled(cid))return;setPerson(cid,mid,{notify:!config.rooms[cid]?.people[mid]?.notify})});for(const name of ['mousedown','pointerdown','dblclick'])button.addEventListener(name,e=>e.stopPropagation());}
   const enabled=config.rooms[roomId]?.people[uid]?.notify===true;r.button.dataset.room=roomId;r.button.dataset.member=uid;const label=enabled?'알림 켜짐':'알림 꺼짐';if(r.button.textContent!==label)r.button.textContent=label;r.button.setAttribute('aria-pressed',String(enabled));r.button.setAttribute('aria-label',memberName(uid)+' 개별 알림 '+(enabled?'켜짐':'꺼짐'));r.button.disabled=String(actions.stores.userStore.id)===uid;r.button.title=r.button.disabled?'본인이 보낸 메시지는 알리지 않습니다.':'이 방의 전체 알림을 끈 상태에서 이 사람의 새 메시지만 알립니다.';
  }
  for(const [row,r]of rows)if(!live.has(row)||!row.isConnected){r.button.remove();row.style.position=r.position;row.style.paddingRight=r.padding;rows.delete(row)}
 }
 function claim(log){const ledgerKey=key+'.seen';let seen={};try{seen=JSON.parse(localStorage.getItem(ledgerKey)||'{}')}catch{}const id=String(log.channelId)+':'+String(log.id);if(seen[id])return false;seen[id]=Date.now();const kept=Object.fromEntries(Object.entries(seen).filter(([,at])=>Number.isFinite(at)&&Date.now()-at<86400000).slice(-500));try{localStorage.setItem(ledgerKey,JSON.stringify(kept))}catch{return false}return true}
 async function onMessage(event){try{
  const eventSocket=socket,eventKey=key,eventStarted=started;
  const raw=JSON.parse(event.data);if(!(raw.type==='channelLog'&&raw.action==='create'||raw.type==='channelLogCreate'))return;const logs=raw.content||raw.contents;
  const serverNow=await noticeClock.now();if(disposed||socket!==eventSocket||key!==eventKey)return;const serverStarted=serverNow-(performance.now()-eventStarted);
  for(const log of Array.isArray(logs)?logs:[logs]){if(!log)continue;const cid=String(log.channelId),uid=String(log.senderId),c=actions.stores.channelsStore.getById(cid);if(!c)continue;const handler=actions.websocketActions.log;
   if(!doorayRoomNoticeAllowed({log,roomEnabled:roomEnabled(cid),opted:config.rooms[cid]?.people[uid]?.notify===true,selfId:actions.stores.userStore.id,now:serverNow,started:serverStarted,main:actions.stores.uiState.isMainView===true,globalEnabled:['loud','silent'].includes(actions.stores.globalSettingStore.notification)}))continue;
   if(handler.isNotificationAvailableTime&&!handler.isNotificationAvailableTime())continue;
   const ctx={channel:c,log};const token=cid+':'+log.id;if(pendingNotices.has(token))continue;pendingNotices.add(token);
   try{if(!claim(log))continue;const person=memberName(uid),title=roomName(c)||'두레이 플러스',body=person+'님이 새 메시지를 보냈습니다.';if(notifyOverride)notifyOverride({title,body,channelId:cid});else handler.handleNotificationParams(log,title,body)}finally{pendingNotices.delete(token)}
  }
 }catch(e){console.warn('Dooray Plus individual notification:',e.message)}}

 function hookLocalMute(){
  const h=actions?.websocketActions?.log;if(noticeHook?.handler===h)return;if(noticeHook&&noticeHook.handler.showNotification===noticeHook.wrapped)noticeHook.handler.showNotification=noticeHook.original;
  if(!h||typeof h.showNotification!=='function')return;const original=h.showNotification;const wrapped=function(ctx){const id=String(ctx?.log?.channelId||ctx?.channel?.channelId||'');if(config.rooms[id]?.localMuted)return;return original.apply(this,arguments)};h.showNotification=wrapped;noticeHook={handler:h,original,wrapped};
 }
 function setLocalMute(id,value){const next=doorayRoomConfig(config);next.rooms[id]||={name:roomName(actions.stores.channelsStore.getById(id)),localMuted:false,people:{}};next.rooms[id].localMuted=value;return save(next)}
 function closeMuteDialog(){muteDialog?.remove();muteDialog=null}
 function showMuteDialog(button,cid){
  closeMuteDialog();muteDialog=node('div');muteDialog.style.cssText='position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;background:#0005';const sh=muteDialog.attachShadow({mode:'open'}),already=config.rooms[cid]?.localMuted===true;
  sh.innerHTML='<style>'+uiCSS+'.dialog{width:380px;max-width:calc(100vw - 32px);padding:20px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#aaa);border-radius:12px;box-shadow:0 12px 40px #0006}.local{display:flex;align-items:center;gap:10px;border:3px solid #e23945;background:#e2394514;padding:14px 10px;border-radius:8px;font-weight:bold;color:var(--dt-text,#222)}.local input{width:22px;height:22px;accent-color:#d5293a;outline:2px solid #e23945;outline-offset:3px}.danger{color:#e23945;font-weight:700}.bar{justify-content:flex-end}</style><section class="dialog" role="dialog" aria-modal="true" aria-labelledby="mute-title"><h3 id="mute-title">'+(already?'이 컴퓨터의 방 알림':'대화방 알림 끄기')+'</h3><p class="room note"></p><label class="local"><input type="checkbox" id="local">이 컴퓨터에서만 알림 끄기</label><p class="note danger">체크하면 다른 컴퓨터·모바일의 알림 설정은 변경하지 않습니다.</p><p class="note explanation"></p><div class="bar"><button id="cancel" type="button">취소</button><button id="apply" class="primary" type="button">적용</button></div><p class="note status" role="status"></p></section>';
  sh.querySelector('.room').textContent=roomName(actions.stores.channelsStore.getById(cid));const checkbox=sh.querySelector('#local');checkbox.checked=already;const explain=()=>{sh.querySelector('.explanation').textContent=already?'체크를 해제하면 이 컴퓨터의 방 알림 차단을 해제합니다.':checkbox.checked?'이 PC에서만 끕니다. 멤버/설정에서 지정한 사람의 예외 알림은 유지됩니다.':'체크하지 않으면 기존 두레이 방식으로 방 알림을 끕니다. 다른 기기에도 영향을 줄 수 있습니다.'};checkbox.onchange=explain;explain();
  const cancel=()=>{closeMuteDialog();button.focus()};sh.querySelector('#cancel').onclick=cancel;sh.querySelector('#apply').onclick=async()=>{if(cid!==roomId){sh.querySelector('.status').textContent='대화방이 바뀌었습니다. 취소 후 다시 시도해 주세요.';return}try{if(already||checkbox.checked){if(!setLocalMute(cid,checkbox.checked))return;}else{await actions.channelActions.updateNotification(cid,'never');}closeMuteDialog();tick();button.focus()}catch(e){sh.querySelector('.status').textContent='알림 설정 실패: '+e.message}};
  sh.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();cancel()}if(e.key==='Tab'){const list=[...sh.querySelectorAll('input,button')],i=list.indexOf(sh.activeElement);if(e.shiftKey&&i===0){e.preventDefault();list.at(-1).focus()}else if(!e.shiftKey&&i===list.length-1){e.preventDefault();list[0].focus()}}});document.body.append(muteDialog);checkbox.focus();
 }
 function bellClick(e){const button=e.target instanceof Element?e.target.closest('button'):null;if(!button||!actions||!room())return;const p=getProps(button,p=>p.name==='notification',22);if(!p)return;if(!roomEnabled(roomId)&&!config.rooms[roomId]?.localMuted)return;e.preventDefault();e.stopImmediatePropagation();showMuteDialog(button,roomId)}
 document.addEventListener('click',bellClick,true);
 function markBells(){const live=new Set();for(const button of document.querySelectorAll('#root button')){const p=getProps(button,p=>p.name==='notification',22);if(!p)continue;live.add(button);if(config.rooms[roomId]?.localMuted){if(!bellMarks.has(button))bellMarks.set(button,{outline:button.style.outline,title:button.getAttribute('title')});button.style.outline='2px solid #e23945';button.title='이 컴퓨터에서만 알림 꺼짐 · 클릭해서 변경';}else if(bellMarks.has(button)){const old=bellMarks.get(button);button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;bellMarks.delete(button)}}for(const [button,old]of bellMarks)if(!live.has(button)){button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;bellMarks.delete(button)}}

 function attachSocket(){const next=actions?.websocketActions.ws?.socket;if(socket===next)return;socket?.removeEventListener('message',onMessage);socket=next;if(socket){started=performance.now();void noticeClock.now();socket.addEventListener('message',onMessage)}}
 const tabRoot=themeShadow.querySelector('[data-dp-tab="bubbles"]');let globalList=null,defaultBox=null,ownBox=null,memberList=null,personBox=null,memberSearch=null,roomLabel=null,roomHint=null;
 if(tabRoot){tabRoot.innerHTML='<h3>현재 대화방 · 사용자별 설정</h3><strong class="dp-room-label"></strong><label class="wide">멤버 검색 <input name="memberSearch" class="dp-member-search" type="text" placeholder="이름 검색"></label><select name="memberList" class="dp-members" size="5" aria-label="말풍선을 꾸밀 대화방 멤버"></select><p class="note dp-room-hint"></p><div class="dp-person-editor"></div><details><summary>전체 대화방 · 상대방 기본 말풍선</summary><h3>상대방 기본 말풍선</h3><p class="note">모든 방의 상대방 메시지에만 적용합니다. 내 말풍선은 변경하지 않습니다. 방별 사용자 설정이 우선합니다.</p><div class="dp-default-editor"></div></details><details><summary>전체 대화방 · 내 말풍선</summary><p class="note">내가 보낸 메시지에만 적용합니다. 방별로 나를 선택해 저장한 설정이 있으면 그 설정이 우선합니다.</p><div class="dp-own-editor"></div></details><h3>저장된 사용자 설정</h3><p class="note">이름 · 테스트 말풍선 · 대화방별 설정</p><div class="dp-all-settings list"></div>';const style=node('style');style.textContent=doorayRoomSettingsCSS(uiCSS);tabRoot.prepend(style);globalList=tabRoot.querySelector('.dp-all-settings');defaultBox=tabRoot.querySelector('.dp-default-editor');ownBox=tabRoot.querySelector('.dp-own-editor');memberList=tabRoot.querySelector('.dp-members');personBox=tabRoot.querySelector('.dp-person-editor');memberSearch=tabRoot.querySelector('.dp-member-search');roomLabel=tabRoot.querySelector('.dp-room-label');roomHint=tabRoot.querySelector('.dp-room-hint');memberList.onchange=renderPersonEditor;memberSearch.oninput=()=>{lastMembers='';refreshPanel()};}
 function renderDefaults(){
  for(const [scope,box,own]of [['defaults',defaultBox,false],['ownDefaults',ownBox,true]]){
   if(!box)continue;box.replaceChildren();const t=theme(own?actions?.stores.userStore.id:undefined);
   editor(box,doorayRoomProfile(config[scope],t),s=>{const ok=save({...config,[scope]:doorayRoomSaveProfile(config[scope],t,s)});if(ok)renderPersonEditor();return ok},{defaults:true,own,onReset:()=>{if(save({...config,[scope]:doorayRoomResetProfile(config[scope],t.mode)})){renderDefaults();renderPersonEditor()}}});
  }
 }

 function tick(){if(disposed)return;try{actions=discover()||actions;if(!actions)return;const user=String(actions.stores.userStore.id||'');if(!/^\d+$/.test(user))return;const nextKey='dooray-plus.rooms.v1.'+user;if(key!==nextKey){socket?.removeEventListener('message',onMessage);socket=null;key=nextKey;try{config=doorayRoomConfig(JSON.parse(localStorage.getItem(key)||'{}'))}catch{config=doorayRoomConfig({})}settingsRevision++;renderDefaults();lastList='';lastMembers='';}const nextRoom=String(actions.stores.mainDetailUiState.currentChannelId||'');if(nextRoom!==roomId&&memberSearch)memberSearch.value='';roomId=nextRoom;const stamp=JSON.stringify(theme());if(stamp!==themeStamp){themeStamp=stamp;lastMembers='';lastList='';renderDefaults();}hookLocalMute();attachSocket();applyBubbles();updateMemberButtons();markBells();refreshPanel();refreshList();}catch(e){console.warn('Dooray Plus room UI:',e.message)}}
 const storage=e=>{if(e.key!==key)return;try{config=doorayRoomConfig(JSON.parse(e.newValue||'{}'));settingsRevision++;lastMembers='';renderDefaults();tick()}catch{}};window.addEventListener('storage',storage);
 const observer=new MutationObserver(()=>{if(!scheduled){scheduled=true;setTimeout(()=>{scheduled=false;tick()},160)}});observer.observe(document.querySelector('#root')||document.body,{subtree:true,childList:true});timer=setInterval(tick,1500);tick();
 return {open(){tick();refreshPanel()},refresh(){tick()},dispose(){disposed=true;clearInterval(timer);observer.disconnect();socket?.removeEventListener('message',onMessage);window.removeEventListener('storage',storage);document.removeEventListener('click',bellClick,true);closeMuteDialog();if(noticeHook&&noticeHook.handler.showNotification===noticeHook.wrapped)noticeHook.handler.showNotification=noticeHook.original;for(const [button,old]of bellMarks){button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;}for(const [el,r]of changed)restore(el,r);for(const [text,value]of changedTexts)restoreText(text,value);for(const [row,r]of rows){r.button.remove();row.style.position=r.position;row.style.paddingRight=r.padding}css.remove()},diagnostics(){return {roomReady:!!room(),styled:changed.size,memberButtons:rows.size,socketConnected:socket?.readyState===1,configured:entries().length}}};
}
function installDooraySettingsTabs(shadow){
 const scroll=shadow.querySelector('.scroll'),items=[...scroll.children],nav=document.createElement('div');nav.className='dp-tabs';nav.setAttribute('role','tablist');nav.setAttribute('aria-label','설정 분류');const style=document.createElement('style');style.textContent='.dp-tabs{display:flex;gap:4px;padding:10px 12px;border-bottom:1px solid #465269;flex-wrap:wrap}.dp-tabs button{flex:1;padding:7px 8px;font-size:12px}.dp-tabs [aria-selected="true"]{background:#3268b9;color:white}.dp-tab{padding-top:8px}.dp-tab h3{font-size:13px;margin:10px 0}.dp-tab[hidden]{display:none!important}';shadow.append(style);scroll.before(nav);const sections={};
 for(const[id,label]of [['basic','기본'],['detail','디테일'],['bubbles','말풍선'],['downloads','다운로드'],['manage','관리']]){const section=document.createElement('section');section.className='dp-tab';section.dataset.dpTab=id;section.id='dp-tab-'+id;section.setAttribute('role','tabpanel');section.hidden=id!=='basic';sections[id]=section;scroll.append(section);const button=document.createElement('button');button.type='button';button.textContent=label;button.id='dp-tab-button-'+id;button.setAttribute('role','tab');button.setAttribute('aria-controls',section.id);section.setAttribute('aria-labelledby',button.id);button.setAttribute('aria-selected',String(id==='basic'));button.tabIndex=id==='basic'?0:-1;button.onclick=()=>{for(const child of nav.children){child.setAttribute('aria-selected',String(child===button));child.tabIndex=child===button?0:-1}for(const[key,p]of Object.entries(sections))p.hidden=key!==id;scroll.scrollTop=0};nav.append(button);}
 nav.addEventListener('keydown',e=>{const buttons=[...nav.children];const index=buttons.indexOf(document.activeElement===shadow.host?shadow.activeElement:document.activeElement);if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const n=e.key==='Home'?0:e.key==='End'?buttons.length-1:(index+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[n].click();buttons[n].focus()});
 for(const el of items){let id='basic';if(el.classList.contains('mode')||el.id==='advanced')id='detail';else if(el.querySelector('#toastSeconds'))id='downloads';else if(el.querySelector('#export,#repairEmoticons,#checkUpdate')||el.textContent.includes('모든 문제에 대한 책임'))id='manage';sections[id].append(el);}return sections;
}

// Personal Drive UI. Credentials and network requests belong to the local helper.
function installDoorayDrivePanel({document=globalThis.document,rpc,downloads}={}){
  const win=document.defaultView||globalThis,MiB=1024*1024,chunkLimit=512*1024,queueLimit=20,historyLimit=100,transferLimit=1024*MiB;
  const connectionLifetime=2*60*60*1000;
  if(typeof rpc!=='function')throw Error('Drive RPC is required');
  const host=document.createElement('div');host.id='dooray-theme-drive';host.setAttribute('data-dp-extension','drive');
  const shadow=host.attachShadow({mode:'open'});
  shadow.innerHTML=`<style>
  :host{display:block;position:relative;width:48px;height:56px;flex:0 0 56px;font:12px/1.5 'Malgun Gothic',sans-serif;color:var(--dt-text,#202733)}*{box-sizing:border-box}[hidden]{display:none!important}button,select,input{font:inherit;color:inherit}button{cursor:pointer;border:1px solid var(--dt-border,#d0d6df);border-radius:6px;background:var(--dt-surface,#f4f6f9);padding:5px 9px}button:hover{background:var(--dt-hover,#e9eef5)}button:disabled{opacity:.45;cursor:default}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:2px}a{color:var(--dt-accent,#1769bb)}#toggle{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;width:44px;height:52px;margin:2px;padding:2px;border:0;background:transparent;font-size:10px}#toggle svg{width:23px;height:23px}#toggle[aria-expanded=true]{background:var(--dt-selection,#e5f1ff)}
  #panel{position:fixed;z-index:5061;right:60px;top:12px;display:flex;flex-direction:column;width:590px;max-width:calc(100vw - 72px);max-height:calc(100vh - 24px);overflow:hidden;border:1px solid var(--dt-border,#cbd2da);border-radius:12px;background:var(--dt-bg,#fff);box-shadow:0 14px 45px #0004}.head{display:flex;align-items:center;gap:9px;padding:14px 16px 9px}.head strong{font-size:16px;flex:1}.chip{font-size:10px;border:1px solid var(--dt-border,#cbd2da);border-radius:20px;padding:2px 7px;color:var(--dt-muted,#657080)}.icon{width:28px;height:28px;padding:0;font-size:18px;flex:none}.help{padding:0 16px 10px;margin:0;color:var(--dt-muted,#657080);font-size:11px}.help a{white-space:nowrap}.toolbar{display:flex;gap:6px;align-items:center;padding:8px 16px;border-block:1px solid var(--dt-border,#d0d6df);background:var(--dt-surface,#f4f6f9)}select{min-width:0;flex:1;border:1px solid var(--dt-border,#cbd2da);border-radius:6px;background:var(--dt-bg,#fff);padding:6px}.body{min-height:0;overflow:auto;overscroll-behavior:contain}.crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:10px 16px}.crumbs button{border:0;background:transparent;padding:2px 5px;max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.crumbs span{color:var(--dt-muted,#657080)}.list{min-height:80px;max-height:350px;overflow:auto;padding:0 10px}.empty{margin:15px 6px;color:var(--dt-muted,#657080)}.file{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;padding:9px 6px;border-bottom:1px solid var(--dt-border,#e1e5eb)}.name{display:block;min-width:0;max-width:100%;overflow-wrap:anywhere;text-align:left;border:0;background:transparent;padding:0;color:var(--dt-text,#202733)}.name .glyph{margin-right:7px;color:var(--dt-accent,#278ac2)}.metadata{font-size:10px;color:var(--dt-muted,#657080);margin-top:2px}.actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}.actions button{padding:4px 7px;font-size:11px}.pager{display:flex;justify-content:center;align-items:center;gap:12px;padding:9px 16px}.pager span{color:var(--dt-muted,#657080);font-size:11px}
  .upload{margin:4px 16px 12px;border:1px dashed var(--dt-border,#9aa8ba);border-radius:8px;padding:12px;text-align:center;background:var(--dt-surface,#f4f6f9)}.upload[data-drag]{border-color:var(--dt-accent,#278ac2);background:var(--dt-selection,#e5f1ff)}.upload p{margin:0 0 7px;color:var(--dt-muted,#657080);font-size:11px}.upload input{max-width:100%}.queue{padding:0 16px 12px}.queue-head{display:flex;align-items:center;gap:6px;margin-bottom:6px}.queue-head strong{flex:1;font-size:12px}.job{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;border-top:1px solid var(--dt-border,#d0d6df);padding:7px 0}.job-name{overflow-wrap:anywhere}.job small{display:block;color:var(--dt-muted,#657080)}progress{display:block;width:100%;height:5px;margin-top:5px;accent-color:var(--dt-accent,#278ac2)}
  .subpanel{margin:0 16px 12px;padding:10px;border:1px solid var(--dt-border,#cbd2da);border-radius:8px;background:var(--dt-surface,#f4f6f9)}.subhead{display:flex;align-items:center;gap:6px;margin-bottom:7px}.subhead strong{flex:1;min-width:0;overflow-wrap:anywhere}.preview-content img,.preview-content video{display:block;max-width:100%;max-height:350px;margin:auto}.preview-content video{width:100%}.preview-content iframe{display:block;width:100%;height:350px;border:0;background:#fff}.preview-content pre{margin:0;max-height:350px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 monospace}.subpanel p{margin:6px 0;font-size:11px;color:var(--dt-muted,#657080)}#shareUrl{width:100%;min-width:0;padding:7px;border:1px solid var(--dt-border,#cbd2da);border-radius:5px;background:var(--dt-bg,#fff)}.confirm{border:1px solid var(--dt-accent,#278ac2)}.confirm .actions{margin-top:10px}.primary{background:var(--dt-selection,#e5f1ff);border-color:var(--dt-accent,#278ac2)}.status{padding:9px 16px;border-top:1px solid var(--dt-border,#cbd2da);font-size:11px;color:var(--dt-muted,#657080);min-height:35px;overflow-wrap:anywhere}.status[data-error]{color:var(--dt-accent,#a93131)}
  @media(max-width:600px){#panel{right:8px;top:8px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px)}.file{grid-template-columns:minmax(0,1fr)}.file .actions{justify-content:flex-start}.toolbar{flex-wrap:wrap}}
  #panel[data-checking-account] :is(.toolbar,.body,.status){visibility:hidden}
  </style><button id="toggle" type="button" aria-label="두레이 드라이브" aria-expanded="false" aria-controls="panel" title="두레이 드라이브"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 6.5h7l2 2h9v11H3z"/><path d="M3 8.5V4.5h7l2 2h7v2"/><path d="M8 14h8m-4-3v6"/></svg><span>드라이브</span></button>
  <section id="panel" aria-label="두레이 드라이브" hidden><div class="head"><strong>드라이브</strong><span id="connection" class="chip">연결 확인 전</span><button id="close" class="icon" type="button" aria-label="드라이브 닫기">×</button></div><p class="help">API 키 입력은 별도의 Windows 창에서 진행합니다. <a id="issueKey" href="https://gravity.dooray.com/setting/api/token" target="_blank" rel="noopener noreferrer">API 키 발급</a></p><div class="toolbar"><button id="credentials" type="button">키 등록 / 변경</button><button id="forget" type="button" disabled>키 삭제</button><select id="drives" aria-label="드라이브 선택" disabled><option value="">드라이브를 선택하세요</option></select><button id="moreDrives" type="button" hidden>더 보기</button><button id="refresh" type="button" aria-label="드라이브 새로고침">↻</button></div><div class="body"><nav id="crumbs" class="crumbs" aria-label="폴더 이동 경로"></nav><div id="files" class="list" aria-label="폴더와 파일 목록"></div><div class="pager"><span id="fileCount"></span><button id="moreFiles" type="button" hidden>더 불러오기</button></div><section id="confirm" class="subpanel confirm" role="alertdialog" aria-label="작업 확인" hidden><strong id="confirmTitle"></strong><p id="confirmText"></p><div class="actions"><button id="confirmCancel" type="button">취소</button><button id="confirmAccept" class="primary" type="button">확인</button></div></section><section id="share" class="subpanel" aria-label="공유 링크" hidden><div class="subhead"><strong id="shareName">공유 링크</strong><button id="shareClose" class="icon" type="button" aria-label="공유 링크 닫기">×</button></div><input id="shareUrl" type="text" readonly aria-label="공유 주소"><div class="actions"><button id="copy" type="button">링크 복사</button></div></section><section id="preview" class="subpanel" aria-label="파일 미리보기" hidden><div class="subhead"><strong id="previewName"></strong><button id="previewClose" class="icon" type="button" aria-label="미리보기 닫기">×</button></div><p id="previewNote"></p><div id="previewContent" class="preview-content"></div><div class="actions"><button id="previewDownload" type="button">다운로드</button></div></section><div id="drop" class="upload" aria-label="파일 업로드 영역"><p>현재 폴더에 올릴 파일을 놓거나 선택하세요. 최대 20개를 대기열에 담을 수 있습니다.</p><input id="picker" type="file" multiple hidden><button id="choose" type="button">파일 선택</button></div><section id="queue" class="queue" aria-label="파일 전송 대기열" hidden><div class="queue-head"><strong>전송 대기열 <span id="queueCount"></span></strong><button id="clearQueue" type="button">완료 항목 정리</button><button id="start" class="primary" type="button">업로드 시작</button></div><div id="jobs"></div></section></div><div id="status" class="status" role="status" aria-live="polite">API 키를 등록하면 드라이브를 볼 수 있습니다.</div></section>`;
  const $=id=>shadow.getElementById(id),files=new Map(),jobs=new Map(),queue=[];
  const shareInfo=document.createElement('p');shareInfo.id='shareInfo';$('shareUrl').after(shareInfo);
  const shareChoices=document.createElement('select');
  shareChoices.id='shareChoices';shareChoices.hidden=true;
  shareChoices.setAttribute('aria-label','기존 공유 링크 선택');
  shareChoices.style.cssText='width:100%;margin-bottom:6px';
  $('shareUrl').before(shareChoices);
  const shareNotice=document.createElement('p');
  shareNotice.id='shareNotice';
  shareInfo.after(shareNotice);
  const shareSettings=document.createElement('div');shareSettings.className='share-settings';shareSettings.innerHTML='<p id="shareKind">기존 공유 링크</p><strong>새 링크 설정</strong><div class="share-fields"><label for="shareScope">공개 범위<select id="shareScope"><option value="member">조직 내 구성원</option><option value="memberAndGuest">조직 내 구성원 및 손님</option><option value="memberAndGuestAndExternal">링크가 있는 누구나</option></select></label><label for="shareExpiry">만료 일시<input id="shareExpiry" type="datetime-local" required step="60"></label></div><p id="shareAccess" class="share-access"></p><p>만료 일시는 이 컴퓨터의 시간을 기준으로 표시합니다.</p><p id="shareError" role="status"></p><div class="actions"><button id="shareCreate" type="button" class="primary">새 링크 생성</button></div><p><a id="advancedShare" target="_blank" rel="noopener noreferrer" hidden>두레이에서 고급 공유</a></p><p>선택한 부서·구성원과 비밀번호는 두레이 드라이브의 공유하기에서 설정할 수 있습니다.</p>';$('share').append(shareSettings);$('shareChoices').before($('shareKind'));
  const shareStyle=document.createElement('style');shareStyle.textContent='.share-settings{border-top:1px solid var(--dt-border,#cbd2da);margin-top:10px;padding-top:10px}.share-fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-top:7px}.share-fields label{min-width:0;font-size:11px}.share-fields select,.share-fields input{display:block;width:100%;min-width:0;margin-top:4px;padding:6px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:5px}.share-access[data-public]{padding:8px;border:1px solid #bb8934;border-radius:5px;background:#bb89341a;color:inherit;font-weight:600}#shareError{color:var(--dt-accent,#a93131)}';shadow.append(shareStyle);
  try{const origin=win.location.origin;if(/^https:\/\/[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.(?:dooray|gov-dooray)\.com$/i.test(origin)){$('advancedShare').href=new win.URL('/drive/',origin).href;$('advancedShare').hidden=false;}}catch{}
  const uploadDisclosure=document.createElement('details'),uploadSummary=document.createElement('summary');uploadDisclosure.id='uploadDisclosure';uploadSummary.textContent='업로드';uploadSummary.style.cssText='margin:8px 16px;padding:7px 10px;cursor:pointer;border:1px solid var(--dt-border,#cbd2da);border-radius:6px';$('drop').before(uploadDisclosure);uploadDisclosure.append(uploadSummary,$('drop'));
  const downloadTools=document.createElement('section');downloadTools.id='downloadFolderTools';downloadTools.className='subpanel';downloadTools.setAttribute('aria-label','다운로드 저장 위치');downloadTools.innerHTML='<div class="subhead"><strong>다운로드 저장 위치</strong><button id="openDownloadFolder" type="button">폴더 열기</button><button id="downloadSettings" type="button" aria-expanded="false" aria-controls="downloadFolderSettings">설정</button></div><p id="downloadFolderPath"></p><div id="downloadFolderSettings" class="actions" hidden><button id="chooseDownloadFolder" type="button">저장 폴더 변경</button><button id="resetDownloadFolder" type="button">기본 다운로드 폴더</button></div><p id="downloadFolderStatus" role="status" aria-live="polite"></p>';
  uploadDisclosure.before(downloadTools);const transferStyle=document.createElement('style');transferStyle.textContent='#downloadFolderPath{overflow-wrap:anywhere}.job .history-remove{align-self:start;padding:1px 7px;font-size:17px;line-height:22px}';shadow.append(transferStyle);
  const folderTools=document.createElement('div');folderTools.className='folder-tools';folderTools.innerHTML='<button id="newFolder" type="button">＋ 새 폴더</button>';$('crumbs').after(folderTools);
  const fileViews=document.createElement('div');
  fileViews.className='file-views';
  fileViews.innerHTML='<label for="fileView">보기</label><select id="fileView"><option value="all">전체</option><option value="folders">폴더만</option><option value="files">파일만</option><option value="extensions">확장자별</option></select>';
  folderTools.prepend(fileViews);
  const folderActions=document.createElement('div');
  folderActions.className='actions';
  $('refresh').textContent='새로고침';
  $('refresh').title='현재 폴더 새로고침';
  folderActions.append($('refresh'),$('newFolder'));
  folderTools.append(folderActions);
  const nameEditor=document.createElement('section');nameEditor.id='nameEditor';nameEditor.className='subpanel';nameEditor.hidden=true;nameEditor.setAttribute('role','dialog');nameEditor.setAttribute('aria-label','항목 이름 설정');nameEditor.innerHTML='<div class="subhead"><strong id="nameTitle"></strong></div><p id="nameLocation"></p><label for="entryName">이름</label><input id="entryName" type="text" maxlength="255" autocomplete="off"><p id="nameError" role="status"></p><div class="actions"><button id="nameCancel" type="button">취소</button><button id="nameSave" class="primary" type="button">저장</button></div>';
  const destinationPicker=document.createElement('section');destinationPicker.id='destinationPicker';destinationPicker.className='subpanel';destinationPicker.hidden=true;destinationPicker.setAttribute('role','dialog');destinationPicker.setAttribute('aria-label','파일 이동 위치');destinationPicker.innerHTML='<div class="subhead"><strong id="moveTitle">파일 이동</strong></div><p id="moveSource"></p><nav id="moveCrumbs" class="crumbs" aria-label="이동할 폴더 경로"></nav><div id="moveFolders" class="list" aria-label="이동할 폴더 목록"></div><div class="pager"><button id="movePrevious" type="button">이전</button><span id="movePage"></span><button id="moveNext" type="button">다음</button></div><p id="moveNote" role="status"></p><div class="actions"><button id="moveCancel" type="button">취소</button><button id="moveSave" class="primary" type="button">여기로 이동</button></div>';$('confirm').before(nameEditor,destinationPicker);
  const managementStyle=document.createElement('style');
  managementStyle.textContent=`
    #files{min-height:120px;max-height:min(480px,60vh)}
    #files .actions{align-items:flex-start}
    .folder-tools{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;padding:0 16px 8px}
    .file-views{display:flex;align-items:center;gap:6px}
    .extension-group{padding:5px 0;border-bottom:1px solid var(--dt-border,#cbd2da)}
    .extension-group>summary{cursor:pointer;padding:5px 6px;font-weight:600;overflow-wrap:anywhere}
    .item-menu{max-width:100%}
    .item-menu summary{width:fit-content;margin-left:auto;list-style:none;cursor:pointer;padding:3px 9px;border:1px solid var(--dt-border,#cbd2da);border-radius:6px}
    .item-menu summary::-webkit-details-marker{display:none}
    .item-menu .menu{display:grid;gap:3px;min-width:112px;margin-top:4px;padding:5px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:6px}
    .item-menu .menu button{text-align:left;white-space:nowrap}
    .item-menu .trash{color:var(--dt-accent,#a93131)}
    #entryName{display:block;width:100%;margin-top:5px;padding:7px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#cbd2da);border-radius:5px}
    #nameError{color:var(--dt-accent,#a93131)}
    #moveCrumbs{padding:3px 0 8px}
    #moveFolders{max-height:230px;padding:0}
    #moveFolders button{display:block;width:100%;margin-bottom:4px;text-align:left;overflow-wrap:anywhere}
  `;
  shadow.append(managementStyle);
  let disposed=false,anchor=null,generation=0,listSerial=0,previewSerial=0,shareSerial=0,initialized=false,configured=false,accountTag=null,checking=false,verifiedAt=null,readFlights=0,drives=[],drive=null,drivePage=0,driveHasNext=false,crumbs=[],listBusy=false,keyBusy=false,pollTimer=0,pollBusy=false,uploadBusy=false,currentUpload=null,activePreview=null,blobURL=null,previewFile=null,confirmResolve=null,writeBusy=false,pendingWrite=null,nameDraft=null,moveDraft=null,moveSerial=0,shareState=null;
  const folderListings=new Map();
  const extensionGroups=new Map();
  const fileTypes=new Map([['all',null],['folders','folder'],['files','file'],['extensions','file']]);
  let activeListing=null,fileView='all',renderedView=null,lastFileScroll=0;
  let folderBusy=false,folderSerial=0;
  const text=value=>typeof value==='string'?value:typeof value==='number'?String(value):'';
  const errorText=error=>(typeof error?.message==='string'?error.message:'요청을 처리하지 못했습니다.').replace(/[\x00-\x1f\x7f]/g,' ').slice(0,400);
  const id=value=>{const valueText=text(value);return valueText&&valueText.length<=128?valueText:null};
  const size=value=>Number.isSafeInteger(value)&&value>=0?value:0;
  const formatSize=value=>{value=size(value);return value>=1024**3?(value/1024**3).toFixed(1)+' GB':value>=MiB?(value/MiB).toFixed(1)+' MB':value>=1024?Math.ceil(value/1024)+' KB':value+' B'};
  const setStatus=(message,error=false)=>{if(disposed)return;$('status').textContent=message;$('status').toggleAttribute('data-error',error)};
  const validTag=value=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\x00-\x20\x7f]/.test(value);
  const invoke=(op,args={})=>{const tag=args.accountTag||accountTag;if(disposed)return Promise.reject(Error('드라이브 창이 종료되었습니다.'));if(op!=='status'&&(!validTag(tag)||tag!==accountTag))return Promise.reject(Error('계정 연결을 다시 확인해 주세요.'));return Promise.resolve().then(()=>{if(disposed)throw Error('드라이브 창이 종료되었습니다.');if(op!=='status'&&tag!==accountTag)throw Error('계정 연결이 변경되었습니다.');return rpc(op,op==='status'?args:{...args,accountTag:tag})})};
  const abandon=(jobId,tag=accountTag)=>{if(jobId&&validTag(tag))try{Promise.resolve(rpc('cancel',{id:jobId,accountTag:tag})).catch(()=>{})}catch{}};
  const parentId=()=>{const value=crumbs[crumbs.length-1]?.id;return value&&value!=='root'?value:null};
  const locationArgs=()=>({driveId:drive?.id,...(parentId()?{parentId:parentId()}:{})});
  const transferActive=()=>uploadBusy||[...jobs.values()].some(entry=>entry.state==='running'||entry.state==='starting');
  function controls(){if(disposed)return;const busy=checking||keyBusy||writeBusy;$('connection').textContent=checking?'연결 확인 중':configured?'키 설정됨':'키 미등록';$('credentials').disabled=busy||!accountTag||transferActive();$('forget').disabled=!configured||busy||!accountTag||transferActive();$('drives').disabled=!configured||busy||listBusy||!drives.length;$('refresh').disabled=busy||listBusy;$('moreDrives').hidden=!driveHasNext;$('moreDrives').disabled=busy||listBusy;$('choose').disabled=!configured||busy||!drive;$('newFolder').disabled=!configured||!drive||busy||listBusy;$('start').disabled=busy||uploadBusy||!queue.some(entry=>entry.state==='queued');fileControls();shareControls();}
  function empty(message){$('files').replaceChildren();const node=document.createElement('p');node.className='empty';node.textContent=message;$('files').append(node);}
  function closeConfirmation(value=false){const resolve=confirmResolve;confirmResolve=null;$('confirm').hidden=true;resolve?.(value);}
  function confirmAction(title,message,accept){closeConfirmation();$('confirmTitle').textContent=title;$('confirmText').textContent=message;$('confirmAccept').textContent=accept;$('confirm').hidden=false;$('confirm').scrollIntoView?.({block:'nearest'});$('confirmCancel').focus({preventScroll:true});return new Promise(resolve=>{confirmResolve=resolve})}
  function closeShare(){
    shareSerial++;
    shareState=null;
    $('share').hidden=true;
    $('shareChoices').replaceChildren();
    $('shareChoices').hidden=true;
    $('shareUrl').value='';
    $('shareUrl').hidden=true;
    for(const key of ['shareInfo','shareNotice','shareError'])$(key).textContent='';
    $('shareName').textContent='공유 링크';
    $('shareScope').value='member';
    $('shareExpiry').value='';
    $('copy').disabled=true;
    $('copy').hidden=true;
  }
  function closePreview(){previewSerial++;if(activePreview){abandon(activePreview.id,activePreview.accountTag);activePreview=null}const media=$('previewContent').querySelector('video');if(media){try{media.pause()}catch{}media.removeAttribute('src');try{media.load()}catch{}}$('previewContent').replaceChildren();if(blobURL){win.URL.revokeObjectURL(blobURL);blobURL=null}previewFile=null;$('preview').hidden=true;}
  function navigation(){closeConfirmation();closePreview();closeShare();closeManagement();}
  function resetSession(nextTag){generation++;listSerial++;verifiedAt=null;pendingWrite=null;writeBusy=false;closeManagement(true);navigation();for(const [jobId,entry]of jobs){if(entry.id&&['running','starting'].includes(entry.state))abandon(entry.id,entry.accountTag);entry.state='cancelled';releaseFile(entry)}for(const entry of queue){entry.state='cancelled';releaseFile(entry)}queue.splice(0);jobs.clear();files.clear();clearListings();currentUpload=null;uploadBusy=false;if(pollTimer)win.clearTimeout(pollTimer);pollTimer=0;drives=[];drive=null;crumbs=[];driveHasNext=false;listBusy=false;accountTag=nextTag;$('files').replaceChildren();renderQueue();renderDrives();renderCrumbs();}
  function renderCrumbs(){$('crumbs').replaceChildren();crumbs.forEach((crumb,index)=>{if(index){const separator=document.createElement('span');separator.textContent='›';separator.setAttribute('aria-hidden','true');$('crumbs').append(separator)}const button=document.createElement('button');button.type='button';button.textContent=crumb.name;button.title=crumb.name;button.disabled=listBusy||writeBusy||index===crumbs.length-1;button.onclick=()=>{if(writeBusy)return;navigation();crumbs=crumbs.slice(0,index+1);loadFiles()};$('crumbs').append(button)})}
  function renderDrives(){const select=$('drives');select.replaceChildren();if(!drives.length){const option=document.createElement('option');option.value='';option.textContent='드라이브가 없습니다.';select.append(option)}for(const entry of drives){const option=document.createElement('option');option.value=entry.id;option.textContent=entry.name;select.append(option)}select.value=drive?.id||'';controls();}
  async function loadDrives(more=false) {
    const stamp = ++listSerial, epoch = generation;
    const current = () => !disposed && epoch === generation && stamp === listSerial;
    let accepted = false;
    listBusy = true;
    controls();
    try {
      const response = await invoke('drives', {page:more ? drivePage + 1 : 0});
      if (!current()) return false;
      if (!Array.isArray(response?.items)) throw Error('드라이브 목록 응답을 확인하지 못했습니다.');
      const fresh = response.items.filter(entry=>id(entry?.id)).slice(0,2000).map(entry=>({id:id(entry.id),name:text(entry.name).slice(0,500)||'드라이브',rootId:entry.rootId==='root'?null:id(entry.rootId)}));
      const known = new Map((more ? drives : []).map(entry => [entry.id,entry]));
      for (const entry of fresh) known.set(entry.id, entry);
      drives = [...known.values()].slice(0,2000);
      drivePage = more ? drivePage + 1 : 0;
      driveHasNext = response.hasNext === true && drives.length < 2000;
      const selected = drive && drives.find(entry => entry.id === drive.id);
      if (!selected) {
        drive = drives[0] || null;
        crumbs = drive ? [{id:drive.rootId,name:drive.name}] : [];
      } else drive = selected;
      accepted = true;
      renderDrives();
    } catch (error) {
      if (current()) {
        verifiedAt = null;
        clearListings();
        setStatus(errorText(error), true);
        empty('드라이브 목록을 불러오지 못했습니다.');
      }
    } finally {
      if (current()) {
        listBusy = false;
        controls();
        renderCrumbs();
      }
    }
    if (!current() || !accepted) return false;
    if (!more && drive) {
      invalidateListings(drive.id,parentId());
      return loadFiles();
    }
    if (!drive) {
      clearListings();
      empty('사용 가능한 드라이브가 없습니다.');
      setStatus('사용 가능한 드라이브가 없습니다.');
      controls();
    }
    return true;
  }
  async function connect(reuse=false) {
    if (disposed || checking || keyBusy || writeBusy) return;
    const age = verifiedAt === null ? Infinity : win.Date.now() - verifiedAt;
    const cachedTag = reuse && age >= 0 && age < connectionLifetime ? accountTag : null;
    const panel = $('panel');
    const epoch = generation;
    checking = true;
    if (accountTag) panel.setAttribute('data-checking-account', '');
    controls();
    if (!cachedTag) setStatus('연결 상태를 확인하는 중…');
    try {
      const response = await invoke('status', cachedTag ? {reuseAccountTag:cachedTag} : {});
      if (disposed || epoch !== generation) return;
      if (cachedTag && response?.reused === true && response.accountTag === cachedTag) return;
      if (!validTag(response?.accountTag) || typeof response.configured !== 'boolean') {
        throw Error('현재 두레이 계정 연결을 확인하지 못했습니다.');
      }
      verifiedAt = null;
      if (accountTag !== response.accountTag || configured && !response.configured) resetSession(response.accountTag);
      configured = response.configured;
      initialized = true;
      if (configured) {
        setStatus('드라이브 목록을 불러오는 중…');
        if (await loadDrives() && !disposed) verifiedAt = win.Date.now();
      } else {
        empty('API 키를 등록해 주세요.');
        setStatus('API 키 발급 후 키 등록 / 변경을 눌러 주세요.');
        verifiedAt = win.Date.now();
      }
    } catch (error) {
      if (!disposed) {
        resetSession(null);
        configured = false;
        initialized = false;
        setStatus(errorText(error), true);
        empty('연결 상태를 확인하지 못했습니다. 새로고침해 주세요.');
      }
    } finally {
      if (!disposed) {
        panel.removeAttribute('data-checking-account');
        checking = false;
        controls();
        runUpload();
      }
    }
  }
  function revealItemMenu(items){
    const list=$('files');
    for(const scroller of [list,list.closest('.body')]){
      const visibleHeight=scroller.clientHeight;
      if(!visibleHeight)continue;
      const top=scroller.getBoundingClientRect().top+scroller.clientTop;
      const bottom=top+visibleHeight;
      const bounds=items.getBoundingClientRect();
      if(bounds.top<top||bounds.height>visibleHeight)scroller.scrollTop+=bounds.top-top;
      else if(bounds.bottom>bottom)scroller.scrollTop+=bounds.bottom-bottom;
    }
    lastFileScroll=list.scrollTop;
  }
  function fileRow(entry){
    const row=document.createElement('div');row.className='file';
    const left=document.createElement('div'),name=document.createElement('button'),glyph=document.createElement('span');name.type='button';name.className='name';glyph.className='glyph';glyph.textContent=entry.isFolder?'▱':'▤';glyph.setAttribute('aria-hidden','true');name.append(glyph,document.createTextNode(entry.name));name.title=entry.name;
    name.onclick=()=>{if(checking||keyBusy||listBusy||writeBusy)return;if(entry.isFolder){navigation();crumbs.push({id:entry.id,name:entry.name});loadFiles()}else showPreview(entry)};
    left.append(name);const metadata=document.createElement('div');metadata.className='metadata';const values=[];if(!entry.isFolder&&Number.isSafeInteger(entry.size))values.push(formatSize(entry.size));if(entry.modifiedAt){const date=new Date(entry.modifiedAt);if(Number.isFinite(date.getTime()))values.push(date.toLocaleString())}metadata.textContent=values.join(' · ');left.append(metadata);row.append(left);
    const actions=document.createElement('div');actions.className='actions';
    if(!entry.isFolder)for(const [label,action]of [['미리보기',()=>showPreview(entry)],['다운로드',()=>download(entry)],['공유',()=>share(entry)]]){const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('aria-label',entry.name+' '+label);button.onclick=()=>{if(!checking&&!keyBusy&&!listBusy&&!writeBusy)action()};actions.append(button)}
    const menu=document.createElement('details'),summary=document.createElement('summary'),items=document.createElement('div');menu.className='item-menu';summary.textContent='⋯';summary.setAttribute('aria-label',entry.name+' 더보기');summary.setAttribute('aria-haspopup','menu');items.className='menu';items.setAttribute('role','menu');summary.addEventListener('click',()=>{for(const other of shadow.querySelectorAll('.item-menu[open]'))if(other!==menu)other.open=false});
    menu.addEventListener('toggle',()=>{if(menu.open&&menu.isConnected&&!$('panel').hidden)revealItemMenu(items)});
    const options=[['이름 변경',()=>openName('rename',entry)],...(!entry.isFolder?[['이동',()=>openMove(entry)]]:[]),['휴지통',()=>trash(entry)]];
    for(const [label,action]of options){const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('role','menuitem');button.setAttribute('aria-label',entry.name+' '+label);if(label==='휴지통')button.className='trash';button.onclick=()=>{menu.open=false;if(managementReady())action()};items.append(button)}menu.append(summary,items);actions.append(menu);row.append(actions);return row;
  }
  function clearListings(){
    folderListings.clear();
    extensionGroups.clear();
    activeListing=null;
    renderedView=null;
    lastFileScroll=0;
  }
  function invalidateListings(driveId,...parents){
    for(const [key,state] of folderListings){
      if(state.driveId!==driveId||parents.length&&!parents.includes(state.parentId))continue;
      folderListings.delete(key);
      if(state===activeListing)state.hasNext=false;
    }
  }
  function trimListings(){
    let itemCount=[...folderListings.values()].reduce((count,state)=>count+state.entries.length,0);
    for(const [key,state] of folderListings){
      if(folderListings.size<=12&&itemCount<=8000)break;
      if(state===activeListing)continue;
      folderListings.delete(key);
      itemCount-=state.entries.length;
    }
  }
  function fileControls(){
    const state=activeListing;
    const busy=checking||keyBusy||writeBusy||listBusy;
    $('fileView').disabled=!configured||!drive||busy;
    $('fileCount').textContent=state?.loadedAt!=null?state.entries.length+'개 불러옴':'';
    $('moreFiles').hidden=!state?.hasNext;
    $('moreFiles').disabled=busy||!!state?.pending;
    $('moreFiles').textContent=state?.pending?'불러오는 중…':state?.failed?'다시 불러오기':'더 불러오기';
  }
  function appendFileRows(entries){
    const list=$('files');
    if(!entries.length)return;
    list.querySelector('.empty')?.remove();
    for(const entry of entries){
      if(fileView!=='extensions'){
        list.append(fileRow(entry));
        continue;
      }
      const dot=entry.name.lastIndexOf('.');
      const extension=dot>0&&dot<entry.name.length-1?entry.name.slice(dot).toLowerCase():'확장자 없음';
      let group=extensionGroups.get(extension);
      if(!group){
        const section=document.createElement('details'),title=document.createElement('summary');
        section.className='extension-group';
        section.open=true;
        section.append(title);
        list.append(section);
        group={section,title,count:0};
        extensionGroups.set(extension,group);
      }
      group.section.append(fileRow(entry));
      group.title.textContent=extension+' · '+(++group.count)+'개';
    }
  }
  function showListing(state){
    const list=$('files');
    if(activeListing!==state||renderedView!==fileView){
      if(activeListing)activeListing.scrolls.set(renderedView,list.scrollTop);
      activeListing=state;
      renderedView=fileView;
      list.replaceChildren();
      extensionGroups.clear();
      appendFileRows(state.entries);
      list.scrollTop=state.scrolls.get(fileView)||0;
      lastFileScroll=list.scrollTop;
    }
    if(!state.entries.length){
      if(state.failed)empty('폴더 목록을 불러오지 못했습니다.');
      else if(state.loadedAt===null)empty('폴더를 불러오는 중…');
      else if(fileView==='folders')empty('이 위치에 폴더가 없습니다.');
      else if(fileView==='all')empty('이 폴더는 비어 있습니다.');
      else empty('이 위치에 파일이 없습니다.');
    }
    if(state.loadedAt!==null&&!state.failed)setStatus(state.entries.length+'개 항목 · '+(crumbs[crumbs.length-1]?.name||drive.name));
    fileControls();
  }
  function loadMoreFiles(state){
    if(!state||disposed||!state.hasNext)return Promise.resolve(false);
    if(state.pending)return state.pending;
    const epoch=generation;
    const current=()=>!disposed&&epoch===generation&&folderListings.get(state.key)===state;
    const initial=state.loadedAt===null;
    state.failed=false;
    if(initial&&activeListing===state){
      listBusy=true;
      setStatus('폴더를 불러오는 중…');
    }
    state.pending=(async()=>{
      try{
        const args={driveId:state.driveId,page:state.nextPage};
        if(state.parentId)args.parentId=state.parentId;
        if(state.type)args.type=state.type;
        const response=await invoke('files',args);
        if(!current())return false;
        if(!Array.isArray(response?.items))throw Error('폴더 목록 응답을 확인하지 못했습니다.');
        const fresh=[];
        for(const entry of response.items.slice(0,2000)){
          const fileId=id(entry?.id);
          if(!fileId||state.ids.has(fileId)||typeof entry.name!=='string')continue;
          state.ids.add(fileId);
          fresh.push({id:fileId,name:entry.name.slice(0,1000),isFolder:entry.isFolder===true,
            size:entry.size,modifiedAt:entry.modifiedAt});
        }
        state.entries.push(...fresh);
        if(initial)state.loadedAt=win.Date.now();
        state.nextPage++;
        state.hasNext=response.hasNext===true&&fresh.length>0&&state.nextPage<10000;
        if(activeListing===state){
          appendFileRows(fresh);
          showListing(state);
        }
        trimListings();
        return true;
      }catch(error){
        if(current()){
          state.failed=true;
          if(activeListing===state){
            if(initial)verifiedAt=null;
            showListing(state);
            setStatus(errorText(error),true);
          }
        }
        return false;
      }finally{
        state.pending=null;
        if(current()&&activeListing===state){
          if(initial)listBusy=false;
          controls();
          renderCrumbs();
        }
      }
    })();
    controls();
    return state.pending;
  }
  function loadFiles(){
    if(!drive||disposed)return Promise.resolve(false);
    const parent=parentId(),type=fileTypes.get(fileView);
    const key=JSON.stringify([drive.id,parent,type]);
    let state=folderListings.get(key);
    if(state?.loadedAt!=null){
      const age=win.Date.now()-state.loadedAt;
      if(age<0||age>=connectionLifetime)state=null;
    }
    if(!state)state={key,driveId:drive.id,parentId:parent,type,entries:[],ids:new Set(),scrolls:new Map(),nextPage:0,hasNext:true,loadedAt:null,pending:null,failed:false};
    folderListings.delete(key);
    folderListings.set(key,state);
    if(activeListing!==state)listBusy=false;
    showListing(state);
    trimListings();
    renderCrumbs();
    if(state.loadedAt!==null){controls();return Promise.resolve(true);}
    if(state.pending&&activeListing===state){listBusy=true;controls();}
    return loadMoreFiles(state);
  }
  function refreshFolder(){
    if(disposed||checking||keyBusy||writeBusy||listBusy)return;
    if(!configured||!drive||!validTag(accountTag)||verifiedAt===null)return connect();
    navigation();
    invalidateListings(drive.id,parentId());
    return loadFiles();
  }
  function managementReady(){return !disposed&&configured&&drive&&validTag(accountTag)&&!checking&&!keyBusy&&!listBusy&&!writeBusy;}
  function managementOwner(entry){return {epoch:generation,accountTag,driveId:drive.id,parentId:parentId(),view:fileView,root:crumbs.length===1,path:crumbs.map(crumb=>crumb.name).join(' / '),...(entry?{fileId:entry.id,name:entry.name,isFolder:entry.isFolder}:{})};}
  function ownsManagement(owner){return !disposed&&owner.epoch===generation&&owner.accountTag===accountTag&&owner.driveId===drive?.id&&owner.parentId===parentId()&&owner.view===fileView;}
  function closeManagement(force=false){if(writeBusy&&!force)return;nameDraft=null;moveDraft=null;moveSerial++;$('nameEditor').hidden=true;$('entryName').value='';$('nameError').textContent='';$('destinationPicker').hidden=true;$('moveFolders').replaceChildren();$('moveCrumbs').replaceChildren();for(const menu of shadow.querySelectorAll('.item-menu[open]'))menu.open=false;}
  function managementControls(){for(const key of ['entryName','nameSave','nameCancel','moveCancel'])$(key).disabled=writeBusy;const picker=moveDraft,root=picker?.crumbs.length===1,selected=picker?.crumbs[picker.crumbs.length-1]?.id??null,same=picker&&(picker.root&&root||!root&&selected===picker.parentId);$('moveSave').disabled=writeBusy||!picker||picker.busy||same;$('movePrevious').disabled=writeBusy||!picker||picker.busy||picker.page===0;$('moveNext').disabled=writeBusy||!picker||picker.busy||!picker.hasNext;}
  function openName(kind,entry){if(!managementReady())return;navigation();nameDraft={...managementOwner(entry),kind};$('nameTitle').textContent=kind==='create-folder'?'새 폴더':'이름 변경';$('nameLocation').textContent=nameDraft.path;$('entryName').value=entry?.name||'';$('nameSave').textContent=kind==='create-folder'?'폴더 만들기':'이름 변경';$('nameEditor').hidden=false;$('nameEditor').scrollIntoView?.({block:'nearest'});managementControls();$('entryName').focus({preventScroll:true});const end=entry&&!entry.isFolder&&entry.name.lastIndexOf('.')>0?entry.name.lastIndexOf('.'):entry?.name.length||0;$('entryName').setSelectionRange(0,end);}
  async function saveName(){const owner=nameDraft;if(!owner||!ownsManagement(owner)||!managementReady())return;const value=$('entryName').value;if(!value.trim()||value.length>255||/^[.]{1,2}$/.test(value)||/[\\/\x00-\x1f\x7f-\x9f]/.test(value)||[...value].some(char=>{const point=char.codePointAt(0);return point>=0xd800&&point<=0xdfff})){$('nameError').textContent='경로 구분자 없이 1~255자의 이름을 입력해 주세요.';return}if(owner.kind==='rename'&&value===owner.name){closeManagement();return}await writeManagement(owner,owner.kind,{driveId:owner.driveId,...(owner.kind==='create-folder'?(owner.parentId?{parentId:owner.parentId}:{}):{fileId:owner.fileId}),name:value});}
  async function writeManagement(owner,op,args){
    if(!ownsManagement(owner)||writeBusy||checking||keyBusy)return;
    const oldVerifiedAt=verifiedAt;verifiedAt=null;writeBusy=true;pendingWrite=owner;controls();renderCrumbs();managementControls();setStatus({rename:'이름을 변경하는 중…',move:'파일을 이동하는 중…',trash:'휴지통으로 이동하는 중…','create-folder':'폴더를 만드는 중…'}[op]);
    const parents=owner.isFolder?[]:op==='move'?[owner.parentId,args.destinationId]:[owner.parentId];
    try{
      const result=await invoke(op,{...args,accountTag:owner.accountTag});
      if(!ownsManagement(owner))return;
      if(op==='create-folder'?!id(result?.id):result!==true)throw Error('처리 결과를 확인하지 못했습니다. 새로고침 후 확인해 주세요.');
      closeManagement(true);
      invalidateListings(owner.driveId,...parents);
      const refreshed=await loadFiles();if(!ownsManagement(owner))return;
      if(refreshed){verifiedAt=oldVerifiedAt;setStatus({rename:'이름을 변경했습니다.',move:'파일을 이동했습니다.',trash:'휴지통으로 이동했습니다.','create-folder':'폴더를 만들었습니다.'}[op]);}
      else setStatus('변경은 적용했지만 목록을 새로 불러오지 못했습니다. 새로고침해 주세요.',true);
    }catch(error){if(ownsManagement(owner)){invalidateListings(owner.driveId,...parents);setStatus(errorText(error),true);if(nameDraft===owner)$('nameError').textContent=errorText(error);if(moveDraft===owner)$('moveNote').textContent=errorText(error);}}
    finally{if(pendingWrite===owner){pendingWrite=null;writeBusy=false;if(!disposed){controls();renderCrumbs();managementControls();runUpload();}}}
  }
  function openMove(entry){if(!managementReady()||entry.isFolder)return;navigation();moveDraft={...managementOwner(entry),crumbs:[{id:null,name:drive.name}],page:0,hasNext:false,busy:false};$('moveSource').textContent=entry.name+' · 현재 위치: '+moveDraft.path;$('moveNote').textContent='같은 드라이브 안에서 이동할 폴더를 연 뒤 여기로 이동을 눌러 주세요.';$('destinationPicker').hidden=false;$('destinationPicker').scrollIntoView?.({block:'nearest'});loadMoveFolders();}
  async function loadMoveFolders(){
    const picker=moveDraft;if(!picker||!ownsManagement(picker)||writeBusy)return;const serial=++moveSerial;picker.busy=true;managementControls();$('moveFolders').textContent='폴더를 불러오는 중…';$('movePage').textContent=(picker.page+1)+'페이지';$('moveCrumbs').replaceChildren();
    picker.crumbs.forEach((crumb,index)=>{const button=document.createElement('button');button.type='button';button.textContent=crumb.name;button.disabled=index===picker.crumbs.length-1;button.onclick=()=>{if(moveDraft!==picker||writeBusy)return;picker.crumbs=picker.crumbs.slice(0,index+1);picker.page=0;loadMoveFolders()};$('moveCrumbs').append(button)});
    try{
      const destination=picker.crumbs[picker.crumbs.length-1]?.id,response=await invoke('files',{driveId:picker.driveId,...(destination?{parentId:destination}:{}),page:picker.page,accountTag:picker.accountTag});
      if(moveDraft!==picker||serial!==moveSerial||!ownsManagement(picker))return;if(!Array.isArray(response?.items))throw Error('폴더 목록을 확인하지 못했습니다.');picker.hasNext=response.hasNext===true;$('moveFolders').replaceChildren();
      const folders=response.items.filter(entry=>entry?.isFolder===true&&id(entry.id)&&typeof entry.name==='string').slice(0,2000);
      for(const folder of folders){const button=document.createElement('button');button.type='button';button.textContent='▱ '+folder.name;button.onclick=()=>{if(moveDraft!==picker||writeBusy||picker.busy)return;picker.crumbs.push({id:id(folder.id),name:folder.name.slice(0,1000)});picker.page=0;loadMoveFolders()};$('moveFolders').append(button)}
      if(!folders.length)$('moveFolders').textContent=picker.hasNext?'이 페이지에는 폴더가 없습니다. 다음 페이지를 확인해 주세요.':'이 위치에는 하위 폴더가 없습니다.';
    }catch(error){if(moveDraft===picker&&serial===moveSerial&&ownsManagement(picker)){$('moveFolders').textContent='폴더 목록을 불러오지 못했습니다.';$('moveNote').textContent=errorText(error);picker.hasNext=false;}}
    finally{if(moveDraft===picker&&serial===moveSerial){picker.busy=false;managementControls();$('destinationPicker').scrollIntoView?.({block:'nearest'});}}
  }
  async function saveMove(){const picker=moveDraft;if(!picker||picker.busy||!ownsManagement(picker)||!managementReady())return;const root=picker.crumbs.length===1,destinationId=root?null:picker.crumbs[picker.crumbs.length-1].id;if(picker.root&&root||!root&&destinationId===picker.parentId)return;await writeManagement(picker,'move',{driveId:picker.driveId,fileId:picker.fileId,destinationId});}
  async function trash(entry){if(!managementReady())return;navigation();const owner=managementOwner(entry),accepted=await confirmAction('휴지통으로 이동할까요?',entry.name+(entry.isFolder?' 폴더와 그 안의 모든 항목을':' 파일을')+' 휴지통으로 이동합니다. 두레이 휴지통에서 복원할 수 있습니다.','휴지통으로 이동');if(!accepted||!ownsManagement(owner)||!managementReady())return;await writeManagement(owner,'trash',{driveId:owner.driveId,fileId:owner.fileId,confirmed:true});}
  function encode(bytes){let binary='';for(let offset=0;offset<bytes.length;offset+=32768)binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));return win.btoa(binary)}
  const readFile=async(key,offset,length)=>{const entry=files.get(key);if(disposed||typeof key!=='string'||!entry||entry.state!=='running'||entry.accountTag!==accountTag||!entry.file||readFlights>=2||!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset<0||length<0||length>chunkLimit||offset+length>entry.file.size)throw Error('허용되지 않은 파일 읽기 요청입니다.');readFlights++;try{const data=await entry.file.slice(offset,offset+length).arrayBuffer();if(data.byteLength!==length)throw Error('파일 읽기 크기가 올바르지 않습니다.');if(disposed||files.get(key)!==entry||entry.state!=='running'||entry.accountTag!==accountTag)throw Error('파일 전송이 취소되었습니다.');return encode(new Uint8Array(data));}finally{readFlights--}};
  win.__doorayDriveReadFile=readFile;
  function removeHistory(entry){if(disposed||!['done','failed','cancelled'].includes(entry.state)||currentUpload===entry)return;entry.historyRemoved=true;const index=queue.indexOf(entry);if(index>=0)queue.splice(index,1);for(const [key,value]of jobs)if(value===entry)jobs.delete(key);releaseFile(entry);renderQueue();}
  function renderQueue(){if(disposed)return;const all=[...queue,...[...jobs.values()].filter(entry=>entry.kind==='download')];$('queue').hidden=!all.length;$('queueCount').textContent=String(all.length);$('jobs').replaceChildren();for(const entry of all){const row=document.createElement('div');row.className='job';row.dataset.state=entry.state;row.dataset.kind=entry.kind;const info=document.createElement('div'),name=document.createElement('div'),note=document.createElement('small');name.className='job-name';name.textContent=(entry.kind==='download'?'↓ ':'↑ ')+entry.name;const labels={queued:'대기',starting:'준비 중',running:'전송 중',done:'완료',failed:'실패',cancelled:'취소됨'};note.textContent=(labels[entry.state]||'확인 중')+' · '+formatSize(entry.bytes||0)+' / '+formatSize(entry.total)+(entry.destination?' · '+entry.destination:'')+(entry.error?' · '+entry.error:'');info.append(name,note);if(entry.state==='running'||entry.state==='starting'){const progress=document.createElement('progress');progress.max=entry.total||1;if(entry.total)progress.value=Math.min(entry.total,entry.bytes||0);progress.setAttribute('aria-label',entry.name+' 전송 진행률');info.append(progress)}row.append(info);if(['queued','starting','running'].includes(entry.state)){const cancel=document.createElement('button');cancel.type='button';cancel.textContent='취소';cancel.onclick=()=>cancelEntry(entry);row.append(cancel)}else if(['done','failed','cancelled'].includes(entry.state)&&currentUpload!==entry){const remove=document.createElement('button');remove.type='button';remove.className='history-remove';remove.textContent='×';remove.title='이 기록만 삭제 (파일은 유지)';remove.setAttribute('aria-label',entry.name+' 전송 기록 삭제');remove.onclick=()=>removeHistory(entry);row.append(remove)}$('jobs').append(row)}controls();}
  function updateDownloads(state){if(disposed||typeof state?.folder!=='string'||!state.folder||state.folder.length>32767||/[\x00-\x1f\x7f]/.test(state.folder))return false;$('downloadFolderPath').textContent='저장 위치: '+state.folder;return true;}
  function folderControls(){for(const key of ['openDownloadFolder','chooseDownloadFolder','resetDownloadFolder'])$(key).disabled=folderBusy||typeof downloads!=='function';}
  async function folderAction(op){
    if(disposed||folderBusy||typeof downloads!=='function'||!['list','open-current-folder','choose-folder','reset-folder'].includes(op))return;
    const serial=++folderSerial;folderBusy=true;folderControls();$('downloadFolderStatus').textContent=op==='choose-folder'?'폴더 선택 창에서 저장 위치를 선택해 주세요…':op==='list'?'저장 위치를 확인하는 중…':'처리 중…';
    try{const result=await downloads(op);if(disposed||serial!==folderSerial)return;if(op==='open-current-folder'){if(result!==true)throw Error('폴더 열기 결과를 확인하지 못했습니다.');$('downloadFolderStatus').textContent='폴더 열기를 요청했습니다.';}else{if(!updateDownloads(result))throw Error('다운로드 저장 위치를 확인하지 못했습니다.');$('downloadFolderStatus').textContent=op==='list'?'':'새 다운로드부터 이 위치에 저장합니다.';}}
    catch(error){if(!disposed&&serial===folderSerial)$('downloadFolderStatus').textContent=errorText(error);}
    finally{if(!disposed&&serial===folderSerial){folderBusy=false;folderControls();}}
  }
  function releaseFile(entry){if(entry.key)files.delete(entry.key);entry.file=null;}
  function finishUpload(entry){if(currentUpload!==entry)return;currentUpload=null;uploadBusy=false;runUpload();}
  function trimHistory(){while(queue.length>historyLimit){const index=queue.findIndex(entry=>['done','failed','cancelled'].includes(entry.state));if(index<0)break;const [entry]=queue.splice(index,1);releaseFile(entry);if(entry.id)jobs.delete(entry.id)}while(jobs.size>historyLimit){const old=[...jobs].find(([,entry])=>['done','failed','cancelled'].includes(entry.state));if(!old)break;jobs.delete(old[0]);}}
  function cancelEntry(entry){if(entry.state==='done'||entry.state==='failed'||entry.state==='cancelled')return;entry.state='cancelled';if(entry.id)abandon(entry.id,entry.accountTag);releaseFile(entry);if(entry.kind==='upload'&&entry.id)finishUpload(entry);renderQueue();}
  function schedulePoll(){if(disposed||pollTimer||pollBusy||![...jobs.values()].some(entry=>entry.state==='running'))return;pollTimer=win.setTimeout(pollJobs,700);}
  async function pollJobs(){pollTimer=0;if(disposed||pollBusy)return;pollBusy=true;try{for(const [jobId,entry]of [...jobs]){if(disposed)return;if(entry.state!=='running')continue;try{const result=await invoke('job',{id:jobId,accountTag:entry.accountTag});if(disposed||jobs.get(jobId)!==entry||entry.state!=='running')continue;if(!['running','done','failed','cancelled'].includes(result?.state))throw Error('전송 상태를 확인하지 못했습니다.');entry.bytes=Math.max(entry.bytes||0,size(result.bytes));entry.total=size(result.total)||entry.total;if(typeof result.name==='string'&&result.name)entry.name=result.name.slice(0,1000);entry.state=result.state;if(entry.state==='failed')entry.error=errorText({message:result.error});if(entry.state!=='running'){releaseFile(entry);if(entry.kind==='upload'){if(entry.state==='done'){invalidateListings(entry.driveId,entry.parentId);if(drive?.id===entry.driveId&&parentId()===entry.parentId)loadFiles();}finishUpload(entry)}}}catch(error){if(disposed)return;if(jobs.get(jobId)!==entry||entry.state!=='running')continue;entry.state='failed';entry.error=errorText(error);abandon(jobId,entry.accountTag);releaseFile(entry);if(entry.kind==='upload')finishUpload(entry)}}trimHistory();renderQueue();}finally{pollBusy=false;schedulePoll()}}
  function addFiles(selected){if(!configured||!drive||checking||keyBusy||writeBusy){setStatus('먼저 드라이브 연결을 확인해 주세요.',true);return}const pending=queue.filter(entry=>['queued','starting','running'].includes(entry.state)).length,available=Math.max(0,queueLimit-pending),chosen=[...selected].slice(0,available);let added=0,rejected=0;for(const file of chosen){if(!file||typeof file.name!=='string'||file.name.length>1000||!Number.isSafeInteger(file.size)||file.size<0||file.size>transferLimit||typeof file.slice!=='function'){rejected++;continue}queue.push({kind:'upload',file,name:file.name,total:file.size,bytes:0,state:'queued',accountTag,driveId:drive.id,parentId:parentId(),destination:crumbs.map(crumb=>crumb.name).join(' / ')});added++}trimHistory();setStatus(added+'개 파일을 대기열에 추가했습니다. 업로드 시작을 눌러 주세요.'+([...selected].length>available?' 대기열은 최대 20개입니다.':'')+(rejected?' 올릴 수 없는 파일은 제외했습니다. 파일당 최대 1GB입니다.':''));renderQueue();}
  async function runUpload(){if(disposed||uploadBusy||checking||keyBusy||writeBusy)return;const entry=queue.find(item=>item.state==='queued'&&item.startRequested);if(!entry)return;if(entry.accountTag!==accountTag){entry.state='cancelled';releaseFile(entry);runUpload();renderQueue();return}uploadBusy=true;currentUpload=entry;entry.state='running';entry.key=win.crypto.randomUUID();files.set(entry.key,entry);renderQueue();try{const result=await invoke('upload',{driveId:entry.driveId,...(entry.parentId?{parentId:entry.parentId}:{}),fileKey:entry.key,name:entry.name,size:entry.total,accountTag:entry.accountTag});const jobId=id(result?.id);if(disposed||entry.state==='cancelled'||entry.accountTag!==accountTag){abandon(jobId,entry.accountTag);finishUpload(entry);return}if(!jobId)throw Error('업로드를 시작하지 못했습니다.');entry.id=jobId;jobs.set(jobId,entry);schedulePoll();}catch(error){if(disposed)return;if(entry.state!=='cancelled'&&entry.accountTag===accountTag){entry.state='failed';entry.error=errorText(error)}releaseFile(entry);finishUpload(entry);renderQueue();}}
  async function download(entry,driveId=drive?.id){if(!driveId||checking||keyBusy||writeBusy)return;if([...jobs.values()].filter(job=>['running','starting'].includes(job.state)).length>=20){setStatus('진행 중인 전송을 마친 뒤 다시 시도해 주세요.',true);return}const epoch=generation,tag=accountTag,target={driveId,fileId:entry.id,accountTag:tag},job={kind:'download',name:entry.name,total:size(entry.size),bytes:0,state:'starting',accountTag:tag};const key=win.crypto.randomUUID();jobs.set(key,job);trimHistory();renderQueue();try{const result=await invoke('download',target);jobs.delete(key);const jobId=id(result?.id);if(disposed||epoch!==generation||job.state==='cancelled'){abandon(jobId,tag);return}if(!jobId)throw Error('다운로드를 시작하지 못했습니다.');job.id=jobId;job.state='running';jobs.set(jobId,job);schedulePoll();renderQueue();}catch(error){if(disposed||epoch!==generation||job.historyRemoved)return;if(job.state!=='cancelled'){job.state='failed';job.error=errorText(error)}jobs.set(key,job);renderQueue();setStatus(job.error||'다운로드를 취소했습니다.',job.state==='failed')}}
  async function showPreview(entry){if(!drive||checking||keyBusy||writeBusy)return;closePreview();closeShare();const stamp=previewSerial,epoch=generation,tag=accountTag,target={driveId:drive.id,fileId:entry.id,accountTag:tag};previewFile={...entry,driveId:drive.id,accountTag:tag};$('preview').hidden=false;$('previewName').textContent=entry.name;$('previewNote').textContent='미리보기를 준비하는 중…';let session=null;try{const result=await invoke('preview',target);session=id(result?.id);if(disposed||epoch!==generation||stamp!==previewSerial){abandon(session,tag);return}if(result?.kind==='text'){if(typeof result.text!=='string'||new win.TextEncoder().encode(result.text).length>256*1024)throw Error('텍스트 미리보기는 256KB까지 지원합니다.');const pre=document.createElement('pre');pre.textContent=result.text;$('previewContent').append(pre);$('previewNote').textContent='텍스트 미리보기 · 최대 256KB';return}const kind=result?.kind,mime=text(result?.mime).split(';')[0].toLowerCase(),allowed={image:['image/png','image/jpeg','image/gif','image/webp','image/bmp','image/avif'],video:['video/mp4','video/webm','video/ogg'],pdf:['application/pdf']},limit=kind==='video'?64*MiB:16*MiB;if(!session||!allowed[kind]?.includes(mime)||!Number.isSafeInteger(result.size)||result.size<0||result.size>limit)throw Error('미리보기는 이미지·PDF 16MB, 영상 64MB까지 지원합니다.');activePreview={id:session,accountTag:tag};const chunks=[];let offset=0,done=false;while(!done){const part=await invoke('preview-chunk',{id:session,offset,accountTag:tag});if(disposed||epoch!==generation||stamp!==previewSerial)return;const base64=part?.base64;if(typeof base64!=='string'||base64.length>Math.ceil(chunkLimit/3)*4||base64.length%4||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(base64))throw Error('미리보기 데이터를 확인하지 못했습니다.');const binary=win.atob(base64),bytes=Uint8Array.from(binary,char=>char.charCodeAt(0));if(bytes.length>chunkLimit||offset+bytes.length>result.size||!bytes.length&&!part.done)throw Error('미리보기 데이터 크기가 올바르지 않습니다.');chunks.push(bytes);offset+=bytes.length;done=part.done===true;$('previewNote').textContent='미리보기 준비 중 · '+formatSize(offset)+' / '+formatSize(result.size);}if(offset!==result.size)throw Error('미리보기 파일이 완전히 도착하지 않았습니다.');const blob=new win.Blob(chunks,{type:mime});if(typeof win.URL.createObjectURL!=='function')throw Error('이 환경에서는 미리보기를 지원하지 않습니다. 다운로드를 이용해 주세요.');blobURL=win.URL.createObjectURL(blob);let media;if(kind==='image'){media=document.createElement('img');media.alt=entry.name}else if(kind==='video'){media=document.createElement('video');media.controls=true;media.preload='metadata';media.playsInline=true}else{media=document.createElement('iframe');media.title=entry.name+' PDF 미리보기';media.setAttribute('sandbox','');media.referrerPolicy='no-referrer'}media.src=blobURL;$('previewContent').append(media);$('previewNote').textContent=kind==='pdf'?'PDF가 표시되지 않으면 다운로드해 주세요.':'미리보기';media.addEventListener('error',()=>{if(stamp===previewSerial)$('previewNote').textContent='미리보기를 표시하지 못했습니다. 다운로드를 이용해 주세요.'},{once:true});}catch(error){if(!disposed&&epoch===generation&&stamp===previewSerial)$('previewNote').textContent=errorText(error);}finally{if(session)abandon(session,tag);if(activePreview?.id===session&&activePreview.accountTag===tag)activePreview=null}}
  const shareScopes={member:'조직 내 구성원',memberAndGuest:'조직 내 구성원 및 손님',memberAndGuestAndExternal:'링크가 있는 누구나'};
  const localDateTime=value=>{const date=new win.Date(value),pad=value=>String(value).padStart(2,'0');return date.getFullYear()+'-'+pad(date.getMonth()+1)+'-'+pad(date.getDate())+'T'+pad(date.getHours())+':'+pad(date.getMinutes());};
  function currentShare(state){return !!state&&shareState===state&&state.serial===shareSerial&&ownsManagement(state.owner);}
  function shareScopeNote(){const external=$('shareScope').value==='memberAndGuestAndExternal';$('shareAccess').toggleAttribute('data-public',external);$('shareAccess').textContent=external?'링크를 전달받은 외부인도 파일에 접근할 수 있습니다. 공개 범위를 확인한 뒤 생성해 주세요.':$('shareScope').value==='memberAndGuest'?'조직 내 구성원과 손님이 접근할 수 있는 링크를 만듭니다.':'조직 내 구성원에게 공유할 링크를 만듭니다.';}
  function shareControls(){
    const state=shareState,busy=!currentShare(state)||!state?.ready||state.loading||state.creating||checking||keyBusy||writeBusy;
    $('shareScope').disabled=busy;
    $('shareExpiry').disabled=busy;
    $('shareCreate').disabled=busy;
    $('shareChoices').disabled=busy;
    $('copy').disabled=!$('shareUrl').value;
  }
  function normalizeShareLink(result,created=false){
    const url=new win.URL(text(result?.url));
    if(url.protocol!=='https:'||url.username||url.password||url.href.length>4096||!Object.hasOwn(shareScopes,result?.scope))throw Error('공유 링크 응답을 확인하지 못했습니다.');
    const expiry=typeof result.expiredAt==='string'?new win.Date(result.expiredAt):null;
    return {url:url.href,scope:result.scope,created,expiry:expiry&&Number.isFinite(expiry.getTime())?expiry:null};
  }
  function showShareLink(link){
    $('shareKind').textContent=link.created?'생성한 링크':'기존 공유 링크';
    $('shareUrl').value=link.url;
    $('shareUrl').hidden=false;
    $('copy').hidden=false;
    $('shareInfo').textContent=shareScopes[link.scope]+' · '+(link.expiry?'만료: '+link.expiry.toLocaleString():'만료 정보가 제공되지 않았습니다.');
  }
  function renderShareChoices(state,selected){
    const choices=$('shareChoices');
    choices.replaceChildren();
    for(const [index,link] of state.links.entries()){
      const option=document.createElement('option');
      option.value=String(index);
      option.textContent=shareScopes[link.scope]+' · '+(link.expiry?link.expiry.toLocaleString():'링크 '+(index+1));
      choices.append(option);
    }
    choices.hidden=state.links.length<2;
    if(selected>=0){
      choices.value=String(selected);
      showShareLink(state.links[selected]);
    }
  }
  async function share(entry){
    if(!drive||checking||keyBusy||writeBusy)return;
    navigation();const state={owner:managementOwner(entry),serial:shareSerial,loading:true,ready:false,creating:false,links:[]};shareState=state;
    $('shareName').textContent=entry.name+' · 공유 링크';$('shareKind').textContent='기존 공유 링크';$('shareInfo').textContent='기존 공유 링크를 확인하는 중…';
    $('shareExpiry').value=localDateTime(win.Date.now()+7*24*60*60*1000);$('shareExpiry').min=localDateTime(win.Date.now()+60000);shareScopeNote();$('share').hidden=false;shareControls();$('share').scrollIntoView?.({block:'nearest'});
    try{
      const result=await invoke('share',{driveId:state.owner.driveId,fileId:state.owner.fileId,create:false,accountTag:state.owner.accountTag});
      if(!currentShare(state))return;
      if(!Array.isArray(result?.links)||result.links.length>2000)throw Error('공유 링크 응답을 확인하지 못했습니다.');
      state.links=result.links.map(link=>normalizeShareLink(link));
      const preferred=['member','memberAndGuest','memberAndGuestAndExternal'].find(scope=>state.links.some(link=>link.scope===scope));
      const selected=state.links.findIndex(link=>link.scope===preferred);
      const advanced=Number.isSafeInteger(result.unsupportedCount)&&result.unsupportedCount>0;
      renderShareChoices(state,selected);
      if(advanced)$('shareNotice').textContent='고급 공유 링크는 두레이의 공식 공유 화면에서 확인할 수 있습니다.';
      if(selected<0)$('shareInfo').textContent=advanced?'두레이에서 확인할 기존 링크가 있습니다.':'현재 사용할 수 있는 공유 링크가 없습니다.';
      state.ready=true;
      setStatus(selected>=0?'공개 범위를 확인한 뒤 링크 복사를 눌러 주세요.':advanced?'두레이에서 고급 공유를 열어 링크를 확인해 주세요.':'공개 범위와 만료 일시를 선택한 뒤 새 링크 생성을 눌러 주세요.');
    }catch(error){if(currentShare(state)){$('shareError').textContent=errorText(error);$('shareInfo').textContent='기존 공유 링크를 확인하지 못했습니다.';setStatus(errorText(error),true);}}
    finally{if(currentShare(state)){state.loading=false;shareControls();}}
  }
  async function createShareLink(){
    const state=shareState;if(!currentShare(state)||!state.ready||state.loading||state.creating||checking||keyBusy||writeBusy)return;
    const scope=$('shareScope').value,expiry=new win.Date($('shareExpiry').value);
    if(!Object.hasOwn(shareScopes,scope)||!$('shareExpiry').value||!Number.isFinite(expiry.getTime())||expiry.getTime()<=win.Date.now()){$('shareError').textContent='현재 시각 이후의 만료 일시를 입력해 주세요.';return;}
    const expiredAt=expiry.toISOString();$('shareError').textContent='';
    const owner=state.owner;state.creating=true;writeBusy=true;pendingWrite=owner;controls();renderCrumbs();managementControls();setStatus('공유 링크를 만드는 중…');
    try{
      const result=await invoke('share',{driveId:owner.driveId,fileId:owner.fileId,create:true,scope,expiredAt,confirmed:true,accountTag:owner.accountTag});
      if(!currentShare(state))return;
      const link=normalizeShareLink(result,true);
      state.links=[link,...state.links.filter(existing=>existing.url!==link.url)];
      renderShareChoices(state,0);
      $('shareError').textContent='';
      setStatus('공유 링크를 만들었습니다. 공개 범위와 만료 일시를 확인한 뒤 복사해 주세요.');
    }catch(error){if(currentShare(state)){$('shareError').textContent=errorText(error);setStatus(errorText(error),true);}}
    finally{state.creating=false;if(pendingWrite===owner){pendingWrite=null;writeBusy=false;if(!disposed){controls();renderCrumbs();managementControls();runUpload();}}if(currentShare(state))shareControls();}
  }
  async function changeCredentials(forget=false) {
    if (keyBusy || checking || writeBusy || disposed) return;
    if (transferActive()) {
      setStatus('진행 중인 전송을 마친 뒤 키를 변경해 주세요.', true);
      return;
    }
    if (forget && !await confirmAction('API 키를 삭제할까요?', '이 컴퓨터에 저장한 API 키를 지웁니다. 대기 중인 업로드 목록도 비웁니다.', '키 삭제')) return;
    if (disposed || keyBusy || checking || writeBusy || transferActive()) return;
    keyBusy = true;
    controls();
    setStatus(forget ? '저장한 API 키를 삭제하는 중…' : 'Windows 인증 창을 여는 중… 열린 창에서 키를 입력하거나 취소해 주세요.');
    try {
      const response = await invoke(forget ? 'forget-key' : 'credentials');
      if (disposed) return;
      if (response?.cancelled) {
        setStatus('키 입력을 취소했습니다.');
        return;
      }
      if (response?.configured !== !forget) throw Error('API 키 처리 결과를 확인하지 못했습니다. 다시 시도해 주세요.');
      resetSession(null);
      configured = response.configured;
      initialized = false;
      setStatus(forget ? '저장한 API 키를 삭제했습니다.' : 'API 키를 저장했습니다.');
    } catch (error) {
      setStatus(errorText(error), true);
    } finally {
      if (!disposed) {
        keyBusy = false;
        controls();
        if (!initialized) connect();
      }
    }
  }
  function closePanel(){closeManagement();$('panel').hidden=true;$('toggle').setAttribute('aria-expanded','false');closeConfirmation();closePreview();closeShare();}
  function position(){if(!anchor)return;const floating=anchor.hasAttribute('data-floating');host.toggleAttribute('data-floating',floating);for(const [key,value]of Object.entries({position:floating?'fixed':'',right:floating?'0px':'',top:floating?Math.max(0,anchor.getBoundingClientRect().bottom+2)+'px':'',zIndex:floating?'5058':''}))host.style[key]=value;}
  $('toggle').onclick=()=>{const opening=$('panel').hidden;if(!opening){closePanel();return}$('panel').hidden=false;$('toggle').setAttribute('aria-expanded','true');connect(true)};$('close').onclick=closePanel;$('credentials').onclick=()=>changeCredentials();$('forget').onclick=()=>changeCredentials(true);$('refresh').onclick=refreshFolder;$('moreDrives').onclick=()=>loadDrives(true);$('drives').onchange=()=>{const selected=drives.find(entry=>entry.id===$('drives').value);if(!selected)return;navigation();drive=selected;crumbs=[{id:drive.rootId,name:drive.name}];loadFiles()};$('confirmCancel').onclick=()=>closeConfirmation();$('confirmAccept').onclick=()=>closeConfirmation(true);$('shareClose').onclick=closeShare;$('previewClose').onclick=closePreview;$('previewDownload').onclick=()=>{if(previewFile&&previewFile.accountTag===accountTag)download(previewFile,previewFile.driveId)};$('copy').onclick=async()=>{const value=$('shareUrl').value;if(!value)return;try{if(typeof win.navigator.clipboard?.writeText!=='function')throw Error('Clipboard unavailable');await win.navigator.clipboard.writeText(value);setStatus('공유 링크를 복사했습니다.')}catch{if(!disposed){$('shareUrl').focus();$('shareUrl').select();setStatus('공유 주소가 선택되었습니다. Ctrl+C로 복사해 주세요.')}}};$('choose').onclick=()=>$('picker').click();$('picker').onchange=()=>{addFiles($('picker').files||[]);$('picker').value=''};$('start').onclick=()=>{for(const entry of queue)if(entry.state==='queued')entry.startRequested=true;runUpload()};$('clearQueue').onclick=()=>{for(let index=queue.length-1;index>=0;index--)if(['done','failed','cancelled'].includes(queue[index].state)){releaseFile(queue[index]);queue.splice(index,1)}for(const [key,entry]of jobs)if(['done','failed','cancelled'].includes(entry.state))jobs.delete(key);renderQueue()};
  $('fileView').onchange=()=>{
    const next=$('fileView').value;
    if(!fileTypes.has(next)||next===fileView||!managementReady())return;
    navigation();
    fileView=next;
    loadFiles();
  };
  $('moreFiles').onclick=()=>{if(activeListing&&!checking&&!keyBusy&&!writeBusy)loadMoreFiles(activeListing);};
  $('files').addEventListener('scroll',()=>{
    const list=$('files'),top=list.scrollTop,down=top>lastFileScroll;
    lastFileScroll=top;
    if(down&&!$('panel').hidden&&!checking&&!keyBusy&&!writeBusy&&!activeListing?.failed&&
       list.scrollHeight-top-list.clientHeight<=80)loadMoreFiles(activeListing);
  },{passive:true});
  $('shareScope').onchange=shareScopeNote;$('shareCreate').onclick=createShareLink;
  $('shareChoices').onchange=()=>{
    const state=shareState,selected=state?.links[$('shareChoices').selectedIndex];
    if(currentShare(state)&&selected)showShareLink(selected);
  };
  for(const [key,op]of [['openDownloadFolder','open-current-folder'],['chooseDownloadFolder','choose-folder'],['resetDownloadFolder','reset-folder']])$(key).onclick=()=>folderAction(op);
  $('downloadSettings').onclick=()=>{const open=$('downloadFolderSettings').hidden;$('downloadFolderSettings').hidden=!open;$('downloadSettings').setAttribute('aria-expanded',String(open));};
  $('toggle').addEventListener('click',()=>{if(!$('panel').hidden)folderAction('list');});folderControls();if(typeof downloads!=='function')$('downloadFolderStatus').textContent='다운로드 연결을 확인해 주세요.';
  $('newFolder').onclick=()=>openName('create-folder');$('nameSave').onclick=saveName;$('nameCancel').onclick=()=>closeManagement();$('moveCancel').onclick=()=>closeManagement();$('moveSave').onclick=saveMove;$('movePrevious').onclick=()=>{if(moveDraft&&!moveDraft.busy&&!writeBusy&&moveDraft.page>0){moveDraft.page--;loadMoveFolders()}};$('moveNext').onclick=()=>{if(moveDraft&&!moveDraft.busy&&!writeBusy&&moveDraft.hasNext){moveDraft.page++;loadMoveFolders()}};
  const drag=event=>{event.preventDefault();event.stopPropagation();if(event.type==='dragover')$('drop').setAttribute('data-drag','');else $('drop').removeAttribute('data-drag');if(event.type==='drop'){const items=[...(event.dataTransfer?.items||[])];if(items.some(item=>item.webkitGetAsEntry?.()?.isDirectory)){setStatus('폴더 대신 파일을 선택해 주세요.',true);return}addFiles(event.dataTransfer?.files||[])}};for(const type of ['dragover','dragleave','drop'])$('drop').addEventListener(type,drag);for(const type of ['dragover','drop'])shadow.addEventListener(type,drag);
  const isolate=event=>{
    event.stopPropagation();
    if(event.type!=='keydown')return;
    if(event.isComposing||event.keyCode===229)return;
    if(event.key==='Enter'&&event.target===$('entryName')){
      event.preventDefault();
      if(!event.repeat&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey)saveName();
      return;
    }
    if(event.key!=='Escape')return;
    event.preventDefault();
    const menu=shadow.querySelector('.item-menu[open]');
    if(confirmResolve)closeConfirmation();
    else if(!$('nameEditor').hidden||!$('destinationPicker').hidden)closeManagement();
    else if(!$('preview').hidden)closePreview();
    else if(menu){
      menu.open=false;
      menu.querySelector('summary').focus({preventScroll:true});
    }else closePanel();
  };
  for(const type of ['keydown','keyup','keypress'])shadow.addEventListener(type,isolate,true);
  const dismiss=event=>{if(!$('panel').hidden&&!event.composedPath().includes(host))closePanel()};document.addEventListener('pointerdown',dismiss,true);win.addEventListener('resize',position);empty('API 키를 등록하면 드라이브를 볼 수 있습니다.');controls();
  return {updateDownloads,mount(downloadHost){if(disposed||!downloadHost?.isConnected||downloadHost.ownerDocument!==document)return;anchor=downloadHost;if(host.previousElementSibling!==anchor)anchor.insertAdjacentElement('afterend',host);position();return host;},dispose(){if(disposed)return;generation++;listSerial++;pendingWrite=null;writeBusy=false;closeManagement(true);closeConfirmation();closePreview();closeShare();disposed=true;if(pollTimer)win.clearTimeout(pollTimer);pollTimer=0;for(const [jobId,entry]of jobs){if(entry.state==='running'||entry.state==='starting')abandon(entry.id||jobId,entry.accountTag);releaseFile(entry)}for(const entry of queue)releaseFile(entry);files.clear();clearListings();jobs.clear();queue.splice(0);drives=[];drive=null;crumbs=[];anchor=null;document.removeEventListener('pointerdown',dismiss,true);win.removeEventListener('resize',position);for(const type of ['keydown','keyup','keypress'])shadow.removeEventListener(type,isolate,true);if(win.__doorayDriveReadFile===readFile)delete win.__doorayDriveReadFile;host.remove();}};
}

  function renderDownloads(){if(!downloadShadow)return;const active=downloadItems.filter(i=>i.status==='downloading').length,unseen=downloadItems.some(i=>i.status==='complete'&&!i.seen);const badge=downloadShadow.getElementById('activeBadge');badge.textContent=String(active);badge.hidden=!active;downloadShadow.getElementById('doneBadge').hidden=!unseen;downloadShadow.getElementById('toggle').toggleAttribute('data-unseen',unseen&&downloadShadow.getElementById('panel').hidden);downloadShadow.getElementById('toggle').setAttribute('aria-label','다운로드 관리'+(active?' · '+active+'개 다운로드 중':'')+(unseen?' · 미확인 완료 있음':''));const list=downloadShadow.getElementById('items');list.replaceChildren();downloadShadow.getElementById('count').textContent=String(downloadItems.length);downloadShadow.getElementById('clear').disabled=!downloadItems.length;if(!downloadItems.length){const empty=document.createElement('p');empty.textContent='다운로드 기록이 없습니다.';list.append(empty)}for(const item of downloadItems){const row=document.createElement('div');row.className='item';const name=document.createElement('strong');name.textContent=item.name;const info=document.createElement('p');const status={complete:'완료',downloading:'다운로드 중',error:'실패',interrupted:'중단됨',cancelled:'취소됨'}[item.status]||'브라우저로 전달됨';const progress=item.total?Math.min(100,Math.round((item.received||0)*100/item.total))+'%':Math.round((item.received||0)/1024)+' KB';info.textContent=new Date(item.at).toLocaleString()+' · '+status+(item.status==='downloading'?' '+progress:'')+(item.error?' · '+item.error:'');const buttons=document.createElement('div');buttons.className='actions';const open=document.createElement('button');open.textContent='↗ 열기';open.disabled=item.status!=='complete';open.onclick=()=>downloadRPC('open',{id:item.id}).catch(e=>info.textContent=e.message);const go=document.createElement('button');go.textContent='대화로 가기';go.dataset.dtGoto='true';if(/^\d+$/.test(String(item.channelId)))go.dataset.dtNavigationChannel=String(item.channelId);go.disabled=!item.logId;go.onclick=()=>{if(goDownload(item))downloadShadow.getElementById('panel').hidden=true;else info.textContent='대화가 있는 파일 목록을 연 뒤 다시 시도해 주세요.'};const folder=document.createElement('button');folder.textContent='폴더 열기';folder.disabled=item.status!=='complete';folder.onclick=async()=>{folder.disabled=true;folder.textContent='여는 중…';try{await downloadRPC('folder',{id:item.id})}catch(e){info.textContent=e.message}finally{folder.disabled=false;folder.textContent='폴더 열기'}};const heading=document.createElement('div');heading.className='item-head';const remove=document.createElement('button');remove.className='item-remove';remove.textContent='×';remove.setAttribute('aria-label',item.name+' 다운로드 기록 삭제');remove.title='이 기록만 삭제 (저장된 파일은 유지)';remove.onclick=()=>{remove.disabled=true;downloadRPC('forget',{id:item.id}).then(state=>{downloadItems=state.items;downloadPersist();renderDownloads()}).catch(e=>{info.textContent=e.message;remove.disabled=false})};heading.append(name,remove);buttons.append(open,folder,go);if(item.status==='downloading'){const cancel=document.createElement('button');cancel.textContent='다운로드 취소';cancel.onclick=()=>{cancel.disabled=true;downloadRPC('cancel',{id:item.id}).then(()=>{info.textContent='취소 요청됨'}).catch(e=>{info.textContent=e.message;cancel.disabled=false})};buttons.prepend(cancel);const meter=document.createElement('progress');meter.max=100;if(item.total)meter.value=Math.min(100,(item.received||0)*100/item.total);meter.setAttribute('aria-label','다운로드 진행률');info.append(meter);}row.append(heading,info,buttons);list.append(row)}}
  drivePanel = typeof installDoorayDrivePanel === 'function'
    ? installDoorayDrivePanel({document, rpc:(op,args)=>downloadRPC('drive-'+op,args),downloads:async op=>{if(!['list','open-current-folder','choose-folder','reset-folder'].includes(op))throw Error('지원하지 않는 다운로드 설정입니다.');const result=await downloadRPC(op);if(result?.folder)window.__doorayDownloadsChanged?.(result);return result;}})
    : null;
  if (drivePanel) cleanup.push(()=>drivePanel.dispose());
  function mountDownloads(){
    mountDownloadsPanel();
    if (downloadHost?.isConnected && nativeDOM.rail()) drivePanel?.mount(downloadHost);
  }
  function mountDownloadsPanel(){if(disposed)return;const rail=nativeDOM.rail();if(!downloadHost){downloadHost=document.createElement('div');downloadHost.id='dooray-theme-downloads';downloadShadow=downloadHost.attachShadow({mode:'open'});downloadShadow.innerHTML=`<style>:host{display:block;position:relative;width:48px;height:56px;flex:0 0 56px;font:12px 'Malgun Gothic',sans-serif;color:var(--dt-text,#333)}*{box-sizing:border-box}[hidden]{display:none!important}button,summary{cursor:pointer;font:inherit}button{color:inherit;border:1px solid var(--dt-border,#ccc);border-radius:4px;background:var(--dt-surface,#fff);padding:5px 8px}button:disabled{opacity:.4;cursor:not-allowed}#toggle{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;width:44px;height:52px;border:0;background:transparent;margin:2px;padding:2px;font-size:10px}#downloadToast{position:fixed;right:18px;bottom:18px;top:auto;width:244px;max-width:calc(100vw - 36px);z-index:2147483000;display:grid;grid-template-columns:18px minmax(0,1fr) 26px;align-items:center;gap:9px;padding:9px 6px 9px 13px;border:1px solid #ffffff26;border-radius:10px;background:#244e78;color:#fff;box-shadow:0 5px 18px #0003;font-size:13px;font-weight:500;line-height:1.4;text-align:left;animation:dt-toast-rise .2s ease-out}#toastMessage{min-width:0;overflow-wrap:anywhere;letter-spacing:-.15px}.toastIcon{width:18px;height:18px;opacity:.9}.toastComplete{display:none}#downloadToast[data-kind=complete] .toastComplete{display:block}#downloadToast[data-kind=complete] .toastBusy{display:none}#toastClose{justify-self:end;display:flex;align-items:center;justify-content:center;width:26px;height:26px;margin:0;padding:0;border:0;border-radius:6px;background:transparent;color:inherit;opacity:.65;cursor:pointer}#toastClose:hover{background:#ffffff1f;opacity:1}#toastClose:focus-visible{outline:2px solid currentColor;outline-offset:1px}#toastClose svg{width:12px;height:12px}@keyframes dt-toast-rise{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){#downloadToast{animation:none}}#toggle[data-unseen]{animation:dt-download-pulse 1.6s ease-in-out infinite}@keyframes dt-download-pulse{0%,100%{box-shadow:inset 0 0 0 0 transparent;background:transparent}50%{box-shadow:inset 0 0 0 2px var(--dt-accent,#278ac2);background:var(--dt-selection,#e5f1ff);color:var(--dt-accent,#278ac2)}}@media(prefers-reduced-motion:reduce){#toggle[data-unseen]{animation:none;box-shadow:inset 0 0 0 2px var(--dt-accent,#278ac2)}}#toggle svg{width:22px;height:22px}#activeBadge{position:absolute;top:0;right:0;min-width:17px;padding:1px 3px;border-radius:9px;background:var(--dt-downloadBadge,#278ac2);color:var(--dt-downloadBadgeText,#fff);font-size:10px;font-weight:bold}#doneBadge{position:absolute;top:1px;left:3px;width:9px;height:9px;border-radius:50%;background:var(--dt-downloadDone,#e53935)}progress{display:block;width:100%;height:7px;margin-top:7px;accent-color:var(--dt-downloadBadge,#278ac2)}#panel{position:fixed;z-index:5060;right:60px;top:12px;width:410px;max-width:calc(100vw - 72px);max-height:calc(100vh - 24px);display:flex;flex-direction:column;border:1px solid var(--dt-border,#ccc);border-radius:8px;background:var(--dt-bg,#fff);box-shadow:0 12px 40px #0006}.head{display:flex;align-items:center;gap:8px;padding:14px;border-bottom:1px solid var(--dt-border,#ccc)}.head strong{flex:1}.note{padding:8px 14px;margin:0;font-size:11px;color:var(--dt-muted,#666)}#items{overflow:auto;padding:0 14px 14px}.item{padding:12px 0;border-bottom:1px solid var(--dt-border,#ccc);overflow-wrap:anywhere}.item p{font-size:11px;color:var(--dt-muted,#666);margin:6px 0}.actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.item-head{display:flex;align-items:flex-start;gap:8px}.item-head strong{flex:1;min-width:0}.item-remove{flex:0 0 26px;padding:1px 5px;font-size:18px;line-height:22px}button:focus-visible,summary:focus-visible{outline:2px solid #007acc}</style><button id="toggle" title="다운로드 관리" aria-label="다운로드 관리"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></svg><span>다운로드</span><span id="activeBadge" hidden></span><span id="doneBadge" hidden aria-label="미확인 다운로드 완료"></span></button><section id="panel" hidden><div class="head"><strong>다운로드 <span id="count"></span></strong><button id="clear" title="다운로드 기록만 삭제합니다. 저장된 파일은 유지됩니다.">전체 목록 삭제</button><button id="close" aria-label="다운로드 창 닫기">×</button></div><p class="note" id="connection">로컬 다운로드 연결을 확인하고 있습니다. 연결되지 않으면 기존 브라우저 다운로드를 사용합니다.</p><div class="actions" style="padding:0 14px 10px"><button id="chooseFolder">저장 폴더 변경</button><button id="resetFolder">기본 다운로드 폴더</button><button id="openCurrentFolder">폴더 열기</button></div><p id="folderStatus" class="note" role="status" aria-live="polite"></p><div id="items"></div></section><div id="downloadToast" role="status" aria-live="polite" aria-atomic="true" hidden><svg class="toastIcon toastBusy" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M10 3v9m-3-3 3 3 3-3M4 13v4h12v-4" stroke-linecap="round" stroke-linejoin="round"/></svg><svg class="toastIcon toastComplete" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="10" cy="10" r="7.5"/><path d="m6.5 10 2.3 2.3 4.7-4.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span id="toastMessage">다운로드 완료</span><button type="button" id="toastClose" aria-label="다운로드 알림 닫기"><svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m3 3 6 6m0-6-6 6" stroke-linecap="round"/></svg></button></div>`;for(const [id,op]of [['chooseFolder','choose-folder'],['resetFolder','reset-folder'],['openCurrentFolder','open-current-folder']])downloadShadow.getElementById(id).onclick=async()=>{const ids=['chooseFolder','resetFolder','openCurrentFolder'];for(const key of ids)downloadShadow.getElementById(key).disabled=true;const status=downloadShadow.getElementById('folderStatus');status.textContent=op==='choose-folder'?'폴더 선택 창에서 저장 위치를 선택해 주세요…':'처리 중…';try{const result=await downloadRPC(op);if(result?.folder)window.__doorayDownloadsChanged(result);status.textContent=op==='open-current-folder'?'폴더 열기를 요청했습니다.':'저장 위치가 적용되었습니다. 새 다운로드부터 사용합니다.';}catch(e){status.textContent=e.message}finally{for(const key of ids)downloadShadow.getElementById(key).disabled=false}};downloadShadow.getElementById('toastClose').onclick=dismissDownloadToast;downloadShadow.getElementById('toggle').onclick=()=>{dismissDownloadToast();const p=downloadShadow.getElementById('panel');p.hidden=!p.hidden;renderDownloads();ackDownloads()};downloadShadow.getElementById('close').onclick=()=>downloadShadow.getElementById('panel').hidden=true;downloadShadow.getElementById('clear').onclick=()=>{downloadShadow.getElementById('clear').disabled=true;downloadRPC('clear').then(state=>{downloadItems=state.items;downloadPersist();renderDownloads()}).catch(e=>{downloadShadow.getElementById('connection').textContent=e.message;downloadShadow.getElementById('clear').disabled=!downloadItems.length})};renderDownloads();}if(!host.isConnected)mountMenu();if(host.nextElementSibling!==downloadHost)host.after(downloadHost);downloadHost.toggleAttribute('data-floating',!rail);for(const [key,value]of Object.entries({position:rail?'':'fixed',right:rail?'':'0px',top:rail?'':'62px',zIndex:rail?'':'5058'}))downloadHost.style[key]=value;}
  const onDownloadCapture=e=>{const target=e.target instanceof Element?e.target:null;if(!target)return;const card=target.closest(':is([data-dp-native~="file-card"],.sc-RcBXQ)');if(card&&target.closest('button,a')){const file=fileData(card);if(file){const log=downloadLog(card);lastDownload={file,log,at:Date.now()}}}const anchor=target.closest('a[download]');if(!anchor)return;let url;try{url=new URL(anchor.href,location.href)}catch{return}if(url.origin!==location.origin||!/^\/messenger\/v2\/api\/channel\/\d+\/file\/\d+$/.test(url.pathname))return;const parts=url.pathname.split('/'),match=lastDownload&&Date.now()-lastDownload.at<10000&&String(lastDownload.file.id)===parts[7]?lastDownload:null;if(typeof window.__doorayDownloadCommand==='function'&&Date.now()-(window.__doorayDownloadsReady||0)<5000){e.preventDefault();e.stopImmediatePropagation();showDownloadToast('다운로드 중..');downloadRPC('download',{url:url.href,name:match?.file.fileName||match?.file.title||anchor.download||'파일 '+parts[7],total:match?.file.fileSize||0,logId:match?.log?.logId||null}).catch(error=>{showDownloadToast('다운로드 실패: '+error.message);if(downloadShadow)downloadShadow.getElementById('connection').textContent=error.message;});return;}downloadItems.unshift({id:crypto.randomUUID(),name:match?.file.fileName||match?.file.title||anchor.download||'파일 '+parts[7],at:Date.now(),channelId:parts[5],fileId:parts[7],logId:match?.log?.logId||null});downloadItems=downloadItems.slice(0,500);downloadPersist();renderDownloads();};document.addEventListener('click',onDownloadCapture,true);const downloadsTimer=setInterval(mountDownloads,1000);cleanup.push(()=>{clearInterval(downloadsTimer);document.removeEventListener('click',onDownloadCapture,true);downloadHost?.remove()});

  function apply(){if(faulted)return;styleDownloadToast();
    const scrollLayout=chatScroll.beforeLayout();
    const c=current.excel?{...defaults,excel:true,dark:current.dark,font:'Malgun Gothic',detail:true,size:13,line:24/13,gap:24,padding:0,padX:6,nameSize:12,nameWeight:400,nameGap:0,timeSize:11,inputSize:13,inputLine:24/13,radius:0,weight:400,darkBrightness:current.excelBrightness}:current.vscode?{...defaults,vscode:true,dark:current.dark,font:'Consolas',detail:true,size:13,line:1.65,padding:6,padX:10,radius:2,bubbleBorder:1,nameSize:12,nameWeight:500,gap:16,inputSize:13,inputLine:1.65}:current;
    if(current.excel||current.vscode){for(const k of ['font','size','line','letter'])c[k]=current[k];if(current.detail)for(const k of [...groups.text.map(x=>x[0]),'inputSize','inputLine'])c[k]=current[k];else{c.inputSize=current.size;c.inputLine=Math.max(1.1,current.line);}}
    const a=c.detail?c:defaults,custom=!c.excel&&!c.vscode&&c.detail&&c.customColors,p={...(c.dark?(custom?c:defaults):(custom?c.lightColors:lightDefaults))},d='html[data-dt-palette="true"]';
    if(c.excel&&!custom)Object.assign(p,c.dark?{bg:'#151719',surface:'#222529',own:'#393526',selection:'#30363b',reply:'#292d31',notice:'#292d31',text:'#eeeeef',muted:'#a5a9ae',accent:'#8ccca5',border:'#34383d',hover:'#303439'}:{bg:'#ffffff',surface:'#f7f7f7',own:'#fff9dc',selection:'#d9ecdf',reply:'#e8f2eb',notice:'#e4f0e8',text:'#20382a',muted:'#586e60',accent:'#107c41',border:'#e2e5e3',hover:'#e7f1ea'});
    if(c.excel&&!custom)Object.assign(p,{newChat:'#107c41',org:'#217346',newChatIcon:'#ffffff',orgIcon:'#ffffff'});
    if(c.vscode)Object.assign(p,c.dark?{bg:'#1e1e1e',surface:'#252526',own:'#22364b',selection:'#37373d',reply:'#2d2d30',notice:'#303031',text:'#d4d4d4',muted:'#969696',accent:'#4fc1ff',border:'#454545',hover:'#2a2d2e'}:{bg:'#ffffff',surface:'#f3f3f3',own:'#e5f2ff',selection:'#e4e6f1',reply:'#f0f0f0',notice:'#f3f3f3',text:'#333333',muted:'#6a6a6a',accent:'#006ab1',border:'#d4d4d4',hover:'#e8e8e8'});
    if(c.vscode)Object.assign(p,{actionIcon:c.dark?'#ffffff':'#333333',newChat:'#007acc',org:'#007acc',newChatIcon:'#ffffff',orgIcon:'#ffffff'});
    p.chatFlash=current.excel?(current.dark?'#31513e':'#cce9d7'):current.vscode?(current.dark?'#264f78':'#cce6ff'):(current.dark?'#3c526b':'#fff4d3');if(current.detail&&current.customColors){const chosen=current.dark?current:current.lightColors;for(const k of ['downloadBadge','downloadBadgeText','downloadDone','chatFlash'])p[k]=chosen[k];}
    document.documentElement.dataset.dtDark=String(c.dark);document.documentElement.dataset.dtPalette=String(c.dark||custom||c.excel||c.vscode);document.documentElement.dataset.dtExcel=String(c.excel);
    if(c.vscode)for(const k of ['bg','surface','own','selection','reply','notice','border','hover'])p[k]=vscodeBackground(p[k]);
    if(c.dark&&!c.vscode)for(const k of ['bg','surface','own','selection','reply','notice','border','hover'])p[k]=brighten(p[k],c.darkBrightness);
    bubbleTheme={mode:c.excel?'excel':c.vscode?'vscode':'default',bg:p.surface,own:p.own,text:p.text,border:p.border,width:c.excel||c.vscode?1:(c.detail?a.bubbleBorder:0),borderStyle:'solid',font:c.font==='original'?'':c.font,fontLabel:c.font==='original'?'Dooray 기본 글꼴':c.font};
    $('demoSettings').hidden=!(current.excel||current.vscode);const shortcut=current[current.excel?'excelShortcut':'vscodeShortcut'].split('+');$('demoModifier').value=shortcut[0];$('demoKey').value=shortcut[1];if(demoHost){if(demoMode!==demoKind())closeDemo();else{positionDemo();paintDemo()}}
    $('vscodeBrightnessBox').hidden=!current.vscode;$('vscodeBrightness').value=current.vscodeBrightness;$('vscodeBrightnessValue').textContent=current.vscodeBrightness+'%';
    $('excelBrightnessBox').hidden=!(current.excel&&current.dark);$('excelBrightness').value=current.excelBrightness;$('excelBrightnessValue').textContent=current.excelBrightness+'%';
    const fontControls=new Set(['customColors','downloadBadge','downloadBadgeText','downloadDone','chatFlash','dark','excel','themeStyle','demoModifier','demoKey','excelBrightness','vscodeBrightness','detail','font','localFont','fontFile','size','line','letter',...groups.text.map(x=>x[0]),'inputSize','inputLine']);
    for(const e of shadow.querySelectorAll('input:not([name]),select:not([name])'))e.disabled=Boolean((current.excel||current.vscode)&&!fontControls.has(e.id.replace(/Number$/,'')));
    $('removeFont').disabled=!library.has(current.font);
    $('darkBrightness').disabled=$('darkBrightnessNumber').disabled=!c.dark||current.excel||current.vscode;
    const font=c.font==='original'?'':`#root *:not([class*="icon"]):not([class*="Icon"]):not(svg):not(svg *):not(code):not(pre){font-family:${JSON.stringify(c.font)},"Malgun Gothic",sans-serif!important}`;
    sheet.textContent=`
    @keyframes jgnbAY{0%{background-color:var(--dt-chatFlash)}100%{background-color:transparent}}
    :root{${colorSpecs.map(([k])=>'--dt-'+k+':'+p[k]+';').join('')}--dt-gap:${c.gap}px;--dt-action-bg:${c.dark?'#253246':p.bg}}
    ${d},${d} body,${d} #root{background-color:${p.bg}!important;color:${p.text}!important;color-scheme:${c.dark?'dark':'light'}}
    :where(html[data-dt-palette="true"] #root *:not([class*="icon"]):not(svg):not(svg *)){color:var(--dt-text)!important}
    ${d} .tippy-tooltip{background:#253246!important;color:#f3f6fc!important;border:1px solid #70819b!important;box-shadow:0 4px 16px #0009!important}
    ${d} .tippy-tooltip .tippy-content,${d} .tippy-tooltip .tippy-content :not(svg):not(svg *){color:#f3f6fc!important}
    ${d} .tippy-popper[x-placement^=top] .tippy-arrow{border-top-color:#253246!important}${d} .tippy-popper[x-placement^=bottom] .tippy-arrow{border-bottom-color:#253246!important}
    ${d} input::placeholder{color:${p.muted}!important}${d} .js-gnb-list-item:hover{background:${p.hover}!important}
    ${font}:is([data-dp-native~="message-text"],.sc-chbbiW),:is([data-dp-native~="message-text"],.sc-chbbiW) :not(img):not(svg):not([class*="icon"]){font-size:${c.size}px!important;line-height:${c.line}!important;letter-spacing:${c.letter}px!important}
    .js-main-editor .dooray-flavored-html-editor-content-editable,.js-main-editor .dooray-flavored-html-paragraph{font-size:${c.detail?a.inputSize:c.size}px!important;line-height:${c.detail?a.inputLine:Math.max(1.1,c.line)}!important;letter-spacing:${c.letter}px!important}
    .js-main-editor .dooray-flavored-html-editor-content-editable{padding:${6+(c.detail?a.inputPadding:0)}px ${12+(c.detail?a.inputPadding:0)}px!important}
    .js-main-editor .ZWrC3{top:${6+(c.detail?a.inputPadding:0)}px!important;padding:0 ${12+(c.detail?a.inputPadding:0)}px!important;font-size:${c.detail?a.inputSize:c.size}px!important;line-height:${c.detail?a.inputLine:Math.max(1.1,c.line)}!important;letter-spacing:${c.letter}px!important}
    :is([data-dp-native~="message-bubble"],.sc-iyvyFf):has(>:is([data-dp-native~="message-text"],.sc-chbbiW)){padding:${c.padding}px ${c.detail?a.padX:12}px!important}
    ${c.detail?`:is([data-dp-native~="message-text"],.sc-chbbiW),:is([data-dp-native~="message-text"],.sc-chbbiW) :not(b):not(strong):not(code):not(pre){font-weight:${a.weight}!important;word-spacing:${a.word}px!important}
    [class*="js-log-right-content-"] .R2Gwc,[class*="js-log-right-content-"] .R2Gwc *{font-size:${a.nameSize}px!important;font-weight:${a.nameWeight}!important;line-height:1.4!important}
    [class*="js-log-right-content-"] .R2Gwc{margin-bottom:${a.nameGap}px!important}
    [class*="js-log-right-content-"] .k2R2n{font-size:${a.timeSize}px!important;line-height:1.4!important}
    .js-gnb-list-item *:not([class*="icon"]):not(svg):not(svg *){font-size:${a.listSize}px!important}
    :is([data-dp-native~="message-bubble"],.sc-iyvyFf):has(>:is([data-dp-native~="message-text"],.sc-chbbiW)){border-radius:${a.radius}px!important;max-width:min(100%,${a.bubbleWidth}px)!important;border:${a.bubbleBorder}px solid ${p.border}!important}
    :is([data-dp-native~="message-group"],.sc-drKuOJ):has(>[class*="js-log-right-content-"]){padding-left:${a.messageInset}px!important;padding-right:${a.messageInset}px!important}
    `:''}`;
    if(c.excel)sheet.textContent+=`
    html[data-dt-excel="true"] :is(.js-channel-list,.sc-hAXbOi,.bnhPp){background-color:${p.surface}!important;box-shadow:inset 0 0 0 1px ${p.border}!important}
    html[data-dt-excel="true"] :is(.js-user-menu,.BNJ0V){background:#217346!important;box-shadow:inset 0 -2px #107c41!important}
    html[data-dt-excel="true"] :is(.js-user-menu,.BNJ0V) :is(div,span,a,button,i,svg),html[data-dt-excel="true"] :is(.js-user-menu,.BNJ0V){color:#ffffff!important}
    html[data-dt-excel="true"] .sc-kEYyzF{background:${p.surface}!important;box-shadow:inset 0 -2px #217346!important}
    html[data-dt-excel="true"] .js-gnb-list-item{border-radius:0!important;box-shadow:inset 0 -1px ${p.border}!important}
    html[data-dt-excel="true"] .js-gnb-list-item img{border-radius:3px!important}
    html[data-dt-excel="true"] .js-scroll-area{background-color:${p.bg}!important;background-image:linear-gradient(to right,${p.border} 1px,transparent 1px),linear-gradient(to bottom,${p.border} 1px,transparent 1px)!important;background-size:72px 24px!important;background-position:68px 0!important;background-attachment:local!important}
    html[data-dt-excel="true"] :is([data-dp-native~="message-bubble"],.sc-iyvyFf){border-radius:0!important;box-shadow:none!important;border:0!important}
    html[data-dt-excel="true"] :is([data-dp-native~="message-group"],.sc-drKuOJ){background-color:transparent!important}
    html[data-dt-excel="true"] .js-main-editor{border-radius:0!important;box-shadow:inset 0 0 0 1px #217346!important;background:${p.bg}!important}
    html[data-dt-excel="true"] :is(.bnhPp .sc-ckVGcZ,.bnhPp > button){border-radius:3px!important}
    `;
    if(c.excel)sheet.textContent+=`
    html[data-dt-excel="true"] :is([data-dp-native~="message-group"],.sc-drKuOJ):has(>[class*="js-log-right-content-"]){position:relative!important;padding-left:68px!important;padding-right:8px!important}
    html[data-dt-excel="true"] :is([data-dp-native~="message-group"],.sc-drKuOJ) > .cVZxH{display:block!important;position:absolute!important;left:32px!important;top:0!important;margin:0!important;transform:scale(.888889);transform-origin:top left}
    html[data-dt-excel="true"] :is([data-dp-native~="message-bubble"],.sc-iyvyFf){box-sizing:border-box!important;padding:0 6px!important;background-color:${p.surface}!important;background-image:none!important;box-shadow:inset 0 0 0 1px ${p.border}!important}
    html[data-dt-excel="true"] :is([data-dp-native~="message-bubble"],.sc-iyvyFf):has(>:is([data-dp-native~="message-text"],.sc-chbbiW)){line-height:24px!important}
    html[data-dt-excel="true"] .R2Gwc,html[data-dt-excel="true"] .R2Gwc *{line-height:24px!important}
    html[data-dt-excel="true"] .js-main-editor{position:relative!important;box-shadow:inset 0 1px ${p.border}!important}
    html[data-dt-excel="true"] .js-main-editor::before{content:'fx';position:absolute;left:-17px;top:14px;font:italic 12px Georgia;color:${p.muted};pointer-events:none}
    `;
    if(c.vscode)sheet.textContent+=`
    html[data-dt-palette="true"] :is(.js-user-menu,.BNJ0V){background:${vscodeBackground(c.dark?'#3c3c3c':'#dddddd')}!important;color:${p.text}!important}
    html[data-dt-palette="true"] :is(.js-channel-list,.sc-kEYyzF){background:${p.surface}!important}
    html[data-dt-palette="true"] .sc-hAXbOi{background:${vscodeBackground(c.dark?'#333333':'#ececec')}!important;border-left:1px solid ${p.border}}
    html[data-dt-palette="true"] .js-gnb-list-item{border-radius:0!important}
    html[data-dt-palette="true"] .bnhPp{background:#007acc!important}
    html[data-dt-palette="true"] .js-main-editor{border-radius:2px!important;background:${p.bg}!important;box-shadow:inset 0 0 0 1px ${p.border}!important}
    html[data-dt-palette="true"] [class*="js-log-right-content-"] .R2Gwc :is(button,div){color:${c.dark?'#4ec9b0':'#267f99'}!important}
    html[data-dt-palette="true"] :is([data-dp-native~="message-bubble"],.sc-iyvyFf){box-shadow:inset 3px 0 #007acc!important}
    `;
    if(custom||c.excel||c.vscode)sheet.textContent+=`
    html[data-dt-palette="true"] .bnhPp .sc-ckVGcZ{background:${p.newChat}!important;color:${p.newChatIcon}!important}
    html[data-dt-palette="true"] .bnhPp .sc-ckVGcZ :is(i,svg){color:${p.newChatIcon}!important}
    html[data-dt-palette="true"] .bnhPp > button{background:${p.org}!important;color:${p.orgIcon}!important}
    html[data-dt-palette="true"] .bnhPp > button :is(i,svg){color:${p.orgIcon}!important}
    html[data-dt-palette="true"] .bnhPp :is(.sc-ckVGcZ,button):hover{filter:brightness(1.12)}
    `;
    mountDownloads();scheduleFiles();sheet.textContent+='[data-dt-collapsed]{display:none!important}#dooray-theme-sidebar button::before{content:var(--side-arrow);font:22px Segoe UI}';updateSidebar();scheduleCells();scheduleExcel();host.toggleAttribute('data-excel',c.excel);host.toggleAttribute('data-vscode',c.vscode);if(c.vscode){host.style.setProperty('--vs-panel',p.surface);host.style.setProperty('--vs-input',vscodeBackground(c.dark?'#3c3c3c':'#ffffff'))}else{host.style.removeProperty('--vs-panel');host.style.removeProperty('--vs-input')}host.toggleAttribute('data-light',!c.dark);
    host.style.setProperty('--panel-width' ,a.panelWidth+'px');$('advanced').hidden=!current.detail;host.style.setProperty('--menu-color',c.dark?p.text:'#333333');host.style.setProperty('--menu-hover',c.dark?p.surface:'#e9eef5');
    for(const[k]of colorSpecs)$(k+'Code').textContent=c.dark?c[k]:c.lightColors[k];
    roomExtension?.refresh();
    chatScroll.afterLayout(scrollLayout);
  }
  const builtins=[['original','Dooray 기본 글꼴'],['Malgun Gothic','맑은 고딕'],['Segoe UI','Segoe UI'],['Gulim','굴림'],['Dotum','돋움'],['Batang','바탕']];
  const builtinReady=(async()=>{try{const probe=new FontFace('DT-NotoSansKR-Probe','local("Noto Sans KR"), local("Noto Sans KR Regular"), local("NotoSansKR-Regular")');await probe.load();if(!disposed&&!builtins.some(([name])=>name==='Noto Sans KR')){builtins.splice(1,0,['Noto Sans KR','Noto Sans KR']);refreshFonts();}}catch{}})();
  const library=new Map(),faces=new Map();let db;cleanup.push(()=>{disposed=true;for(const f of faces.values())document.fonts.delete(f);db?.close()});
  function refreshFonts(){const select=$('font');select.replaceChildren();const add=(v,l)=>{const o=document.createElement('option');o.value=v;o.textContent=l;select.append(o)};builtins.forEach(([v,l])=>add(v,l));for(const f of library.values())add(f.family,`${f.name} (${f.kind==='local'?'설치 글꼴':'파일'})`);if(![...select.options].some(o=>o.value===current.font))add(current.font,current.font+' · 로딩/추가 필요');add('__add_font__','＋ 글꼴 추가하기…');select.value=current.font;$('removeFont').disabled=!library.has(current.font)}
  function sync(){$('toastCustom').checked=current.toastCustom;$('toastCustomColors').hidden=!current.toastCustom;for(const k of ['toastSeconds','toastBg','toastText'])$(k).value=current[k];$('themeStyle').value=current.excel?'excel':current.vscode?'vscode':'default';for(const k of ['dark','detail','customColors','excel'])$(k).checked=current[k];for(const[k]of specs){$(k).value=current[k];$(k+'Number').value=Number(current[k].toFixed(3))}for(const[k]of colorSpecs)$(k).value=current.dark?current[k]:current.lightColors[k];refreshFonts();apply()}
  function persist(){try{current=clean(current);localStorage.setItem(KEY,JSON.stringify(current));saved={...current};status('자동 저장됨 · 취소하면 패널을 열기 전 상태로 복원');return true}catch{status('설정을 저장하지 못했습니다. 저장 공간을 확인해 주세요.');return false}}
  for(const id of ['demoModifier','demoKey'])$(id).addEventListener('change',()=>{current[current.excel?'excelShortcut':'vscodeShortcut']=$('demoModifier').value+'+'+$('demoKey').value;persist();if(demoHost)paintDemo()});$('demoPreview').onclick=toggleDemo;
  $('themeStyle').addEventListener('change',()=>{current.excel=$('themeStyle').value==='excel';current.vscode=$('themeStyle').value==='vscode';sync();persist()});
  $('vscodeBrightness').addEventListener('input',()=>{current.vscodeBrightness=Number($('vscodeBrightness').value);apply();persist()});
  $('excelBrightness').addEventListener('input',()=>{current.excelBrightness=Number($('excelBrightness').value);apply();persist()});
  $('font').addEventListener('change',()=>{const value=$('font').value;if(value==='__add_font__'){$('font').value=current.font;$('fontManager').open=true;$('localFont').focus();$('fontManager').scrollIntoView({block:'nearest'});return}current.font=value;refreshFonts();apply();persist()});
  function close(rollback){if(rollback){current={...baseline};sync();persist()}else baseline={...current};open=false;$('panel').hidden=true;$('toggle').setAttribute('aria-expanded','false');$('toggle').focus()}
  $('toggle').onclick=()=>{roomExtension?.open();if(open){close(false);return}baseline={...current};open=true;$('panel').hidden=false;$('toggle').setAttribute('aria-expanded','true');status('변경 내용은 자동으로 저장됩니다.');$('dark').focus()};
  for(const k of ['dark','detail','customColors','excel'])$(k).addEventListener('input',()=>{current[k]=$(k).checked;if(k==='excel'&&current.excel)current.vscode=false;sync();persist()});
  for(const[k]of colorSpecs)$(k).addEventListener('input',()=>{if(current.dark)current[k]=$(k).value;else current.lightColors={...current.lightColors,[k]:$(k).value};apply();persist()});
  for(const[k,,min,max,step]of specs)for(const suffix of ['','Number'])$(k+suffix).addEventListener('input',()=>{const e=$(k+suffix);if(!e.value||!Number.isFinite(e.valueAsNumber))return;current[k]=Math.round(Math.min(max,Math.max(min,e.valueAsNumber))/step)*step;$(k+(suffix?'':'Number')).value=Number(current[k].toFixed(3));apply();persist()});
  $('toastCustom').addEventListener('input',()=>{current.toastCustom=$('toastCustom').checked;$('toastCustomColors').hidden=!current.toastCustom;persist();styleDownloadToast()});$('toastStartPreview').onclick=()=>showDownloadToast('다운로드 중..');
  for(const k of ['toastSeconds','toastBg','toastText'])$(k).addEventListener('input',()=>{if(k==='toastSeconds'&&!Number.isFinite($(k).valueAsNumber))return;current[k]=k==='toastSeconds'?Math.max(1,Math.min(30,Math.round($(k).valueAsNumber))):$(k).value;persist();styleDownloadToast();});$('toastPreview').onclick=()=>showDownloadToast('다운로드 완료');
  $('reset').onclick=()=>{current={...defaults};sync();persist()};$('cancel').onclick=()=>close(true);
  $('save').onclick=()=>{if(persist()){baseline={...current};close(false)}};
  shadow.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close(true)}});
  function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('local-dooray-theme-fonts',1);r.onupgradeneeded=()=>r.result.createObjectStore('fonts',{keyPath:'family'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
  function transaction(mode,fn){return new Promise((resolve,reject)=>{if(!db)return reject(Error('폰트 저장소가 준비되지 않았습니다.'));const tx=db.transaction('fonts',mode),request=fn(tx.objectStore('fonts'));tx.oncomplete=()=>resolve(request?.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('저장 취소'))})}
  async function loadFace(f){const source=f.kind==='local'?`local(${JSON.stringify(f.name)})`:f.data;const face=new FontFace(f.family,source);await face.load();if(disposed)return;document.fonts.add(face);faces.set(f.family,face);return face}
  async function addFont(f){await fontReady;if(library.size>=30)throw Error('추가 폰트는 최대 30개입니다.');const bytes=[...library.values()].reduce((n,x)=>n+(x.data?.byteLength||0),0)+(f.data?.byteLength||0);if(bytes>100*1024*1024)throw Error('폰트 합계가 100MB를 넘습니다.');const face=await loadFace(f);try{await transaction('readwrite',s=>s.put(f))}catch(e){if(face)document.fonts.delete(face);faces.delete(f.family);throw e}if(disposed)return;library.set(f.family,f);current.font=f.family;sync();persist()}
  $('addLocal').onclick=async()=>{const name=$('localFont').value.trim();if(!name)return;$('addLocal').disabled=true;try{await addFont({family:'DT-'+crypto.randomUUID(),name,kind:'local'});$('fontStatus').textContent='글꼴을 추가했습니다. 목록과 선택이 자동 저장되었습니다.';$('localFont').value=''}catch{$('fontStatus').textContent='추가하지 못했습니다. 설치된 글꼴의 정확한 이름과 저장 공간을 확인해 주세요.'}finally{$('addLocal').disabled=false}};
  $('fontFile').onchange=async()=>{const files=[...$('fontFile').files];$('fontFile').disabled=true;const messages=[];for(const file of files){try{if(!/\.(ttf|otf|woff2?)$/i.test(file.name))throw Error('지원하지 않는 형식');if(file.size>20*1024*1024)throw Error('20MB 초과');await addFont({family:'DT-'+crypto.randomUUID(),name:file.name,kind:'file',data:await file.arrayBuffer()});messages.push(file.name+': 추가 완료')}catch(e){messages.push(file.name+': 실패 ('+(e.message||'폰트 로드 오류')+')')}}$('fontStatus').textContent=messages.join(' / ');$('fontFile').value='';$('fontFile').disabled=false};
  $('removeFont').onclick=async()=>{const family=current.font;if(!library.has(family))return;try{await transaction('readwrite',s=>s.delete(family));document.fonts.delete(faces.get(family));faces.delete(family);library.delete(family);current.font='original';if(baseline.font===family)baseline.font='original';sync();persist();$('fontStatus').textContent='추가 폰트를 삭제했습니다.'}catch{$('fontStatus').textContent='폰트를 삭제하지 못했습니다.'}};
  const fontReady=(async()=>{await builtinReady;try{db=await openDB();const all=await transaction('readonly',s=>s.getAll());let failed=0;for(const f of all){library.set(f.family,f);try{await loadFace(f)}catch{failed++}}if(!disposed){refreshFonts();apply();if(failed)$('fontStatus').textContent=`${failed}개 폰트를 불러오지 못했습니다. 다시 추가해 주세요.`}}catch{if(!disposed)$('fontStatus').textContent='폰트 저장소를 열지 못했습니다. 기본 글꼴은 사용할 수 있습니다.'}})();
  let updateBusy=false,updateRevision=0;
  function createUpdateNotice({button,badge,version,storage,getActions}){
    const key='dooray-plus.update-notified.v1';let lastNotified='',available='';
    const valid=v=>typeof v==='string'&&/^\d+\.\d+\.\d+$/.test(v)&&v.length<40;
    const newer=(a,b)=>{if(!valid(a)||!valid(b))return false;const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i];return false};
    const paint=()=>{badge.hidden=!available;const label=available?'두레이 플러스 · '+available+' 업데이트 있음':'두레이 플러스 설정';button.title=label;button.setAttribute('aria-label',label)};
    return result=>{
      // A failed/checking response must not manufacture availability or dismiss an existing dot.
      if(!result||['error','checking','downloading','idle','restarting'].includes(result.status))return;
      const active=valid(result.active)?result.active:version;
      const candidates=[result.available,result.pending].filter(v=>newer(v,active));
      if(candidates.length)available=candidates.reduce((a,b)=>newer(a,b)?a:b);
      else if(['current','ahead'].includes(result.status)){available='';paint();return}else return;
      paint();if(result.backgroundNotice===true)return;let seen=lastNotified;try{const stored=storage.getItem(key);if(valid(stored)&&(!seen||newer(stored,seen)))seen=stored}catch{}
      if(seen&&!newer(available,seen))return;
      try{
        const actions=getActions();if(!actions?.stores?.uiState?.isMainView||actions.stores.globalSettingStore?.notification==='never'||typeof actions.nativeActions?.sendNotification!=='function')return;
        const channelId=actions.stores.mainDetailUiState?.currentChannelId;if(!channelId)return;
        actions.nativeActions.sendNotification({title:'두레이 플러스 업데이트',body:available+' 버전이 출시 됐습니다.\n업데이트 해주세요!',channelId,onClick:()=>button.click()});
        lastNotified=available;try{storage.setItem(key,available)}catch{}
      }catch{} // Keep the dot; retry after the native bridge becomes ready.
    };
  }
  const updateNotice=createUpdateNotice({button:$('toggle'),badge:$('updateBadge'),version:VERSION,storage:{getItem:k=>localStorage.getItem(k),setItem:(k,v)=>localStorage.setItem(k,v)},getActions:()=>{
    for(const node of [document.querySelector('.js-main-editor'),...document.querySelectorAll('#root > *')]){let f=node?.[Object.keys(node).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<100;i++,f=f.return)if(f.memoizedProps?.actions?.stores)return f.memoizedProps.actions;}return null;
  }});
  const showUpdate=result=>{updateNotice(result);const button=$('installUpdate');button.hidden=!(result.available||result.pending);button.disabled=updateBusy||result.status==='restarting';button.textContent=result.kind==='installer'?'설치 업데이트하기':'업데이트하기';$('updateStatus').textContent=result.status==='error'?'업데이트 처리 실패: '+result.error:result.status==='restarting'?'두레이를 종료하고 업데이트 후 다시 실행합니다…':result.pending?result.pending+' 준비 완료 · 업데이트하기를 누르면 자동으로 재실행합니다.':result.available?result.available+(result.kind==='installer'?' 설치 업데이트가 있습니다. UAC 승인이 필요합니다.':' 새 버전이 있습니다. 업데이트 후 자동 재실행합니다.'):result.status==='ahead'?'새 업데이트가 없습니다.':result.status==='current'?(result.warning?'패치 확인 완료. '+result.warning:'최신 버전입니다. ('+(result.active||VERSION)+')'):'업데이트 확인 대기 중입니다.';if(result.warning&&result.status!=='current')$('updateStatus').textContent+=' '+result.warning;};
  const runUpdate=async op=>{updateRevision++;updateBusy=true;$('checkUpdate').disabled=true;$('installUpdate').disabled=true;$('updateStatus').textContent=op==='update-install'?'업데이트 다운로드 및 검증 중…':'최신 버전 확인 중…';let result;try{result=await downloadRPC(op);if(result.status==='prepared'){const preflight=await downloadRPC('update-preflight');if(preflight.downloads)throw Error('진행 중인 파일 작업이 있습니다. 완료 후 다시 눌러 주세요.');if(preflight.drafts&&!window.confirm('작성 중인 내용이 있습니다. 저장되지 않은 내용이 사라질 수 있습니다. 두레이를 종료하고 업데이트할까요?')){await downloadRPC('update-cancel');result={status:'error',error:'업데이트 적용을 취소했습니다. 준비된 패치는 유지됩니다.'};}else{result=await downloadRPC('update-apply',{token:result.token});}}}catch(e){await downloadRPC('update-cancel').catch(()=>{});result={status:'error',error:e.message}}finally{updateBusy=false;$('checkUpdate').disabled=false;showUpdate(result)}};
  $('checkUpdate').onclick=()=>runUpdate('update-check');$('installUpdate').onclick=()=>runUpdate('update-install');
  const pollUpdate=()=>{if(!disposed&&!updateBusy&&!updatePolling){updatePolling=true;const revision=updateRevision;downloadRPC('update-status').then(result=>{if(!disposed&&!updateBusy&&revision===updateRevision)showUpdate(result)}).catch(()=>{}).finally(()=>{updatePolling=false})}};let updatePolling=false;const updatePoll=setInterval(pollUpdate,5000);pollUpdate();cleanup.push(()=>clearInterval(updatePoll));
  $('export').onclick=()=>{const payload={format:'DoorayPlus',version:2,settings:current};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Dooray-Plus-settings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status('설정 JSON 다운로드를 요청했습니다. 폰트 파일은 제외됩니다.')};
  $('import').onclick=()=>$('importFile').click();$('importFile').onchange=async()=>{try{const f=$('importFile').files[0];if(!f)return;if(f.size>65536)throw Error('파일이 너무 큽니다.');const data=JSON.parse(await f.text());if(!['DoorayPlus','DoorayTheme'].includes(data.format)||data.version!==2||!data.settings)throw Error('지원하지 않는 설정 파일입니다.');current=clean(data.settings);sync();persist();status('설정을 가져와 저장했습니다. 필요한 폰트를 추가해 주세요.')}catch(e){status('가져오기 실패: '+e.message)}finally{$('importFile').value=''}};
  try{cleanup.push(installInlineVideos({scrollController:chatScroll}))}catch(error){console.warn('Inline video unavailable',error.message)}
  try{roomExtension=installDoorayRooms({themeShadow:shadow,onError:status,getTheme:()=>bubbleTheme});cleanup.push(()=>roomExtension.dispose())}catch(error){console.warn('Room customization unavailable',error.message)}
  let emoticonExtension;
  const startEmoticons=()=>{emoticonExtension=installCustomEmoticons({rpc:downloadRPC,scrollController:chatScroll});cleanup.push(emoticonExtension)};
  try{startEmoticons()}catch(error){console.warn('Custom emoticons unavailable',error.message)}
  const showEmoticonHealth=()=>{const d=emoticonExtension?.diagnostics();if(d)$('emoticonHealth').textContent=d.error?'메시지 인식 오류: '+d.error:'이미지 표시 '+d.ready+' · 대기 '+d.waiting+' · 로딩 실패 '+d.failed+' (인식한 메시지 '+d.messages+'개)'};
  $('repairEmoticons').onclick=()=>{try{if(!emoticonExtension)startEmoticons();emoticonExtension.repair();showEmoticonHealth()}catch(error){$('emoticonHealth').textContent='복구 실패: '+error.message}};
  const emoticonHealthTimer=setInterval(()=>{if(open)showEmoticonHealth()},2000);cleanup.push(()=>clearInterval(emoticonHealthTimer));
  window.__doorayTheme={version:VERSION,ready:fontReady,isHealthy(){return !disposed&&!faulted&&nativeDOM.ready()&&host.isConnected&&!!downloadHost?.isConnected&&!!shadow.getElementById('toggle')&&!!downloadShadow?.getElementById('toggle')},get settings(){return {...current}},get saved(){return {...saved}},get diagnostics(){return {paletteCompiles:compileCount,nativeDOM:nativeDOM.diagnostics(),fallbackMenu:host.hasAttribute('data-floating'),rooms:roomExtension?.diagnostics()}},repair(){nativeDOM.refresh();mountMenu();mountDownloads()},remove(){stop('removed')}};
  const onError=e=>{if(String(e.filename||'').includes('dooray-theme-extension')||String(e.error?.stack||'').includes('dooray-theme-extension'))stop('extension-error')};
  window.addEventListener('error',onError);cleanup.push(()=>window.removeEventListener('error',onError));
  cleanup.push(nativeDOM.subscribe(()=>{if(disposed||faulted)return;chatScroll.refresh();mountMenu();mountDownloads();scheduleCells();updateSidebar()}));
  sync();return 'installed '+VERSION;
})();

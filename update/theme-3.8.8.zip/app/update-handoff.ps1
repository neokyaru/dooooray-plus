﻿param([Parameter(Mandatory=$true)][string]$Job)
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath $Job -Raw -Encoding UTF8 | ConvertFrom-Json
$jobDir=Split-Path -Parent $Job
$guard=New-Object System.Threading.Mutex($false,'Local\DoorayPlus-UpdateHandoff')
if(-not $guard.WaitOne(0)){exit 2}
$closed=$false
function Result([string]$phase,[string]$message){
 @{phase=$phase;message=$message;version=$config.version;at=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $jobDir 'result.json') -Encoding UTF8
}
function DoorayProcesses {
 @(Get-Process -Name DoorayMessenger -ErrorAction SilentlyContinue | Where-Object {try{$_.Path -and [String]::Equals([IO.Path]::GetFullPath($_.Path),[IO.Path]::GetFullPath($config.dooray),[StringComparison]::OrdinalIgnoreCase)}catch{$false}})
}
function FileHash([string]$file){
 $stream=[IO.File]::OpenRead($file);$algorithm=[Security.Cryptography.SHA256]::Create()
 try{([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$algorithm.Dispose()}
}
function Reopen {
 if(@(DoorayProcesses).Count -eq 0){Start-Process -FilePath $config.dooray -WorkingDirectory (Split-Path -Parent $config.dooray) | Out-Null}
}
try {
 if($config.kind -notin @('patch','installer')){throw 'Invalid update kind'}
 if(-not (Test-Path -LiteralPath $config.dooray -PathType Leaf)){throw 'Dooray executable missing'}
 if($config.kind -eq 'installer'){
  if((FileHash $config.installer.file) -ne $config.installer.sha256){throw 'Installer hash mismatch'}
 }
 Add-Type -TypeDefinition @'
using System;using System.Linq;public static class DoorayExit {
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr menu);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern int GetMenuString(IntPtr menu,uint item,System.Text.StringBuilder text,int length,uint flags);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool PostMessage(IntPtr window,uint message,UIntPtr wparam,IntPtr lparam);
 delegate bool EnumWindowProc(IntPtr window,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowProc callback,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
 static uint? ExitCommand(IntPtr menu){
  if(menu==IntPtr.Zero)return null;
  for(int i=0;i<GetMenuItemCount(menu);i++){
   var text=new System.Text.StringBuilder(256);GetMenuString(menu,(uint)i,text,text.Capacity,0x400);
   string label=System.Text.RegularExpressions.Regex.Replace(text.ToString(),@"\(&.\)|&|\t.*","").Trim();
   if(new[]{"끝내기","종료","Exit","Quit"}.Any(value=>String.Equals(value,label,StringComparison.OrdinalIgnoreCase))){uint command=GetMenuItemID(menu,i);if(command!=UInt32.MaxValue)return command;}
   var child=ExitCommand(GetSubMenu(menu,i));if(child.HasValue)return child;
  }return null;
 }
public static bool Request(int id){bool requested=false;EnumWindows((window,data)=>{uint pid;GetWindowThreadProcessId(window,out pid);if(pid!=(uint)id)return true;uint? command=ExitCommand(GetMenu(window));if(command.HasValue){requested=PostMessage(window,0x111,new UIntPtr(command.Value),IntPtr.Zero);if(requested)return false;}return true;},IntPtr.Zero);return requested;}}
'@
 Start-Sleep -Milliseconds 800
 Result 'closing' '두레이를 종료하고 있습니다.'
 foreach($process in (DoorayProcesses)){if(-not [DoorayExit]::Request($process.Id)){[void]$process.CloseMainWindow()}}
 $deadline=[DateTime]::UtcNow.AddSeconds(25)
 while(@(DoorayProcesses).Count -gt 0){if([DateTime]::UtcNow -gt $deadline){throw '두레이가 종료되지 않았습니다. 확인 창을 처리한 뒤 다시 시도하세요. 강제 종료하지 않았습니다.'};Start-Sleep -Milliseconds 250}
 $closed=$true
 if($config.kind -eq 'installer'){
  Result 'installing' '관리자 권한 승인을 기다립니다.'
  if((FileHash $config.installer.file) -ne $config.installer.sha256){throw 'Installer hash mismatch'}
  $setup=Start-Process -FilePath $config.installer.file -ArgumentList '--update' -Verb RunAs -Wait -PassThru -WindowStyle Hidden
  if($setup.ExitCode -ne 0){throw ('설치가 완료되지 않았습니다. 종료 코드: '+$setup.ExitCode)}
 }else{
  Result 'applying' '패치를 적용하고 있습니다.'
  $deadline=[DateTime]::UtcNow.AddSeconds(120)
  while($true){
   $state=$null;try{$state=Get-Content -LiteralPath (Join-Path $config.data 'update-state.json') -Raw -Encoding UTF8 | ConvertFrom-Json}catch{}
   if($state -and $state.active -eq $config.version){break}
   if($state -and $state.failed -contains $config.version){throw '새 패치 실행에 실패해 이전 버전으로 복구되었습니다.'}
   if([DateTime]::UtcNow -gt $deadline){throw '패치 적용 대기 시간이 초과되었습니다. 기존 두레이를 다시 실행합니다.'}
   Start-Sleep -Milliseconds 500
  }
 }
 Reopen
 Result 'complete' '업데이트 적용 후 두레이를 다시 실행했습니다.'
}catch{
 $message=$_.Exception.Message
 if($closed){try{Reopen}catch{$message+=' 재실행 실패: '+$_.Exception.Message}}
 Result 'error' $message
 Add-Type -AssemblyName System.Windows.Forms
 [void][System.Windows.Forms.MessageBox]::Show($message,'두레이 플러스 업데이트')
}finally{$guard.ReleaseMutex();$guard.Dispose()}

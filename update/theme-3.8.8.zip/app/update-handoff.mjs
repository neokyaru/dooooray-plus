import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
import {atomicJSON,hash} from './update-store.mjs';
export async function prepareHandoff({root,data,version,kind,installer}){
 const dooray=path.join(path.dirname(root),'DoorayMessenger.exe');if(!(await fs.stat(dooray)).isFile())throw Error('두레이 실행 파일을 찾지 못했습니다.');
 const token=crypto.randomUUID(),dir=path.join(data,'handoffs',token);await fs.mkdir(dir,{recursive:true});
 const config={token,version,kind,dooray,root,data,installer:installer||null,createdAt:Date.now()};
 await fs.copyFile(path.join(path.dirname(fileURLToPath(import.meta.url)),'update-handoff.ps1'),path.join(dir,'run.ps1'));
 await atomicJSON(path.join(dir,'job.json'),config);return {token,dir,config};
}
export async function startHandoff(job,spawnProcess=spawn){
 if(Date.now()-job.config.createdAt>15*60*1000)throw Error('업데이트 준비 시간이 만료되었습니다. 다시 확인해 주세요.');
 if(job.config.installer&&hash(await fs.readFile(job.config.installer.file))!==job.config.installer.sha256)throw Error('Installer verification failed');
 const exe=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const child=spawnProcess(exe,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(job.dir,'run.ps1'),'-Job',path.join(job.dir,'job.json')],{detached:true,windowsHide:true,stdio:'ignore'});
 await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject)});child.unref();
}

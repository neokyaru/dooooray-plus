// One owner for conversation bottom-follow. Never sends messages, replaces a
// native handler or infers a send from composing/modified Enter events.
function installChatScroll({document=globalThis.document,getTargets=()=>[],now=()=>performance.now(),requestFrame,cancelFrame,ResizeObserver,MutationObserver}={}){
  const win=document.defaultView||globalThis;
  requestFrame ||= win.requestAnimationFrame.bind(win);cancelFrame ||= win.cancelAnimationFrame.bind(win);
  ResizeObserver ||= win.ResizeObserver;MutationObserver ||= win.MutationObserver;
  const states=new Map(),observedRefs=new Map(),tokenOwner={};let disposed=false,refreshing=false,writes=0;
  const geometry=scroll=>({top:Math.max(0,Number(scroll.scrollTop)||0),height:Number(scroll.scrollHeight)||0,client:Number(scroll.clientHeight)||0});
  const near=m=>Math.max(0,m.height-m.client)-m.top<=3;
  const changed=(a,b)=>Math.abs(a.height-b.height)>.5||Math.abs(a.client-b.client)>.5;
  const hasMessages=scroll=>!!scroll.querySelector('[data-dp-native~="message-group"],[data-logid]');
  const editable=node=>!!node?.closest?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]');
  function relevant(state,node){return !node||node===state.scroll||state.scroll.contains(node)||node.contains?.(state.scroll)||state.editor&&(node===state.editor||state.editor.contains(node)||node.contains?.(state.editor));}
  function current(state){return !disposed&&states.get(state.scroll)===state&&state.scroll.isConnected;}
  function cancel(state){state.follow=false;state.allowRearm=false;state.inputFollow=null;state.revision++;state.remaining=0;state.writtenTop=null;if(state.frame){cancelFrame(state.frame);state.frame=0}}
  function measureAnchor(state){
    const viewport=state.scroll.getBoundingClientRect();
    const candidates=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');
    for(const node of candidates.length?candidates:state.content.children){const rect=node.getBoundingClientRect();if(rect.height>0&&rect.bottom>viewport.top&&rect.top<viewport.bottom)return {node,offset:rect.top-viewport.top};}
    return null;
  }
  function write(state,top){
    if(!current(state))return;state.writing=true;
    try{state.scroll.scrollTop=top;writes++;state.metrics=geometry(state.scroll);state.writtenTop=state.metrics.top;}finally{state.writing=false}
  }
  function schedule(state){
    if(!current(state)||!state.follow||state.drag||state.touchMoving)return;
    state.remaining=3;state.stable=0;if(!state.frame)state.frame=requestFrame(()=>settle(state));
  }
  function settle(state){
    state.frame=0;refresh();if(!current(state)||!state.follow||state.drag||state.touchMoving)return;
    const before=geometry(state.scroll);
    // Newly mounted empty panes may still receive Dooray's saved reading
    // position. Measure that native restoration before taking ownership.
    if(state.unsettled){if(before.height>before.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(before)}state.metrics=before;state.remaining=0;return;}
    const gap=Math.max(0,before.height-before.client)-before.top;
    if(gap>.5)write(state,state.scroll.scrollHeight);
    const after=geometry(state.scroll);state.stable=!changed(before,after)&&Math.max(0,after.height-after.client)-after.top<=.5?state.stable+1:0;
    state.metrics=after;state.remaining--;
    if(state.remaining>0&&state.stable<2)state.frame=requestFrame(()=>settle(state));
  }
  function onScroll(state){
    refresh();if(!current(state))return;const value=geometry(state.scroll),old=state.metrics;
    if(state.writing){state.metrics=value;return;}
    const layoutChanged=changed(value,old),own=state.writtenTop!==null&&Math.abs(value.top-state.writtenTop)<.75;
    // Native Enter handling can restore the pre-layout bottom after our first
    // correction. Recognize only that recent range; older history jumps and
    // any explicit reading gesture still cancel immediately.
    const input=state.inputFollow,age=input?now()-input.at:Infinity;
    const restoring=!!input&&age>=0&&age<=600&&value.top>=input.top-3&&Math.max(0,value.height-value.client)>input.max+.5;
    if(input&&(age<0||age>600))state.inputFollow=null;
    state.writtenTop=null;
    if(state.drag||state.touchMoving){state.follow=false;}
    else if(state.unsettled&&layoutChanged){if(value.height>value.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(value)}}
    else if(state.follow&&!own&&value.top<old.top-.5&&!layoutChanged&&!restoring){cancel(state);}
    else if(!state.follow&&near(value)&&(value.top>old.top+.5||state.allowRearm)){state.follow=true;state.allowRearm=false;}
    else if(!state.follow&&!layoutChanged&&!own&&Math.abs(value.top-old.top)>.5){state.revision++;}
    state.metrics=value;if(state.follow&&(layoutChanged||restoring))schedule(state);
  }
  const resize=ResizeObserver?new ResizeObserver(entries=>{refresh();for(const state of states.values())if(entries.some(entry=>state.observed.has(entry.target)))schedule(state)}):null;
  function observeSize(state){
    if(!state.sizeDirty)return;state.sizeDirty=false;
    const next=new Set([state.scroll,state.content]);if(state.editor)next.add(state.editor);
    // Dooray can put the message groups directly in a fixed-height scroller;
    // observing that viewport alone would miss late fonts and inline images.
    for(const child of [...state.content.children].slice(-512))next.add(child);
    const last=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');if(last.length)next.add(last[last.length-1]);
    for(const node of state.observed)if(!next.has(node))releaseSize(node);
    for(const node of next)if(!state.observed.has(node)){const count=observedRefs.get(node)||0;if(!count)resize?.observe(node);observedRefs.set(node,count+1)}
    state.observed=next;
  }
  function releaseSize(node){const count=observedRefs.get(node)||0;if(count<=1){observedRefs.delete(node);resize?.unobserve(node)}else observedRefs.set(node,count-1);}
  function attach(target){
    const scroll=target.scroll,metrics=geometry(scroll),state={scroll,content:target.content||scroll,editor:target.editor||null,roomKey:target.roomKey,metrics,follow:near(metrics),frame:0,remaining:0,stable:0,revision:0,writtenTop:null,writing:false,drag:false,touchMoving:false,touchY:null,allowRearm:false,inputFollow:null,observed:new Set(),sizeDirty:true,unsettled:metrics.height<=metrics.client&&!hasMessages(scroll)};
    state.scrollEvent=()=>onScroll(state);
    state.wheel=event=>{if(event.deltaY<0)cancel(state);else if(event.deltaY>0){state.allowRearm=true;if(near(geometry(scroll))){state.follow=true;schedule(state)}}};
    state.pointer=event=>{const rect=scroll.getBoundingClientRect(),width=Math.max(12,(Number(scroll.offsetWidth)||scroll.clientWidth)-scroll.clientWidth);if(event.target===scroll&&event.pointerType!=='touch'&&event.clientX>=rect.right-width&&event.clientX<=rect.right+1){state.drag=true;cancel(state)}};
    state.touchStart=event=>{state.touchY=event.touches?.[0]?.clientY??null;state.touchMoving=false;};
    state.touchMove=event=>{const y=event.touches?.[0]?.clientY;if(state.touchY!==null&&Number.isFinite(y)&&Math.abs(y-state.touchY)>2){state.touchMoving=true;cancel(state)}};
    scroll.addEventListener('scroll',state.scrollEvent,{passive:true});scroll.addEventListener('wheel',state.wheel,{passive:true});scroll.addEventListener('pointerdown',state.pointer,{passive:true});scroll.addEventListener('touchstart',state.touchStart,{passive:true});scroll.addEventListener('touchmove',state.touchMove,{passive:true});
    states.set(scroll,state);observeSize(state);return state;
  }
  function detach(state){
    cancel(state);for(const node of state.observed)releaseSize(node);state.observed.clear();
    for(const [event,handler]of [['scroll',state.scrollEvent],['wheel',state.wheel],['pointerdown',state.pointer],['touchstart',state.touchStart],['touchmove',state.touchMove]])state.scroll.removeEventListener(event,handler);
    states.delete(state.scroll);
  }
  function refresh(){
    if(disposed||refreshing)return;refreshing=true;
    try{
      let targets;try{targets=getTargets()||[]}catch{targets=[]}
      const selected=new Map();for(const target of targets){if(!target?.scroll?.isConnected||target.scroll.clientHeight<=0||target.roomKey===undefined||target.roomKey===null||target.roomKey==='')continue;if(!selected.has(target.scroll))selected.set(target.scroll,target);}
      for(const state of states.values()){const target=selected.get(state.scroll);if(!target||target.roomKey!==state.roomKey)detach(state);}
      for(const target of selected.values()){
        let state=states.get(target.scroll);if(!state){attach(target);continue;}
        const content=target.content||target.scroll,editor=target.editor||null;
        if(content!==state.content||editor!==state.editor){state.content=content;state.editor=editor;state.sizeDirty=true;observeSize(state);schedule(state)}else observeSize(state);
      }
    }finally{refreshing=false}
  }
  function notifyLayout(node){if(disposed)return;refresh();for(const state of states.values())if(relevant(state,node))schedule(state);}
  function beforeLayout(node){
    if(disposed)return null;refresh();const records=[];
    for(const state of states.values())if(relevant(state,node))records.push({state,revision:state.revision,roomKey:state.roomKey,follow:state.follow,anchor:state.follow?null:measureAnchor(state)});
    return {owner:tokenOwner,records};
  }
  function afterLayout(token){
    if(disposed||token?.owner!==tokenOwner)return;refresh();
    for(const record of token.records){const state=record.state;if(!current(state)||record.roomKey!==state.roomKey||record.revision!==state.revision)continue;
      if(record.follow&&state.follow){schedule(state);continue;}
      // Explicit decoration/theme changes can occur above a reader. Preserve
      // a real visible anchor, and avoid doubling the browser's own anchoring.
      const anchor=record.anchor;if(!record.follow&&!state.follow&&anchor?.node.isConnected&&state.scroll.contains(anchor.node)){
        const offset=anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top,delta=offset-anchor.offset;
        if(Math.abs(delta)>.5)write(state,state.scroll.scrollTop+delta);
      }
    }
  }
  const key=event=>{
    if(disposed)return;refresh();for(const state of states.values())state.inputFollow=null;
    if(event.isComposing||event.keyCode===229)return;
    for(const state of states.values())if(relevant(state,event.target)){
      if(editable(event.target)){
        if(event.key==='Enter'&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&state.editor?.contains(event.target)&&state.follow){const value=geometry(state.scroll);state.unsettled=false;state.inputFollow={at:now(),top:value.top,max:Math.max(0,value.height-value.client)};schedule(state)}
        continue;
      }
      if(['ArrowUp','PageUp','Home'].includes(event.key)||event.key===' '&&event.shiftKey)cancel(state);
      else if(['ArrowDown','PageDown','End'].includes(event.key)||event.key===' ')state.allowRearm=true;
    }
  };
  // Clicking a native search/quote jump can target the old bottom by chance.
  // Clear only the short Enter hint; ordinary clicks keep following enabled.
  const pointerIntent=()=>{for(const state of states.values())state.inputFollow=null;};
  const pointerUp=()=>{for(const state of states.values())if(state.drag){state.drag=false;if(near(geometry(state.scroll))){state.follow=true;schedule(state)}}};
  const touchEnd=()=>{for(const state of states.values()){const moved=state.touchMoving;state.touchY=null;state.touchMoving=false;if(moved&&near(geometry(state.scroll))){state.follow=true;schedule(state)}}};
  const mutation=MutationObserver?new MutationObserver(records=>{
    if(disposed)return;for(const state of states.values())if(records.some(record=>relevant(state,record.target)))state.sizeDirty=true;
    refresh();for(const state of states.values())if(records.some(record=>relevant(state,record.target)))schedule(state);
  }):null;
  mutation?.observe(document.documentElement||document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class','hidden']});
  const onLoad=event=>notifyLayout(event.target),onResize=()=>notifyLayout(),onFonts=()=>notifyLayout();
  document.addEventListener('keydown',key,true);document.addEventListener('pointerdown',pointerIntent,true);document.addEventListener('pointerup',pointerUp,true);document.addEventListener('pointercancel',pointerUp,true);document.addEventListener('touchend',touchEnd,true);document.addEventListener('touchcancel',touchEnd,true);document.addEventListener('load',onLoad,true);document.addEventListener('loadedmetadata',onLoad,true);win.addEventListener('resize',onResize);
  document.fonts?.addEventListener?.('loadingdone',onFonts);document.fonts?.ready?.then(()=>{if(!disposed)onFonts()}).catch(()=>{});
  refresh();
  return {
    refresh,beforeLayout,afterLayout,notifyLayout,
    isFollowing(node){if(disposed)return false;refresh();return [...states.values()].some(state=>relevant(state,node)&&state.follow)},
    diagnostics(){return {targets:states.size,following:[...states.values()].filter(state=>state.follow).length,pending:[...states.values()].filter(state=>state.frame).length,writes}},
    dispose(){if(disposed)return;disposed=true;mutation?.disconnect();resize?.disconnect();for(const state of [...states.values()])detach(state);document.removeEventListener('keydown',key,true);document.removeEventListener('pointerdown',pointerIntent,true);document.removeEventListener('pointerup',pointerUp,true);document.removeEventListener('pointercancel',pointerUp,true);document.removeEventListener('touchend',touchEnd,true);document.removeEventListener('touchcancel',touchEnd,true);document.removeEventListener('load',onLoad,true);document.removeEventListener('loadedmetadata',onLoad,true);win.removeEventListener('resize',onResize);document.fonts?.removeEventListener?.('loadingdone',onFonts);}
  };
}

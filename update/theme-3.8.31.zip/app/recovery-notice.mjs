// Mutable, per-user failure notices. This module never installs, elevates,
// changes update state, or describes an unchecked version as current/latest.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const reasons=new Set(['load-timeout','connection-unavailable','engine-error']);
const kinds=new Set(['patch','installer','unknown']);
const failurePhases=new Set(['connecting','retrying','blocked','waiting']);
const pauseReasons=new Set(['login','login-page','waiting-login','signed-out','handoff','update-handoff']);
const validVersion=value=>typeof value==='string'&&/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(value);
const later=(left,right)=>{if(!validVersion(left)||!validVersion(right))return false;const a=left.split('.').map(Number),b=right.split('.').map(Number);for(let i=0;i<3;i++)if(a[i]!==b[i])return a[i]>b[i];return false;};
const positiveTime=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=8640000000000000;
function normalize(status,fallback){
  status=status&&typeof status==='object'?status:{};
  const version=status.version===undefined?fallback:status.version;
  const available=status.updateChecked===true&&later(status.available,version)?status.available:null,pending=later(status.pending,version)?status.pending:null;
  return {
    version:validVersion(version)?version:null,phase:typeof status.phase==='string'?status.phase:'unknown',
    enabled:status.enabled===true,paused:status.paused===true||pauseReasons.has(status.reason),
    present:status.present===true?true:status.present===false?false:null,
    nativeRunning:status.nativeRunning===true?true:status.nativeRunning===false?false:null,
    nativeInteractive:status.nativeInteractive===true,retryCount:Number.isSafeInteger(status.retryCount)&&status.retryCount>=0?status.retryCount:0,
    reason:typeof status.reason==='string'?status.reason:'',kind:available?(kinds.has(status.kind)?status.kind:'unknown'):pending?'patch':'unknown',available,pending,
  };
}
function noticeReason(status){
  const code=status.reason.split(';',1)[0].trim();
  if(status.phase==='blocked'||['runtime-error','helper-exited','bootstrap-error','integrity-failure'].includes(code))return 'engine-error';
  return status.present!==true?'connection-unavailable':'load-timeout';
}
function safeHistory(value){
  if(value?.schema!==1||!Array.isArray(value.entries)||value.entries.length>64)return [];
  const records=new Map();
  for(const item of value.entries){
    if(!item||!validVersion(item.version)||!reasons.has(item.reason)||!positiveTime(item.at))continue;
    const key=item.version+'|'+item.reason,old=records.get(key);
    if(!old||old.at<item.at)records.set(key,{version:item.version,reason:item.reason,at:item.at});
  }
  return [...records.values()];
}

export class RecoveryNoticePolicy {
  constructor({version,graceMs=90000,cooldownMs=6*60*60*1000,globalCooldownMs=10*60*1000,retryMs=30000,maxAttempts=3}={}){
    this.version=version;this.graceMs=graceMs;this.cooldownMs=cooldownMs;this.globalCooldownMs=globalCooldownMs;this.retryMs=retryMs;this.maxAttempts=maxAttempts;
    this.history=new Map();this.lastGlobal=-Infinity;this.episode=null;this.sequence=0;
  }
  hydrate(value,{now=performance.now(),wallNow=Date.now()}={}){
    this.history.clear();this.lastGlobal=-Infinity;
    for(const item of safeHistory(value)){
      // Convert persisted wall time to monotonic age once. A backward clock
      // grants a bounded cooldown, never a permanent future-date lockout.
      const age=Math.max(0,wallNow-item.at),monotonicAt=now-age;
      this.history.set(item.version+'|'+item.reason,{...item,monotonicAt});this.lastGlobal=Math.max(this.lastGlobal,monotonicAt);
    }
  }
  observe(input,{now=performance.now(),wallNow=Date.now()}={}){
    const status=normalize(input,this.version);
    if(!Number.isFinite(now)||!positiveTime(wallNow)||!status.version||!status.enabled||status.paused||status.nativeRunning!==true||!failurePhases.has(status.phase)||(status.present!==true&&!status.nativeInteractive)){
      this.episode=null;return null;
    }
    if(!this.episode||this.episode.version!==status.version||now<this.episode.started){
      this.episode={id:++this.sequence,version:status.version,started:now,attempts:0,nextAttempt:now,status};
    }else this.episode.status=status;
    const candidate={episodeId:this.episode.id,version:status.version,reason:noticeReason(status),kind:status.kind,available:status.available,pending:status.pending};
    return this.canSend(candidate,now)?candidate:null;
  }
  canSend(candidate,now=performance.now()){
    const episode=this.episode;if(!episode||episode.id!==candidate.episodeId||episode.version!==candidate.version)return false;
    const status=episode.status;
    if(noticeReason(status)!==candidate.reason||status.available!==candidate.available||status.pending!==candidate.pending||status.kind!==candidate.kind)return false;
    if(now-episode.started<this.graceMs||(status.present&&['connecting','retrying'].includes(status.phase)&&status.retryCount<2)||episode.attempts>=this.maxAttempts||now<episode.nextAttempt)return false;
    const prior=this.history.get(candidate.version+'|'+candidate.reason);
    return (!prior||now-prior.monotonicAt>=this.cooldownMs)&&now-this.lastGlobal>=this.globalCooldownMs;
  }
  beginAttempt(candidate,now=performance.now()){
    if(!this.canSend(candidate,now))return false;this.episode.attempts++;return true;
  }
  failed(candidate,now=performance.now()){
    if(this.episode?.id===candidate.episodeId)this.episode.nextAttempt=now+this.retryMs*2**Math.min(4,Math.max(0,this.episode.attempts-1));
  }
  accepted(candidate,{now=performance.now(),wallNow=Date.now()}={}){
    this.history.set(candidate.version+'|'+candidate.reason,{version:candidate.version,reason:candidate.reason,at:wallNow,monotonicAt:now});this.lastGlobal=now;
    if(this.episode?.id===candidate.episodeId){this.episode.attempts=0;this.episode.nextAttempt=now;}
    if(this.history.size>64){const oldest=[...this.history].sort((a,b)=>a[1].monotonicAt-b[1].monotonicAt)[0];this.history.delete(oldest[0]);}
  }
  serialize(){return {schema:1,entries:[...this.history.values()].map(({version,reason,at})=>({version,reason,at}))};}
}

const moduleDirectory=path.dirname(fileURLToPath(import.meta.url));
// Static code only; neither a request path nor script path becomes shell text.
export const RECOVERY_NOTICE_COMMAND="$ErrorActionPreference='Stop'; & ([ScriptBlock]::Create([IO.File]::ReadAllText($env:DOORAY_PLUS_NOTICE_SCRIPT)))";
const guid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const acceptedStatuses=new Set(['accepted','balloon-shown','clicked','closed']);
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function regularFile(file,filesystem){const stat=await filesystem.lstat(file);if(stat.isSymbolicLink()||!stat.isFile())throw Error('Unsafe notice file');return stat;}
async function safeAncestors(directory,filesystem,allowMissing=false){
  for(let current=path.resolve(directory);;current=path.dirname(current)){
    try{
      const stat=await filesystem.lstat(current);if(stat.isSymbolicLink()||!stat.isDirectory())throw Error('Linked recovery directory');
      if(filesystem.realpath){const actual=await filesystem.realpath(current);if(path.resolve(actual).toLowerCase()!==current.toLowerCase())throw Error('Redirected recovery directory');}
    }catch(error){if(!allowMissing||error.code!=='ENOENT')throw error;}
    if(path.dirname(current)===current)break;
  }
}
export {safeAncestors as verifyNoticeDirectory,regularFile as verifyNoticeFile};
async function pruneRequests(directory,filesystem,wallNow){
  await safeAncestors(directory,filesystem);
  const groups=new Map(),pattern=/^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\.result)?\.json$/i;
  for(const entry of await filesystem.readdir(directory,{withFileTypes:true})){
    const match=pattern.exec(entry.name);if(!match||entry.isSymbolicLink()||!entry.isFile())continue;
    const file=path.join(directory,entry.name);let stat;try{stat=await regularFile(file,filesystem)}catch{continue;}
    if(!positiveTime(stat.mtimeMs))continue;
    const group=groups.get(match[1].toLowerCase())||{at:0,files:[]};group.at=Math.max(group.at,stat.mtimeMs);group.files.push(file);groups.set(match[1].toLowerCase(),group);
  }
  // Reserve one slot for the next request; retain all recent/possibly active
  // UI jobs even during a burst. Only expired exact GUID JSON files are deleted.
  const expiredBefore=wallNow-15*60*1000,older=[...groups.values()].sort((a,b)=>b.at-a.at).slice(31);
  for(const group of older)if(group.at<expiredBefore)for(const file of group.files){
    await safeAncestors(directory,filesystem);
    try{const stat=await regularFile(file,filesystem);if(stat.mtimeMs<expiredBefore)await filesystem.unlink(file);}catch(error){if(error.code!=='ENOENT')throw error;}
  }
}

export async function sendRecoveryNotice({file,request,scriptPath=path.join(moduleDirectory,'recovery-notice.ps1'),signal},{filesystem=fs,spawnProcess=spawn,ownDirectory=moduleDirectory,systemRoot=process.env.SystemRoot||'C:\\Windows',environment=process.env,clock=()=>performance.now(),wait=delay,acknowledgmentMs=6000}={}){
  scriptPath=path.resolve(scriptPath);ownDirectory=path.resolve(ownDirectory);
  if(path.dirname(scriptPath).toLowerCase()!==ownDirectory.toLowerCase()||path.basename(scriptPath)!=='recovery-notice.ps1')throw Error('Notice script outside signed release');
  const script=await regularFile(scriptPath,filesystem);if(script.size>256*1024)throw Error('Notice script too large');
  for(let ancestor=ownDirectory;;ancestor=path.dirname(ancestor)){
    const stat=await filesystem.lstat(ancestor);if(stat.isSymbolicLink()||!stat.isDirectory())throw Error('Linked notice script directory');if(path.dirname(ancestor)===ancestor)break;
  }
  if(signal?.aborted)return false;
  const executable=path.join(systemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe');
  const args=['-NoLogo','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-STA','-EncodedCommand',Buffer.from(RECOVERY_NOTICE_COMMAND,'utf16le').toString('base64')];
  let child,exited=false,spawned=false,acknowledged=false;
  const abort=()=>{try{child?.kill()}catch{}};
  try{
    child=spawnProcess(executable,args,{windowsHide:true,detached:false,stdio:'ignore',env:{...environment,DOORAY_PLUS_NOTICE_FILE:file,DOORAY_PLUS_NOTICE_SCRIPT:scriptPath}});
    signal?.addEventListener('abort',abort,{once:true});
    child.once('exit',()=>{exited=true});
    await new Promise((resolve,reject)=>{child.once('error',reject);child.once('spawn',()=>{spawned=true;resolve()})});child.unref?.();
    const receipt=file.replace(/\.json$/i,'.result.json'),started=clock();
    while(!signal?.aborted&&clock()-started<acknowledgmentMs){
      try{
        const stat=await regularFile(receipt,filesystem);if(stat.size>8192)return false;
        const value=JSON.parse((await filesystem.readFile(receipt,'utf8')).replace(/^\ufeff/,''));
        if(value?.schema===1&&value.token===request.token&&value.version===request.version&&positiveTime(value.at)&&value.at>=request.at-30000&&value.at<=request.at+900000){if(acceptedStatuses.has(value.status)){acknowledged=true;return true;}if(value.status==='failed')return false;}
      }catch(error){if(error.code!=='ENOENT'&&!(error instanceof SyntaxError))return false;}
      if(exited)break;await wait(125);
    }
    return false;
  }finally{
    signal?.removeEventListener('abort',abort);
    // A launched but unacknowledged UI must not survive a retry and produce
    // a delayed duplicate. An acknowledged UI keeps its independent lifetime.
    if(signal?.aborted||!spawned||!acknowledged)abort();
  }
}

export function createRecoveryNotice({root,userData,version,scriptPath=path.join(moduleDirectory,'recovery-notice.ps1'),log=()=>{},filesystem=fs,sender=sendRecoveryNotice,clock={monotonic:()=>performance.now(),wall:()=>Date.now()},platform=process.platform,...policyOptions}={}){
  const policy=new RecoveryNoticePolicy({version,...policyOptions}),directory=path.join(userData,'recovery-notices'),stateFile=path.join(directory,'state-v1.json');
  let disposed=false,busy=null,controller=null,storageReady=false;
  const note=code=>{try{const result=log('Recovery notice: '+code);result?.catch?.(()=>{})}catch{}};
  const time=()=>({now:clock.monotonic(),wallNow:clock.wall()});
  const ready=(async()=>{
    try{
      await safeAncestors(directory,filesystem,true);await filesystem.mkdir(directory,{recursive:true});await safeAncestors(directory,filesystem);
      let history;
      try{const saved=await regularFile(stateFile,filesystem);if(saved.size>32768)throw Error('History too large');history=JSON.parse(await filesystem.readFile(stateFile,'utf8'));}
      catch(error){if(error.code!=='ENOENT'&&!(error instanceof SyntaxError))throw error;}
      policy.hydrate(history,time());storageReady=true;
    }catch{note('history-unavailable');}
  })();
  async function saveHistory(){
    const temp=path.join(directory,'state-v1.'+crypto.randomUUID()+'.tmp');
    try{
      await safeAncestors(directory,filesystem);
      try{await regularFile(stateFile,filesystem)}catch(error){if(error.code!=='ENOENT')throw error;}
      await filesystem.writeFile(temp,JSON.stringify(policy.serialize()),{flag:'wx',mode:0o600});await safeAncestors(directory,filesystem);await filesystem.rename(temp,stateFile);
    }finally{try{await safeAncestors(directory,filesystem);await filesystem.unlink(temp)}catch{}}
  }
  async function explicitlyStopped(){
    for(const name of ['stop-agent.flag','theme-disabled.flag'])try{await filesystem.lstat(path.join(userData,name));return true}catch(error){if(error.code!=='ENOENT')return true;}
    return false;
  }
  function observe(input){
    if(disposed)return Promise.resolve({status:'disposed'});
    const candidate=policy.observe(input,time());
    if(!policy.episode)controller?.abort();
    if(!candidate||platform!=='win32')return Promise.resolve({status:'suppressed'});
    if(busy)return busy;
    busy=(async()=>{
      await ready;if(disposed||!storageReady||!policy.canSend(candidate,clock.monotonic()))return {status:'suppressed'};
      if(await explicitlyStopped()){policy.episode=null;return {status:'suppressed'};}
      if(!policy.beginAttempt(candidate,clock.monotonic()))return {status:'suppressed'};
      controller=new AbortController();const attempt=controller;
      const token=crypto.randomUUID(),file=path.join(directory,token+'.json');
      const request={schema:1,version:candidate.version,reason:candidate.reason,kind:candidate.kind,available:candidate.available,pending:candidate.pending,at:clock.wall(),token};
      if(!guid.test(token)||!positiveTime(request.at))return {status:'suppressed'};
      try{
        await safeAncestors(directory,filesystem);try{await pruneRequests(directory,filesystem,clock.wall())}catch{note('request-cleanup-skipped');}await safeAncestors(directory,filesystem);
        await filesystem.writeFile(file,JSON.stringify(request),{flag:'wx',mode:0o600});
        if(disposed||attempt.signal.aborted||!policy.episode||await explicitlyStopped()){attempt.abort();return {status:'suppressed'};}
        const acknowledged=await sender({root,userData,file,request,scriptPath,signal:attempt.signal});
        if(acknowledged!==true||attempt.signal.aborted){policy.failed(candidate,clock.monotonic());note('ui-not-acknowledged');return {status:'unacknowledged'};}
        policy.accepted(candidate,time());
        try{await saveHistory()}catch{note('history-save-failed');}
        note('ui-accepted');return {status:'accepted'};
      }catch{
        policy.failed(candidate,clock.monotonic());note('delivery-failed');return {status:'failed'};
      }finally{if(controller===attempt)controller=null;}
    })().finally(()=>{busy=null});return busy;
  }
  return {observe,dispose(){disposed=true;policy.episode=null;controller?.abort();},policy};
}

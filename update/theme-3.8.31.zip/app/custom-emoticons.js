// Bundled inside theme.js; explicit item clicks use Dooray's native message pipeline.
function installCustomEmoticons({rpc,scrollController}){
  let disposed=false,scheduled=0,catalog=null,loading=null;const popups=new Map(),decorated=new Map(),assetPromises=new Map();
  const scrollStates=new Map();
  const atBottom=scroll=>scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<=48;
  function scrollState(node){
    // The shared conversation controller is the sole scroll owner in the
    // bundled app. The local path remains for standalone older integrations.
    if(scrollController)return null;
    let scroll=node.closest('[data-dp-native~="scroll"],.js-scroll-area');
    // Some Dooray layouts put the actual overflow on a wrapper around the message list.
    for(let p=node.parentElement;p&&p!==document.body;p=p.parentElement){if(/auto|scroll/.test(getComputedStyle(p).overflowY)&&p.clientHeight>0){scroll=p;break}}
    if(!scroll)return null;
    if(!scrollStates.has(scroll)){
      const state={scroll,follow:atBottom(scroll),frame:0};
      const changed=()=>{state.follow=atBottom(scroll)};
      const cancel=()=>{state.follow=false};
      const wheel=e=>{if(e.deltaY<0)cancel()};
      const key=e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))cancel()};
      scroll.addEventListener('scroll',changed,{passive:true});scroll.addEventListener('wheel',wheel,{passive:true});
      scroll.addEventListener('touchstart',cancel,{passive:true});scroll.addEventListener('pointerdown',cancel,{passive:true});scroll.addEventListener('keydown',key);
      state.dispose=()=>{cancelAnimationFrame(state.frame);scroll.removeEventListener('scroll',changed);scroll.removeEventListener('wheel',wheel);scroll.removeEventListener('touchstart',cancel);scroll.removeEventListener('pointerdown',cancel);scroll.removeEventListener('keydown',key)};
      scrollStates.set(scroll,state);
    }
    return scrollStates.get(scroll);
  }
  function followBottom(state){
    if(!state||!state.follow||disposed||!state.scroll.isConnected)return;
    state.scroll.scrollTop=state.scroll.scrollHeight;
    cancelAnimationFrame(state.frame);
    state.frame=requestAnimationFrame(()=>{state.frame=0;if(state.follow&&!disposed&&state.scroll.isConnected)state.scroll.scrollTop=state.scroll.scrollHeight});
  }
  const resized=new ResizeObserver(entries=>{for(const entry of entries){if(scrollController)scrollController.notifyLayout(entry.target);else followBottom(scrollState(entry.target))}});
  const prefix='[[dooray-emoji:v1:',suffix=']]';
  const encode=item=>prefix+btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify({p:item.path,r:item.ref,n:item.label})))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')+suffix;
  function decode(text){try{text=text.replace(/[\s\u200B-\u200D\uFEFF]/g,'');if(text.length>5000||!text.startsWith(prefix)||!text.endsWith(suffix))return null;const base=text.slice(prefix.length,-suffix.length).replace(/-/g,'+').replace(/_/g,'/');const obj=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(base),c=>c.charCodeAt(0))));if(typeof obj.p!=='string'||!obj.p.startsWith('packs/')||obj.p.length>1000||!/^([a-f\d]{40})$/i.test(obj.r)||!(/\.(png|gif|jpe?g|webp)$/i.test(obj.p)))return null;return {path:obj.p,ref:obj.r,label:String(obj.n||'커스텀 이모티콘').slice(0,100)}}catch{return null}}
  const memory=new Map(),queue=[];let running=0,memoryBytes=0;
  function pump(){while(!disposed&&running<6&&queue.length){queue.sort((a,b)=>a.priority-b.priority);const job=queue.shift();running++;job.run().finally(()=>{running--;pump()})}}
  function image(item,refresh=false,priority=0){
    const key=item.ref+'/'+item.path;
    if(refresh&&memory.has(key)){memoryBytes-=memory.get(key).length*2;memory.delete(key)}
    if(!refresh&&memory.has(key)){const data=memory.get(key);memory.delete(key);memory.set(key,data);return Promise.resolve(data)}
    if(assetPromises.has(key)){const waiting=queue.find(j=>j.key===key);if(waiting)waiting.priority=Math.min(waiting.priority,priority);return assetPromises.get(key)}
    let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});assetPromises.set(key,promise);
    queue.push({key,priority,run:async()=>{try{const r=await rpc('emoticon-image',{path:item.path,ref:item.ref,refresh});if(!/^data:image\/(png|gif|jpeg|webp);base64,/.test(r.data))throw Error('이미지 응답 오류');
      if(!disposed&&r.data.length*2<=24*1024*1024){memory.set(key,r.data);memoryBytes+=r.data.length*2;while(memory.size>128||memoryBytes>24*1024*1024){const first=memory.keys().next().value;memoryBytes-=memory.get(first).length*2;memory.delete(first)}}resolve(r.data)
    }catch(e){reject(e)}finally{assetPromises.delete(key)}}});pump();return promise;
  }
  let hoverPreview=null,hoverGeneration=0;
  function hidePreview(){hoverGeneration++;hoverPreview?.remove();hoverPreview=null;}
  async function showPreview(item,anchor){
    hidePreview();const generation=hoverGeneration;
    try{const src=await image(item);if(disposed||generation!==hoverGeneration||!anchor.isConnected||anchor.getRootNode().host?.hidden)return;
      const card=document.createElement('div');card.className='dt-emoticon-hover-preview';card.setAttribute('role','tooltip');card.style.cssText='position:fixed;z-index:2147483647;pointer-events:none;width:220px;height:220px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);padding:8px;box-sizing:border-box;border:1px solid #8793a4;border-radius:12px;box-shadow:0 8px 28px #0004;background:#fff';
      const theme=getComputedStyle(anchor);card.style.background=theme.getPropertyValue('--dt-bg').trim()||'#fff';const shadow=card.attachShadow({mode:'open'}),img=document.createElement('img');img.alt=item.label;img.src=src;img.style.cssText='display:block;width:100%;height:100%;object-fit:contain';shadow.append(img);document.body.append(card);hoverPreview=card;
      const rect=anchor.getBoundingClientRect(),width=card.getBoundingClientRect().width||220,height=card.getBoundingClientRect().height||220;const left=rect.right+12+width<=innerWidth?rect.right+12:rect.left-width-12;card.style.left=Math.max(8,Math.min(left,innerWidth-width-8))+'px';card.style.top=Math.max(8,Math.min(rect.top+(rect.height-height)/2,innerHeight-height-8))+'px';
    }catch{}
  }
  document.addEventListener('scroll',hidePreview,true);window.addEventListener('resize',hidePreview);
  let emojiMenu=null,jumpRequest=null;
  function closeEmojiMenu(){emojiMenu?.remove();emojiMenu=null;}
  function dismissEmojiMenu(event){if(emojiMenu&&!event.composedPath().includes(emojiMenu))closeEmojiMenu()}
  function menuKey(event){if(event.key==='Escape'){closeEmojiMenu();jumpRequest=null}}
  document.addEventListener('pointerdown',dismissEmojiMenu,true);document.addEventListener('keydown',menuKey);
  function emojiOpener(){
    for(const svg of document.querySelectorAll('#root svg')){let f=svg[Object.keys(svg).find(k=>k.startsWith('__reactFiber'))];for(let n=0;f&&n<12;n++,f=f.return)if(f.memoizedProps?.name==='editorEmoticon'){const button=svg.closest('button');if(button&&!button.disabled&&button.getClientRects().length)return button;break}}
    return null;
  }
  function openEmojiPack(item){
    const popup=[...popups.keys()].find(p=>p.isConnected&&p.getClientRects().length);const opener=popup?null:emojiOpener();if(!popup&&!opener)return false;
    jumpRequest={item,expires:Date.now()+10000,popup:null};if(opener)opener.click();if(popup)beginJump(popup,popups.get(popup));return true;
  }
  function beginJump(popup,state){if(!jumpRequest||jumpRequest.popup)return;jumpRequest.popup=popup;state.tab.onclick();applyJump(popup,state)}
  function applyJump(popup,state){
    if(!jumpRequest||jumpRequest.popup!==popup||!state.data)return;const item=jumpRequest.item,pack=state.data.packs.find(p=>p.items.some(x=>x.path===item.path));jumpRequest=null;
    if(!pack){state.status.textContent='현재 목록에서 이 이모티콘 팩을 찾지 못했습니다. 새로고침 후 확인해 주세요.';return}
    state.selected=pack;state.page=Math.floor(state.data.packs.indexOf(pack)/packsPerPage);drawPack(popup,state);
    const cell=[...state.grid.children].find(c=>c.dataset.path===item.path);if(cell){cell.style.outline='2px solid var(--dt-accent,#278ac2)';cell.style.borderRadius='8px';cell.scrollIntoView?.({block:'nearest'});}rememberPicker(state);
  }
  function showEmojiMenu(event,item){
    event.preventDefault();event.stopPropagation();hidePreview();closeEmojiMenu();const menu=document.createElement('div');menu.className='dt-emoticon-context-menu';menu.style.cssText='position:fixed;z-index:2147483647;max-width:calc(100vw - 16px)';const shadow=menu.attachShadow({mode:'open'});shadow.innerHTML='<style>:host{font:13px sans-serif}button{padding:10px 14px;border:1px solid #9ba6b5;border-radius:7px;background:#fff;color:#182638;box-shadow:0 4px 16px #0003;cursor:pointer}button:hover{background:#eaf2fc}</style><button type="button" role="menuitem">해당 이모티콘으로 가기</button>';menu.setAttribute('role','menu');document.body.append(menu);emojiMenu=menu;
    const rect=menu.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(event.clientX,innerWidth-rect.width-8))+'px';menu.style.top=Math.max(8,Math.min(event.clientY,innerHeight-rect.height-8))+'px';const button=shadow.querySelector('button');button.onclick=()=>{if(openEmojiPack(item))closeEmojiMenu();else button.textContent='이모티콘 선택 창을 먼저 열어 주세요.'};button.focus();
  }
  const favoritesKey='dooray-plus-emoticon-favorites-v1';
  const favoritesDefaultKey='dooray-plus-emoticon-favorites-default-v1';
  const pickerKey='dooray-plus-emoticon-picker-v1';
  let lastPicker=null;try{const p=JSON.parse(localStorage.getItem(pickerKey)||'null');if(p&&['packs','items','favorites'].includes(p.mode))lastPicker={mode:p.mode,page:Number.isInteger(p.page)?Math.max(0,p.page):0,packId:typeof p.packId==='string'?p.packId:null,top:Number.isFinite(p.top)?Math.max(0,p.top):0}}catch{}
  const pickerTabKey='dooray-plus-emoticon-tab-v1';
  let customTabSelected=!!lastPicker;try{const saved=localStorage.getItem(pickerTabKey);if(saved!==null)customTabSelected=saved==='custom'}catch{}
  function rememberTab(custom){customTabSelected=custom;try{localStorage.setItem(pickerTabKey,custom?'custom':'native')}catch{}}
  function rememberPicker(state){if(!state.visited)return;lastPicker={mode:state.mode,page:state.page,packId:state.selected?.id||null,top:state.grid.scrollTop};try{localStorage.setItem(pickerKey,JSON.stringify(lastPicker))}catch{}}
  function favoritesDefault(){try{return localStorage.getItem(favoritesDefaultKey)==='true'}catch{return false}}
  function readFavorites(){try{const value=JSON.parse(localStorage.getItem(favoritesKey)||'[]');return Array.isArray(value)?value.map(x=>decode(encode(x))).filter(Boolean).filter((x,i,a)=>a.findIndex(y=>y.path===x.path)===i).slice(0,500):[]}catch{return []}}
  let favorites=readFavorites();
  function saveFavorites(next,state){try{localStorage.setItem(favoritesKey,JSON.stringify(next));favorites=next;return true}catch{state.status.textContent='즐겨찾기를 저장하지 못했습니다. 저장 공간을 확인해 주세요.';return false}}
  function updateStars(){for(const state of popups.values())for(const star of state.grid.querySelectorAll('.star')){const selected=favorites.some(x=>x.path===star.dataset.path);star.textContent=selected?'★':'☆';star.setAttribute('aria-pressed',String(selected));star.title=selected?'즐겨찾기 제거':'즐겨찾기 추가';star.setAttribute('aria-label',star.title+' · '+star.dataset.label)}}
  function drawItems(popup,state,items){
    state.pageLabel.textContent=items.length+'개';
    for(const item of items){
      const cell=document.createElement('div');cell.className='item';cell.dataset.path=item.path;const send=document.createElement('button');send.type='button';send.className='send';send.title=item.label;send.setAttribute('aria-label',item.label+' 보내기');send.textContent=item.label;send.disabled=true;send.addEventListener('mouseenter',()=>showPreview(item,send));send.addEventListener('mouseleave',hidePreview);send.addEventListener('focus',()=>showPreview(item,send));send.addEventListener('blur',hidePreview);
      const star=document.createElement('button');star.type='button';star.className='star';star.dataset.path=item.path;star.dataset.label=item.label;
      star.onclick=()=>{const exists=favorites.some(x=>x.path===item.path);if(!exists&&favorites.length>=500){state.status.textContent='즐겨찾기는 최대 500개까지 저장할 수 있습니다.';return}if(!saveFavorites(exists?favorites.filter(x=>x.path!==item.path):[...favorites,item],state))return;updateStars();if(state.mode==='favorites'){const top=state.grid.scrollTop;drawFavorites(popup,state);state.grid.scrollTop=top}};
      cell.append(send,star);state.grid.append(cell);
      if(state.mode==='favorites'){
        const order=document.createElement('div');order.className='order';
        for(const [label,delta] of [['←',-1],['→',1]]){const move=document.createElement('button');move.type='button';move.textContent=label;move.setAttribute('aria-label',item.label+(delta<0?' 앞으로 이동':' 뒤로 이동'));const index=favorites.findIndex(x=>x.path===item.path);move.disabled=index+delta<0||index+delta>=favorites.length;move.onclick=()=>{const next=[...favorites],at=next.findIndex(x=>x.path===item.path),to=at+delta;if(at<0||to<0||to>=next.length)return;[next[at],next[to]]=[next[to],next[at]];if(saveFavorites(next,state)){const top=state.grid.scrollTop;drawFavorites(popup,state);state.grid.scrollTop=top;state.grid.children[to]?.querySelector('.star').focus()}};order.append(move)}cell.append(order);
      }
      lazy(cell,()=>image(item).then(src=>{if(!cell.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{send.disabled=false};img.onerror=()=>{send.textContent='이미지 로딩 실패'};img.src=src;send.replaceChildren(img);send.onclick=()=>{if(!state.combined)return insert(popup,item,state.status);if(state.selection.length>=2){state.status.textContent='두 개가 선택되었습니다. 듀얼콘 보내기를 누르거나 선택을 해제해 주세요.';return}state.selection.push(item);renderSelection(state)}}).catch(e=>{send.textContent='불러오기 실패';send.title=e.message}));
    }updateStars();
  }
  function drawFavorites(popup,state){clearGrid(state);state.mode='favorites';state.panel.dataset.view='items';state.back.hidden=false;state.title.textContent='';state.favorite.setAttribute('aria-pressed','true');state.previous.hidden=state.next.hidden=true;state.grid.setAttribute('aria-label','즐겨찾기 이모티콘 목록');state.status.textContent=favorites.length?'별표로 제거 · 화살표로 순서 변경':'이모티콘 모서리의 ☆을 눌러 추가해 주세요.';drawItems(popup,state,favorites);rememberPicker(state)}
  function context(popup){let f=popup[Object.keys(popup).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<35;i++,f=f.return){const p=f.memoizedProps;if(p?.actions?.emoticonStickerActions&&p?.data?.emoticonStickerStore)return p}return null}
  function renderSelection(state){
    state.pairSlots.replaceChildren();state.pairSend.hidden=!state.combined;state.pairSend.disabled=state.selection.length!==2;state.pairMode.setAttribute('aria-pressed',String(state.combined));
    state.selection.forEach((item,index)=>{const button=document.createElement('button');button.type='button';button.textContent=(index+1)+'. '+item.label+' ×';button.title=item.path;button.setAttribute('aria-label',(index+1)+'번 선택 해제');button.onclick=()=>{state.selection.splice(index,1);renderSelection(state)};state.pairSlots.append(button)});
    state.status.textContent=state.combined?'듀얼콘으로 보낼 이모티콘 두 개를 선택해 주세요. ('+state.selection.length+'/2)':'이모티콘을 누르면 바로 전송됩니다.';
  }
  const sending=new WeakSet();
  async function insert(popup,item,status){hidePreview();if(sending.has(popup))return;sending.add(popup);try{const p=context(popup),active=p?.data.emoticonStickerStore.activePopperState,stickers=p?.actions.emoticonStickerActions,logs=stickers?.logActions,channel=stickers?.activeChannelId;if(!popup.isConnected||!active||!channel||typeof logs?.createAndSendLog!=='function'||typeof logs?.fetchLatestLogsIfNeeded!=='function')throw Error('이모티콘 창을 다시 열어 주세요.');status.textContent='전송 중…';await logs.fetchLatestLogsIfNeeded(channel);if(!popup.isConnected||disposed||stickers.activeChannelId!==channel||p.data.emoticonStickerStore.activePopperState!==active)throw Error('대화방이 변경되어 전송하지 않았습니다.');const items=Array.isArray(item)?item:[item];if(items.length<1||items.length>2)throw Error('한 번에 최대 두 개를 보낼 수 있습니다.');logs.createAndSendLog(channel,items.map(encode).join(''));const state=popups.get(popup);if(state){rememberPicker(state);state.selection=[];renderSelection(state)}active.setOpen(false);}catch(e){status.textContent=e.message}finally{sending.delete(popup)}}
  const css=document.createElement('style');css.id='dooray-custom-emoticons-style';css.textContent=`
  .js-sticker-emotion[data-dt-custom-open] > :not([data-dt-custom-tabs]):not(.dt-emoticon-custom){display:none!important}
  [data-dt-custom-tab] button[aria-selected="true"],button[data-dt-custom-tab][aria-selected="true"]{color:var(--dt-accent,#278ac2)!important;box-shadow:inset 0 -2px var(--dt-accent,#278ac2)}
  .dt-emoticon-custom[hidden]{display:none!important}
  [data-dt-emoticon][data-dt-emoticon]{font-size:0!important;line-height:0!important;letter-spacing:0!important;word-spacing:0!important;visibility:hidden!important;width:fit-content!important;min-width:0!important}
  [data-dp-native~="message-bubble"]:has([data-dt-emoticon]),.sc-iyvyFf:has([data-dt-emoticon]){width:fit-content!important;min-width:0!important}
  [data-dt-emoticon][data-dt-emoticon] > :not(.dt-received-emoticon){display:none!important}
  .dt-received-emoticon{visibility:visible!important;display:inline-flex!important;align-items:center;justify-content:center;vertical-align:middle;flex-wrap:wrap;gap:4px;max-width:100%;font:12px/1.4 sans-serif!important;color:var(--dt-text,#333);overflow:hidden}
  .dt-emoticon-imagebox{display:inline-flex;width:160px;height:160px;align-items:center;justify-content:center;flex:none;max-width:100%} .dt-emoticon-text{white-space:pre-wrap;font-size:14px;line-height:1.5}
  .dt-received-emoticon.dt-dual-emoticon{gap:0;flex-wrap:nowrap;width:320px}.dt-dual-emoticon .dt-emoticon-imagebox{width:50%;max-width:50%;height:auto;aspect-ratio:1;flex:0 0 50%}.dt-dual-emoticon .dt-emoticon-imagebox:first-child img{object-position:right center}.dt-dual-emoticon .dt-emoticon-imagebox:last-child img{object-position:left center}
  .dt-received-emoticon img{display:block;width:100%;height:100%;object-fit:contain}
  .dt-received-emoticon button{font:inherit;color:inherit;background:transparent;border:0;cursor:pointer;max-width:100%}
  `;document.head.append(css);
  const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){observer.unobserve(entry.target);entry.target.__dtLoadEmoticon?.();}},{rootMargin:'160px'});
  function lazy(target,load){target.__dtLoadEmoticon=load;observer.observe(target)}
  const packsPerPage=6;
  function clearGrid(state){hidePreview();for(const child of state.grid.children)observer.unobserve(child);state.grid.replaceChildren();state.grid.scrollTop=0;}
  function thumbnail(pack){return pack.items.find(item=>/^01\.(png|gif|jpe?g|webp)$/i.test(item.path.split('/').pop()))||pack.items.find(item=>String(item.id)==='01'||item.label==='01')||pack.items[0];}
  function fillPicker(popup,state,data){
    if(!popup.isConnected||disposed)return;state.data=data;state.page=Math.min(state.page,Math.max(0,Math.ceil(data.packs.length/packsPerPage)-1));if(state.mode==='favorites')drawFavorites(popup,state);else if(state.mode==='items'&&state.selected&&(state.selected=data.packs.find(p=>p.id===state.selected.id)))drawPack(popup,state);else drawPacks(popup,state);if(state.restoreTop!==undefined){state.grid.scrollTop=state.restoreTop;delete state.restoreTop;}rememberPicker(state);applyJump(popup,state);
  }
  function drawPacks(popup,state){
    clearGrid(state);state.mode='packs';state.grid.setAttribute('aria-label','이모티콘 팩 목록');state.panel.dataset.view='packs';state.back.hidden=true;state.title.textContent='';state.favorite.setAttribute('aria-pressed','false');
    const packs=state.data?.packs||[],pages=Math.max(1,Math.ceil(packs.length/packsPerPage));
    state.previous.hidden=state.next.hidden=false;state.previous.disabled=state.page===0;state.next.disabled=state.page>=pages-1;
    state.pageLabel.textContent=(state.page+1)+' / '+pages;
    state.status.textContent=state.data?.warnings?.length?'일부 팩을 읽지 못했습니다. '+state.data.warnings[0]:'팩을 눌러 열기 · 휠로 페이지 이동';
    for(const pack of packs.slice(state.page*packsPerPage,(state.page+1)*packsPerPage)){
      const button=document.createElement('button');button.type='button';button.className='pack';button.title=pack.name;button.setAttribute('aria-label',pack.name+' 팩 열기');
      const preview=document.createElement('span');preview.className='preview';preview.textContent='…';
      const name=document.createElement('span');name.className='name';name.textContent=pack.name;button.append(preview,name);state.grid.append(button);
      button.onclick=()=>{state.selected=pack;drawPack(popup,state);state.back.focus()};
      const item=thumbnail(pack);if(item)lazy(button,()=>image(item).then(src=>{if(!button.isConnected||disposed)return;const img=document.createElement('img');img.alt='';img.onerror=()=>{preview.textContent='미리보기 없음'};img.src=src;preview.replaceChildren(img)}).catch(()=>{if(button.isConnected)preview.textContent='미리보기 없음'}));else preview.textContent='비어 있음';
    }rememberPicker(state);
  }
  function turnPage(popup,state,direction){
    if(state.mode!=='packs'||!state.data)return;
    const next=Math.max(0,Math.min(state.page+direction,Math.ceil(state.data.packs.length/packsPerPage)-1));
    if(next===state.page||next<0)return;state.page=next;drawPacks(popup,state);
  }
  function drawPack(popup,state){
    clearGrid(state);const pack=state.selected;if(!pack)return;state.mode='items';state.grid.setAttribute('aria-label',pack.name+' 이모티콘 목록');state.panel.dataset.view='items';state.back.hidden=false;state.title.textContent=pack.name;
    state.previous.hidden=state.next.hidden=true;state.pageLabel.textContent=pack.items.length+'개';state.status.textContent='이모티콘을 누르면 바로 전송됩니다.';
    state.favorite.setAttribute('aria-pressed','false');drawItems(popup,state,pack.items);rememberPicker(state);
  }
  async function loadPicker(popup,state,refresh=false){
    if(catalog&&!refresh)fillPicker(popup,state,catalog);else state.status.textContent='이모티콘 목록을 불러오는 중…';
    state.refresh.disabled=true;
    try{if(refresh&&loading)await loading.catch(()=>{});loading ||= rpc('emoticon-catalog',{refresh}).finally(()=>{loading=null});const next=await loading;catalog=next;if(!disposed&&popup.isConnected&&(refresh||state.data?.ref!==next.ref||JSON.stringify(state.data?.warnings)!==JSON.stringify(next.warnings)))fillPicker(popup,state,catalog)}
    catch(e){state.status.textContent=e.message+(catalog?' 저장된 목록은 계속 사용할 수 있습니다.':' 새로고침을 눌러 다시 시도해 주세요.')}
    finally{state.refresh.disabled=false;applyJump(popup,state)}
  }
  function pickerTabs(popup){
    // The popup's stable hook survives styled-components class regeneration.
    // Its tab strip is a direct child containing tab buttons, not the item grid.
    const strips=[...popup.children].filter(n=>!n.classList.contains('dt-emoticon-custom')&&!n.hasAttribute('data-dt-custom-tab'));
    const slots=strip=>[...strip.children].filter(n=>!n.hasAttribute('data-dt-custom-tab')&&(n.matches('button,[role="tab"]')||n.querySelector(':scope > button,:scope > [role="tab"]')));
    return strips.find(n=>n.matches('[role="tablist"]')&&slots(n).length)||strips.find(n=>slots(n).some(slot=>slot.matches('[role="tab"]')||slot.querySelector('[role="tab"]')))||strips.find(n=>slots(n).length>=2)||strips.find(n=>n.matches('.lcdHJ')&&slots(n).length)||strips.find(n=>slots(n).length);
  }
  function mount(popup){
    const previous=popups.get(popup);if(previous){if(previous.tabs.parentElement===popup&&previous.tab.isConnected&&previous.panel.parentElement===popup)return;previous.detach();popups.delete(popup)}
    const tabs=pickerTabs(popup);if(!tabs)return;
    const nativeSlots=[...tabs.children].filter(n=>n.matches('button,[role="tab"]')||n.querySelector(':scope > button,:scope > [role="tab"]'));
    const nativeButton=slot=>slot.matches('button,[role="tab"]')?slot:slot.querySelector('button,[role="tab"]');
    const selected=slot=>[slot,nativeButton(slot)].some(n=>n?.matches('[aria-selected="true"],[aria-pressed="true"],[data-state="active"],[data-state="selected"]'));
    const commonClasses=nodes=>nodes.length?new Set([...nodes[0].classList].filter(c=>nodes.every(n=>n.classList.contains(c)))):new Set();
    const commonSlots=commonClasses(nativeSlots),buttons=nativeSlots.map(nativeButton),commonButtons=commonClasses(buttons);
    const classSelected=nativeSlots.filter(n=>commonSlots.size&&[...n.classList].some(c=>!commonSlots.has(c)));
    const sample=nativeSlots.find(selected)||(classSelected.length===1?classSelected[0]:nativeSlots[0]),sampleButton=nativeButton(sample);
    const selectedSlotClasses=nativeSlots.length>1?[...sample.classList].filter(c=>!commonSlots.has(c)):[];
    const selectedButtonClasses=nativeSlots.length>1?[...sampleButton.classList].filter(c=>!commonButtons.has(c)):[];
    const tab=document.createElement('button');tab.type='button';tab.className=sampleButton.className;for(const c of selectedButtonClasses)tab.classList.remove(c);
    const tabSlot=sample.matches('button')?tab:document.createElement(sample.tagName.toLowerCase());if(tabSlot!==tab){tabSlot.className=sample.className;for(const c of selectedSlotClasses)tabSlot.classList.remove(c);tabSlot.append(tab)}
    tabSlot.dataset.dtCustomTab='true';tab.setAttribute('role','tab');const label=document.createElement('div');label.className=sampleButton.querySelector(':scope > div')?.className||'';label.textContent='커스텀';tab.append(label);tab.setAttribute('aria-selected','false');
    const priorTabsMarker=tabs.getAttribute('data-dt-custom-tabs');tabs.setAttribute('data-dt-custom-tabs','');tabs.append(tabSlot);let selectedNative=[];
    const selectTab=(custom,restore=true)=>{
      if(custom&&tab.getAttribute('aria-selected')!=='true'){
        selectedNative=nativeSlots.filter(slot=>selected(slot)||selectedSlotClasses.some(c=>slot.classList.contains(c))).map(slot=>({slot,button:nativeButton(slot),classes:selectedSlotClasses.filter(c=>slot.classList.contains(c)),buttonClasses:selectedButtonClasses.filter(c=>nativeButton(slot).classList.contains(c)),attributes:[...new Set([slot,nativeButton(slot)])].flatMap(node=>['aria-selected','aria-pressed','data-state'].map(name=>({node,name,value:node.getAttribute(name)})).filter(a=>['true','active','selected'].includes(a.value)).map(a=>({...a,muted:a.value==='true'?'false':a.value==='active'?'inactive':'unselected'})))}));
        for(const old of selectedNative){for(const c of old.classes)old.slot.classList.remove(c);for(const c of old.buttonClasses)old.button.classList.remove(c);for(const a of old.attributes)a.node.setAttribute(a.name,a.muted)}
      }else if(!custom){for(const old of selectedNative)if(old.slot.isConnected&&restore){for(const c of old.classes)old.slot.classList.add(c);for(const c of old.buttonClasses)old.button.classList.add(c);for(const a of old.attributes)if(a.node.getAttribute(a.name)===a.muted)a.node.setAttribute(a.name,a.value)}selectedNative=[];}
      for(const c of selectedSlotClasses)tabSlot.classList.toggle(c,custom);for(const c of selectedButtonClasses)tab.classList.toggle(c,custom);tab.setAttribute('aria-selected',String(custom));
    };
    const panel=document.createElement('div');panel.className='dt-emoticon-custom';panel.hidden=true;panel.dataset.view='packs';const shadow=panel.attachShadow({mode:'open'});shadow.innerHTML=`<style>
    :host{display:block;width:360px;max-width:80vw;color:var(--dt-text,#333);background:var(--dt-bg,#fff);font:12px sans-serif}*{box-sizing:border-box}[hidden]{display:none!important}
    .tools{display:flex;align-items:center;gap:6px;padding:10px}#title{flex:1;min-width:0;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    button{color:inherit;background:var(--dt-surface,#eee);border:1px solid var(--dt-border,#bbb);border-radius:8px;padding:6px;font:inherit;cursor:pointer}button:hover{background:var(--dt-hover,#ddd)}button:disabled{opacity:.4;cursor:default}button:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:1px}
    #status{padding:0 10px;margin:0 0 6px;font-size:11px;line-height:1.5;overflow-wrap:anywhere;min-height:17px}.browser{display:grid;grid-template-columns:28px minmax(0,1fr) 28px;align-items:center;gap:3px;padding:0 5px}.arrow{padding:8px 0;font-size:22px;line-height:1}
    #grid{height:268px;overflow:auto;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));align-content:start;gap:6px;padding:4px;overscroll-behavior:contain}
    #grid button{min-width:0;overflow:hidden;padding:5px;height:122px}.preview{display:flex;height:78px;align-items:center;justify-content:center;font-size:11px}.name{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:11px;line-height:15px;margin-top:3px;word-break:break-all}img{display:block;width:100%;height:100%;object-fit:contain}
    :host([data-view="items"]) .browser{grid-template-columns:minmax(0,1fr)}:host([data-view="items"]) #grid{grid-template-columns:repeat(4,minmax(0,1fr))}:host([data-view="items"]) #grid button{height:78px}
    .item{position:relative;min-width:0}.item .send{width:100%;padding:9px!important}.item .star{position:absolute;right:1px;top:1px;width:23px;height:23px!important;padding:0!important;font-size:19px;line-height:21px;border:0;background:var(--dt-bg,#fff);border-radius:7px;color:var(--dt-text,#555)}.item .star[aria-pressed="true"]{color:#b77d00;background:#fff2c2}.order{display:flex;gap:3px;margin-top:3px}.order button{height:22px!important;flex:1;padding:0!important}#favorites[aria-pressed="true"]{border-color:var(--dt-accent,#278ac2);background:var(--dt-hover,#ddd)}
    .pair{display:flex;flex-wrap:wrap;align-items:center;gap:5px;padding:5px 10px}.pair button{font-size:11px}#pairSlots{display:flex;gap:4px;min-width:0}#pairSlots button{max-width:105px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#pairMode[aria-pressed="true"]{border-color:var(--dt-accent,#278ac2);background:var(--dt-hover,#ddd)}
    .footer{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:5px 10px 9px;font-size:11px}.footer label{display:flex;align-items:center;gap:5px;cursor:pointer}.footer input{margin:0;accent-color:var(--dt-accent,#278ac2)}#page{opacity:.75;white-space:nowrap}
    </style><div class="tools"><button id="back" hidden aria-label="팩 목록으로 뒤로 가기">← 뒤로</button><button id="favorites" aria-pressed="false">★ 즐겨찾기</button><span id="title"></span><button id="refresh" aria-label="이모티콘 목록 새로고침">새로고침</button></div><p id="status" role="status"></p><div class="browser"><button id="previous" class="arrow" aria-label="이전 페이지" title="이전 페이지">‹</button><div id="grid" tabindex="0" aria-label="이모티콘 팩 목록"></div><button id="next" class="arrow" aria-label="다음 페이지" title="다음 페이지">›</button></div><div class="pair"><button id="pairMode" aria-pressed="false">듀얼콘</button><span id="pairSlots"></span><button id="pairSend" hidden disabled>듀얼콘 보내기</button></div><div class="footer"><label><input id="favoritesDefault" type="checkbox">즐겨찾기를 기본으로 보기</label><span id="page" aria-live="polite"></span></div>`;
    popup.append(panel);const get=id=>shadow.getElementById(id);const state={panel,tab,tabs,grid:get('grid'),status:get('status'),refresh:get('refresh'),back:get('back'),title:get('title'),favorite:get('favorites'),previous:get('previous'),next:get('next'),pageLabel:get('page'),page:0,mode:'packs',selected:null,combined:false,selection:[],pairMode:get('pairMode'),pairSlots:get('pairSlots'),pairSend:get('pairSend')};
    state.pairMode.onclick=()=>{state.combined=!state.combined;state.selection=[];renderSelection(state)};state.pairSend.onclick=()=>{if(state.selection.length===2)insert(popup,[...state.selection],state.status)};
    const defaultOption=get('favoritesDefault');defaultOption.checked=favoritesDefault();defaultOption.onchange=()=>{try{localStorage.setItem(favoritesDefaultKey,String(defaultOption.checked));for(const other of popups.values())other.panel.shadowRoot.getElementById('favoritesDefault').checked=defaultOption.checked}catch{defaultOption.checked=favoritesDefault();state.status.textContent='기본 화면 설정을 저장하지 못했습니다.'}};
    state.favorite.onclick=()=>drawFavorites(popup,state);
    state.previous.onclick=()=>turnPage(popup,state,-1);state.next.onclick=()=>turnPage(popup,state,1);
    state.back.onclick=()=>{const index=(state.data?.packs||[]).indexOf(state.selected)%packsPerPage;drawPacks(popup,state);state.grid.children[index]?.focus()};
    let wheelSum=0,lastWheel=0,lastPageTurn=0;
    const wheel=e=>{if(state.mode!=='packs'||e.ctrlKey)return;e.preventDefault();e.stopPropagation();const now=performance.now();if(now-lastWheel>180)wheelSum=0;lastWheel=now;wheelSum+=(Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY)*(e.deltaMode===1?16:e.deltaMode===2?268:1);if(Math.abs(wheelSum)<40||now-lastPageTurn<300)return;turnPage(popup,state,Math.sign(wheelSum));wheelSum=0;lastPageTurn=now};
    shadow.querySelector('.browser').addEventListener('wheel',wheel,{passive:false});
    state.grid.onkeydown=e=>{if(state.mode==='packs'&&['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();turnPage(popup,state,e.key==='ArrowRight'?1:-1)}};
    state.grid.addEventListener('scroll',()=>rememberPicker(state),{passive:true});
    const nativeClick=e=>{const clicked=e.target.closest('button,[role="tab"]');if(!clicked||clicked===tab)return;rememberTab(false);rememberPicker(state);hidePreview();panel.hidden=true;popup.removeAttribute('data-dt-custom-open');selectTab(false,selectedNative.some(old=>old.slot===clicked||old.slot.contains(clicked)))};tabs.addEventListener('click',nativeClick);state.detach=()=>{rememberPicker(state);clearGrid(state);selectTab(false);tabs.removeEventListener('click',nativeClick);if(priorTabsMarker===null)tabs.removeAttribute('data-dt-custom-tabs');else tabs.setAttribute('data-dt-custom-tabs',priorTabsMarker);tabSlot.remove();panel.remove();popup.removeAttribute('data-dt-custom-open')};
    tab.onclick=()=>{rememberTab(true);defaultOption.checked=favoritesDefault();const saved=lastPicker;state.visited=true;state.mode=defaultOption.checked?'favorites':saved?.mode||'packs';state.page=saved?.page||0;state.selected=saved?.packId?{id:saved.packId}:null;state.restoreTop=saved?.mode===state.mode?saved.top:0;panel.hidden=false;popup.setAttribute('data-dt-custom-open','');selectTab(true);if(state.mode==='favorites')drawFavorites(popup,state);loadPicker(popup,state)};state.refresh.onclick=()=>loadPicker(popup,state,true);popups.set(popup,state);if(customTabSelected)tab.onclick();
  }
  // Dooray may leave markdown spacing entities as literal text after a message.
  const normalizeSpacing=text=>text.replace(/&(?:#x(?:20|a0)|#(?:32|160)|nbsp);/gi,' ');
  function messageText(node){return normalizeSpacing([...node.childNodes].filter(n=>!(n.nodeType===1&&n.classList.contains('dt-received-emoticon'))).map(n=>n.textContent).join('')).replace(/[\u200B-\u200D\uFEFF]/g,'').trim()}
  const tokenPattern=()=>/\[\s*\[\s*dooray\s*-\s*emoji\s*:\s*v1\s*:\s*[A-Za-z0-9_\-\s]+\]\s*\]/g;
  function messageCandidates(){
    const bubbles='[data-dp-native~="message-bubble"],.sc-iyvyFf',texts='[data-dp-native~="message-text"],.sc-chbbiW',contents='[data-dp-native~="message-content"],[class*="js-log-right-content-"]';
    const skip='textarea,input,script,style,noscript,[contenteditable]:not([contenteditable="false"]),.js-main-editor,.js-channel-list,[data-dp-native~="sidebar"],blockquote,button,[role="button"],.dt-received-emoticon,.dt-emoticon-custom,.js-sticker-emotion';
    const foreignLink=node=>{const link=node.closest('a[href]');return link&&!/^dooray-emoji:/i.test(link.getAttribute('href')||'')};
    const excluded=node=>!node||node.isContentEditable||node.closest(skip)||foreignLink(node);
    // A sidebar, sender, quote or read-count is never a message body. The
    // adapter's semantic boundary also covers renamed classes and side panels.
    const boundary=node=>!excluded(node)&&(node.closest(bubbles)||node.closest(texts));
    const groups=new Map(),checked=new Set();
    function consider(node,owner){
      if(checked.has(node))return;checked.add(node);
      if(excluded(node)||node.closest('a[href]')||node.querySelector('[data-logid]')||[...node.querySelectorAll(skip)].some(child=>!child.closest('.dt-received-emoticon'))||[...node.querySelectorAll('a[href]')].some(foreignLink))return;
      const text=messageText(node);if(text.length>16000)return;
      let count=0;for(const match of text.matchAll(tokenPattern()))if(decode(match[0])&&++count>=8)break;
      if(!count)return;
      const group=groups.get(owner)||[];group.push({node,count});groups.set(owner,group);
    }
    for(const node of document.querySelectorAll(bubbles+','+texts)){
      const owner=boundary(node);if(!owner)continue;consider(node,owner);
      // Dooray can turn the middle of a token into a native link, or split
      // adjacent tokens into separate chunks. Keep examining its own bubble;
      // an incomplete smaller chunk must not suppress a complete parent.
      for(let parent=node.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){consider(parent,owner);if(parent===owner)break;}
      let visited=0;const walker=document.createTreeWalker(node,NodeFilter.SHOW_TEXT);
      for(let text=walker.nextNode();text&&visited++<24000;text=walker.nextNode()){
        if(excluded(text.parentElement)||!/\[\[|dooray-|emoji:v1:/.test(text.nodeValue||''))continue;
        for(let parent=text.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){if(excluded(parent))break;consider(parent,owner);if(parent===owner)break;}
      }
    }
    // If a renderer cannot yet be tagged by the adapter, retain token recovery
    // inside its stable per-log content boundary. Never walk the whole document
    // or combine sibling messages, and prefer semantic bodies whenever present.
    for(const owner of document.querySelectorAll(contents)){
      if(excluded(owner)||owner.querySelector(bubbles+','+texts))continue;
      let visited=0;const walker=document.createTreeWalker(owner,NodeFilter.SHOW_TEXT);
      for(let text=walker.nextNode();text&&visited++<24000;text=walker.nextNode()){
        if(excluded(text.parentElement)||text.parentElement.closest(contents)!==owner||!/[\[\]]|dooray|emoji|v1:/.test(text.nodeValue||''))continue;
        const log=text.parentElement.closest('[data-logid]');
        for(let parent=text.parentElement,depth=0;parent&&owner.contains(parent)&&depth<24;parent=parent.parentElement,depth++){
          if(excluded(parent)||parent.closest('[data-logid]')!==log)break;consider(parent,owner);if(parent===owner||parent===log)break;
        }
      }
    }
    // Preserve every token in the same bubble (including a split dual emoticon),
    // then prefer the smallest complete container with that coverage.
    const result=[];for(const group of groups.values()){
      const count=Math.max(...group.map(x=>x.count)),best=group.filter(x=>x.count===count);
      result.push(...best.filter(x=>!best.some(other=>other!==x&&x.node.contains(other.node))).map(x=>x.node));
    }
    return [...new Set(result)];
  }
  function undecorate(node){const d=decorated.get(node);if(!d)return;const layout=scrollController?.beforeLayout(node);resized.unobserve(d.view);for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(d.view);d.view.remove();node.removeAttribute('data-dt-emoticon');decorated.delete(node);if(scrollController)scrollController.afterLayout(layout)}
  function decorate(node,segments,key){
    const previous=decorated.get(node);if(previous?.key===key&&previous.view.parentNode===node&&previous.view.childNodes.length){if(!node.hasAttribute('data-dt-emoticon'))node.setAttribute('data-dt-emoticon','');return;}
    const layout=scrollController?.beforeLayout(node),state=scrollState(node),scroll=state?.scroll,oldTop=scroll?.scrollTop,above=scroll&&node.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,oldHeight=node.getBoundingClientRect().height;
    if(previous){resized.unobserve(previous.view);for(const box of previous.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(previous.view);previous.view.remove()}
    const dual=segments.filter(s=>typeof s!=='string').length===2&&segments.every(s=>typeof s!=='string'||!s.trim());const view=document.createElement('span');view.className='dt-received-emoticon'+(dual?' dt-dual-emoticon':'');view.setAttribute('aria-label','커스텀 이모티콘 메시지');node.setAttribute('data-dt-emoticon','');node.append(view);decorated.set(node,{key,view});
    for(const segment of segments){if(typeof segment==='string'){if(dual)continue;const text=document.createElement('span');text.className='dt-emoticon-text';text.textContent=segment;view.append(text);continue;}const item=segment,box=document.createElement('span');box.className='dt-emoticon-imagebox';box.addEventListener('contextmenu',event=>showEmojiMenu(event,item));box.textContent='이모티콘 불러오는 중…';view.append(box);let loadingImage=false;const load=(refresh=false)=>{if(loadingImage||disposed||!box.isConnected)return;loadingImage=true;box.dataset.loadState='loading';box.textContent='이모티콘 불러오는 중…';return image(item,refresh).then(src=>{if(!box.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{box.dataset.loadState='ready';if(scrollController)scrollController.notifyLayout(box);else followBottom(state)};img.onerror=failed;img.src=src;box.replaceChildren(img)}).catch(failed).finally(()=>{loadingImage=false})};function failed(error){if(!box.isConnected||disposed)return;box.dataset.loadState='failed';box.title=error?.message||'이미지를 표시하지 못했습니다.';const retry=document.createElement('button');retry.textContent=item.label+' · 다시 불러오기';retry.onclick=()=>load(true);box.replaceChildren(retry)}box.__dtReload=load;lazy(box,()=>load());}
    if(scrollController)scrollController.afterLayout(layout);else if(state?.follow)followBottom(state);else if(above)scroll.scrollTop=oldTop+node.getBoundingClientRect().height-oldHeight;
    resized.observe(view);

  }
  function scan(){scheduled=0;if(disposed)return;for(const popup of document.querySelectorAll('.js-sticker-emotion'))mount(popup);if(jumpRequest&&Date.now()>jumpRequest.expires)jumpRequest=null;for(const[p,state]of popups)if(p.isConnected&&jumpRequest&&!jumpRequest.popup)beginJump(p,state);for(const[p,state]of popups)if(!p.isConnected){state.detach();popups.delete(p)}
    const candidates=messageCandidates(),selected=new Set(candidates);
    // Clear obsolete parents before decorating a replacement child, and clear
    // detached nodes too: virtualized native nodes can be inserted again later.
    for(const node of decorated.keys())if(!node.isConnected||!selected.has(node))undecorate(node);
    for(const node of candidates){const text=messageText(node),segments=[];let at=0,count=0;for(const match of text.matchAll(tokenPattern())){const item=decode(match[0]);if(!item||count>=8)continue;if(match.index>at)segments.push(text.slice(at,match.index));segments.push(item);at=match.index+match[0].length;count++;}if(at<text.length)segments.push(text.slice(at));if(count)decorate(node,segments,text);else undecorate(node)}
    for(const[scroll,state]of scrollStates)if(!scroll.isConnected){state.dispose();scrollStates.delete(scroll)}
  }
  let lastError='',lastScan=0;
  const runScan=()=>{try{scan();lastScan=Date.now();lastError=''}catch(e){lastError=e.message;scheduled=0}};
  const changes=new MutationObserver(()=>{if(!scheduled)scheduled=setTimeout(runScan,120)});changes.observe(document,{subtree:true,childList:true,characterData:true});runScan();
  const recoveryTimer=setInterval(()=>{if(!document.hidden)runScan()},2500);
  function diagnostics(){const boxes=[...decorated.values()].flatMap(d=>[...d.view.querySelectorAll('.dt-emoticon-imagebox')]);return {messages:decorated.size,ready:boxes.filter(b=>b.dataset.loadState==='ready').length,failed:boxes.filter(b=>b.dataset.loadState==='failed').length,waiting:boxes.filter(b=>!['ready','failed'].includes(b.dataset.loadState)).length,lastScan,error:lastError}}
  function repair(){runScan();for(const d of decorated.values())for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))if(box.dataset.loadState==='failed')box.__dtReload?.(true);return diagnostics()}

  const dispose=()=>{disposed=true;closeEmojiMenu();jumpRequest=null;document.removeEventListener('pointerdown',dismissEmojiMenu,true);document.removeEventListener('keydown',menuKey);hidePreview();document.removeEventListener('scroll',hidePreview,true);window.removeEventListener('resize',hidePreview);clearInterval(recoveryTimer);clearTimeout(scheduled);changes.disconnect();observer.disconnect();resized.disconnect();for(const state of scrollStates.values())state.dispose();scrollStates.clear();css.remove();for(const[p,s]of popups)s.detach();for(const[n,d]of decorated){d.view.remove();n.removeAttribute('data-dt-emoticon')}popups.clear();decorated.clear();assetPromises.clear();queue.splice(0);memory.clear();memoryBytes=0};
  dispose.repair=repair;dispose.diagnostics=diagnostics;return dispose;
}




import {createEmoticonRepository} from './emoticon-repository.mjs';
const emoticons=createEmoticonRepository();
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
export function createUpdatePreflight({sessions,jobs,now=()=>performance.now(),isApplying=()=>false,timeoutMs=2500,setTimer=setTimeout,clearTimer=clearTimeout}) {
 let backgroundLeaseUntil=0,lastAt=null,generation=0,disposed=false;
 const pending=new Set();
 const expression="[...document.querySelectorAll('[contenteditable=\"true\"],textarea')].some(e=>(e.innerText||e.value||'').trim().length>0)";
 function clock(){const at=now();if(!Number.isFinite(at)||at<0){backgroundLeaseUntil=0;return null}if(lastAt!==null&&at<lastAt)backgroundLeaseUntil=0;lastAt=at;return at}
 function probe(session){return new Promise((resolve,reject)=>{
  let settled=false,timer;const finish=(error,value)=>{if(settled)return;settled=true;clearTimer(timer);pending.delete(cancel);error?reject(error):resolve(value)};
  const cancel=()=>finish(Error('preflight disposed'));pending.add(cancel);timer=setTimer(()=>finish(Error('preflight timeout')),timeoutMs);
  Promise.resolve().then(()=>{if(settled||disposed)throw Error('preflight disposed');return session.send('Runtime.evaluate',{expression,returnByValue:true})}).then(result=>{
   if(result?.exceptionDetails||typeof result?.result?.value!=='boolean')throw Error('invalid preflight result');
   finish(null,result.result.value);
  }).catch(error=>finish(error));
 });}
 async function inspect(){
  if(disposed)return {known:false,drafts:0,downloads:jobs.size};
  const snapshot=[...sessions].map(([id,session])=>({id,session,epoch:session.preflightEpoch||0}));
  if(!snapshot.length||snapshot.some(x=>x.session.ws?.readyState!==1))return {known:false,drafts:0,downloads:jobs.size};
  const results=await Promise.all(snapshot.map(async x=>{try{return {known:true,draft:await probe(x.session)}}catch{return {known:false,draft:false}}}));
  const stable=!disposed&&snapshot.length===sessions.size&&snapshot.every(x=>sessions.get(x.id)===x.session&&x.session.ws?.readyState===1&&(x.session.preflightEpoch||0)===x.epoch);
  return {known:stable&&results.every(x=>x.known),drafts:results.filter(x=>x.draft).length,downloads:jobs.size};
 }
 return {
  inspect,
  async reserve(){const request=++generation,result=await inspect(),at=clock();const reserved=!disposed&&request===generation&&result.known&&result.drafts===0&&result.downloads===0&&!isApplying()&&at!==null;
   if(request===generation)backgroundLeaseUntil=reserved?at+15*60*1000:0;
   return {...result,reserved};
  },
  unreserve(){generation++;backgroundLeaseUntil=0},
  downloadBlocked(){const at=clock();return isApplying()||at!==null&&at<backgroundLeaseUntil},
  dispose(){disposed=true;generation++;backgroundLeaseUntil=0;for(const cancel of [...pending])cancel()}
 };
}
// End isolated update preflight.
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(19349,'127.0.0.1',()=>r(true))}))process.exit(0);
import {spawn} from 'node:child_process';
import {createDownloadSettings} from './download-settings.mjs';
import {resolveDownloads,openFolder,chooseDownloadFolder,commitDownloadFile} from './download-paths.mjs';
const defaultFolder=await resolveDownloads();
const dataDir=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
await fs.mkdir(defaultFolder,{recursive:true});await fs.mkdir(dataDir,{recursive:true});
const downloadSettings=await createDownloadSettings(dataDir,defaultFolder,{legacyFolders:[path.join(process.env.USERPROFILE,'Downloads','Dooray'),path.join(defaultFolder,'Dooray')]});
const allowedFolders=downloadSettings.allowed;let pickingFolder=null;
const historyFile=path.join(dataDir,'managed-downloads.json');let items=[];try{items=JSON.parse(await fs.readFile(historyFile,'utf8'));if(!Array.isArray(items))items=[];}catch{}
for(const i of items)if(i.status==='downloading')i.status='interrupted';
let saveQueue=Promise.resolve();function save(){const text=JSON.stringify(items);saveQueue=saveQueue.then(()=>fs.writeFile(historyFile,text)).catch(()=>{});return saveQueue;}
let completionId="",startId="",batchFailed=false;const jobs=new Map();const sessions=new Map();const state=()=>({folder:downloadSettings.folder,defaultFolder,completionId,startId,items:items.map(({path:localPath,...x})=>x)});
function publish(){for(const s of sessions.values())if(s.ws.readyState===1)s.send('Runtime.evaluate',{expression:'window.__doorayDownloadsReady=Date.now();window.__doorayDownloadsChanged?.('+JSON.stringify(state())+')'}).catch(()=>{});}
const safeName=name=>(String(name||'download').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'').replace(/^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?=\.|$)/i,'_$1').slice(0,150)||'download');
async function download(s,p){const url=new URL(p.url);if(url.origin!==s.origin||!/^\/messenger\/v2\/api\/channel\/\d+\/file\/\d+$/.test(url.pathname)||url.search)throw Error('지원하지 않는 파일 주소입니다.');const id=crypto.randomUUID(),name=safeName(p.name),parts=url.pathname.split('/'),folder=downloadSettings.folder,temp=path.join(folder,'.dooray-'+id+'.part');const item={id,name,path:path.join(folder,name),received:0,total:Number(p.total)||0,status:'downloading',at:Date.now(),channelId:parts[5],fileId:parts[7],logId:/^\d+$/.test(p.logId||'')?p.logId:null};const job={cancelled:false,handle:null,session:s};if(!jobs.size)batchFailed=false;jobs.set(id,job);items.unshift(item);startId=id;publish();void save();
(async()=>{let file,handle;try{const tree=await s.send('Page.getFrameTree',{});const {resource:r}=await s.send('Network.loadNetworkResource',{frameId:tree.frameTree.frame.id,url:url.href,options:{disableCache:true,includeCredentials:true}});if(!r?.success||r.httpStatusCode>=400||!r.stream)throw Error('다운로드 실패: '+(r?.httpStatusCode||r?.netErrorName||'권한/만료 확인'));handle=r.stream;job.handle=handle;if(job.cancelled)throw Error('취소됨');const length=Number(Object.entries(r.headers||{}).find(([k])=>k.toLowerCase()==='content-length')?.[1]);if(length>0)item.total=length;file=await fs.open(temp,'wx');let last=0;while(true){if(job.cancelled)throw Error('취소됨');const chunk=await s.send('IO.read',{handle,size:262144});if(job.cancelled)throw Error('취소됨');const b=Buffer.from(chunk.data||'',chunk.base64Encoded?'base64':'utf8');await file.write(b);item.received+=b.length;if(Date.now()-last>250){publish();last=Date.now()}if(chunk.eof)break;}await file.close();file=null;if(job.cancelled)throw Error('취소됨');job.committing=true;item.path=await commitDownloadFile(temp,folder,name);item.name=path.basename(item.path);item.status='complete';item.seen=false;item.total=item.received;}catch(e){item.status=job.cancelled?'cancelled':'error';item.error=String(e.message).slice(0,180);}finally{if(file)await file.close().catch(()=>{});if(handle)await s.send('IO.close',{handle}).catch(()=>{});await fs.unlink(temp).catch(()=>{});if(item.status!=='complete')batchFailed=true;jobs.delete(id);if(!jobs.size&&!batchFailed)completionId=crypto.randomUUID();publish();void save();}})();return {id};}
const updateRequests=new Map();let applyingUpdate=false;
const updatePreflight=createUpdatePreflight({sessions,jobs,isApplying:()=>applyingUpdate});
const backgroundRequestId=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
process.on('message',m=>{
 if(m?.type==='background-unreserve'){updatePreflight.unreserve();return}
 if(m?.type==='background-preflight'&&backgroundRequestId(m.id)){
  void updatePreflight.reserve().catch(()=>({known:false,drafts:0,downloads:jobs.size,reserved:false})).then(result=>{if(process.connected)try{process.send({type:'background-preflight-result',id:m.id,result})}catch{}});return;
 }
 if(m?.type!=='update-result')return;const p=updateRequests.get(m.id);if(p){clearTimeout(p.timer);updateRequests.delete(m.id);p.resolve(m.result)}
});
process.on('disconnect',()=>{updatePreflight.dispose();for(const p of updateRequests.values()){clearTimeout(p.timer);p.reject(Error('업데이트 연결 종료'));}updateRequests.clear();});
process.on('exit',()=>updatePreflight.dispose());
function requestUpdate(type,args={}){return new Promise((resolve,reject)=>{if(!process.connected)return reject(Error('업데이트 지원 설치 파일로 전환 설치해 주세요.'));const id=crypto.randomUUID(),timer=setTimeout(()=>{updateRequests.delete(id);reject(Error('업데이트 응답 시간 초과'));},720000);updateRequests.set(id,{resolve,reject,timer});process.send({type,id,token:args.token});});}
async function command(s,p){
if(p.op==='choose-folder'){if(!pickingFolder)pickingFolder=(async()=>{const selected=await chooseDownloadFolder(downloadSettings.folder);if(selected!==null)await downloadSettings.set(selected);publish();return state();})().finally(()=>{pickingFolder=null});return pickingFolder;}
if(p.op==='reset-folder'){await downloadSettings.set(null);publish();return state();}
if(p.op==='open-current-folder'){await openFolder(downloadSettings.folder);return true;}
if(p.op==='update-preflight'){const result=await updatePreflight.inspect();if(!result.known)throw Error('작성 중인 내용을 확인하지 못했습니다. 다시 시도해 주세요.');return {drafts:result.drafts,downloads:result.downloads};}
if(['update-check','update-status','update-install','update-apply','update-cancel'].includes(p.op)){if(['update-install','update-apply'].includes(p.op)&&jobs.size)throw Error('진행 중인 다운로드가 있습니다. 완료 후 업데이트해 주세요.');if(p.op==='update-apply')applyingUpdate=true;try{const result=await requestUpdate(p.op,p);if(p.op==='update-cancel'||result.status==='error')applyingUpdate=false;return result}catch(e){applyingUpdate=false;throw e}}if(p.op==='emoticon-catalog')return emoticons.catalog(p.refresh===true);if(p.op==='emoticon-image')return emoticons.image(p.path,p.ref,p.refresh===true);if(p.op==='list')return state();if(p.op==='seen'){const ids=new Set(Array.isArray(p.ids)?p.ids:[]);for(const item of items)if(item.status==='complete'&&ids.has(item.id))item.seen=true;await save();publish();return true;}if(p.op==='cancel'){const job=jobs.get(p.id);if(!job||job.committing)return false;job.cancelled=true;if(job.handle)await job.session.send('IO.close',{handle:job.handle}).catch(()=>{});return true;}if(p.op==='download'){if(updatePreflight.downloadBlocked())throw Error('업데이트 적용 중입니다. 재실행 후 다운로드해 주세요.');return download(s,p);}if(p.op==='forget'||p.op==='clear'){if(p.op==='forget'&&typeof p.id!=='string')throw Error('다운로드 기록 ID가 필요합니다.');items=p.op==='clear'?[]:items.filter(x=>x.id!==p.id);await save();publish();return state();}if(!['open','folder'].includes(p.op))throw Error('지원하지 않는 작업입니다.');const item=items.find(x=>x.id===p.id);if(!item||item.status!=='complete')throw Error('완료된 파일이 없습니다.');const file=path.resolve(item.path);if(!allowedFolders.has(path.dirname(file).toLowerCase()))throw Error('관리 폴더 밖의 파일입니다.');if(p.op==='folder'){await openFolder(path.dirname(file));return true;}const stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink())throw Error('일반 파일만 열 수 있습니다.');if(p.op==='open'&&/\.(exe|com|bat|cmd|ps1|vbs|js|msi|scr|lnk|url|hta)$/i.test(file))throw Error('실행 파일은 폴더에서 직접 확인해 주세요.');await new Promise((resolve,reject)=>{const child=spawn('explorer.exe',p.op==='folder'?[path.dirname(file)]:[file],{windowsHide:false,stdio:'ignore'});child.once('error',reject);child.once('spawn',resolve);});return true;}
async function attach(t){const origin=new URL(t.url).origin,ws=new WebSocket(t.webSocketDebuggerUrl),pending=new Map(),contexts=new Map();let seq=0;const s={ws,origin,preflightEpoch:0,send(method,params){return new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));})}};sessions.set(t.id,s);
ws.onopen=async()=>{try{await s.send('Runtime.enable',{});await s.send('Runtime.addBinding',{name:'__doorayDownloadCommand'});publish();}catch{ws.close();}};
ws.onmessage=async e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}return;}if(m.method==='Runtime.executionContextCreated'){s.preflightEpoch++;const c=m.params.context;contexts.set(c.id,c.origin===origin&&c.auxData?.isDefault===true);}if(m.method==='Runtime.executionContextsCleared'){s.preflightEpoch++;updatePreflight.unreserve();contexts.clear();void requestUpdate('update-cancel').catch(()=>{});}if(m.method==='Runtime.executionContextDestroyed'){s.preflightEpoch++;updatePreflight.unreserve();contexts.delete(m.params.executionContextId);}if(m.method==='Runtime.bindingCalled'&&m.params.name==='__doorayDownloadCommand'&&contexts.get(m.params.executionContextId)){let p;try{p=JSON.parse(m.params.payload);if(typeof p.requestId!=='string'||p.requestId.length>80)return;const result=await command(s,p);await s.send('Runtime.evaluate',{contextId:m.params.executionContextId,expression:'window.__doorayDownloadReply?.('+JSON.stringify(p.requestId)+','+JSON.stringify(result)+',null)'});}catch(error){if(p?.requestId)await s.send('Runtime.evaluate',{contextId:m.params.executionContextId,expression:'window.__doorayDownloadReply?.('+JSON.stringify(p.requestId)+',null,'+JSON.stringify(error.message)+')'}).catch(()=>{});}}};
ws.onclose=()=>{updatePreflight.unreserve();void requestUpdate('update-cancel').catch(()=>{});sessions.delete(t.id);for(const p of pending.values())p.reject(Error('연결 종료'));pending.clear();};ws.onerror=()=>ws.close();}
let busy=false;async function tick(){if(busy)return;busy=true;try{for(const name of ['stop-agent.flag','theme-disabled.flag']){try{await fs.access(path.join(dataDir,name));process.exit(0)}catch{}}const targets=await(await fetch('http://127.0.0.1:19347/json/list')).json();for(const t of targets){let u;try{u=new URL(t.url)}catch{continue;}if(t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)&&u.pathname.startsWith('/messenger')&&!sessions.has(t.id))await attach(t);}publish();}catch{}finally{busy=false;}}
await tick();setInterval(tick,1500);

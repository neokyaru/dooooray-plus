// One owner for conversation bottom-follow. Never sends messages, replaces a
// native handler or infers a send from composing/modified Enter events.
function installChatScroll({document=globalThis.document,getTargets=()=>[],now=()=>performance.now(),requestFrame,cancelFrame,ResizeObserver,MutationObserver}={}){
  const win=document.defaultView||globalThis;
  requestFrame ||= win.requestAnimationFrame.bind(win);cancelFrame ||= win.cancelAnimationFrame.bind(win);
  ResizeObserver ||= win.ResizeObserver;MutationObserver ||= win.MutationObserver;
  const states=new Map(),observedRefs=new Map(),tokenOwner={};let disposed=false,refreshing=false,writes=0;
  const geometry=scroll=>({top:Math.max(0,Number(scroll.scrollTop)||0),height:Number(scroll.scrollHeight)||0,client:Number(scroll.clientHeight)||0});
  const near=m=>Math.max(0,m.height-m.client)-m.top<=3;
  const changed=(a,b)=>Math.abs(a.height-b.height)>.5||Math.abs(a.client-b.client)>.5;
  const hasMessages=scroll=>!!scroll.querySelector('[data-dp-native~="message-group"],[data-logid]');
  const editable=node=>!!node?.closest?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]');
  function relevant(state,node){return !node||node===state.scroll||state.scroll.contains(node)||node.contains?.(state.scroll)||state.editor&&(node===state.editor||state.editor.contains(node)||node.contains?.(state.editor));}
  function current(state){return !disposed&&states.get(state.scroll)===state&&state.scroll.isConnected;}
  function cancel(state){state.follow=false;state.allowRearm=false;state.tailHistory=[];state.revision++;state.remaining=0;state.writtenTop=null;if(state.frame){cancelFrame(state.frame);state.frame=0}}
  function anchorIdentity(node){
    const id=node.getAttribute?.('data-logid');if(id!==null&&id!==undefined)return 'log:'+id;
    const section=node.matches?.('[class*="js-log-right-content-"]')?node:node.querySelector?.('[class*="js-log-right-content-"]');
    const token=[...(section?.classList||[])].find(value=>value.startsWith('js-log-right-content-'));
    return token?'content:'+token:null;
  }
  const validAnchor=(state,anchor,requireIdentity=false)=>!!(anchor?.node.isConnected&&state.scroll.contains(anchor.node)&&(!requireIdentity||anchor.identity!==null)&&(anchor.identity===null||anchorIdentity(anchor.node)===anchor.identity));
  function measureAnchor(state){
    const viewport=state.scroll.getBoundingClientRect();
    const candidates=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');
    for(const node of candidates.length?candidates:state.content.children){const rect=node.getBoundingClientRect();if(rect.height>0&&rect.bottom>viewport.top&&rect.top<viewport.bottom)return {node,offset:rect.top-viewport.top,identity:anchorIdentity(node)};}
    return null;
  }
  // A native composer handler can scroll its conversation even when the reader
  // is far above the tail. Capture before that handler runs, then keep the real
  // visible message (not the subsequently forced scrollTop) as the reading intent.
  function captureReading(state){return {anchor:measureAnchor(state),top:geometry(state.scroll).top};}
  function holdReading(state){if(!state.follow&&!state.readingHold)state.readingHold=captureReading(state);}
  function readingGesture(state,direction){
    state.tailHistory=[];
    if(state.readingHold){state.readingHold=captureReading(state);state.readingNavigation={direction,at:now()};}
  }
  function readingNavigation(state,value,old){
    if(state.drag||state.touchMoving)return true;
    const intent=state.readingNavigation,age=intent?now()-intent.at:Infinity;
    if(!intent||age<0||age>900){state.readingNavigation=null;return false;}
    const delta=value.top-old.top;
    if(Math.abs(delta)<.5)return false;
    return intent.direction===0||Math.sign(delta)===intent.direction;
  }
  function acceptReadingNavigation(state,value,old){
    if(!readingNavigation(state,value,old))return false;
    state.readingHold=captureReading(state);state.revision++;
    if(near(value)&&!state.drag&&!state.touchMoving){state.follow=true;state.readingHold=null;state.readingNavigation=null;state.allowRearm=false;}
    else if(state.readingNavigation?.direction===0)state.readingNavigation=null;
    state.metrics=value;return true;
  }
  function restoreReading(state){
    const hold=state.readingHold;if(!hold||!current(state))return;
    const value=geometry(state.scroll),anchor=hold.anchor;
    let top=hold.top;
    if(validAnchor(state,anchor,true))top=value.top+anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top-anchor.offset;
    if(Math.abs(value.top-top)>.5)write(state,top);
    // Native history prepending may already have preserved the same anchor.
    // Retain its updated numeric position as the fallback if that row is recycled.
    hold.top=geometry(state.scroll).top;state.metrics=geometry(state.scroll);
  }
  function rememberTail(state,value){
    if(!state.follow||!near(value))return;
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    const previous=state.tailHistory[state.tailHistory.length-1];
    if(!previous||Math.abs(previous.height-value.height)>.5||Math.abs(previous.client-value.client)>.5)state.tailHistory.push({height:value.height,client:value.client,at});
    if(state.tailHistory.length>12)state.tailHistory.shift();
  }
  function restoredTail(state,value){
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    // Dooray can restore either the old scrollTop or its old content extent
    // adjusted for the resized composer. Only these proven tail coordinates
    // qualify; an arbitrary jump elsewhere in history still cancels following.
    return state.tailHistory.some(point=>Math.abs(value.top-Math.max(0,point.height-point.client))<=3||Math.abs(value.top-Math.max(0,point.height-value.client))<=3);
  }
  function write(state,top){
    if(!current(state))return;state.writing=true;
    try{state.scroll.scrollTop=top;writes++;state.metrics=geometry(state.scroll);state.writtenTop=state.metrics.top;}finally{state.writing=false}
  }
  function schedule(state){
    if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    state.remaining=3;state.stable=0;if(!state.frame)state.frame=requestFrame(()=>settle(state));
  }
  function settle(state){
    state.frame=0;refresh();if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    if(!state.follow){
      // A wheel/key can move the browser before its asynchronous scroll event.
      // A layout observer must not restore the pre-gesture reading snapshot.
      acceptReadingNavigation(state,geometry(state.scroll),state.metrics);
      if(!state.follow){restoreReading(state);state.remaining=0;return;}
    }
    const before=geometry(state.scroll);
    // Newly mounted empty panes may still receive Dooray's saved reading
    // position. Measure that native restoration before taking ownership.
    if(state.unsettled){if(before.height>before.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(before)}state.metrics=before;state.remaining=0;return;}
    if(changed(before,state.metrics))rememberTail(state,state.metrics);
    const gap=Math.max(0,before.height-before.client)-before.top;
    if(gap>.5)write(state,state.scroll.scrollHeight);
    const after=geometry(state.scroll);state.stable=!changed(before,after)&&Math.max(0,after.height-after.client)-after.top<=.5?state.stable+1:0;
    rememberTail(state,after);state.metrics=after;state.remaining--;
    if(state.remaining>0&&state.stable<2)state.frame=requestFrame(()=>settle(state));
  }
  function onScroll(state){
    refresh();if(!current(state))return;const value=geometry(state.scroll),old=state.metrics;
    if(state.writing){state.metrics=value;return;}
    const layoutChanged=changed(value,old),own=state.writtenTop!==null&&Math.abs(value.top-state.writtenTop)<.75;
    if(layoutChanged)rememberTail(state,old);
    const restoring=restoredTail(state,value);
    state.writtenTop=null;
    if(state.readingHold&&!state.follow&&!own){
      if(!acceptReadingNavigation(state,value,old)){restoreReading(state);return;}
    }
    if(state.drag||state.touchMoving){state.follow=false;}
    else if(state.unsettled&&layoutChanged){if(value.height>value.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(value)}}
    else if(state.follow&&!own&&value.top<old.top-.5&&!layoutChanged&&!near(value)&&!restoring){cancel(state);}
    else if(!state.follow&&!state.readingHold&&near(value)&&(value.top>old.top+.5||state.allowRearm)){state.follow=true;state.allowRearm=false;}
    else if(!state.follow&&!layoutChanged&&!own&&Math.abs(value.top-old.top)>.5){state.revision++;}
    state.metrics=value;if(state.follow){if(near(value))rememberTail(state,value);if(layoutChanged||restoring)schedule(state);}
  }
  const resize=ResizeObserver?new ResizeObserver(entries=>{refresh();for(const state of states.values())if(entries.some(entry=>state.observed.has(entry.target)))schedule(state)}):null;
  function observeSize(state){
    if(!state.sizeDirty)return;state.sizeDirty=false;
    const next=new Set([state.scroll,state.content]);if(state.editor)next.add(state.editor);
    // Dooray can put the message groups directly in a fixed-height scroller;
    // observing that viewport alone would miss late fonts and inline images.
    for(const child of [...state.content.children].slice(-512))next.add(child);
    const last=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');if(last.length)next.add(last[last.length-1]);
    for(const node of state.observed)if(!next.has(node))releaseSize(node);
    for(const node of next)if(!state.observed.has(node)){const count=observedRefs.get(node)||0;if(!count)resize?.observe(node);observedRefs.set(node,count+1)}
    state.observed=next;
  }
  function releaseSize(node){const count=observedRefs.get(node)||0;if(count<=1){observedRefs.delete(node);resize?.unobserve(node)}else observedRefs.set(node,count-1);}
  function attach(target){
    const scroll=target.scroll,metrics=geometry(scroll),state={scroll,content:target.content||scroll,editor:target.editor||null,roomKey:target.roomKey,metrics,follow:near(metrics),frame:0,remaining:0,stable:0,revision:0,writtenTop:null,writing:false,drag:false,touchMoving:false,touchY:null,allowRearm:false,tailHistory:[],readingHold:null,readingNavigation:null,observed:new Set(),sizeDirty:true,unsettled:metrics.height<=metrics.client&&!hasMessages(scroll)};
    state.scrollEvent=()=>onScroll(state);
    state.wheel=event=>{if(event.deltaY<0){readingGesture(state,-1);cancel(state);}else if(event.deltaY>0){readingGesture(state,1);state.allowRearm=true;if(near(geometry(scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}}};
    state.pointer=event=>{const rect=scroll.getBoundingClientRect(),width=Math.max(12,(Number(scroll.offsetWidth)||scroll.clientWidth)-scroll.clientWidth);if(event.target===scroll&&event.pointerType!=='touch'&&event.clientX>=rect.right-width&&event.clientX<=rect.right+1){readingGesture(state,0);state.drag=true;cancel(state)}};
    state.touchStart=event=>{state.touchY=event.touches?.[0]?.clientY??null;state.touchMoving=false;};
    state.touchMove=event=>{const y=event.touches?.[0]?.clientY;if(state.touchY!==null&&Number.isFinite(y)&&Math.abs(y-state.touchY)>2){readingGesture(state,Math.sign(state.touchY-y));state.touchMoving=true;cancel(state)}};
    scroll.addEventListener('scroll',state.scrollEvent,{passive:true});scroll.addEventListener('wheel',state.wheel,{passive:true});scroll.addEventListener('pointerdown',state.pointer,{passive:true});scroll.addEventListener('touchstart',state.touchStart,{passive:true});scroll.addEventListener('touchmove',state.touchMove,{passive:true});
    states.set(scroll,state);observeSize(state);return state;
  }
  function detach(state){
    cancel(state);for(const node of state.observed)releaseSize(node);state.observed.clear();
    for(const [event,handler]of [['scroll',state.scrollEvent],['wheel',state.wheel],['pointerdown',state.pointer],['touchstart',state.touchStart],['touchmove',state.touchMove]])state.scroll.removeEventListener(event,handler);
    states.delete(state.scroll);
  }
  function refresh(){
    if(disposed||refreshing)return;refreshing=true;
    try{
      let targets;try{targets=getTargets()||[]}catch{targets=[]}
      const selected=new Map();for(const target of targets){if(!target?.scroll?.isConnected||target.scroll.clientHeight<=0||target.roomKey===undefined||target.roomKey===null||target.roomKey==='')continue;if(!selected.has(target.scroll))selected.set(target.scroll,target);}
      for(const state of states.values()){const target=selected.get(state.scroll);if(!target||target.roomKey!==state.roomKey)detach(state);}
      for(const target of selected.values()){
        let state=states.get(target.scroll);if(!state){attach(target);continue;}
        const content=target.content||target.scroll,editor=target.editor||null;
        if(content!==state.content||editor!==state.editor){state.content=content;state.editor=editor;state.sizeDirty=true;observeSize(state);schedule(state)}else observeSize(state);
      }
    }finally{refreshing=false}
  }
  function notifyLayout(node){if(disposed)return;refresh();for(const state of states.values())if(relevant(state,node))schedule(state);}
  function beforeLayout(node){
    if(disposed)return null;refresh();const records=[];
    for(const state of states.values())if(relevant(state,node))records.push({state,revision:state.revision,roomKey:state.roomKey,follow:state.follow,metrics:geometry(state.scroll),anchor:state.follow?null:measureAnchor(state)});
    return {owner:tokenOwner,records};
  }
  function afterLayout(token){
    if(disposed||token?.owner!==tokenOwner)return;refresh();
    for(const record of token.records){const state=record.state;if(!current(state)||record.roomKey!==state.roomKey||record.revision!==state.revision)continue;
      if(record.follow&&state.follow){
        const value=geometry(state.scroll);
        // Excel temporarily removes row min-heights while measuring. Chromium
        // can clamp top during that owned transaction, then report a scroll only
        // after the final height is restored. Keep the actually observed clamp
        // as evidence, without treating any unrelated history jump as a restore.
        if(value.top<record.metrics.top-.5&&!near(value)){
          state.tailHistory.push({height:value.top+value.client,client:value.client,at:now()});
          if(state.tailHistory.length>12)state.tailHistory.shift();
        }
        schedule(state);continue;
      }
      // Explicit decoration/theme changes can occur above a reader. Preserve
      // a real visible anchor, and avoid doubling the browser's own anchoring.
      const anchor=record.anchor;if(!record.follow&&!state.follow&&validAnchor(state,anchor)){
        const offset=anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top,delta=offset-anchor.offset;
        if(Math.abs(delta)>.5)write(state,state.scroll.scrollTop+delta);
      }
    }
  }
  const key=event=>{
    if(disposed)return;refresh();
    for(const state of states.values())if(relevant(state,event.target)){
      if(editable(event.target)){
        if(!state.editor?.contains(event.target))continue;
        holdReading(state);
        if(!event.isComposing&&event.keyCode!==229&&event.key==='Enter'&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&state.follow){state.unsettled=false;rememberTail(state,geometry(state.scroll));schedule(state)}
        continue;
      }
      if(event.isComposing||event.keyCode===229)continue;
      if(['ArrowUp','PageUp','Home'].includes(event.key)||event.key===' '&&event.shiftKey){readingGesture(state,-1);cancel(state);}
      else if(['ArrowDown','PageDown','End'].includes(event.key)||event.key===' '){readingGesture(state,1);state.allowRearm=true;}
      else readingGesture(state,0);
    }
  };
  const editorInput=event=>{if(disposed)return;refresh();for(const state of states.values())if(state.editor?.contains(event.target))holdReading(state);};
  // Native search/quote navigation wins over an old restore hint. Clicking or
  // editing a different pane must not release this pane's saved reading intent.
  const pointerIntent=event=>{
    if(disposed)return;refresh();const owned=[...states.values()].filter(state=>relevant(state,event.target));
    for(const state of owned.length?owned:states.values()){
      if(state.editor?.contains(event.target)){holdReading(state);continue;}
      state.tailHistory=[];
      const message=event.target?.closest?.('[data-logid],[class*="js-log-right-content-"]');
      const action=event.target?.closest?.('button,[role="button"],a,[role="link"]');
      const label=(action?.getAttribute('aria-label')||'')+' '+(action?.getAttribute('title')||'');
      const inside=state.scroll.contains(event.target),explicitJump=!!message&&!inside||/검색|인용|답글|메시지.*이동|search|quote|jump|go to message|reply/i.test(label);
      const jump=inside||explicitJump;
      // Submit buttons can be siblings of the editor. An arbitrary click is
      // not permission to discard a saved reading position. A proven message
      // navigation releases the hold, including asynchronously loaded results.
      if(jump){state.readingHold=null;state.readingNavigation=null;if(explicitJump)cancel(state);}
    }
  };
  const pointerUp=()=>{for(const state of states.values())if(state.drag){state.drag=false;state.readingNavigation=null;if(near(geometry(state.scroll))){state.follow=true;state.readingHold=null;schedule(state)}else if(state.readingHold)state.readingHold=captureReading(state)}};
  const touchEnd=()=>{for(const state of states.values()){const moved=state.touchMoving;state.touchY=null;state.touchMoving=false;if(moved&&near(geometry(state.scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}else if(moved&&state.readingHold)state.readingHold=captureReading(state)}};
  const mutation=MutationObserver?new MutationObserver(records=>{
    if(disposed)return;for(const state of states.values())if(records.some(record=>relevant(state,record.target)))state.sizeDirty=true;
    refresh();for(const state of states.values())if(records.some(record=>relevant(state,record.target)))schedule(state);
  }):null;
  mutation?.observe(document.documentElement||document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class','hidden']});
  const onLoad=event=>notifyLayout(event.target),onResize=()=>notifyLayout(),onFonts=()=>notifyLayout();
  document.addEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.addEventListener(event,editorInput,true);document.addEventListener('pointerdown',pointerIntent,true);document.addEventListener('pointerup',pointerUp,true);document.addEventListener('pointercancel',pointerUp,true);document.addEventListener('touchend',touchEnd,true);document.addEventListener('touchcancel',touchEnd,true);document.addEventListener('load',onLoad,true);document.addEventListener('loadedmetadata',onLoad,true);win.addEventListener('resize',onResize);
  document.fonts?.addEventListener?.('loadingdone',onFonts);document.fonts?.ready?.then(()=>{if(!disposed)onFonts()}).catch(()=>{});
  refresh();
  return {
    refresh,beforeLayout,afterLayout,notifyLayout,
    isFollowing(node){if(disposed)return false;refresh();return [...states.values()].some(state=>relevant(state,node)&&state.follow)},
    diagnostics(){return {targets:states.size,following:[...states.values()].filter(state=>state.follow).length,pending:[...states.values()].filter(state=>state.frame).length,writes}},
    dispose(){if(disposed)return;disposed=true;mutation?.disconnect();resize?.disconnect();for(const state of [...states.values()])detach(state);document.removeEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.removeEventListener(event,editorInput,true);document.removeEventListener('pointerdown',pointerIntent,true);document.removeEventListener('pointerup',pointerUp,true);document.removeEventListener('pointercancel',pointerUp,true);document.removeEventListener('touchend',touchEnd,true);document.removeEventListener('touchcancel',touchEnd,true);document.removeEventListener('load',onLoad,true);document.removeEventListener('loadedmetadata',onLoad,true);win.removeEventListener('resize',onResize);document.fonts?.removeEventListener?.('loadingdone',onFonts);}
  };
}

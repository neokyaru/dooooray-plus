export function isNavigationError(error){return /Cannot find context|context.*destroyed|context.*not found|Inspected target.*(navigat|closed)|Session.*closed|No frame with given id/i.test(error?.message||'');}
export function makeBootstrap(source,attempt=''){
 const session=typeof attempt==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(attempt)?attempt:'';
 return `(()=>{
 if(window!==window.top||location.protocol!=='https:'||!/(^|\\.)(dooray|gov-dooray)\\.com$/.test(location.hostname)||!location.pathname.startsWith('/messenger'))return;
 const attempt=${JSON.stringify(session)};
 const freshAttempt=!!attempt&&window.__doorayThemeAttempt!==attempt;
 if(freshAttempt){
  window.__doorayThemeAttempt=attempt;
  if(['initialization-error','bootstrap-error','extension-error'].includes(window.__doorayThemeBlocked)){
   try{window.__doorayThemeBootstrapDispose?.()}catch{}
   delete window.__doorayThemeBoot320;delete window.__doorayThemeBlocked;
  }
 }
 if(window.__doorayTheme?.version==='3.8.33'){
  // A helper restart must be able to rebuild its own damaged UI. Ordinary
  // polls still repair/reuse it, and a healthy instance is never replaced.
  if(window.__doorayThemeBlocked&&!['removed','helper-disabled','page-structure-unavailable'].includes(window.__doorayThemeBlocked))return;
  const previous=window.__doorayTheme;let healthy=false;
  try{healthy=previous.isHealthy?.()===true}catch{}
  if(freshAttempt&&!healthy&&typeof previous.remove==='function'){
   try{previous.remove()}catch{window.__doorayThemeBlocked='initialization-error';return}
   // Cleanup owns its listeners, styles and DOM. Never delete the API alone
   // and install a duplicate over a component that refused to clean up.
   if(window.__doorayTheme===previous)return;
   delete window.__doorayThemeBoot320;
  }else{previous.repair?.();return}
 }
 if(['removed','helper-disabled','page-structure-unavailable'].includes(window.__doorayThemeBlocked))delete window.__doorayThemeBlocked;
 if(window.__doorayThemeBlocked||window.__doorayThemeBoot320)return;
 window.__doorayThemeBoot320=true;
 let observer,timer,health,missing=0;
 const release=()=>{observer?.disconnect();clearTimeout(timer);delete window.__doorayThemeBoot320};
 const stop=reason=>{release();clearInterval(health);window.__doorayThemeEmergencyStop?.(reason);window.__doorayTheme?.remove();window.__doorayThemeBlocked=reason};
 // Generated CSS class names are not an application contract. The feature
 // adapter locates native controls, and can expose a floating recovery menu.
 const structure=()=>!!document.querySelector('#root');
 const run=()=>{
  if(!document.head||!document.body||!structure())return;
  if(!window.CSS?.supports('selector(:has(*))')||!window.MutationObserver){stop('missing-browser-capability');return}
  release();
  try{(0,eval)(${JSON.stringify(source+'\n//# sourceURL=dooray-theme-extension.js')});if(!window.__doorayTheme)throw Error('Theme did not initialize');delete window.__doorayThemeBlocked;
   health=setInterval(()=>{if(window.__doorayThemeBlocked){clearInterval(health);return}missing=structure()?0:missing+1;if(missing>=5)stop('page-structure-unavailable')},2000);window.__doorayThemeBootstrapDispose=()=>{clearInterval(health);release()};
  }catch{stop('initialization-error')}
 };
 observer=new MutationObserver(()=>{try{run()}catch{stop('bootstrap-error')}});observer.observe(document,{childList:true,subtree:true});timer=setTimeout(()=>stop('page-structure-unavailable'),20000);run();
})();`}

// A child remains owned until its actual exit, not merely until IPC shutdown or
// kill was requested. Pure/injectable so lifecycle tests never start the app.
export function createOwnedChildRetirement({graceMs=7000,killWaitMs=1000,setTimer=setTimeout,clearTimer=clearTimeout,onExit=()=>{},onStalled=()=>{}}={}){
 const retiring=new Map();
 const exited=child=>child.exitCode!==null&&child.exitCode!==undefined||child.signalCode!==null&&child.signalCode!==undefined;
 const notify=(fn,...args)=>{try{fn(...args)}catch{}};
 function retire(child){
  if(!child)return Promise.resolve(true);
  if(retiring.has(child))return retiring.get(child).promise;
  if(exited(child)){notify(onExit,child);return Promise.resolve(true);}
  let resolve;const record={promise:new Promise(r=>resolve=r),grace:null,deadline:null,settled:false};
  const settle=value=>{if(!record.settled){record.settled=true;resolve(value)}};
  const finish=()=>{
   if(retiring.get(child)!==record)return;
   clearTimer(record.grace);clearTimer(record.deadline);retiring.delete(child);
   child.removeListener('exit',finish);child.removeListener('close',finish);child.removeListener('error',error);
   settle(true);notify(onExit,child);
  };
  const error=()=>{if(!child.pid||exited(child))finish();};
  retiring.set(child,record);child.on('exit',finish);child.on('close',finish);child.on('error',error);
  record.grace=setTimer(()=>{
   record.grace=null;if(retiring.get(child)!==record)return;if(exited(child)){finish();return;}
   record.deadline=setTimer(()=>{record.deadline=null;if(retiring.get(child)!==record)return;if(exited(child)){finish();return;}settle(false);notify(onStalled,child);},killWaitMs);
   try{child.kill();}catch{} // Directly owned child only; never enumerate/kill by name.
  },graceMs);
  try{if(child.connected)child.send({type:'shutdown'});}catch{}
  return record.promise;
 }
 return {retire,has:child=>retiring.has(child),get busy(){return retiring.size>0},get count(){return retiring.size},wait(){return Promise.all([...retiring.values()].map(record=>record.promise)).then(results=>results.every(Boolean));},forceRemaining(){for(const child of retiring.keys())if(!exited(child))try{child.kill()}catch{}}};
}

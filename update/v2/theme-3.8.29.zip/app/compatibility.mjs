export function isNavigationError(error){return /Cannot find context|context.*destroyed|context.*not found|Inspected target.*(navigat|closed)|Session.*closed|No frame with given id/i.test(error?.message||'');}
export function makeBootstrap(source,attempt=''){
 const session=typeof attempt==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(attempt)?attempt:'';
 return `(()=>{
 if(window!==window.top||location.protocol!=='https:'||!/(^|\\.)(dooray|gov-dooray)\\.com$/.test(location.hostname)||!location.pathname.startsWith('/messenger'))return;
 const attempt=${JSON.stringify(session)};
 if(attempt&&window.__doorayThemeAttempt!==attempt){
  window.__doorayThemeAttempt=attempt;
  if(['initialization-error','bootstrap-error','extension-error'].includes(window.__doorayThemeBlocked)){
   try{window.__doorayThemeBootstrapDispose?.()}catch{}
   delete window.__doorayThemeBoot320;delete window.__doorayThemeBlocked;
  }
 }
 if(window.__doorayTheme?.version==='3.8.29'){window.__doorayTheme.repair?.();return}
 if(['removed','helper-disabled','page-structure-unavailable'].includes(window.__doorayThemeBlocked))delete window.__doorayThemeBlocked;
 if(window.__doorayThemeBlocked||window.__doorayThemeBoot320)return;
 window.__doorayThemeBoot320=true;
 let observer,timer,health,missing=0;
 const release=()=>{observer?.disconnect();clearTimeout(timer);delete window.__doorayThemeBoot320};
 const stop=reason=>{release();clearInterval(health);window.__doorayThemeEmergencyStop?.(reason);window.__doorayTheme?.remove();window.__doorayThemeBlocked=reason};
 // Generated CSS class names are not an application contract. The feature
 // adapter locates native controls, and can expose a floating recovery menu.
 const structure=()=>!!document.querySelector('#root');
 const run=()=>{
  if(!document.head||!document.body||!structure())return;
  if(!window.CSS?.supports('selector(:has(*))')||!window.MutationObserver){stop('missing-browser-capability');return}
  release();
  try{(0,eval)(${JSON.stringify(source+'\n//# sourceURL=dooray-theme-extension.js')});if(!window.__doorayTheme)throw Error('Theme did not initialize');delete window.__doorayThemeBlocked;
   health=setInterval(()=>{if(window.__doorayThemeBlocked){clearInterval(health);return}missing=structure()?0:missing+1;if(missing>=5)stop('page-structure-unavailable')},2000);window.__doorayThemeBootstrapDispose=()=>{clearInterval(health);release()};
  }catch{stop('initialization-error')}
 };
 observer=new MutationObserver(()=>{try{run()}catch{stop('bootstrap-error')}});observer.observe(document,{childList:true,subtree:true});timer=setTimeout(()=>stop('page-structure-unavailable'),20000);run();
})();`}

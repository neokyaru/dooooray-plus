import {makeBootstrap,isNavigationError} from './compatibility.mjs';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

// Target recovery stays inside the signed feature release. Exported as an isolated
// controller so tests never need to connect to, modify, or close a real Dooray app.
export function createTargetMonitor({getTargets,Socket,bootstrap,now=()=>performance.now(),onHealthy=()=>{},onUnhealthy=()=>{},onFault=()=>{},onStatus=()=>{},log=()=>{},port=19347}){
 const clients=new Map(),retries=new Map();let disposed=false,busy=false,lastTick=null,lastStatus='';
 const alive=c=>!disposed&&!c.dead&&clients.get(c.target)===c;
 const status=phase=>{if(phase!=='ready'&&[...clients.values()].some(c=>c.login))phase='waiting-login';const value={phase,targets:clients.size,connected:[...clients.values()].filter(c=>c.ws.readyState===Socket.OPEN).length,ready:[...clients.values()].filter(c=>c.ready).length};const key=JSON.stringify(value);if(key!==lastStatus){lastStatus=key;onStatus(value)}};
 const unready=()=>{if(![...clients.values()].some(c=>c.ready))onUnhealthy()};
 const allowed=t=>{try{const u=new URL(t.url),ws=new URL(t.webSocketDebuggerUrl);return t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)&&u.pathname.startsWith('/messenger')&&ws.protocol==='ws:'&&!ws.username&&!ws.password&&['127.0.0.1','localhost','[::1]'].includes(ws.hostname)&&Number(ws.port)===port}catch{return false}};
 function drop(c,reason,retry=true){
  if(!alive(c))return;c.dead=true;c.ready=false;clients.delete(c.target);c.pending.clear();
  // Callback identity is retired before close: late replies/close events cannot
  // write health, reconnect an obsolete target, or erase its newer connection.
  c.ws.onopen=c.ws.onmessage=c.ws.onclose=c.ws.onerror=null;
  if(c.script&&c.ws.readyState===Socket.OPEN)try{c.ws.send(JSON.stringify({id:++c.id,method:'Page.removeScriptToEvaluateOnNewDocument',params:{identifier:c.script}}))}catch{}
  try{c.ws.close()}catch{}
  if(retry){const attempt=(retries.get(c.target)?.attempt||0)+1;retries.set(c.target,{attempt,at:now()+Math.min(30000,1000*2**Math.min(attempt-1,5))});}else retries.delete(c.target);
  log('CDP reconnect: '+reason);unready();status('reconnecting');
 }
 function send(c,method,params,kind='command'){
  if(!alive(c)||c.ws.readyState!==Socket.OPEN)return null;const id=++c.id;c.pending.set(id,{method,kind,at:now()});
  try{c.ws.send(JSON.stringify({id,method,params}));return id}catch{drop(c,'send-failed');return null}
 }
 function probe(c){
  if(!alive(c)||[...c.pending.values()].some(p=>p.kind==='probe'))return;
  send(c,'Runtime.evaluate',{expression:bootstrap},'bootstrap');
  send(c,'Runtime.evaluate',{expression:"({blocked:window.__doorayThemeBlocked||'',ready:window.__doorayTheme?.version==='3.8.29'&&window.__doorayTheme.isHealthy?.()===true,booting:!!window.__doorayThemeBoot320,login:[...document.querySelectorAll('input[type=password],[autocomplete=current-password]')].some(e=>!e.disabled&&e.getClientRects().length>0)})",returnByValue:true},'probe');
 }
 function navigation(c){c.ready=false;for(const[id,p]of c.pending)if(p.kind==='probe'||p.kind==='bootstrap')c.pending.delete(id);unready();status('waiting-navigation')}
 function connect(t){
  let ws;try{ws=new Socket(t.webSocketDebuggerUrl)}catch{const attempt=(retries.get(t.id)?.attempt||0)+1;retries.set(t.id,{attempt,at:now()+Math.min(30000,1000*2**Math.min(attempt-1,5))});log('CDP reconnect: socket-construction-failed');return}
  const c={target:t.id,url:t.webSocketDebuggerUrl,ws,id:0,pending:new Map(),script:null,ready:false,dead:false,created:now()};clients.set(t.id,c);
  ws.onopen=()=>{if(!alive(c))return;send(c,'Page.enable',{});send(c,'Runtime.enable',{});send(c,'Page.addScriptToEvaluateOnNewDocument',{source:bootstrap},'registration');probe(c);log('Theme connected');status('connecting')};
  ws.onmessage=e=>{
   if(!alive(c))return;let m;try{m=JSON.parse(e.data)}catch{drop(c,'invalid-response');return}
   if(m.method==='Runtime.executionContextsCleared'||m.method==='Page.frameNavigated'&&!m.params?.frame?.parentId){navigation(c);return}
   const pending=c.pending.get(m.id);if(!pending)return;c.pending.delete(m.id);
   if(m.error||m.result?.exceptionDetails){
    c.ready=false;unready();const error=m.error||{message:m.result.exceptionDetails.exception?.description||m.result.exceptionDetails.text};
    if(isNavigationError(error)){if(pending.kind==='registration'||pending.kind==='command')drop(c,'navigation-context-reset');else navigation(c);return}
    // Do not log exception descriptions: host pages may put message contents or
    // URLs in them. The protocol method/code and category are enough to diagnose.
    log('CDP command failed: '+pending.method+' code='+(Number.isFinite(m.error?.code)?m.error.code:'exception'));drop(c,'command-failed');return;
   }
   if(pending.kind==='registration'){if(typeof m.result?.identifier!=='string'){drop(c,'missing-script-identifier');return}c.script=m.result.identifier;}
   if(pending.kind==='probe'){
    const value=m.result?.result?.value;if(!value||typeof value.ready!=='boolean'){drop(c,'invalid-health-response');return}
    c.ready=value.ready;c.login=!c.ready&&value.login===true;
    if(c.ready){retries.delete(c.target);onHealthy();status('ready')}else{unready();status(value.login?'waiting-login':value.booting?'waiting-page':'waiting-theme')}
    const reason=value.blocked;
    if(['initialization-error','bootstrap-error','extension-error','missing-browser-capability'].includes(reason))onFault('theme-stopped: '+reason);
   }
  };
  ws.onclose=()=>{if(alive(c))drop(c,'socket-closed')};ws.onerror=()=>{if(alive(c))drop(c,'socket-error')};
 }
 async function tick(){
  if(disposed||busy)return;busy=true;try{
   const instant=now();if(lastTick!==null&&(instant-lastTick>30000||instant<lastTick)){for(const c of [...clients.values()])drop(c,'resume',false);retries.clear();}lastTick=instant;
   let list;try{list=await getTargets()}catch{list=null}if(disposed)return;
   if(Array.isArray(list)){
    const wanted=new Map(list.filter(allowed).map(t=>[t.id,t]));
    for(const c of [...clients.values()])if(!wanted.has(c.target)||wanted.get(c.target).webSocketDebuggerUrl!==c.url)drop(c,'target-replaced',false);
    for(const id of retries.keys())if(!wanted.has(id))retries.delete(id);
    for(const t of wanted.values())if(!clients.has(t.id)&&now()>=(retries.get(t.id)?.at||0))connect(t);
   }
   for(const c of [...clients.values()]){
    if(c.ws.readyState===Socket.CONNECTING){if(now()-c.created>=10000)drop(c,'connect-timeout');continue}
    if(c.ws.readyState!==Socket.OPEN){drop(c,'socket-not-open');continue}
    if([...c.pending.values()].some(p=>now()-p.at>=12000)){drop(c,'response-timeout');continue}
    probe(c);
   }
   status(Array.isArray(list)?[...clients.values()].some(c=>c.ready)?'ready':clients.size?'waiting-page':'waiting-target':'waiting-debug-port');
  }finally{busy=false}
 }
 function dispose({removeTheme=false}={}){
  if(disposed)return;for(const c of [...clients.values()]){if(removeTheme)send(c,'Runtime.evaluate',{expression:"window.__doorayThemeEmergencyStop?.('helper-disabled')"});drop(c,'monitor-stopped',false)}disposed=true;retries.clear();status('stopped');
 }
 return {tick,dispose,get diagnostics(){return {targets:clients.size,retries:retries.size,pending:[...clients.values()].reduce((n,c)=>n+c.pending.size,0)}}};
}
// End isolated target controller.

export function createBackgroundPreflightRelay({getChild,sendParent,version,session}) {
 const pending=new Map();
 const validId=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
 const unknown=()=>({known:false,drafts:0,downloads:0,reserved:false});
 function result(id,value){
  const safe=value&&typeof value.known==='boolean'&&typeof value.reserved==='boolean'&&['drafts','downloads'].every(key=>Number.isSafeInteger(value[key])&&value[key]>=0&&value[key]<=100000)&&(!value.reserved||value.known&&value.drafts===0&&value.downloads===0);
  try{sendParent({type:'background-preflight-result',id,version,session,result:safe?{known:value.known,drafts:value.drafts,downloads:value.downloads,reserved:value.reserved}:unknown()})}catch{}
 }
 return {
  parent(message){
   if(message?.type==='background-unreserve'){pending.clear();const child=getChild();if(child?.connected)try{child.send({type:'background-unreserve'})}catch{}return true}
   if(message?.type!=='background-preflight'||!validId(message.id))return false;
   const child=getChild();if(!child?.connected){result(message.id,unknown());return true}
   if(pending.size>=16){result(message.id,unknown());return true}
   pending.set(message.id,child);try{child.send({type:'background-preflight',id:message.id})}catch{pending.delete(message.id);result(message.id,unknown())}return true;
  },
  child(child,message){
   if(message?.type!=='background-preflight-result'||!validId(message.id)||getChild()!==child||pending.get(message.id)!==child)return false;
   pending.delete(message.id);result(message.id,message.result);return true;
  },
  retire(child){for(const [id,owner]of pending)if(owner===child){pending.delete(id);result(id,unknown())}},
  dispose(){pending.clear()}
 };
}
// End isolated background preflight relay.

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const data=path.join(process.env.LOCALAPPDATA||root,'DoorayTheme');
const disabled=path.join(data,'theme-disabled.flag');
const log=message=>{try{fs.mkdirSync(data,{recursive:true});const f=path.join(data,'launcher.log');if(fs.existsSync(f)&&fs.statSync(f).size>1048576)fs.renameSync(f,path.join(data,'launcher.previous.log'));fs.appendFileSync(f,new Date().toISOString()+' '+message+'\n')}catch{}};
const port=19347;
if(process.argv.includes('--check')){console.log(JSON.stringify({version:'3.8.29',mode:'attach-only',versionRestricted:false,runtime:process.version,themePresent:fs.existsSync(path.join(root,'app/theme.js'))}));process.exit(0)}
// The native launcher starts Dooray first. This helper never launches, kills,
// waits for, or modifies the vendor program, and never displays blocking dialogs.
if(fs.existsSync(disabled))process.exit(0);
const lock=net.createServer(s=>s.end());
const acquired=await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(port+1,'127.0.0.1',()=>r(true))});
if(!acquired){log('Feature singleton port unavailable: '+(port+1));process.exit(0)}
let downloadProcess=null;
const backgroundPreflight=createBackgroundPreflightRelay({getChild:()=>downloadProcess,sendParent:m=>{if(process.connected)process.send(m)},version:'3.8.29',session:process.env.DOORAY_ENGINE_SESSION});
function ensureDownloads(){if(downloadProcess||stopped)return;downloadProcess=spawn(process.execPath,[path.join(root,'app/download-helper.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc']});const child=downloadProcess;child.on('message',m=>{if(backgroundPreflight.child(child,m))return;if(downloadProcess===child&&['update-check','update-status','update-install','update-apply','update-cancel'].includes(m?.type)&&typeof m.id==='string'&&m.id.length<=80){if(process.connected)process.send(m);else if(child.connected)child.send({type:'update-result',id:m.id,result:{status:'error',error:'업데이트 지원 설치 파일로 전환 설치해 주세요.'}})}});const retired=()=>{backgroundPreflight.retire(child);if(downloadProcess===child)downloadProcess=null};child.once('error',retired);child.once('exit',retired);}
process.on('message',m=>{if(backgroundPreflight.parent(m))return;if(m?.type==='update-result'&&downloadProcess?.connected)downloadProcess.send(m)});
process.on('disconnect',()=>{backgroundPreflight.parent({type:'background-unreserve'});backgroundPreflight.dispose()});
process.on('exit',()=>{try{downloadProcess?.kill()}catch{}});
let stopped=false,monitor;
function stop(reason){if(stopped)return;stopped=true;backgroundPreflight.dispose();try{downloadProcess?.kill()}catch{}if(reason){log(reason);try{fs.writeFileSync((process.env.DOORAY_ENGINE_ERROR||path.join(data,'release-error.json')),JSON.stringify({version:'3.8.29',reason,session:process.env.DOORAY_ENGINE_SESSION,pid:process.pid}))}catch{}}
 monitor?.dispose({removeTheme:true});
 lock.close();setTimeout(()=>process.exit(0),300).unref();
}
process.on('message',m=>{if(m?.type==='shutdown')stop()});
process.on('uncaughtException',()=>stop('helper-error'));process.on('unhandledRejection',()=>stop('helper-error'));
const source=fs.readFileSync(path.join(root,'app/theme.js'),'utf8');
const bootstrap=makeBootstrap(source,process.env.DOORAY_ENGINE_SESSION);
async function targets(){try{const response=await fetch('http://127.0.0.1:'+port+'/json/list',{signal:AbortSignal.timeout(1000)});return await response.json()}catch{return null}}
monitor=createTargetMonitor({getTargets:targets,Socket:WebSocket,bootstrap,log,
 onHealthy(){try{fs.writeFileSync((process.env.DOORAY_ENGINE_HEALTH||path.join(data,'healthy.flag')),JSON.stringify({version:'3.8.29',at:Date.now(),session:process.env.DOORAY_ENGINE_SESSION,pid:process.pid}))}catch{}},
 onUnhealthy(){try{const file=process.env.DOORAY_ENGINE_HEALTH||(process.env.DOORAY_ENGINE_HEALTH||path.join(data,'healthy.flag'));if(!process.env.DOORAY_ENGINE_SESSION||JSON.parse(fs.readFileSync(file,'utf8')).session===process.env.DOORAY_ENGINE_SESSION)fs.unlinkSync(file)}catch{}},
 onFault:stop,onStatus(value){if(process.connected)try{process.send({type:'launcher-status',version:'3.8.29',session:process.env.DOORAY_ENGINE_SESSION,...value})}catch{}}
});
async function tick(){if(stopped)return;
 if(fs.existsSync(disabled)||fs.existsSync(path.join(data,'stop-agent.flag'))){stop();return}
 await monitor.tick();if(monitor.diagnostics.targets)ensureDownloads();}
await tick();setInterval(tick,2000);

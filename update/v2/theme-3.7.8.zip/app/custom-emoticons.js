// Bundled inside theme.js; explicit item clicks use Dooray's native message pipeline.
function installCustomEmoticons({rpc}){
  let disposed=false,scheduled=0,catalog=null,loading=null;const popups=new Map(),decorated=new Map(),assetPromises=new Map();
  const scrollStates=new Map();
  const atBottom=scroll=>scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<=48;
  function scrollState(node){
    let scroll=node.closest('.js-scroll-area');
    // Some Dooray layouts put the actual overflow on a wrapper around the message list.
    for(let p=node.parentElement;p&&p!==document.body;p=p.parentElement){if(/auto|scroll/.test(getComputedStyle(p).overflowY)&&p.clientHeight>0){scroll=p;break}}
    if(!scroll)return null;
    if(!scrollStates.has(scroll)){
      const state={scroll,follow:atBottom(scroll),frame:0};
      const changed=()=>{state.follow=atBottom(scroll)};
      const cancel=()=>{state.follow=false};
      const wheel=e=>{if(e.deltaY<0)cancel()};
      const key=e=>{if(['ArrowUp','PageUp','Home'].includes(e.key))cancel()};
      scroll.addEventListener('scroll',changed,{passive:true});scroll.addEventListener('wheel',wheel,{passive:true});
      scroll.addEventListener('touchstart',cancel,{passive:true});scroll.addEventListener('pointerdown',cancel,{passive:true});scroll.addEventListener('keydown',key);
      state.dispose=()=>{cancelAnimationFrame(state.frame);scroll.removeEventListener('scroll',changed);scroll.removeEventListener('wheel',wheel);scroll.removeEventListener('touchstart',cancel);scroll.removeEventListener('pointerdown',cancel);scroll.removeEventListener('keydown',key)};
      scrollStates.set(scroll,state);
    }
    return scrollStates.get(scroll);
  }
  function followBottom(state){
    if(!state||!state.follow||disposed||!state.scroll.isConnected)return;
    state.scroll.scrollTop=state.scroll.scrollHeight;
    cancelAnimationFrame(state.frame);
    state.frame=requestAnimationFrame(()=>{state.frame=0;if(state.follow&&!disposed&&state.scroll.isConnected)state.scroll.scrollTop=state.scroll.scrollHeight});
  }
  const resized=new ResizeObserver(entries=>{for(const entry of entries){const state=scrollState(entry.target);followBottom(state)}});
  const prefix='[[dooray-emoji:v1:',suffix=']]';
  const encode=item=>prefix+btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify({p:item.path,r:item.ref,n:item.label})))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')+suffix;
  function decode(text){try{text=text.replace(/[\s\u200B-\u200D\uFEFF]/g,'');if(text.length>5000||!text.startsWith(prefix)||!text.endsWith(suffix))return null;const base=text.slice(prefix.length,-suffix.length).replace(/-/g,'+').replace(/_/g,'/');const obj=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(base),c=>c.charCodeAt(0))));if(typeof obj.p!=='string'||!obj.p.startsWith('packs/')||obj.p.length>1000||!/^([a-f\d]{40})$/i.test(obj.r)||!(/\.(png|gif|jpe?g|webp)$/i.test(obj.p)))return null;return {path:obj.p,ref:obj.r,label:String(obj.n||'커스텀 이모티콘').slice(0,100)}}catch{return null}}
  function image(item,refresh=false){const key=item.ref+'/'+item.path;if(refresh)assetPromises.delete(key);if(!assetPromises.has(key)){if(assetPromises.size>=48)assetPromises.delete(assetPromises.keys().next().value);const p=rpc('emoticon-image',{path:item.path,ref:item.ref,refresh}).then(r=>{if(!/^data:image\/(png|gif|jpeg|webp);base64,/.test(r.data))throw Error('이미지 응답 오류');return r.data}).catch(e=>{assetPromises.delete(key);throw e});assetPromises.set(key,p)}return assetPromises.get(key)}
  function context(popup){let f=popup[Object.keys(popup).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<35;i++,f=f.return){const p=f.memoizedProps;if(p?.actions?.emoticonStickerActions&&p?.data?.emoticonStickerStore)return p}return null}
  const sending=new WeakSet();
  async function insert(popup,item,status){if(sending.has(popup))return;sending.add(popup);try{const p=context(popup),active=p?.data.emoticonStickerStore.activePopperState,stickers=p?.actions.emoticonStickerActions,logs=stickers?.logActions,channel=stickers?.activeChannelId;if(!popup.isConnected||!active||!channel||typeof logs?.createAndSendLog!=='function'||typeof logs?.fetchLatestLogsIfNeeded!=='function')throw Error('이모티콘 창을 다시 열어 주세요.');status.textContent='전송 중…';await logs.fetchLatestLogsIfNeeded(channel);if(!popup.isConnected||disposed||stickers.activeChannelId!==channel||p.data.emoticonStickerStore.activePopperState!==active)throw Error('대화방이 변경되어 전송하지 않았습니다.');logs.createAndSendLog(channel,encode(item));active.setOpen(false);}catch(e){status.textContent=e.message}finally{sending.delete(popup)}}
  const css=document.createElement('style');css.id='dooray-custom-emoticons-style';css.textContent=`
  .js-sticker-emotion[data-dt-custom-open] > :not(.lcdHJ):not(.dt-emoticon-custom){display:none!important}
  .dt-emoticon-custom[hidden]{display:none!important}
  [data-dt-emoticon][data-dt-emoticon]{font-size:0!important;line-height:0!important;visibility:hidden!important}
  [data-dt-emoticon][data-dt-emoticon] > :not(.dt-received-emoticon){display:none!important}
  .dt-received-emoticon{visibility:visible!important;display:inline-flex!important;align-items:center;justify-content:center;vertical-align:middle;flex-wrap:wrap;gap:4px;max-width:100%;font:12px/1.4 sans-serif!important;color:var(--dt-text,#333);overflow:hidden}
  .dt-emoticon-imagebox{display:inline-flex;width:160px;height:160px;align-items:center;justify-content:center;flex:none;max-width:100%} .dt-emoticon-text{white-space:pre-wrap;font-size:14px;line-height:1.5}
  .dt-received-emoticon img{display:block;width:100%;height:100%;object-fit:contain}
  .dt-received-emoticon button{font:inherit;color:inherit;background:transparent;border:0;cursor:pointer;max-width:100%}
  `;document.head.append(css);
  const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){observer.unobserve(entry.target);entry.target.__dtLoadEmoticon?.();}},{rootMargin:'160px'});
  function lazy(target,load){target.__dtLoadEmoticon=load;observer.observe(target)}
  const packsPerPage=6;
  function clearGrid(state){for(const child of state.grid.children)observer.unobserve(child);state.grid.replaceChildren();state.grid.scrollTop=0;}
  function thumbnail(pack){return pack.items.find(item=>/^01\.(png|gif|jpe?g|webp)$/i.test(item.path.split('/').pop()))||pack.items.find(item=>String(item.id)==='01'||item.label==='01')||pack.items[0];}
  function fillPicker(popup,state,data){
    if(!popup.isConnected||disposed)return;state.data=data;state.page=Math.min(state.page,Math.max(0,Math.ceil(data.packs.length/packsPerPage)-1));drawPacks(popup,state);
  }
  function drawPacks(popup,state){
    clearGrid(state);state.mode='packs';state.grid.setAttribute('aria-label','이모티콘 팩 목록');state.panel.dataset.view='packs';state.back.hidden=true;state.title.textContent='커스텀 이모티콘';
    const packs=state.data?.packs||[],pages=Math.max(1,Math.ceil(packs.length/packsPerPage));
    state.previous.hidden=state.next.hidden=false;state.previous.disabled=state.page===0;state.next.disabled=state.page>=pages-1;
    state.pageLabel.textContent=(state.page+1)+' / '+pages;
    state.status.textContent=state.data?.warnings?.length?'일부 팩을 읽지 못했습니다. '+state.data.warnings[0]:'팩을 눌러 열기 · 휠로 페이지 이동';
    for(const pack of packs.slice(state.page*packsPerPage,(state.page+1)*packsPerPage)){
      const button=document.createElement('button');button.type='button';button.className='pack';button.title=pack.name;button.setAttribute('aria-label',pack.name+' 팩 열기');
      const preview=document.createElement('span');preview.className='preview';preview.textContent='…';
      const name=document.createElement('span');name.className='name';name.textContent=pack.name;button.append(preview,name);state.grid.append(button);
      button.onclick=()=>{state.selected=pack;drawPack(popup,state);state.back.focus()};
      const item=thumbnail(pack);if(item)lazy(button,()=>image(item).then(src=>{if(!button.isConnected||disposed)return;const img=document.createElement('img');img.alt='';img.onerror=()=>{preview.textContent='미리보기 없음'};img.src=src;preview.replaceChildren(img)}).catch(()=>{if(button.isConnected)preview.textContent='미리보기 없음'}));else preview.textContent='비어 있음';
    }
  }
  function turnPage(popup,state,direction){
    if(state.mode!=='packs'||!state.data)return;
    const next=Math.max(0,Math.min(state.page+direction,Math.ceil(state.data.packs.length/packsPerPage)-1));
    if(next===state.page||next<0)return;state.page=next;drawPacks(popup,state);
  }
  function drawPack(popup,state){
    clearGrid(state);const pack=state.selected;if(!pack)return;state.mode='items';state.grid.setAttribute('aria-label',pack.name+' 이모티콘 목록');state.panel.dataset.view='items';state.back.hidden=false;state.title.textContent=pack.name;
    state.previous.hidden=state.next.hidden=true;state.pageLabel.textContent=pack.items.length+'개';state.status.textContent='이모티콘을 누르면 바로 전송됩니다.';
    for(const item of pack.items){const b=document.createElement('button');b.type='button';b.title=item.label;b.setAttribute('aria-label',item.label+' 보내기');b.textContent=item.label;b.disabled=true;state.grid.append(b);
      lazy(b,()=>image(item).then(src=>{if(!b.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{b.disabled=false};img.onerror=()=>{b.textContent='이미지 로딩 실패';};img.src=src;b.replaceChildren(img);b.onclick=()=>insert(popup,item,state.status)}).catch(e=>{b.textContent='불러오기 실패';b.title=e.message}));
    }
  }
  async function loadPicker(popup,state,refresh=false){state.status.textContent='이모티콘 목록을 불러오는 중…';state.refresh.disabled=true;try{if(refresh)catalog=null;if(!catalog){loading ||= rpc('emoticon-catalog',{refresh}).finally(()=>{loading=null});catalog=await loading}fillPicker(popup,state,catalog)}catch(e){state.status.textContent=e.message+' 목록 준비 후 새로고침을 눌러 주세요.'}finally{state.refresh.disabled=false}}
  function mount(popup){
    if(popups.has(popup))return;const tabs=popup.querySelector(':scope > .lcdHJ');if(!tabs)return;
    const tabSlot=document.createElement('div');tabSlot.className='M306H';tabSlot.dataset.dtCustomTab='true';const tab=document.createElement('button');tab.type='button';tab.className=tabs.querySelector('button')?.className||'';const label=document.createElement('div');label.className=tabs.querySelector('button > div')?.className||'';label.textContent='커스텀';tab.append(label);tab.setAttribute('aria-selected','false');tabSlot.append(tab);tabs.append(tabSlot);let selectedNative=[];const selectTab=selected=>{if(selected){selectedNative=[...tabs.children].filter(n=>n!==tabSlot&&n.classList.contains('LOqnd'));for(const n of selectedNative)n.classList.remove('LOqnd');}else{for(const n of selectedNative)if(n.isConnected)n.classList.add('LOqnd');selectedNative=[];}tabSlot.classList.toggle('LOqnd',selected);tab.setAttribute('aria-selected',String(selected));};
    const panel=document.createElement('div');panel.className='dt-emoticon-custom';panel.hidden=true;panel.dataset.view='packs';const shadow=panel.attachShadow({mode:'open'});shadow.innerHTML=`<style>
    :host{display:block;width:360px;max-width:80vw;color:var(--dt-text,#333);background:var(--dt-bg,#fff);font:12px sans-serif}*{box-sizing:border-box}[hidden]{display:none!important}
    .tools{display:flex;align-items:center;gap:6px;padding:10px}#title{flex:1;min-width:0;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    button{color:inherit;background:var(--dt-surface,#eee);border:1px solid var(--dt-border,#bbb);border-radius:8px;padding:6px;font:inherit;cursor:pointer}button:hover{background:var(--dt-hover,#ddd)}button:disabled{opacity:.4;cursor:default}button:focus-visible{outline:2px solid var(--dt-accent,#278ac2);outline-offset:1px}
    #status{padding:0 10px;margin:0 0 6px;font-size:11px;line-height:1.5;overflow-wrap:anywhere;min-height:17px}.browser{display:grid;grid-template-columns:28px minmax(0,1fr) 28px;align-items:center;gap:3px;padding:0 5px}.arrow{padding:8px 0;font-size:22px;line-height:1}
    #grid{height:268px;overflow:auto;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));align-content:start;gap:6px;padding:4px;overscroll-behavior:contain}
    #grid button{min-width:0;overflow:hidden;padding:5px;height:122px}.preview{display:flex;height:78px;align-items:center;justify-content:center;font-size:11px}.name{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:11px;line-height:15px;margin-top:3px;word-break:break-all}img{display:block;width:100%;height:100%;object-fit:contain}
    :host([data-view="items"]) .browser{grid-template-columns:minmax(0,1fr)}:host([data-view="items"]) #grid{grid-template-columns:repeat(4,minmax(0,1fr))}:host([data-view="items"]) #grid button{height:78px}
    #page{display:block;text-align:center;padding:5px 0 9px;font-size:11px;opacity:.75}
    </style><div class="tools"><button id="back" hidden aria-label="팩 목록으로 뒤로 가기">← 뒤로</button><span id="title">커스텀 이모티콘</span><button id="refresh" aria-label="이모티콘 목록 새로고침">새로고침</button></div><p id="status" role="status"></p><div class="browser"><button id="previous" class="arrow" aria-label="이전 페이지" title="이전 페이지">‹</button><div id="grid" tabindex="0" aria-label="이모티콘 팩 목록"></div><button id="next" class="arrow" aria-label="다음 페이지" title="다음 페이지">›</button></div><span id="page" aria-live="polite"></span>`;
    popup.append(panel);const get=id=>shadow.getElementById(id);const state={panel,tab,grid:get('grid'),status:get('status'),refresh:get('refresh'),back:get('back'),title:get('title'),previous:get('previous'),next:get('next'),pageLabel:get('page'),page:0,mode:'packs',selected:null};
    state.previous.onclick=()=>turnPage(popup,state,-1);state.next.onclick=()=>turnPage(popup,state,1);
    state.back.onclick=()=>{const index=state.data.packs.indexOf(state.selected)%packsPerPage;drawPacks(popup,state);state.grid.children[index]?.focus()};
    let wheelSum=0,lastWheel=0,lastPageTurn=0;
    const wheel=e=>{if(state.mode!=='packs'||e.ctrlKey)return;e.preventDefault();e.stopPropagation();const now=performance.now();if(now-lastWheel>180)wheelSum=0;lastWheel=now;wheelSum+=(Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY)*(e.deltaMode===1?16:e.deltaMode===2?268:1);if(Math.abs(wheelSum)<40||now-lastPageTurn<300)return;turnPage(popup,state,Math.sign(wheelSum));wheelSum=0;lastPageTurn=now};
    shadow.querySelector('.browser').addEventListener('wheel',wheel,{passive:false});
    state.grid.onkeydown=e=>{if(state.mode==='packs'&&['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();turnPage(popup,state,e.key==='ArrowRight'?1:-1)}};
    const nativeClick=e=>{if(e.target.closest('button')===tab)return;panel.hidden=true;popup.removeAttribute('data-dt-custom-open');selectTab(false)};tabs.addEventListener('click',nativeClick);state.detach=()=>{clearGrid(state);selectTab(false);tabs.removeEventListener('click',nativeClick);tabSlot.remove();panel.remove();popup.removeAttribute('data-dt-custom-open')};
    tab.onclick=()=>{panel.hidden=false;popup.setAttribute('data-dt-custom-open','');if(!tabSlot.classList.contains('LOqnd'))selectTab(true);loadPicker(popup,state)};state.refresh.onclick=()=>loadPicker(popup,state,true);popups.set(popup,state);
  }
  // Dooray may leave markdown spacing entities as literal text after a message.
  const normalizeSpacing=text=>text.replace(/&(?:#x(?:20|a0)|#(?:32|160)|nbsp);/gi,' ');
  function messageText(node){return normalizeSpacing([...node.childNodes].filter(n=>!(n.nodeType===1&&n.classList.contains('dt-received-emoticon'))).map(n=>n.textContent).join('')).replace(/[\u200B-\u200D\uFEFF]/g,'').trim()}
  const tokenPattern=()=>/\[\s*\[\s*dooray\s*-\s*emoji\s*:\s*v1\s*:\s*[A-Za-z0-9_\-\s]+\]\s*\]/g;
  function messageCandidates(){
    const candidates=new Set([...decorated.keys()].filter(n=>n.isConnected));
    // The first scroll area can be a channel list. Search every rendered message area,
    // including side-panel conversations, without relying on generated CSS classes.
    const root=document.body;
    const skip='textarea,input,script,style,noscript,.dt-received-emoticon,.dt-emoticon-custom,.js-sticker-emotion';
    const excluded=node=>!node||node.isContentEditable||node.closest(skip);
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>excluded(n.parentElement)?NodeFilter.FILTER_REJECT:/\[\[|dooray-|emoji:v1:/.test(n.nodeValue||'')?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});
    for(let text=walker.nextNode();text;text=walker.nextNode()){
      const existing=text.parentElement?.closest('[data-dt-emoticon]');if(existing){candidates.add(existing);continue;}
      for(let node=text.parentElement,depth=0;node&&node!==root&&depth<24;node=node.parentElement,depth++){
        if(excluded(node)||node.querySelector('[contenteditable]:not([contenteditable="false"]),textarea,input'))break;const value=messageText(node);if(value.length>16000)break;
        if([...value.matchAll(tokenPattern())].some(m=>decode(m[0]))){candidates.add(node);break;}
      }
    }
    // Prefer the smallest matching text container; do not decorate a message twice.
    const nodes=[...candidates];return nodes.filter(n=>!nodes.some(other=>other!==n&&n.contains(other)));
  }
  function decorate(node,segments,key){
    const previous=decorated.get(node);if(previous?.key===key&&previous.view.parentNode===node&&previous.view.childNodes.length){if(!node.hasAttribute('data-dt-emoticon'))node.setAttribute('data-dt-emoticon','');return;}
    const state=scrollState(node),scroll=state?.scroll,oldTop=scroll?.scrollTop,above=scroll&&node.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,oldHeight=node.getBoundingClientRect().height;
    if(previous){resized.unobserve(previous.view);for(const box of previous.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(previous.view);previous.view.remove()}
    const view=document.createElement('span');view.className='dt-received-emoticon';view.setAttribute('aria-label','커스텀 이모티콘 메시지');node.setAttribute('data-dt-emoticon','');node.append(view);decorated.set(node,{key,view});
    for(const segment of segments){if(typeof segment==='string'){const text=document.createElement('span');text.className='dt-emoticon-text';text.textContent=segment;view.append(text);continue;}const item=segment,box=document.createElement('span');box.className='dt-emoticon-imagebox';box.textContent='이모티콘 불러오는 중…';view.append(box);let loadingImage=false;const load=(refresh=false)=>{if(loadingImage||disposed||!box.isConnected)return;loadingImage=true;box.dataset.loadState='loading';box.textContent='이모티콘 불러오는 중…';return image(item,refresh).then(src=>{if(!box.isConnected||disposed)return;const img=document.createElement('img');img.alt=item.label;img.onload=()=>{box.dataset.loadState='ready';followBottom(state)};img.onerror=failed;img.src=src;box.replaceChildren(img)}).catch(failed).finally(()=>{loadingImage=false})};function failed(error){if(!box.isConnected||disposed)return;box.dataset.loadState='failed';box.title=error?.message||'이미지를 표시하지 못했습니다.';const retry=document.createElement('button');retry.textContent=item.label+' · 다시 불러오기';retry.onclick=()=>load(true);box.replaceChildren(retry)}box.__dtReload=load;lazy(box,()=>load());}
    if(state?.follow)followBottom(state);else if(above)scroll.scrollTop=oldTop+node.getBoundingClientRect().height-oldHeight;
    resized.observe(view);

  }
  function scan(){scheduled=0;if(disposed)return;for(const popup of document.querySelectorAll('.js-sticker-emotion'))mount(popup);for(const[p,state]of popups)if(!p.isConnected){state.detach();popups.delete(p)}
    for(const node of messageCandidates()){if(node.closest('[contenteditable="true"]'))continue;const text=messageText(node),segments=[];let at=0,count=0;for(const match of text.matchAll(tokenPattern())){const item=decode(match[0]);if(!item||count>=8)continue;if(match.index>at)segments.push(text.slice(at,match.index));segments.push(item);at=match.index+match[0].length;count++;}if(at<text.length)segments.push(text.slice(at));if(count)decorate(node,segments,text);else if(decorated.has(node)){const d=decorated.get(node);resized.unobserve(d.view);for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))observer.unobserve(box);observer.unobserve(d.view);d.view.remove();node.removeAttribute('data-dt-emoticon');decorated.delete(node)}}
    for(const[n,d]of decorated)if(!n.isConnected){resized.unobserve(d.view);observer.unobserve(d.view);decorated.delete(n)}
    for(const[scroll,state]of scrollStates)if(!scroll.isConnected){state.dispose();scrollStates.delete(scroll)}
  }
  let lastError='',lastScan=0;
  const runScan=()=>{try{scan();lastScan=Date.now();lastError=''}catch(e){lastError=e.message;scheduled=0}};
  const changes=new MutationObserver(()=>{if(!scheduled)scheduled=setTimeout(runScan,120)});changes.observe(document,{subtree:true,childList:true,characterData:true});runScan();
  const recoveryTimer=setInterval(()=>{if(!document.hidden)runScan()},2500);
  function diagnostics(){const boxes=[...decorated.values()].flatMap(d=>[...d.view.querySelectorAll('.dt-emoticon-imagebox')]);return {messages:decorated.size,ready:boxes.filter(b=>b.dataset.loadState==='ready').length,failed:boxes.filter(b=>b.dataset.loadState==='failed').length,waiting:boxes.filter(b=>!['ready','failed'].includes(b.dataset.loadState)).length,lastScan,error:lastError}}
  function repair(){runScan();for(const d of decorated.values())for(const box of d.view.querySelectorAll('.dt-emoticon-imagebox'))if(box.dataset.loadState==='failed')box.__dtReload?.(true);return diagnostics()}

  const dispose=()=>{disposed=true;clearInterval(recoveryTimer);clearTimeout(scheduled);changes.disconnect();observer.disconnect();resized.disconnect();for(const state of scrollStates.values())state.dispose();scrollStates.clear();css.remove();for(const[p,s]of popups)s.detach();for(const[n,d]of decorated){d.view.remove();n.removeAttribute('data-dt-emoticon')}popups.clear();decorated.clear();assetPromises.clear()};
  dispose.repair=repair;dispose.diagnostics=diagnostics;return dispose;
}

// Versioned update supervisor: delivered and replaced with every signed user release.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,checkRemote,atomicJSON,newer} from './update-store.mjs';
import {installerStatus,downloadInstaller} from './installer-update.mjs';
import {prepareHandoff,startHandoff} from './update-handoff.mjs';
const root=process.env.DOORAY_INSTALL_ROOT;
const ownVersion=path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
if(process.argv.includes('--check')){console.log(JSON.stringify({controller:ownVersion,mode:'per-user-signed-updates',runtime:process.version}));process.exit(0);}
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(process.env.DOORAY_LEGACY_BRIDGE?19353:19351,'127.0.0.1',()=>r(true))}))process.exit(0);
await fs.mkdir(data,{recursive:true});
const store=await new UpdateStore({data,publicKey}).init();
const disabled=path.join(userData,'theme-disabled.flag'),stopFlag=path.join(userData,'stop-agent.flag'),healthy=process.env.DOORAY_ENGINE_HEALTH||path.join(userData,'healthy.flag'),releaseError=process.env.DOORAY_ENGINE_ERROR||path.join(userData,'release-error.json');
const exists=async p=>{try{await fs.access(p);return true}catch{return false}};
const log=async message=>{try{const file=path.join(userData,'updater.log');if((await fs.stat(file).catch(()=>({size:0}))).size>1048576)await fs.rename(file,file+'.previous');await fs.appendFile(file,new Date().toISOString()+' '+message+'\n')}catch{}};
const expectedExit=new WeakSet();let childReady=false;let mayActivate=false;let child=null,busy=false,remoteBusy=false,closing=false,holdUntilClose=false,started=0,wasPresent=false,lastCheck=0,crashed=false;
async function activate(){
  await store.activate();
  if(store.state.active!==ownVersion)process.exit(75);
}
process.on('disconnect',()=>shutdown());
process.on('message',m=>{if(m?.type==='shutdown')void shutdown()});
setInterval(()=>{if(process.connected)process.send({type:'supervisor-alive',version:ownVersion})},2000).unref();
if(process.connected)process.send({type:'supervisor-alive',version:ownVersion});
async function shutdown(){if(closing)return;closing=true;if(child){try{child.send({type:'shutdown'})}catch{}const old=child;setTimeout(()=>{try{old.kill()}catch{}},2500).unref();}setTimeout(()=>process.exit(0),3000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);process.on('exit',()=>{try{child?.kill()}catch{}});
async function fail(reason){await log('Release failed: '+store.state.active+' '+reason);const old=child;child=null;if(old){try{old.send({type:'shutdown'})}catch{}setTimeout(()=>{try{old.kill()}catch{}},1500).unref();}
  if(old)try{old.kill()}catch{}
  if(!store.state.trial){await fs.unlink(releaseError).catch(()=>{});holdUntilClose=true;await log('Confirmed release retained: '+store.state.active+' '+reason);return;}
  const previous=await store.rollback();await fs.unlink(releaseError).catch(()=>{});holdUntilClose=true;
  if(previous)process.exit(75);
  await log('No healthy release; retry on next launch');await shutdown();
}
let remotePromise=null,lastResult={status:'idle'},installerInfo=null,handoffJob=null,handoffBusy=false,activeHandoff=null,handoffGeneration=0;
function cancelPreparation(){handoffGeneration++;handoffJob=null;handoffBusy=false;}
const updateStatus=()=>({...lastResult,...(activeHandoff?{status:'restarting'}:{}),active:store.state.active,pending:store.state.pending,checkedAt:lastCheck});
async function remote(force=false,download=true){
 if(remotePromise){await remotePromise;if(!download||store.state.pending)return updateStatus();}
 if(!force&&Date.now()-lastCheck<1800000)return updateStatus();
 lastCheck=Date.now();lastResult={status:download?'downloading':'checking'};
 remotePromise=(async()=>{try{let warning=null;try{installerInfo=await installerStatus(root,publicKey,store.state.active)}catch(e){if(e instanceof SyntaxError||/signature|metadata|contract/i.test(e.message))throw e;warning='설치 업데이트 정보 확인 실패: '+e.message;await log(warning);}const result=await checkRemote(store,fetch,{download:download&&!installerInfo?.needed});lastResult={status:installerInfo?.needed?'available':store.state.pending?'ready':result?.available?'available':result?.ahead?'ahead':'current',available:installerInfo?.needed?installerInfo.manifest.version:result?.available||null,kind:installerInfo?.needed?'installer':'patch',remoteVersion:result?.remoteVersion||null,warning};if(store.state.pending)await log('Update staged: '+store.state.pending);}catch(e){lastResult={status:'error',error:e.message};await log('Update check deferred: '+e.message)}return updateStatus()})().finally(()=>{remotePromise=null});
 return remotePromise;
}
function connectUpdates(running){running.on('message',async m=>{
 if(running!==child||!['update-check','update-status','update-install','update-apply','update-cancel'].includes(m?.type)||typeof m.id!=='string'||m.id.length>80)return;
 if(m.type==='update-install'&&(handoffBusy||activeHandoff)){if(running.connected)running.send({type:'update-result',id:m.id,result:{...updateStatus(),status:'error',error:'업데이트가 이미 진행 중입니다.'}});return;}
 let result,applying=null,generation=handoffGeneration;try{
 if(m.type==='update-install'){
  if(handoffBusy)throw Error('업데이트가 이미 준비 중입니다.');handoffBusy=true;generation=++handoffGeneration;
  const ensureCurrent=()=>{if(generation!==handoffGeneration||running!==child)throw Error('업데이트 준비가 취소되었습니다. 다시 시도해 주세요.');};
  const checked=await remote(true,false);ensureCurrent();if(checked.status==='error')throw Error(checked.error);
  let installer=null,version,kind=installerInfo?.needed?'installer':'patch';
  if(kind==='installer'){version=installerInfo.manifest.version;installer=await downloadInstaller(installerInfo,publicKey,path.join(data,'installers',version));}
  else{const downloaded=await remote(true,true);if(downloaded.status==='error')throw Error(downloaded.error);version=store.state.pending;if(!version)throw Error('적용할 새 업데이트가 없습니다.');await store.validate(version);}
  ensureCurrent();const prepared=await prepareHandoff({root,data,version,kind,installer});ensureCurrent();handoffJob=prepared;result={...updateStatus(),status:'prepared',token:handoffJob.token,kind,available:version};
 }else if(m.type==='update-apply'){
  if(!handoffJob||m.token!==handoffJob.token)throw Error('업데이트 준비 정보가 만료되었습니다. 다시 확인해 주세요.');
  applying=handoffJob;handoffJob=null;activeHandoff=applying;
  if(applying.config.kind==='patch')await store.validate(applying.config.version);
  await startHandoff(applying);result={...updateStatus(),status:'restarting'};handoffJob=null;handoffBusy=false;
 }else if(m.type==='update-cancel'){cancelPreparation();result=updateStatus();}
 else result=m.type==='update-check'?await remote(true,false):updateStatus();
 }catch(e){if(applying&&activeHandoff===applying)activeHandoff=null;if(generation===handoffGeneration){cancelPreparation();lastResult={status:'error',error:e.message};}result={...updateStatus(),status:'error',error:e.message};await log('Update handoff deferred: '+e.message)}
 if(running===child&&running.connected)try{running.send({type:'update-result',id:m.id,result})}catch{}
});}
async function targets(){try{const list=await(await fetch('http://127.0.0.1:19347/json/list',{signal:AbortSignal.timeout(1000)})).json();return Array.isArray(list)?list.some(t=>{try{const u=new URL(t.url);return t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)&&u.pathname.startsWith('/messenger')}catch{return false}}):null}catch(e){return e.cause?.code==='ECONNREFUSED'?false:null}}
async function tick(){if(handoffBusy&&handoffJob&&Date.now()-handoffJob.config.createdAt>60000){cancelPreparation();}if(busy||closing)return;busy=true;try{
  if(activeHandoff){let outcome;try{outcome=JSON.parse((await fs.readFile(path.join(activeHandoff.dir,'result.json'),'utf8')).replace(/^\uFEFF/,''))}catch{}if(outcome?.phase==='error'||Date.now()-activeHandoff.config.createdAt>20*60*1000){lastResult={status:'error',error:outcome?.message||'업데이트 실행 응답 시간이 초과되었습니다.'};activeHandoff=null;}else if(outcome?.phase==='complete')activeHandoff=null;}
  if(await exists(disabled)||await exists(stopFlag)){await shutdown();return;}
  const present=await targets();if(present===null)return;
  if(!present){holdUntilClose=false;crashed=false;mayActivate=true;if(wasPresent&&child){expectedExit.add(child);try{child.send({type:'shutdown'})}catch{}}wasPresent=false;
    if(!child&&store.state.pending&&!handoffBusy)await activate();return;
  }
  if(!wasPresent){if(!handoffBusy)await remote(true);if(!child){if(store.state.pending&&!handoffBusy)await activate();mayActivate=false;}}
  wasPresent=true;if(!handoffBusy)void remote();if(holdUntilClose)return;
  if(child){
    if(await exists(releaseError)){await fail('runtime-error');return;}
    let health=null;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
    if(health?.version===store.state.active&&health.at>=started){childReady=true;if(store.state.trial)await store.confirm();return;}
    if(!childReady&&Date.now()-started>45000)await fail('startup-timeout');return;
  }
  if(!child&&mayActivate){if(store.state.pending&&!handoffBusy)await activate();mayActivate=false;}
  if(crashed){crashed=false;await fail('helper-exited');return;}
  if(!store.state.active){await fail('missing-active-release');return;}
  try{await store.validate(store.state.active)}catch(e){await fail(e.message);return;}
  await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});started=Date.now();childReady=false;if(store.state.trial){store.state.trialStarted=true;await store.persist();}
  const running=spawn(process.execPath,[path.join(store.dir(store.state.active),'app/launcher.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],cwd:store.dir(store.state.active)});child=running;connectUpdates(running);
  running.once('error',()=>{if(child===running){child=null;crashed=true}});running.once('exit',(code)=>{if(child===running){child=null;const systemExit=code===0||code===null||[0x40010004,0xC000013A].includes(code>>>0);crashed=wasPresent&&!closing&&!expectedExit.has(running)&&!systemExit}});
  await log('Loaded user release '+store.state.active);
}catch(e){await log('Bootstrap error: '+e.message);if(child)await fail('bootstrap-error');}finally{busy=false}}
try{if(store.state.active!==ownVersion)process.exit(75);await tick();setInterval(tick,2000);}catch(e){await log('Initialization deferred: '+e.message);await shutdown();}

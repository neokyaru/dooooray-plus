import path from 'node:path';
import fs from 'node:fs/promises';
import {spawn,execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
const execute=promisify(execFile);
const focusSource=()=>fs.readFile(fileURLToPath(new URL('./window-focus.ps1',import.meta.url)),'utf8');
export async function focusExplorer(directory,{run=execute,env=process.env}={}){
  const script=await focusSource()+'\n'+await fs.readFile(fileURLToPath(new URL('./focus-download-folder.ps1',import.meta.url)),'utf8');
  await run(path.join(env.WINDIR||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-NonInteractive','-Sta','-Command',script],{windowsHide:true,env:{...env,DOORAY_THEME_FOLDER:directory},encoding:'utf8',timeout:8000,maxBuffer:16384});
}
export async function chooseDownloadFolder(initial,{run=execute,env=process.env}={}){
  const script=await focusSource()+'\n'+await fs.readFile(fileURLToPath(new URL('./select-download-folder.ps1',import.meta.url)),'utf8');
  const {stdout}=await run(path.join(env.WINDIR||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-NonInteractive','-Sta','-Command',script],{windowsHide:true,env:{...env,DOORAY_THEME_PICK_INITIAL:initial},encoding:'utf8',timeout:180000,maxBuffer:16384});
  const selected=stdout.trim();if(!selected)return null;if(!path.isAbsolute(selected)||/[\r\n\x00]/.test(selected))throw Error('선택한 폴더 경로가 올바르지 않습니다.');return path.normalize(selected);
}
// Resolve once at helper startup, including a redirected Windows Downloads folder.
export async function resolveDownloads({run=execute,env=process.env}={}){
  const fallback=path.join(env.USERPROFILE,'Downloads');
  try{
    const script="[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); $p=(Get-ItemProperty -LiteralPath 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders').'{374DE290-123F-4565-9164-39C4925E467B}'; if($p){[Console]::Write([Environment]::ExpandEnvironmentVariables($p))}";
    const {stdout}=await run(path.join(env.WINDIR||'C:/Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,encoding:'utf8',timeout:3000,maxBuffer:16384});
    const directory=stdout.trim();if(path.isAbsolute(directory)&&!/[\r\n\x00]/.test(directory))return path.normalize(directory);
  }catch{}
  return fallback;
}
// Ask Explorer directly. Never resize, reparent, or force its topmost state.
export async function openFolder(directory,{stat=fs.stat,launch=spawn,env=process.env,focus=p=>focusExplorer(p,{env})}={}){
  if(!(await stat(directory)).isDirectory())throw Error('저장 폴더를 찾을 수 없습니다.');
  await new Promise((resolve,reject)=>{
    const child=launch(path.join(env.WINDIR||'C:/Windows','explorer.exe'),[directory],{windowsHide:false,stdio:'ignore'});
    child.once('error',reject);child.once('spawn',()=>{child.unref();Promise.resolve().then(()=>focus(directory)).catch(()=>{});resolve();});
  });
}

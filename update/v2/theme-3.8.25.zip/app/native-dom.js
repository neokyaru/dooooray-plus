// Shared, content-free adapter for native Dooray DOM. Generated CSS names are
// compatibility hints only; they never establish a toolbar's identity.
function installDoorayNativeDOM({document=globalThis.document}={}){
  const win=document.defaultView||globalThis,attribute='data-dp-native',owned=new Map(),listeners=new Set();
  let disposed=false,dirty=true,scheduled=0,lastScan=-Infinity,scans=0,currentRail=null,appReady=false,railReason='not-scanned';
  const now=()=>win.performance?.now?.()??Date.now();
  const injected='[id^="dooray-theme-"],[id^="dooray-custom-"],.dt-received-emoticon,[data-dp-extension]';
  const excluded='[contenteditable="true"],.js-main-editor,[role="dialog"],[aria-modal="true"]';
  const tokens=el=>new Set((el.getAttribute(attribute)||'').split(/\s+/).filter(Boolean));
  const reactProps=el=>{try{const key=Object.keys(el).find(k=>k.startsWith('__reactProps'));return key?el[key]:null}catch{return null}};
  const fiber=el=>{try{const key=Object.keys(el).find(k=>k.startsWith('__reactFiber'));return key?el[key]:null}catch{return null}};
  function propsWhere(el,predicate,limit=24){
    const direct=reactProps(el);if(direct&&predicate(direct))return direct;
    let f=fiber(el);const seen=new Set();for(let i=0;f&&i<limit&&!seen.has(f);i++,f=f.return){seen.add(f);const p=f.memoizedProps;if(p&&predicate(p))return p;}return null;
  }
  const foreign=el=>!el||el.nodeType!==1||!!el.closest(injected);
  function visible(el){
    if(!el?.isConnected||el.closest('[hidden],[aria-hidden="true"]'))return false;
    for(let p=el;p&&p!==document.documentElement;p=p.parentElement){const style=win.getComputedStyle(p);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||style.opacity==='0')return false;}
    const r=el.getBoundingClientRect();return r.width>0&&r.height>0;
  }
  const semantic=value=>{
    const s=String(value||'').trim().toLowerCase().replace(/[\s_-]+/g,'');
    if(/^(search|searchlog|searchmessage|messagesearch|검색|대화검색|메시지검색)$/.test(s))return 'search';
    if(/^(mention|mentions|searchmention|at|멘션|언급)$/.test(s))return 'mention';
    if(/^(attach|attachment|attachments|clip|paperclip|file|files|searchfile|첨부|첨부파일|파일)$/.test(s))return 'attach';
    if(/^(link|links|searchlink|링크)$/.test(s))return 'link';
    return '';
  };
  function iconRole(el){
    const labels=[el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-icon'),el.getAttribute('name')];
    const p=propsWhere(el,p=>typeof p.name==='string'&&!!semantic(p.name),8);if(p)labels.unshift(p.name);
    return labels.map(semantic).find(Boolean)||'';
  }
  function discoverRail(root){
    const hits=[];
    for(const el of root.querySelectorAll('svg,button,[role="button"],[aria-label],[data-icon]')){
      if(foreign(el)||el.closest(excluded+',.js-scroll-area,.js-channel-list')||!visible(el))continue;
      const role=iconRole(el);if(!role)continue;
      // An icon and its button are one control, never two independent votes.
      const control=el.closest('button,[role="button"]')||el;
      if(!hits.some(h=>h.control===control&&h.role===role))hits.push({control,role});
    }
    const candidates=new Map(),bounds=root.getBoundingClientRect(),right=bounds.width?bounds.right:win.innerWidth;
    for(const hit of hits){let p=hit.control.parentElement;for(let depth=0;p&&p!==root&&depth<6;depth++,p=p.parentElement){
      if(foreign(p)||p.closest(excluded+',.js-scroll-area,.js-channel-list'))break;
      const r=p.getBoundingClientRect();if(r.width<=0||r.width>128||r.height<90||r.height<r.width*1.6||r.bottom<=0||r.top>=win.innerHeight||r.right>right+8||r.left<right-Math.max(180,(bounds.width||win.innerWidth)*.2))continue;
      if(!visible(p))continue;
      if(!candidates.has(p))candidates.set(p,new Set());candidates.get(p).add(hit.role);
    }}
    const trusted=[...candidates].filter(([,roles])=>roles.size>=3&&roles.has('search')&&(roles.has('mention')||roles.has('attach'))).map(([el])=>el);
    // Nested wrappers describe one toolbar. Keep its narrowest semantic owner;
    // disjoint qualifying toolbars are ambiguous and must not receive our UI.
    const leaves=trusted.filter(el=>!trusted.some(other=>other!==el&&el.contains(other)));
    railReason=leaves.length===1?'semantic-toolbar':leaves.length?'ambiguous-toolbar':'toolbar-unavailable';
    return leaves.length===1?leaves[0]:null;
  }
  function reconcile(next){
    let changed=false;
    for(const [el,added] of owned){const wanted=next.get(el)||new Set(),current=tokens(el);for(const token of [...added])if(!wanted.has(token)){if(current.delete(token))changed=true;added.delete(token);}
      const value=[...current].join(' ');if(value!==el.getAttribute(attribute)){if(value)el.setAttribute(attribute,value);else el.removeAttribute(attribute);}if(!added.size)owned.delete(el);
    }
    for(const [el,wanted] of next){const current=tokens(el);let added=owned.get(el);for(const token of wanted)if(!current.has(token)){current.add(token);if(!added){added=new Set();owned.set(el,added)}added.add(token);changed=true;}
      const value=[...current].join(' ');if(value!==el.getAttribute(attribute))el.setAttribute(attribute,value);
    }
    return changed;
  }
  function chunkRenderer(el){
    // Current renderer: DOM text span -> chunks components -> {log,chunks}
    // component -> DOM bubble. Stop at the first enclosing DOM node so nested
    // links, usernames and controls cannot inherit the whole message identity.
    let f=fiber(el),message=false;const seen=new Set();
    for(let i=0;f&&i<24&&!seen.has(f);i++,f=f.return){
      seen.add(f);const p=f.memoizedProps;
      if(f.stateNode?.nodeType===1&&f.stateNode!==el)return message?f.stateNode:null;
      if(p?.log?.id!=null&&p.log.channelId!=null&&p.log.senderId!=null&&Object.prototype.hasOwnProperty.call(p,'chunks'))message=true;
    }
    return null;
  }
  function ownsFileModel(el){
    let f=fiber(el);const direct=reactProps(el),isFile=p=>p?.file?.id!=null&&(typeof p.file.fileName==='string'||typeof p.file.title==='string');
    if(isFile(direct))return true;
    const seen=new Set();for(let i=0;f&&i<20&&!seen.has(f);i++,f=f.return){seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==el)return false;if(isFile(f.memoizedProps))return true;}return false;
  }
  function ownsLogModel(el){
    const isLog=p=>p?.log?.id!=null&&p.log.channelId!=null&&p.log.senderId!=null;
    if(isLog(reactProps(el)))return true;
    let f=fiber(el);const seen=new Set();for(let i=0;f&&i<24&&!seen.has(f);i++,f=f.return){seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==el)return false;if(isLog(f.memoizedProps))return true;}return false;
  }
  function scan(){
    if(disposed)return;dirty=false;lastScan=now();scans++;
    const root=document.querySelector('#root'),next=new Map(),previousRail=currentRail,previousReady=appReady;
    const mark=(el,role)=>{if(!el||foreign(el)||!root?.contains(el))return;if(!next.has(el))next.set(el,new Set());next.get(el).add(role)};
    currentRail=null;appReady=false;
    if(root){
      const editors=[...root.querySelectorAll('.js-main-editor,[contenteditable="true"][role="textbox"]')].filter(el=>!foreign(el));
      const scrolls=[...root.querySelectorAll('.js-scroll-area')].filter(el=>!foreign(el));
      const nativeActions=editors.some(el=>propsWhere(el,p=>p.actions?.stores,60))||[...root.children].some(el=>propsWhere(el,p=>p.actions?.stores,60));
      appReady=!!(editors.length||scrolls.length||nativeActions);
      for(const el of editors)mark(el,'editor');for(const el of scrolls)mark(el,'scroll');
      for(const el of root.querySelectorAll('.js-channel-list'))mark(el,'sidebar');
      currentRail=discoverRail(root);if(currentRail){mark(currentRail,'rail');appReady=true;}
      // Message boundaries have stable per-log classes. Never inspect or log the
      // message string: React prop shape identifies the renderer, not its value.
      for(const group of root.querySelectorAll('[data-logid]'))if(!group.closest(excluded))mark(group,'message-group');
      for(const section of root.querySelectorAll('[class*="js-log-right-content-"]')){
        if(foreign(section)||section.closest(excluded))continue;mark(section,'message-content');mark(section.parentElement,'message-group');
        for(const el of section.querySelectorAll('*')){
          if(foreign(el)||el.closest(excluded))continue;
          const direct=reactProps(el)||fiber(el)?.memoizedProps;
          const bubble=chunkRenderer(el);if(bubble&&section.contains(bubble)){mark(el,'message-text');mark(bubble,'message-bubble');continue;}
          const html=direct?.dangerouslySetInnerHTML;
          if(ownsLogModel(el)&&html&&typeof html==='object'&&Object.prototype.hasOwnProperty.call(html,'__html')){mark(el,'message-text');mark(el.parentElement,'message-bubble');}
        }
      }
      // Old renderer compatibility. Restrict to the native conversation scope;
      // these hints do not permit unrelated pages or toolbar spoofing.
      const messageScopes=scrolls.length?scrolls:[root];
      for(const scope of messageScopes){for(const el of scope.querySelectorAll('.sc-chbbiW')){if(el.closest(excluded)||foreign(el))continue;const log=propsWhere(el,p=>p.log?.id!=null&&p.log.channelId!=null,30);if(!log&&!el.closest('[class*="js-log-right-content-"]'))continue;mark(el,'message-text');const bubble=el.closest('.sc-iyvyFf');if(bubble)mark(bubble,'message-bubble');const group=el.closest('.sc-drKuOJ');if(group)mark(group,'message-group');}}
      // A file prop is a native model boundary. Prefer the innermost element
      // carrying its own file prop rather than all React ancestors/descendants.
      const fileCandidates=[];
      for(const el of root.querySelectorAll('div,article,section')){
        if(foreign(el)||el.closest(excluded))continue;
        if(ownsFileModel(el))fileCandidates.push(el);
      }
      for(const el of fileCandidates)if(!fileCandidates.some(other=>other!==el&&el.contains(other)))mark(el,'file-card');
    }else railReason='root-unavailable';
    const changed=reconcile(next);
    if(changed||currentRail!==previousRail||appReady!==previousReady)for(const fn of [...listeners])try{fn()}catch{}
  }
  function schedule(){if(disposed||scheduled)return;scheduled=win.setTimeout(()=>{scheduled=0;if(dirty)scan()},Math.max(0,120-(now()-lastScan)));}
  function refresh(){if(disposed)return false;dirty=true;if(now()-lastScan>=120){if(scheduled){win.clearTimeout(scheduled);scheduled=0}scan()}else schedule();return appReady;}
  const observer=new win.MutationObserver(records=>{if(records.some(record=>!foreign(record.target.nodeType===1?record.target:record.target.parentElement))){dirty=true;schedule()}});
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','id','role','aria-label','title','aria-hidden','hidden','contenteditable']});
  const timer=win.setInterval(refresh,1500),onResize=()=>refresh();win.addEventListener('resize',onResize);scan();
  return {
    rail(){if(disposed)return null;if(currentRail&&!currentRail.isConnected){currentRail=null;dirty=true;schedule()}return currentRail;},
    ready(){return !disposed&&appReady;},refresh,
    diagnostics(){return {ready:!disposed&&appReady,rail:!!currentRail,railReason,scans,marked:owned.size};},
    subscribe(fn){if(typeof fn!=='function'||disposed)return ()=>{};listeners.add(fn);return ()=>listeners.delete(fn);},
    dispose(){if(disposed)return;disposed=true;observer.disconnect();win.clearInterval(timer);if(scheduled)win.clearTimeout(scheduled);win.removeEventListener('resize',onResize);listeners.clear();currentRail=null;appReady=false;reconcile(new Map());}
  };
}

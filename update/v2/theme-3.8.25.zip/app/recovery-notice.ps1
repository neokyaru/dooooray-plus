# Windows PowerShell 5.1. This UI is started only by a verified per-user release.
# No request field can select an executable, URL, action, or filesystem target.
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

function Assert-RecoveryNoticePath([string]$Path, [bool]$RequireFile) {
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path.IndexOfAny([IO.Path]::GetInvalidPathChars()) -ge 0) { throw 'invalid-path' }
    $full = [IO.Path]::GetFullPath($Path)
    if (-not [string]::Equals($full, $Path, [StringComparison]::OrdinalIgnoreCase) -or $full -notmatch '^[A-Za-z]:\\') { throw 'invalid-path' }
    $cursor = $full
    while ($cursor) {
        if (-not [IO.File]::Exists($cursor) -and -not [IO.Directory]::Exists($cursor)) { throw 'missing-path' }
        $attributes = [IO.File]::GetAttributes($cursor)
        if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'reparse-path' }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ([string]::Equals($parent, $cursor, [StringComparison]::OrdinalIgnoreCase)) { break }
        $cursor = $parent
    }
    if ($RequireFile -and (([IO.File]::GetAttributes($full) -band [IO.FileAttributes]::Directory) -ne 0)) { throw 'not-file' }
    return $full
}

function Get-ValidatedRecoveryNotice([string]$RequestPath, [string]$LocalData, [string]$CurrentSid, [bool]$Elevated, [long]$Now) {
    if ($Elevated -or $CurrentSid -notmatch '^S-1-[0-9]+(?:-[0-9]+)+$' -or $CurrentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) { throw 'invalid-user-token' }
    $data = [IO.Path]::Combine([IO.Path]::GetFullPath($LocalData), 'DoorayTheme')
    $folder = [IO.Path]::Combine($data, 'recovery-notices')
    $path = Assert-RecoveryNoticePath $RequestPath $true
    if (-not [string]::Equals([IO.Path]::GetDirectoryName($path), $folder, [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-request-folder' }
    $name = [IO.Path]::GetFileName($path)
    if ($name -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\.json$') { throw 'invalid-request-name' }
    $token = [IO.Path]::GetFileNameWithoutExtension($path)
    $stream = $null
    $reader = $null
    try {
        $stream = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        if ($stream.Length -lt 2 -or $stream.Length -gt 65536) { throw 'invalid-request-size' }
        $reader = New-Object IO.StreamReader($stream, (New-Object Text.UTF8Encoding($false, $true)), $true)
        $request = $reader.ReadToEnd() | ConvertFrom-Json
    } finally {
        if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() }
    }
    if ($request -isnot [Management.Automation.PSCustomObject]) { throw 'invalid-schema' }
    $allowed = @('schema','version','reason','kind','available','pending','at','token','userSid')
    foreach ($property in $request.PSObject.Properties.Name) { if ($property -notin $allowed) { throw 'unknown-field' } }
    foreach ($required in @('schema','version','reason','kind','available','pending','at','token')) {
        if ($required -notin $request.PSObject.Properties.Name) { throw 'missing-field' }
    }
    if ($request.schema -isnot [int] -or $request.schema -ne 1) { throw 'invalid-schema' }
    foreach ($field in @('version','available','pending')) {
        $value = $request.$field
        if ($field -ne 'version' -and $null -eq $value) { continue }
        if ($value -isnot [string] -or $value -notmatch '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$') { throw 'invalid-version' }
    }
    if ($request.reason -isnot [string] -or $request.reason -cnotin @('load-timeout','connection-unavailable','engine-error')) { throw 'invalid-reason' }
    if ($request.kind -isnot [string] -or $request.kind -cnotin @('patch','installer','unknown')) { throw 'invalid-kind' }
    if ($request.token -isnot [string] -or -not [string]::Equals($request.token, $token, [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-token' }
    if ('userSid' -in $request.PSObject.Properties.Name -and ($request.userSid -isnot [string] -or $request.userSid -cne $CurrentSid)) { throw 'wrong-user' }
    if (($request.at -isnot [long] -and $request.at -isnot [int]) -or $request.at -le 0 -or $request.at -lt ($Now - 900000) -or $request.at -gt ($Now + 30000)) { throw 'expired-request' }
    return [pscustomobject]@{ Request=$request; Path=$path; Data=$data; Receipt=[IO.Path]::Combine($folder, $token+'.result.json') }
}

function Write-RecoveryNoticeReceipt($Notice, [string]$Status, [string]$Reason='') {
    if ($Status -cnotin @('accepted','balloon-shown','clicked','closed','failed')) { throw 'invalid-status' }
    if ($Reason -and $Reason -cne 'ui-unavailable') { throw 'invalid-status-reason' }
    $null = Assert-RecoveryNoticePath ([IO.Path]::GetDirectoryName($Notice.Receipt)) $false
    if ([IO.File]::Exists($Notice.Receipt) -or [IO.Directory]::Exists($Notice.Receipt)) { $null = Assert-RecoveryNoticePath $Notice.Receipt $true }
    $record = [ordered]@{schema=1; version=$Notice.Request.version; token=$Notice.Request.token; at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds(); status=$Status}
    if ($Reason) { $record.reason=$Reason }
    $temporary = $Notice.Receipt+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    $stream = $null
    try {
        $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes(($record | ConvertTo-Json -Compress))
        $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $stream.Write($bytes,0,$bytes.Length); $stream.Dispose(); $stream=$null
        if ([IO.File]::Exists($Notice.Receipt)) { [IO.File]::Replace($temporary, $Notice.Receipt, [Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temporary, $Notice.Receipt) }
    } finally {
        if ($stream) { $stream.Dispose() }
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}

function Get-RecoveryNoticeText([string]$Kind) {
    switch -CaseSensitive ($Kind) {
        'patch' { return '두레이 플러스를 불러오지 못했습니다. 패치 업데이트 안내를 확인해 주세요.' }
        'installer' { return '두레이 플러스를 불러오지 못했습니다. 설치 복구 안내를 확인해 주세요.' }
        'unknown' { return '두레이 플러스를 불러오지 못했습니다. 업데이트 또는 설치 복구 안내를 확인해 주세요.' }
        default { throw 'invalid-kind' }
    }
}

function New-RecoveryNoticeLaunch([string]$Action, [string]$Data) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.UseShellExecute = $true
    switch -CaseSensitive ($Action) {
        'page' { $start.FileName='https://gitlab.com/neokyaru/dooooraytheme/-/tree/main/update/v2' }
        'logs' {
            $null = Assert-RecoveryNoticePath $Data $false
            if (-not [IO.Directory]::Exists($Data)) { throw 'not-directory' }
            $start.FileName = [IO.Path]::Combine([Environment]::GetFolderPath('Windows'),'explorer.exe')
            $start.Arguments = '"'+$Data+'"'
        }
        default { throw 'invalid-action' }
    }
    return $start
}

function Show-RecoveryNoticeDetails {
    $state = $script:RecoveryNoticeUI
    if ($state.Form -and -not $state.Form.IsDisposed) { return }
    $state.Clicked=$true
    try { Write-RecoveryNoticeReceipt $state.Notice 'clicked' } catch {}
    $form=New-Object Windows.Forms.Form
    $state.Form=$form
    $form.Text='두레이 플러스 복구 안내'
    $form.StartPosition='CenterScreen'
    $form.ClientSize=New-Object Drawing.Size(480,240)
    $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false; $form.MinimizeBox=$true
    $form.Font=New-Object Drawing.Font('Malgun Gothic',9)
    $label=New-Object Windows.Forms.Label
    $label.Location=New-Object Drawing.Point(20,18); $label.Size=New-Object Drawing.Size(440,132)
    $version=$state.Notice.Request.version
    $target=if($state.Notice.Request.pending){$state.Notice.Request.pending}else{$state.Notice.Request.available}
    $label.Text=(Get-RecoveryNoticeText $state.Notice.Request.kind)+"`r`n`r`n현재 버전: "+$version
    if ($target) { $label.Text+="`r`n확인된 업데이트: "+$target }
    $label.Text+="`r`n배포 페이지의 안내와 로그 폴더를 확인해 주세요."
    $form.Controls.Add($label)
    $status=New-Object Windows.Forms.Label
    $status.Location=New-Object Drawing.Point(20,151); $status.Size=New-Object Drawing.Size(440,28)
    $form.Controls.Add($status); $state.Status=$status
    $page=New-Object Windows.Forms.Button
    $page.Text='배포 페이지 열기'; $page.Location=New-Object Drawing.Point(20,190); $page.Size=New-Object Drawing.Size(142,30)
    $page.Add_Click({try { $null=[Diagnostics.Process]::Start((New-RecoveryNoticeLaunch 'page' $script:RecoveryNoticeUI.Notice.Data)) } catch { $script:RecoveryNoticeUI.Status.Text='배포 페이지를 열지 못했습니다.' }})
    $logs=New-Object Windows.Forms.Button
    $logs.Text='로그 폴더 열기'; $logs.Location=New-Object Drawing.Point(172,190); $logs.Size=New-Object Drawing.Size(142,30)
    $logs.Add_Click({try { $null=[Diagnostics.Process]::Start((New-RecoveryNoticeLaunch 'logs' $script:RecoveryNoticeUI.Notice.Data)) } catch { $script:RecoveryNoticeUI.Status.Text='로그 폴더를 열지 못했습니다.' }})
    $close=New-Object Windows.Forms.Button
    $close.Text='닫기'; $close.Location=New-Object Drawing.Point(354,190); $close.Size=New-Object Drawing.Size(106,30)
    $close.Add_Click({$script:RecoveryNoticeUI.Form.Close()})
    $form.Controls.AddRange(@($page,$logs,$close)); $form.CancelButton=$close
    $form.Add_FormClosed({$script:RecoveryNoticeUI.Context.ExitThread()})
    $form.Show()
}

function Invoke-DoorayPlusRecoveryNotice {
    $notice=$null; $context=$null; $icon=$null; $timer=$null; $script:RecoveryNoticeUI=$null
    try {
        $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal=New-Object Security.Principal.WindowsPrincipal($identity)
            $notice=Get-ValidatedRecoveryNotice $env:DOORAY_PLUS_NOTICE_FILE ([Environment]::GetFolderPath('LocalApplicationData')) $identity.User.Value ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
        } finally { $identity.Dispose() }
    } catch { [Console]::Error.WriteLine('Recovery notice request rejected.'); return 2 }
    try {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        [Windows.Forms.Application]::EnableVisualStyles()
        $context=New-Object Windows.Forms.ApplicationContext
        $icon=New-Object Windows.Forms.NotifyIcon
        $timer=New-Object Windows.Forms.Timer
        $script:RecoveryNoticeUI=[pscustomobject]@{Notice=$notice; Context=$context; Icon=$icon; Timer=$timer; Form=$null; Status=$null; Clicked=$false; Clock=[Diagnostics.Stopwatch]::StartNew()}
        $icon.Icon=[Drawing.SystemIcons]::Warning
        $icon.Text='두레이 플러스 복구 안내'
        $icon.BalloonTipTitle='두레이 플러스 복구 안내'
        $icon.BalloonTipText=Get-RecoveryNoticeText $notice.Request.kind
        $icon.BalloonTipIcon='Warning'
        $icon.Add_BalloonTipShown({try { Write-RecoveryNoticeReceipt $script:RecoveryNoticeUI.Notice 'balloon-shown' } catch {}})
        $icon.Add_BalloonTipClicked({try { Show-RecoveryNoticeDetails } catch { $script:RecoveryNoticeUI.Context.ExitThread() }})
        $icon.Add_DoubleClick({try { Show-RecoveryNoticeDetails } catch { $script:RecoveryNoticeUI.Context.ExitThread() }})
        $timer.Interval=1000
        $timer.Add_Tick({$state=$script:RecoveryNoticeUI; $limit=if($state.Clicked){300000}else{75000}; if($state.Clock.ElapsedMilliseconds -ge $limit){$state.Context.ExitThread()}})
        $icon.Visible=$true
        $icon.ShowBalloonTip(12000)
        # This is a delivery request acknowledgment, not proof the user saw it.
        Write-RecoveryNoticeReceipt $notice 'accepted'
        $timer.Start()
        [Windows.Forms.Application]::Run($context)
        try { Write-RecoveryNoticeReceipt $notice 'closed' } catch {}
        return 0
    } catch {
        try { Write-RecoveryNoticeReceipt $notice 'failed' 'ui-unavailable' } catch {}
        [Console]::Error.WriteLine('Recovery notice UI unavailable.')
        return 3
    } finally {
        $state=$script:RecoveryNoticeUI
        if($state){
            try {if($state.Form){$state.Form.Dispose()}}catch{}
            $script:RecoveryNoticeUI=$null
        }
        try {if($timer){$timer.Stop();$timer.Dispose()}}catch{}
        try {if($icon){$icon.Visible=$false;$icon.Dispose()}}catch{}
        try {if($context){$context.Dispose()}}catch{}
    }
}

# Runtime entry. Tests load function definitions only and never invoke this UI.
exit (Invoke-DoorayPlusRecoveryNotice)

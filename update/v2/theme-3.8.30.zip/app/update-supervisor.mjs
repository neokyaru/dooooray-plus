// Versioned update supervisor: delivered and replaced with every signed user release.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,checkRemote,atomicJSON,newer} from './update-store.mjs';
import {installerStatus,downloadInstaller} from './installer-update.mjs';
import {prepareHandoff,startHandoff} from './update-handoff.mjs';
import {createRecoveryNotice} from './recovery-notice.mjs';
import {createNativePresenceProbe} from './native-presence.mjs';
import {createBackgroundUpdatePolicy} from './background-update-policy.mjs';
import {createBackgroundUpdateNotice,backgroundUpdateCandidate} from './background-update-notice.mjs';
const root=process.env.DOORAY_INSTALL_ROOT;
const ownVersion=path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
if(process.argv.includes('--check')){console.log(JSON.stringify({controller:ownVersion,mode:'per-user-signed-updates',runtime:process.version}));process.exit(0);}
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(process.env.DOORAY_LEGACY_BRIDGE?19353:19351,'127.0.0.1',()=>r(true))})){await fs.appendFile(path.join(userData,'updater.log'),new Date().toISOString()+' Supervisor singleton port unavailable; another instance or port conflict\n').catch(()=>{});process.exit(0);}
await fs.mkdir(data,{recursive:true});
const store=await new UpdateStore({data,publicKey}).init();
const disabled=path.join(userData,'theme-disabled.flag'),stopFlag=path.join(userData,'stop-agent.flag'),healthy=process.env.DOORAY_ENGINE_HEALTH||path.join(userData,'healthy.flag'),releaseError=process.env.DOORAY_ENGINE_ERROR||path.join(userData,'release-error.json');
const exists=async p=>{try{await fs.access(p);return true}catch{return false}};
const log=async message=>{try{const file=path.join(userData,'updater.log');if((await fs.stat(file).catch(()=>({size:0}))).size>1048576)await fs.rename(file,file+'.previous');await fs.appendFile(file,new Date().toISOString()+' '+message+'\n')}catch{}};
const nativePresence=createNativePresenceProbe({root});
const updateSchedule=createBackgroundUpdatePolicy();
const backgroundNotice=createBackgroundUpdateNotice({root,userData,version:ownVersion,onApply:applyBackgroundUpdate,log});
const recoveryNotice=createRecoveryNotice({root,userData,version:ownVersion,scriptPath:path.join(path.dirname(fileURLToPath(import.meta.url)),'recovery-notice.ps1'),log});
const expectedExit=new WeakSet();let childReady=false;let mayActivate=false;let child=null,busy=false,remoteBusy=false,activationBusy=false,closing=false,holdUntilClose=false,started=0,wasPresent=false,lastCheck=0,crashed=false;
// All recovery state is per helper attempt, independent of the wall clock and remote checks.
let retryAt=0,retryCount=0,sessionId='',healthStamp=null,lastHealthy=0,stableSince=0,lastTick=performance.now(),resumeGrace=0,diagnosticKey='',diagnosticQueue=Promise.resolve();
let recoveryPhase='connecting',recoveryReason='',nativePageState='unknown';
const backgroundPreflights=new Map();
function releaseBackgroundLease(running){try{if(running?.connected)running.send({type:'background-unreserve'})}catch{}}
function preflightBackground(running=child){
 if(!running||running!==child||!running.connected)return Promise.resolve({known:false});
 const id=crypto.randomUUID();return new Promise(resolve=>{const timer=setTimeout(()=>{backgroundPreflights.delete(id);resolve({known:false})},5000);backgroundPreflights.set(id,{running,resolve,timer});try{running.send({type:'background-preflight',id})}catch{clearTimeout(timer);backgroundPreflights.delete(id);resolve({known:false})}});
}
async function applyBackgroundUpdate(request){
 const progress=async(phase,code,handoffToken)=>{try{await request.progress(phase,code,handoffToken)}catch{}};
 if(closing||activationBusy||handoffBusy||activeHandoff){await progress('error','busy');return;}
 handoffBusy=true;const generation=++handoffGeneration;let reserved=null,applying=null;
 const ensure=()=>{if(closing||generation!==handoffGeneration)throw Error('cancelled')};
 const preflight=async()=>{ensure();const native=await nativePresence.refreshFresh();ensure();if(!native.known)throw Error('window-required');if(native.running){reserved=child;const check=await preflightBackground(reserved);ensure();if(check.downloads>0)throw Error('downloads-active');if(!check.known||check.drafts!==0||check.reserved!==true||reserved!==child)throw Error('window-required');}};
 try{
  await progress('checking');await preflight();const checked=await remote(true,false);ensure();if(checked.status==='error')throw Error('check-failed');
  if(!newer(request.available,store.state.active)){await progress('complete','updated');return;}
  const candidate=backgroundUpdateCandidate(checked,store.state.active);if(!candidate||candidate.available!==request.available||candidate.kind!==request.kind)throw Error('update-changed');
  await progress('downloading');let installer=null;
  if(candidate.kind==='installer'){if(installerInfo?.manifest.version!==candidate.available)throw Error('update-changed');installer=await downloadInstaller(installerInfo,publicKey,path.join(data,'installers',candidate.available));}
  else{const downloaded=await remote(true,true);ensure();if(downloaded.status==='error')throw Error('check-failed');if(store.state.pending!==candidate.available)throw Error('update-changed');await store.validate(candidate.available);}
  ensure();await progress('confirming');ensure();
  const prepared=await prepareHandoff({root,data,version:candidate.available,kind:candidate.kind,installer});ensure();
  prepared.reservedChild=reserved;applying=prepared;activeHandoff=prepared;handoffJob=null;
  if(candidate.kind==='patch')await store.validate(candidate.available);
  const ensureOwner=()=>{ensure();if(activeHandoff!==prepared)throw Error('cancelled')};ensureOwner();
  await progress('restarting',undefined,prepared.token);ensureOwner();
  // The Windows notice already owns a progress window for this action.
  await startHandoff(prepared,undefined,async()=>{ensureOwner();await preflight();ensureOwner();prepared.reservedChild=reserved},async()=>{});prepared.authorized=true;handoffBusy=false;
 }catch(error){
  if(applying&&activeHandoff===applying)activeHandoff=null;
  if(generation===handoffGeneration){cancelPreparation();lastResult={status:'error',error:'백그라운드 업데이트를 진행하지 못했습니다. ('+(['window-required','downloads-active','update-changed','cancelled','check-failed'].includes(error.message)?error.message:'helper-failed')+')'};}
  await progress('error',['window-required','downloads-active','update-changed','cancelled','check-failed'].includes(error.message)?error.message:'helper-failed');await log('Background apply deferred: '+error.message);
 }finally{if(!applying||activeHandoff!==applying)releaseBackgroundLease(reserved);if(generation===handoffGeneration)handoffBusy=false;}
}
function observeRecovery(present,native){
 const checked=['current','ahead','available','ready'].includes(lastResult.status);
 void recoveryNotice.observe({present,nativeRunning:native?.known?native.running:null,nativeInteractive:native?.known&&native.interactive===true,phase:recoveryPhase,reason:recoveryReason,retryCount,version:store.state.active||ownVersion,available:checked?lastResult.available||null:null,pending:checked?store.state.pending:null,kind:checked?lastResult.kind:'unknown',updateChecked:checked,enabled:!closing,paused:closing||!!activeHandoff||handoffBusy||performance.now()<resumeGrace||nativePageState==='login'||recoveryReason.includes('waiting-login')}).catch(()=>{});
}
async function diagnostic(phase,reason=''){
 recoveryPhase=phase;recoveryReason=reason;
 const key=phase+'|'+reason+'|'+store.state.active;if(key===diagnosticKey)return;diagnosticKey=key;
 const value={phase,reason,version:store.state.active,helperPid:child?.pid||null,retryCount,at:Date.now()};
 diagnosticQueue=diagnosticQueue.then(async()=>{await atomicJSON(path.join(userData,'connection-status.json'),value).catch(()=>{});await log('Connection '+phase+(reason?': '+reason:''));});await diagnosticQueue;
}
async function retryHelper(reason){
 if(activeHandoff)return;
 cancelPreparation();const old=child;child=null;childReady=false;healthStamp=null;stableSince=0;
 if(old){expectedExit.add(old);try{old.send({type:'shutdown'})}catch{}setTimeout(()=>{try{old.kill()}catch{}},2500).unref();}
 await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});
 retryCount++;const delay=Math.min(60000,5000*2**Math.min(retryCount-1,4));retryAt=performance.now()+delay;
 await diagnostic('retrying',reason+'; retry in '+delay+'ms');
}
async function currentFault(){try{const fault=JSON.parse(await fs.readFile(releaseError,'utf8'));return fault?.version===store.state.active&&fault.session===sessionId?fault:null}catch{return null}}
async function monitorHelper(){
 if(activeHandoff)return;
 if(await currentFault()){await fail('runtime-error');return;}
 let health=null;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
 const now=performance.now();
 if(health?.version===store.state.active&&health.session===sessionId&&Number.isFinite(health.at)){
  if(health.at!==healthStamp){healthStamp=health.at;lastHealthy=now;}
  if(now-lastHealthy<=30000){
   if(!childReady){childReady=true;stableSince=now;}await diagnostic('ready');
   if(store.state.trial)await store.confirm();
   if(now-stableSince>=30000){retryCount=0;retryAt=0;}return;
  }
 }
 if(now<resumeGrace)return;
 if((!childReady&&now-started>45000)||(childReady&&now-lastHealthy>45000))await retryHelper(childReady?'health-stalled':'startup-timeout');
}
async function activate(){
  if(!canActivatePending())return;const proof=await nativePresence.refreshFresh();if(!proof.known||proof.running||!canActivatePending())return;activationBusy=true;
  try{await store.activate();if(store.state.active!==ownVersion)process.exit(75);}finally{activationBusy=false;}
}
function canActivatePending(){return !closing&&!activationBusy&&!remotePromise&&!handoffBusy&&!!store.state.pending&&(!activeHandoff||(activeHandoff.authorized===true&&activeHandoff.config.kind==='patch'&&activeHandoff.config.version===store.state.pending));}
process.on('disconnect',()=>shutdown());
process.on('message',m=>{if(m?.type==='shutdown')void shutdown()});
setInterval(()=>{if(process.connected)process.send({type:'supervisor-alive',version:ownVersion})},2000).unref();
if(process.connected)process.send({type:'supervisor-alive',version:ownVersion});
async function shutdown(){if(closing)return;closing=true;nativePresence.dispose();recoveryNotice.dispose();backgroundNotice.dispose();for(const p of backgroundPreflights.values()){clearTimeout(p.timer);p.resolve({known:false})}backgroundPreflights.clear();if(child){try{child.send({type:'shutdown'})}catch{}const old=child;setTimeout(()=>{try{old.kill()}catch{}},2500).unref();}setTimeout(()=>process.exit(0),3000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);process.on('exit',()=>{try{child?.kill()}catch{}});
async function fail(reason){cancelPreparation();await log('Release failed: '+store.state.active+' '+reason);const old=child;child=null;if(old){try{old.send({type:'shutdown'})}catch{}setTimeout(()=>{try{old.kill()}catch{}},1500).unref();}
  if(old)try{old.kill()}catch{}
  if(!store.state.trial){await log('Confirmed release retained: '+store.state.active+' '+reason);if(['runtime-error','helper-exited','bootstrap-error'].includes(reason)){await retryHelper(reason);}else{holdUntilClose=true;await diagnostic('blocked',reason);}return;}
  const previous=await store.rollback();await fs.unlink(releaseError).catch(()=>{});holdUntilClose=true;
  if(previous)process.exit(75);
  await log('No healthy release; retry on next launch');await shutdown();
}
let remotePromise=null,remoteDownload=false,lastResult={status:'idle'},installerInfo=null,handoffJob=null,handoffBusy=false,activeHandoff=null,handoffGeneration=0;
function cancelPreparation(){handoffGeneration++;handoffJob=null;handoffBusy=false;}
const updateStatus=()=>({...lastResult,...(activeHandoff?{status:'restarting'}:{}),active:store.state.active,pending:store.state.pending,checkedAt:lastCheck,backgroundNotice:backgroundNotice.handles()});
async function remote(force=false,download=true){
 if(activationBusy)return {...updateStatus(),status:'restarting'};
 if(remotePromise){const covered=remoteDownload;await remotePromise;if(!download||covered||store.state.pending)return updateStatus();return remote(force,download);}
 if(!updateSchedule.begin(performance.now(),{force}))return updateStatus();
 lastCheck=Date.now();lastResult={status:download?'downloading':'checking'};
 remoteDownload=download;
 remotePromise=(async()=>{try{
  let warning=null;try{installerInfo=await installerStatus(root,publicKey,store.state.active)}catch(e){installerInfo=null;if(e.code!=='INSTALLATION_STATE_INVALID'&&(e instanceof SyntaxError||/signature|metadata|contract/i.test(e.message)))throw e;warning='설치 업데이트 정보 확인 실패: '+e.message;await log(warning);}
  const result=await checkRemote(store,fetch,{download:download&&!installerInfo?.needed});
  if(store.state.pending)await store.validate(store.state.pending);
  lastResult={status:installerInfo?.needed?'available':store.state.pending?'ready':result?.available?'available':result?.ahead?'ahead':'current',available:installerInfo?.needed?installerInfo.manifest.version:result?.available||null,kind:installerInfo?.needed?'installer':'patch',remoteVersion:result?.remoteVersion||null,warning};if(store.state.pending)await log('Update staged: '+store.state.pending);
 }catch(e){lastResult={status:'error',error:e.message};await log('Update check deferred: '+e.message)}return updateStatus()})().finally(()=>{remotePromise=null});
 try{return await remotePromise}finally{updateSchedule.complete(lastResult.status!=='error',performance.now());}
}
function connectUpdates(running){running.on('message',async m=>{
 if(running===child&&m?.type==='background-preflight-result'&&m.version===store.state.active&&m.session===sessionId){const pending=backgroundPreflights.get(m.id);if(pending&&pending.running===running){clearTimeout(pending.timer);backgroundPreflights.delete(m.id);const v=m.result;pending.resolve(v&&typeof v.known==='boolean'&&typeof v.reserved==='boolean'&&Number.isInteger(v.drafts)&&v.drafts>=0&&Number.isInteger(v.downloads)&&v.downloads>=0?v:{known:false});}return;}
 if(running===child&&m?.type==='launcher-status'&&m.version===store.state.active&&m.session===sessionId){if(['connecting','reconnecting','waiting-page','waiting-theme','waiting-debug-port','waiting-target','waiting-navigation','waiting-login'].includes(m.phase))await diagnostic('connecting','launcher '+m.phase);return;}
 if(running!==child||!['update-check','update-status','update-install','update-apply','update-cancel'].includes(m?.type)||typeof m.id!=='string'||m.id.length>80)return;
 if(m.type==='update-install'&&(activationBusy||handoffBusy||activeHandoff)){if(running.connected)running.send({type:'update-result',id:m.id,result:{...updateStatus(),status:'error',error:'업데이트가 이미 진행 중입니다.'}});return;}
 let result,applying=null,generation=handoffGeneration;try{
 if(m.type==='update-install'){
  if(handoffBusy)throw Error('업데이트가 이미 준비 중입니다.');handoffBusy=true;generation=++handoffGeneration;
  const ensureCurrent=()=>{if(generation!==handoffGeneration||running!==child)throw Error('업데이트 준비가 취소되었습니다. 다시 시도해 주세요.');};
  const checked=await remote(true,false);ensureCurrent();if(checked.status==='error')throw Error(checked.error);
  let installer=null,version,kind=installerInfo?.needed?'installer':'patch';
  if(kind==='installer'){version=installerInfo.manifest.version;installer=await downloadInstaller(installerInfo,publicKey,path.join(data,'installers',version));}
  else{const downloaded=await remote(true,true);if(downloaded.status==='error')throw Error(downloaded.error);version=store.state.pending;if(!version)throw Error('적용할 새 업데이트가 없습니다.');await store.validate(version);}
  ensureCurrent();const prepared=await prepareHandoff({root,data,version,kind,installer});ensureCurrent();handoffJob=prepared;result={...updateStatus(),status:'prepared',token:handoffJob.token,kind,available:version};
 }else if(m.type==='update-apply'){
  if(!handoffJob||m.token!==handoffJob.token)throw Error('업데이트 준비 정보가 만료되었습니다. 다시 확인해 주세요.');
  applying=handoffJob;handoffJob=null;activeHandoff=applying;
  const ensureApplying=()=>{if(closing||generation!==handoffGeneration||running!==child||activeHandoff!==applying)throw Error('업데이트 준비가 취소되었습니다. 다시 확인해 주세요.');};
  if(applying.config.kind==='patch')await store.validate(applying.config.version);
  ensureApplying();await startHandoff(applying,undefined,ensureApplying);applying.authorized=true;result={...updateStatus(),status:'restarting'};handoffJob=null;handoffBusy=false;
 }else if(m.type==='update-cancel'){cancelPreparation();result=updateStatus();}
 else result=m.type==='update-check'?await remote(true,false):updateStatus();
 }catch(e){if(applying&&activeHandoff===applying)activeHandoff=null;if(generation===handoffGeneration){cancelPreparation();lastResult={status:'error',error:e.message};}result={...updateStatus(),status:'error',error:e.message};await log('Update handoff deferred: '+e.message)}
 if(running===child&&running.connected)try{running.send({type:'update-result',id:m.id,result})}catch{}
});}
async function targets(){try{const list=await(await fetch('http://127.0.0.1:19347/json/list',{signal:AbortSignal.timeout(1000)})).json();if(!Array.isArray(list)){nativePageState='unknown';return null}const pages=list.filter(t=>{try{const u=new URL(t.url);return t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)}catch{return false}});const present=pages.some(t=>new URL(t.url).pathname.startsWith('/messenger'));nativePageState=present?'messenger':pages.length?'login':'unavailable';return present}catch(e){nativePageState='unavailable';return e.cause?.code==='ECONNREFUSED'?false:null}}
async function tick(){if(handoffBusy&&handoffJob&&Date.now()-handoffJob.config.createdAt>60000){cancelPreparation();}if(busy||closing)return;busy=true;let recoverySnapshot;try{
  const now=performance.now();if(now-lastTick>15000){resumeGrace=now+30000;await diagnostic('resuming','scheduler gap; allowing connection recovery');}lastTick=now;
  if(activeHandoff){let outcome;try{outcome=JSON.parse((await fs.readFile(path.join(activeHandoff.dir,'result.json'),'utf8')).replace(/^\uFEFF/,''))}catch{}if(outcome?.phase==='error'||Date.now()-activeHandoff.config.createdAt>20*60*1000){lastResult={status:'error',error:outcome?.message||'업데이트 실행 응답 시간이 초과되었습니다.'};releaseBackgroundLease(activeHandoff.reservedChild);activeHandoff=null;}else if(outcome?.phase==='complete'){releaseBackgroundLease(activeHandoff.reservedChild);activeHandoff=null;}}
  if(await exists(disabled)||await exists(stopFlag)){await diagnostic('disabled','explicit stop flag');await shutdown();return;}
  // The signed updater lives independently of the native app and renderer.
  if(!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  void backgroundNotice.pollActions().catch(()=>{});
  const present=await targets();let native=nativePresence.poll();
  updateSchedule.observeNative(present===true?{known:true,running:true}:native);
  // Negative cached evidence can predate a new native launch. Before a close
  // boundary can stop a helper or activate a patch, require a fresh OS query.
  if(present===false&&native.known&&!native.running&&(wasPresent||child||store.state.pending))native=await nativePresence.refreshFresh();
  if(closing)return;
  recoverySnapshot={present,native};
  // A live native window can lose its debugging port during a vendor update.
  // Check signed recovery updates independently; never interpret that outage
  // (or an unknown process probe) as permission to activate a pending release.
  if(!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  if(present===null){await diagnostic('waiting','debug endpoint unavailable (19347)');if(child)await monitorHelper();return;}
  if(!present&&(!native.known||native.running)){await diagnostic('waiting',nativePageState==='login'?'launcher waiting-login':'native Dooray still running; messenger connection unavailable');if(child)await monitorHelper();return;}
  if(!present&&(handoffBusy||activeHandoff)&&!canActivatePending()){if(child)await monitorHelper();return;}
  if(!present){holdUntilClose=false;crashed=false;mayActivate=true;retryAt=0;retryCount=0;if(wasPresent&&child){expectedExit.add(child);try{child.send({type:'shutdown'})}catch{}}wasPresent=false;
    await diagnostic('waiting','no Dooray messenger target (19347)');if(!child&&canActivatePending())await activate();return;
  }
  const firstPresent=!wasPresent;
  if(firstPresent&&!child)mayActivate=false;
  wasPresent=true;
  // Remote I/O must never hold the local feature startup or recovery loop.
  if(!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  if(holdUntilClose)return;
  if(child){await monitorHelper();return;}
  if(activeHandoff)return;
  if(!child&&mayActivate)mayActivate=false;
  if(crashed){const reason=crashed;crashed=false;if(await currentFault())await fail('runtime-error');else if(reason==='helper-exited')await fail(reason);else await retryHelper(reason);return;}
  if(performance.now()<retryAt)return;
  if(!store.state.active){await fail('missing-active-release');return;}
  try{await store.validate(store.state.active)}catch(e){await fail(e.message);return;}
  await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});started=performance.now();childReady=false;healthStamp=null;lastHealthy=started;stableSince=0;sessionId=crypto.randomUUID();if(store.state.trial){store.state.trialStarted=true;await store.persist();}
  const running=spawn(process.execPath,[path.join(store.dir(store.state.active),'app/launcher.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],cwd:store.dir(store.state.active),env:{...process.env,DOORAY_ENGINE_SESSION:sessionId}});child=running;connectUpdates(running);
  running.once('error',e=>{if(child===running){child=null;crashed='helper-spawn-error';void log('Helper spawn failed: '+e.message)}});
  running.once('exit',(code)=>{if(child===running){child=null;const systemExit=code===null||[0x40010004,0xC000013A].includes(code>>>0);crashed=wasPresent&&!closing&&!expectedExit.has(running)&&!systemExit?(code===0?'helper-stopped':'helper-exited'):false;void log('Helper exited: code='+code+' expected='+expectedExit.has(running));}});
  await log('Loaded user release '+store.state.active);await diagnostic('connecting');
}catch(e){await log('Bootstrap error: '+e.message);if(child&&!activeHandoff)await fail('bootstrap-error');}finally{if(recoverySnapshot)observeRecovery(recoverySnapshot.present,recoverySnapshot.native);void backgroundNotice.observe(updateStatus(),{enabled:!closing&&!activeHandoff&&!handoffBusy}).catch(()=>{});busy=false}}

try{if(store.state.active!==ownVersion)process.exit(75);await tick();setInterval(tick,2000);}catch(e){await log('Initialization deferred: '+e.message);await shutdown();}

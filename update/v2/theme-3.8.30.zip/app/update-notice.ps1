# Windows PowerShell 5.1. Only a verified per-user supervisor may request this UI.
# The Update button writes a fixed action record; it never installs or runs code.
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Assert-UpdateNoticePath([string]$Path, [bool]$RequireFile) {
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path.IndexOfAny([IO.Path]::GetInvalidPathChars()) -ge 0) { throw 'invalid-path' }
    $full = [IO.Path]::GetFullPath($Path)
    if (-not [string]::Equals($full, $Path, [StringComparison]::OrdinalIgnoreCase) -or $full -notmatch '^[A-Za-z]:\\') { throw 'invalid-path' }
    $cursor = $full
    while ($cursor) {
        if (-not [IO.File]::Exists($cursor) -and -not [IO.Directory]::Exists($cursor)) { throw 'missing-path' }
        if (([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'reparse-path' }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ([string]::Equals($parent, $cursor, [StringComparison]::OrdinalIgnoreCase)) { break }
        $cursor = $parent
    }
    if ($RequireFile -and (([IO.File]::GetAttributes($full) -band [IO.FileAttributes]::Directory) -ne 0)) { throw 'not-file' }
    return $full
}

function Read-UpdateNoticeJSON([string]$Path) {
    $path = Assert-UpdateNoticePath $Path $true
    $stream=$null; $reader=$null
    try {
        $stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        if ($stream.Length -lt 2 -or $stream.Length -gt 65536) { throw 'invalid-record-size' }
        $reader=New-Object IO.StreamReader($stream,(New-Object Text.UTF8Encoding($false,$true)),$true)
        $json=$reader.ReadToEnd()
        if (-not $json.TrimStart().StartsWith('{') -or -not $json.TrimEnd().EndsWith('}')) { throw 'invalid-schema' }
        $record=$json | ConvertFrom-Json
        if ($record -isnot [Management.Automation.PSCustomObject]) { throw 'invalid-schema' }
        return $record
    } finally {
        if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() }
    }
}

function Assert-UpdateNoticeFields($Record, [string[]]$Required, [string[]]$Optional=@()) {
    foreach ($field in $Record.PSObject.Properties.Name) { if ($field -cnotin ($Required+$Optional)) { throw 'unknown-field' } }
    foreach ($field in $Required) { if ($field -cnotin $Record.PSObject.Properties.Name) { throw 'missing-field' } }
    if ($Record.schema -isnot [int] -or $Record.schema -ne 1) { throw 'invalid-schema' }
}

function Test-UpdateNoticeVersion([string]$Candidate, [string]$Current) {
    $left=$Candidate.Split('.'); $right=$Current.Split('.')
    for ($i=0; $i -lt 3; $i++) {
        if ([int]$left[$i] -gt [int]$right[$i]) { return $true }
        if ([int]$left[$i] -lt [int]$right[$i]) { return $false }
    }
    return $false
}

function Get-ValidatedUpdateNotice([string]$RequestPath, [string]$LocalData, [string]$CurrentSid, [bool]$Elevated, [long]$Now) {
    if ($Elevated -or $CurrentSid -notmatch '^S-1-[0-9]+(?:-[0-9]+)+$' -or $CurrentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) { throw 'invalid-user-token' }
    $data=[IO.Path]::Combine([IO.Path]::GetFullPath($LocalData),'DoorayTheme')
    $folder=[IO.Path]::Combine($data,'update-notices')
    $path=Assert-UpdateNoticePath $RequestPath $true
    if (-not [string]::Equals([IO.Path]::GetDirectoryName($path),$folder,[StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-request-folder' }
    if ([IO.Path]::GetFileName($path) -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\.json$') { throw 'invalid-request-name' }
    $token=[IO.Path]::GetFileNameWithoutExtension($path)
    $request=Read-UpdateNoticeJSON $path
    Assert-UpdateNoticeFields $request @('schema','version','available','kind','at','token','jobToken')
    foreach ($field in @('version','available')) {
        if ($request.$field -isnot [string] -or $request.$field -notmatch '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$') { throw 'invalid-version' }
    }
    if (-not (Test-UpdateNoticeVersion $request.available $request.version)) { throw 'not-newer' }
    if ($request.kind -isnot [string] -or $request.kind -cnotin @('patch','installer')) { throw 'invalid-kind' }
    if ($request.token -isnot [string] -or -not [string]::Equals($request.token,$token,[StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-token' }
    if ($request.jobToken -isnot [string] -or $request.jobToken -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') { throw 'invalid-job-token' }
    if (($request.at -isnot [long] -and $request.at -isnot [int]) -or $request.at -le 0 -or $request.at -lt ($Now-900000) -or $request.at -gt ($Now+30000)) { throw 'expired-request' }
    return [pscustomobject]@{Request=$request; Path=$path; Data=$data; Folder=$folder; Receipt=[IO.Path]::Combine($folder,$token+'.result.json'); Action=[IO.Path]::Combine($folder,$token+'.action.json'); Progress=[IO.Path]::Combine($folder,$token+'.progress.json')}
}

function Write-UpdateNoticeRecord([string]$Path, $Record, [bool]$Replace) {
    $null=Assert-UpdateNoticePath ([IO.Path]::GetDirectoryName($Path)) $false
    if ([IO.File]::Exists($Path) -or [IO.Directory]::Exists($Path)) {
        $null=Assert-UpdateNoticePath $Path $true
        if (-not $Replace) { throw 'record-exists' }
    }
    $temporary=$Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'; $stream=$null
    try {
        $bytes=(New-Object Text.UTF8Encoding($false)).GetBytes(($Record | ConvertTo-Json -Compress))
        $stream=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $stream.Write($bytes,0,$bytes.Length); $stream.Dispose(); $stream=$null
        if ($Replace -and [IO.File]::Exists($Path)) { [IO.File]::Replace($temporary,$Path,[Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temporary,$Path) }
    } finally {
        if ($stream) { $stream.Dispose() }
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}

function Write-UpdateNoticeReceipt($Notice, [string]$Status, [string]$Reason='') {
    if ($Status -cnotin @('accepted','balloon-shown','clicked','closed','failed')) { throw 'invalid-status' }
    if ($Reason -and $Reason -cne 'ui-unavailable') { throw 'invalid-status-reason' }
    $record=[ordered]@{schema=1; version=$Notice.Request.version; available=$Notice.Request.available; token=$Notice.Request.token; jobToken=$Notice.Request.jobToken; status=$Status; at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
    if ($Reason) { $record.reason=$Reason }
    Write-UpdateNoticeRecord $Notice.Receipt $record $true
}

function Write-UpdateNoticeAction($Notice, [long]$Now) {
    # Revalidate the original record immediately before recording a user's click.
    $current=Read-UpdateNoticeJSON $Notice.Path
    Assert-UpdateNoticeFields $current @('schema','version','available','kind','at','token','jobToken')
    foreach ($field in @('version','available','kind','at','token','jobToken')) {
        if ($null -eq $current.$field -or $current.$field.GetType() -ne $Notice.Request.$field.GetType() -or $current.$field -cne $Notice.Request.$field) { throw 'request-changed' }
    }
    if ($current.at -lt ($Now-900000) -or $current.at -gt ($Now+30000)) { throw 'expired-request' }
    $record=[ordered]@{schema=1; token=$Notice.Request.token; jobToken=$Notice.Request.jobToken; action='apply'; at=$Now}
    Write-UpdateNoticeRecord $Notice.Action $record $false
}

function Get-UpdateNoticeProgress($Notice, [long]$Now) {
    if (-not [IO.File]::Exists($Notice.Progress) -and -not [IO.Directory]::Exists($Notice.Progress)) { return $null }
    $record=Read-UpdateNoticeJSON $Notice.Progress
    Assert-UpdateNoticeFields $record @('schema','token','jobToken','phase','at') @('code','handoffToken')
    if ($record.token -isnot [string] -or $record.token -cne $Notice.Request.token -or $record.jobToken -isnot [string] -or $record.jobToken -cne $Notice.Request.jobToken) { throw 'wrong-progress-identity' }
    if ($record.phase -isnot [string] -or $record.phase -cnotin @('checking','downloading','confirming','restarting','complete','error')) { throw 'invalid-progress-phase' }
    if (($record.at -isnot [long] -and $record.at -isnot [int]) -or $record.at -lt $Notice.Request.at -or $record.at -lt ($Now-1200000) -or $record.at -gt ($Now+30000)) { throw 'expired-progress' }
    if ('code' -cin $record.PSObject.Properties.Name -and ($record.code -isnot [string] -or $record.code -cnotin @('window-required','downloads-active','update-changed','busy','check-failed','helper-failed','updated','cancelled','action-expired'))) { throw 'invalid-progress-code' }
    if ('code' -cin $record.PSObject.Properties.Name -and $record.code -ceq 'updated' -and $record.phase -cne 'complete') { throw 'invalid-progress-code' }
    if ('handoffToken' -cin $record.PSObject.Properties.Name -and ($record.phase -cne 'restarting' -or $record.handoffToken -isnot [string] -or $record.handoffToken -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')) { throw 'invalid-handoff-token' }
    return $record
}

function Get-UpdateNoticeHandoff($Notice, [string]$Token, [long]$Now) {
    if ($Token -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') { throw 'invalid-handoff-token' }
    $path=[IO.Path]::Combine([string[]]@($Notice.Data,'engine-v1','handoffs',$Token,'result.json'))
    if (-not [IO.File]::Exists($path) -and -not [IO.Directory]::Exists($path)) { return $null }
    $record=Read-UpdateNoticeJSON $path
    foreach ($field in $record.PSObject.Properties.Name) { if ($field -cnotin @('phase','message','version','token','at')) { throw 'unknown-handoff-field' } }
    foreach ($field in @('phase','version','token','at')) { if ($field -cnotin $record.PSObject.Properties.Name) { throw 'missing-handoff-field' } }
    if ($record.token -isnot [string] -or $record.token -cne $Token -or $record.version -isnot [string] -or $record.version -cne $Notice.Request.available) { throw 'wrong-handoff-identity' }
    if ($record.phase -isnot [string] -or $record.phase -cnotin @('ready','closing','installing','applying','reopening','complete','error')) { throw 'invalid-handoff-phase' }
    if ($record.at -isnot [string] -or $record.at -notmatch '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,7})?(?:Z|[+-][0-9]{2}:[0-9]{2})$') { throw 'invalid-handoff-time' }
    $parsed=[DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse($record.at,[Globalization.CultureInfo]::InvariantCulture,([Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal),[ref]$parsed)) { throw 'invalid-handoff-time' }
    $at=$parsed.ToUnixTimeMilliseconds()
    if ($at -lt $Notice.Request.at -or $at -lt ($Now-1200000) -or $at -gt ($Now+30000)) { throw 'expired-handoff' }
    # Native helper errors can contain paths or arbitrary exception strings.
    # Only validated phase/time leave this function; message is never displayed.
    return [pscustomobject]@{phase=$record.phase; at=$at}
}

function Get-UpdateNoticeHandoffText([string]$Phase) {
    switch -CaseSensitive ($Phase) {
        'ready' { return '업데이트 도우미가 준비되었습니다.' }
        'closing' { return '업데이트를 위해 두레이를 종료하고 있습니다.' }
        'installing' { return '설치 업데이트를 진행하고 있습니다. Windows 승인 창을 확인해 주세요.' }
        'applying' { return '업데이트 패치를 적용하고 있습니다.' }
        'reopening' { return '두레이를 다시 시작하고 있습니다.' }
        'complete' { return '업데이트가 완료되었습니다.' }
        'error' { return '업데이트를 완료하지 못했습니다. 두레이 플러스에서 상태를 확인해 주세요.' }
        default { throw 'invalid-handoff-phase' }
    }
}

function Get-UpdateNoticeProgressText($Progress) {
    if ($Progress.phase -ceq 'error' -and 'code' -cin $Progress.PSObject.Properties.Name) {
        switch -CaseSensitive ($Progress.code) {
            'window-required' { return '작성 중인 내용을 저장해 주세요. 화면 연결이 안 되면 두레이를 완전히 종료해 준비된 패치를 적용해 주세요.' }
            'downloads-active' { return '다운로드가 진행 중입니다. 완료 후 업데이트를 다시 확인해 주세요.' }
            'update-changed' { return '업데이트 정보가 변경되었습니다. 최신 업데이트를 다시 확인해 주세요.' }
            'check-failed' { return '업데이트를 확인하지 못했습니다. 잠시 후 다시 확인해 주세요.' }
            'helper-failed' { return '업데이트 도우미를 시작하지 못했습니다. 배포 페이지에서 설치 복구를 확인해 주세요.' }
            'cancelled' { return '업데이트가 취소되었습니다.' }
            'action-expired' { return '업데이트 요청이 만료되었습니다. 업데이트를 다시 확인해 주세요.' }
            'busy' { return '다른 업데이트가 진행 중입니다. 잠시 후 상태를 확인해 주세요.' }
        }
    }
    switch -CaseSensitive ($Progress.phase) {
        'checking' { return '업데이트를 확인하고 있습니다.' }
        'downloading' { return '업데이트 파일을 다운로드하고 있습니다.' }
        'confirming' { return '업데이트 적용을 준비하고 있습니다.' }
        'restarting' { return '업데이트를 적용하고 있습니다. 잠시 기다려 주세요.' }
        'complete' { return '업데이트가 완료되었습니다.' }
        'error' { return '업데이트를 완료하지 못했습니다. 두레이 플러스 메뉴에서 상태를 확인해 주세요.' }
        default { throw 'invalid-progress-phase' }
    }
}

function Get-UpdateNoticeText([string]$Available) { return $Available+' 버전이 출시 됐습니다.'+"`r`n"+'업데이트 해주세요!' }

function New-UpdateNoticePageLaunch {
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.UseShellExecute=$true
    $start.FileName='https://gitlab.com/neokyaru/dooooraytheme/-/tree/main/update/v2'
    return $start
}

function Show-UpdateNoticeDetails {
    $state=$script:UpdateNoticeUI
    if ($state.Form -and -not $state.Form.IsDisposed) { return }
    $state.Clicked=$true
    try { Write-UpdateNoticeReceipt $state.Notice 'clicked' } catch {}
    $form=New-Object Windows.Forms.Form; $state.Form=$form
    $form.Text='두레이 플러스 업데이트'; $form.StartPosition='CenterScreen'
    $form.ClientSize=New-Object Drawing.Size(510,288)
    $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false; $form.MinimizeBox=$true
    $form.Font=New-Object Drawing.Font('Malgun Gothic',9)
    $label=New-Object Windows.Forms.Label
    $label.Location=New-Object Drawing.Point(20,18); $label.Size=New-Object Drawing.Size(470,108)
    $kind=if($state.Notice.Request.kind -ceq 'installer'){'설치 업데이트 (Windows 승인 필요)'}else{'일반 패치'}
    $label.Text=(Get-UpdateNoticeText $state.Notice.Request.available)+"`r`n`r`n현재 버전: "+$state.Notice.Request.version+'    새 버전: '+$state.Notice.Request.available+"`r`n업데이트 종류: "+$kind
    $form.Controls.Add($label)
    $status=New-Object Windows.Forms.Label; $state.Status=$status
    $status.Location=New-Object Drawing.Point(20,132); $status.Size=New-Object Drawing.Size(470,74)
    $status.Text='업데이트하기를 누르면 업데이트를 시작합니다.'+"`r`n"+'두레이가 실행 중이면 업데이트 과정에서 다시 시작할 수 있습니다.'
    $form.Controls.Add($status)
    $apply=New-Object Windows.Forms.Button; $state.Apply=$apply
    $apply.Text='업데이트하기'; $apply.Location=New-Object Drawing.Point(20,230); $apply.Size=New-Object Drawing.Size(132,36)
    $apply.Add_Click({
        $s=$script:UpdateNoticeUI
        if ($s.Requested) { return }
        try {
            Write-UpdateNoticeAction $s.Notice ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
            $s.Requested=$true; $s.Apply.Enabled=$false
            $s.Status.Text='업데이트 요청을 전달했습니다. 상태를 확인하고 있습니다.'+"`r`n"+'이 창을 닫아도 시작된 업데이트는 계속됩니다.'
        } catch {
            $s.Apply.Enabled=$false
            $s.Status.Text='업데이트 요청을 전달하지 못했습니다. 두레이 플러스에서 다시 확인해 주세요.'
        }
    })
    $page=New-Object Windows.Forms.Button
    $page.Text='배포 페이지 열기'; $page.Location=New-Object Drawing.Point(162,230); $page.Size=New-Object Drawing.Size(152,36)
    $page.Add_Click({try {$null=[Diagnostics.Process]::Start((New-UpdateNoticePageLaunch))}catch{$script:UpdateNoticeUI.Status.Text='배포 페이지를 열지 못했습니다.'}})
    $close=New-Object Windows.Forms.Button
    $close.Text='닫기'; $close.Location=New-Object Drawing.Point(384,230); $close.Size=New-Object Drawing.Size(106,36)
    $close.Add_Click({$script:UpdateNoticeUI.Form.Close()})
    $form.Controls.AddRange(@($apply,$page,$close)); $form.CancelButton=$close
    $form.Add_FormClosed({$script:UpdateNoticeUI.Context.ExitThread()})
    $form.Show()
}

function Invoke-DoorayPlusUpdateNotice {
    $notice=$null; $context=$null; $icon=$null; $timer=$null; $script:UpdateNoticeUI=$null
    try {
        $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal=New-Object Security.Principal.WindowsPrincipal($identity)
            $notice=Get-ValidatedUpdateNotice $env:DOORAY_PLUS_UPDATE_NOTICE_FILE ([Environment]::GetFolderPath('LocalApplicationData')) $identity.User.Value ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
        } finally { $identity.Dispose() }
    } catch { [Console]::Error.WriteLine('Update notice request rejected.'); return 2 }
    try {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        [Windows.Forms.Application]::EnableVisualStyles()
        $context=New-Object Windows.Forms.ApplicationContext
        $icon=New-Object Windows.Forms.NotifyIcon
        $timer=New-Object Windows.Forms.Timer
        $script:UpdateNoticeUI=[pscustomobject]@{Notice=$notice; Context=$context; Icon=$icon; Timer=$timer; Form=$null; Status=$null; Apply=$null; Clicked=$false; Requested=$false; Terminal=$false; LastProgressAt=0L; HandoffToken=$null; LastHandoffAt=0L; Clock=[Diagnostics.Stopwatch]::StartNew()}
        $icon.Icon=[Drawing.SystemIcons]::Information; $icon.Text='두레이 플러스 업데이트'
        $icon.BalloonTipTitle='두레이 플러스 업데이트'; $icon.BalloonTipText=Get-UpdateNoticeText $notice.Request.available
        $icon.BalloonTipIcon='Info'
        $icon.Add_BalloonTipShown({try {Write-UpdateNoticeReceipt $script:UpdateNoticeUI.Notice 'balloon-shown'}catch{}})
        $icon.Add_BalloonTipClicked({try {Show-UpdateNoticeDetails}catch{$script:UpdateNoticeUI.Context.ExitThread()}})
        $icon.Add_DoubleClick({try {Show-UpdateNoticeDetails}catch{$script:UpdateNoticeUI.Context.ExitThread()}})
        $timer.Interval=1000
        $timer.Add_Tick({
            $s=$script:UpdateNoticeUI
            $limit=if($s.Requested){1200000}elseif($s.Clicked){300000}else{75000}
            if ($s.Clock.ElapsedMilliseconds -ge $limit) { $s.Context.ExitThread(); return }
            if ($s.Requested -and $s.Status -and -not $s.Terminal) {
                try {
                    $progress=Get-UpdateNoticeProgress $s.Notice ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
                    if ($progress -and $progress.at -ge $s.LastProgressAt) {
                        $s.LastProgressAt=$progress.at; $s.Status.Text=Get-UpdateNoticeProgressText $progress
                        if ('handoffToken' -cin $progress.PSObject.Properties.Name -and -not $s.HandoffToken) { $s.HandoffToken=$progress.handoffToken }
                        if ($progress.phase -cin @('complete','error')) { $s.Terminal=$true }
                    }
                } catch { } # Invalid/stale status is never displayed as success.
                if ($s.HandoffToken -and -not $s.Terminal) {
                    try {
                        $handoff=Get-UpdateNoticeHandoff $s.Notice $s.HandoffToken ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
                        if ($handoff -and $handoff.at -ge $s.LastHandoffAt) {
                            $s.LastHandoffAt=$handoff.at; $s.Status.Text=Get-UpdateNoticeHandoffText $handoff.phase
                            if ($handoff.phase -cin @('complete','error')) { $s.Terminal=$true }
                        }
                    } catch { } # Missing/partial helper output is not completion.
                }
            }
        })
        $icon.Visible=$true; $icon.ShowBalloonTip(12000)
        # Acknowledges a UI delivery request, not proof that Windows displayed it.
        Write-UpdateNoticeReceipt $notice 'accepted'
        $timer.Start(); [Windows.Forms.Application]::Run($context)
        try {Write-UpdateNoticeReceipt $notice 'closed'}catch{}
        return 0
    } catch {
        try {Write-UpdateNoticeReceipt $notice 'failed' 'ui-unavailable'}catch{}
        [Console]::Error.WriteLine('Update notice UI unavailable.'); return 3
    } finally {
        $state=$script:UpdateNoticeUI
        if ($state) {try {if($state.Form){$state.Form.Dispose()}}catch{}; $script:UpdateNoticeUI=$null}
        try {if($timer){$timer.Stop();$timer.Dispose()}}catch{}
        try {if($icon){$icon.Visible=$false;$icon.Dispose()}}catch{}
        try {if($context){$context.Dispose()}}catch{}
    }
}

function Get-ValidatedHandoffProgress([string]$JobFile, [string]$LocalData, [string]$CurrentSid, [bool]$Elevated, [long]$Now) {
    if ($Elevated -or $CurrentSid -notmatch '^S-1-[0-9]+(?:-[0-9]+)+$' -or $CurrentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) { throw 'invalid-user-token' }
    $data=[IO.Path]::Combine([IO.Path]::GetFullPath($LocalData),'DoorayTheme')
    $engine=[IO.Path]::Combine($data,'engine-v1')
    $path=Assert-UpdateNoticePath $JobFile $true
    $folder=[IO.Path]::GetDirectoryName($path); $token=[IO.Path]::GetFileName($folder)
    if ([IO.Path]::GetFileName($path) -cne 'job.json' -or $token -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' -or -not [string]::Equals([IO.Path]::GetDirectoryName($folder),[IO.Path]::Combine($engine,'handoffs'),[StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-handoff-folder' }
    $job=Read-UpdateNoticeJSON $path
    $required=@('token','version','kind','dooray','root','data','installer','createdAt')
    foreach ($field in $job.PSObject.Properties.Name) { if ($field -cnotin $required) { throw 'unknown-job-field' } }
    foreach ($field in $required) { if ($field -cnotin $job.PSObject.Properties.Name) { throw 'missing-job-field' } }
    if ($job.token -isnot [string] -or $job.token -cne $token) { throw 'wrong-job-token' }
    if ($job.version -isnot [string] -or $job.version -notmatch '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$') { throw 'invalid-job-version' }
    if ($job.kind -isnot [string] -or $job.kind -cnotin @('patch','installer')) { throw 'invalid-job-kind' }
    if (($job.createdAt -isnot [long] -and $job.createdAt -isnot [int]) -or $job.createdAt -le 0 -or $job.createdAt -lt ($Now-900000) -or $job.createdAt -gt ($Now+30000)) { throw 'expired-job' }
    if ($job.data -isnot [string] -or -not [string]::Equals($job.data,$engine,[StringComparison]::OrdinalIgnoreCase)) { throw 'wrong-job-data' }
    foreach ($field in @('root','dooray')) { if ($job.$field -isnot [string] -or $job.$field.Length -gt 32760 -or $job.$field -notmatch '^[A-Za-z]:[\\/]' -or $job.$field -match '[\x00-\x1f]') { throw 'invalid-job-path' } }
    # These paths/installer fields are never executed, opened or used as UI actions.
    # The existing helper-result reader needs only this fixed data/token/version proxy.
    return [pscustomobject]@{Data=$data; Folder=$folder; Token=$token; Kind=$job.kind; Request=[pscustomobject]@{available=$job.version;at=$job.createdAt}}
}

function Get-HandoffProgressView([string]$Phase, [bool]$Observed, [long]$ElapsedMs, [long]$QuietMs) {
    if ($Observed -and $Phase -cin @('complete','error')) { return [pscustomobject]@{Text=(Get-UpdateNoticeHandoffText $Phase);Busy=$false;Terminal=$true;Exit=$false} }
    if ($ElapsedMs -ge 900000) { return [pscustomobject]@{Text='업데이트 상태를 확인할 수 없습니다. 로그에서 결과를 확인해 주세요. 이 창은 잠시 후 닫힙니다.';Busy=$false;Terminal=$false;Exit=($ElapsedMs -ge 915000)} }
    if ($QuietMs -ge 120000) { return [pscustomobject]@{Text='업데이트 응답을 기다리고 있습니다. 설치 중이면 Windows 승인 창을 확인해 주세요. 완료 여부는 아직 확인되지 않았습니다.';Busy=$true;Terminal=$false;Exit=$false} }
    $text=if($Observed){Get-UpdateNoticeHandoffText $Phase}else{'업데이트 도우미의 진행 상태를 확인하고 있습니다.'}
    return [pscustomobject]@{Text=$text;Busy=$true;Terminal=$false;Exit=$false}
}

function New-HandoffProgressForm($Notice) {
    $form=New-Object Windows.Forms.Form
    $form.Text='두레이 플러스 업데이트'; $form.StartPosition='CenterScreen'; $form.ClientSize=New-Object Drawing.Size(470,246)
    $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false; $form.MinimizeBox=$true; $form.Font=New-Object Drawing.Font('Malgun Gothic',9)
    $title=New-Object Windows.Forms.Label; $title.Location=New-Object Drawing.Point(20,18); $title.Size=New-Object Drawing.Size(430,28)
    $title.Font=New-Object Drawing.Font('Malgun Gothic',12,[Drawing.FontStyle]::Bold); $title.Text='두레이 플러스 '+$Notice.Request.available+' 업데이트'
    $status=New-Object Windows.Forms.Label; $status.Location=New-Object Drawing.Point(20,57); $status.Size=New-Object Drawing.Size(430,64)
    $status.Text='업데이트 도우미의 진행 상태를 확인하고 있습니다.'
    $bar=New-Object Windows.Forms.ProgressBar; $bar.Location=New-Object Drawing.Point(20,130); $bar.Size=New-Object Drawing.Size(430,12)
    $bar.Style='Marquee'; $bar.MarqueeAnimationSpeed=28
    $elapsed=New-Object Windows.Forms.Label; $elapsed.Location=New-Object Drawing.Point(20,154); $elapsed.Size=New-Object Drawing.Size(430,20); $elapsed.Text='경과 시간 00:00'
    $hint=New-Object Windows.Forms.Label; $hint.Location=New-Object Drawing.Point(20,195); $hint.Size=New-Object Drawing.Size(330,34); $hint.Text='이 창을 닫아도 시작된 업데이트는 계속됩니다.'
    $close=New-Object Windows.Forms.Button; $close.Location=New-Object Drawing.Point(356,194); $close.Size=New-Object Drawing.Size(94,32); $close.Text='닫기'
    $close.Add_Click({if($script:HandoffProgressUI){$script:HandoffProgressUI.Form.Close()}})
    $form.Controls.AddRange(@($title,$status,$bar,$elapsed,$hint,$close)); $form.CancelButton=$close
    return [pscustomobject]@{Form=$form;Status=$status;Bar=$bar;Elapsed=$elapsed;Hint=$hint;Close=$close}
}

function Invoke-DoorayPlusHandoffProgress {
    $notice=$null; $timer=$null; $ui=$null; $script:HandoffProgressUI=$null
    try {
        $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal=New-Object Security.Principal.WindowsPrincipal($identity)
            $notice=Get-ValidatedHandoffProgress $env:DOORAY_PLUS_HANDOFF_JOB_FILE ([Environment]::GetFolderPath('LocalApplicationData')) $identity.User.Value ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
        } finally { $identity.Dispose() }
        Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing
        [Windows.Forms.Application]::EnableVisualStyles()
        $ui=New-HandoffProgressForm $notice
        $ui | Add-Member NoteProperty Notice $notice
        $ui | Add-Member NoteProperty Clock ([Diagnostics.Stopwatch]::StartNew())
        $ui | Add-Member NoteProperty LastAt 0L
        $ui | Add-Member NoteProperty LastChange 0L
        $ui | Add-Member NoteProperty Phase 'ready'
        $ui | Add-Member NoteProperty Observed $false
        $ui | Add-Member NoteProperty Terminal $false
        $ui | Add-Member NoteProperty TerminalAt 0L
        $script:HandoffProgressUI=$ui
        $timer=New-Object Windows.Forms.Timer; $timer.Interval=500
        $timer.Add_Tick({
            $s=$script:HandoffProgressUI; $elapsed=$s.Clock.ElapsedMilliseconds
            if ($s.Terminal) { if ($elapsed-$s.TerminalAt -ge 15000) { $s.Form.Close() }; return }
            try {
                $record=Get-UpdateNoticeHandoff $s.Notice $s.Notice.Token ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
                if ($record -and $record.at -ge $s.LastAt) {
                    if ($record.at -gt $s.LastAt) { $s.LastChange=$elapsed }
                    $s.LastAt=$record.at; $s.Phase=$record.phase; $s.Observed=$true
                }
            } catch { } # A missing, locked, partial, stale or invalid record is never success.
            $view=Get-HandoffProgressView $s.Phase $s.Observed $elapsed ($elapsed-$s.LastChange)
            $s.Status.Text=$view.Text
            $s.Elapsed.Text='경과 시간 '+([TimeSpan]::FromMilliseconds($elapsed).ToString('mm\:ss'))
            if (-not $view.Busy) { $s.Bar.MarqueeAnimationSpeed=0; $s.Bar.Style='Blocks'; $s.Bar.Value=if($view.Terminal -and $s.Phase -ceq 'complete'){100}else{0} }
            if ($view.Terminal) { $s.Terminal=$true; $s.TerminalAt=$elapsed; $s.Hint.Text='진행창은 15초 후 자동으로 닫힙니다.' }
            if ($view.Exit) { $s.Form.Close() }
        })
        $timer.Start(); [Windows.Forms.Application]::Run($ui.Form)
        return 0
    } catch { [Console]::Error.WriteLine('Update progress UI unavailable.'); return 3 }
    finally { if($timer){$timer.Stop();$timer.Dispose()};if($ui){$ui.Form.Dispose()};$script:HandoffProgressUI=$null }
}

# Runtime entry. Tests load definitions only; no notification or form is executed.
if ($env:DOORAY_PLUS_HANDOFF_JOB_FILE) { exit (Invoke-DoorayPlusHandoffProgress) }
exit (Invoke-DoorayPlusUpdateNotice)

import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
import {atomicJSON,hash} from './update-store.mjs';
export async function prepareHandoff({root,data,version,kind,installer}){
 const dooray=path.join(path.dirname(root),'DoorayMessenger.exe');if(!(await fs.stat(dooray)).isFile())throw Error('두레이 실행 파일을 찾지 못했습니다.');
 const token=crypto.randomUUID(),dir=path.join(data,'handoffs',token);await fs.mkdir(dir,{recursive:true});
 const config={token,version,kind,dooray,root,data,installer:installer||null,createdAt:Date.now()};
 await fs.writeFile(path.join(dir,'run.ps1'),'\ufeff'+(await fs.readFile(path.join(path.dirname(fileURLToPath(import.meta.url)),'update-handoff.ps1'),'utf8')).replace(/^\ufeff/,''),'utf8');
 await atomicJSON(path.join(dir,'job.json'),config);return {token,dir,config};
}
export async function startHandoff(job,spawnProcess=spawn){
 if(Date.now()-job.config.createdAt>15*60*1000)throw Error('업데이트 준비 시간이 만료되었습니다. 다시 확인해 주세요.');
 if(job.config.installer&&hash(await fs.readFile(job.config.installer.file))!==job.config.installer.sha256)throw Error('Installer verification failed');
 const exe=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const stderr=await fs.open(path.join(job.dir,'helper-stderr.log'),'a'),stdout=await fs.open(path.join(job.dir,'helper-stdout.log'),'a');
 let child,exited=false,exitCode=null,exitSignal=null;
 // Detached PowerShell may exit 0 before executing -File on Windows without a console.
 // A detached hidden cmd owns the console; encoded PowerShell avoids shell interpretation of job paths.
 const quotePS=value=>"'"+value.replaceAll("'","''")+"'";
 const command='& '+quotePS(path.join(job.dir,'run.ps1'))+' -Job '+quotePS(path.join(job.dir,'job.json'));
 const encoded=Buffer.from(command,'utf16le').toString('base64');
 const wrapper=path.join(process.env.SystemRoot||'C:\\Windows','System32','cmd.exe');
 try{
  child=spawnProcess(wrapper,['/d','/s','/c','""'+exe+'" -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+encoded+'"'],{detached:true,windowsHide:true,windowsVerbatimArguments:true,stdio:['ignore',stdout.fd,stderr.fd]});
  child.once('exit',(code,signal)=>{exited=true;exitCode=code;exitSignal=signal});
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject)});child.unref();
 }finally{await stdout.close();await stderr.close()}
 const deadline=Date.now()+20000;
 while(Date.now()<deadline){
  let result;try{result=JSON.parse((await fs.readFile(path.join(job.dir,'result.json'),'utf8')).replace(/^\ufeff/,''))}catch{}
  if(result?.phase==='ready'&&result.version===job.config.version&&result.token===job.token){await fs.writeFile(path.join(job.dir,'proceed.flag'),job.token,{flag:'wx'});return;}
  if(result?.phase==='error')throw Error(result.message||'업데이트 도우미 시작 실패');
  if(exited)break;
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 throw Error('업데이트 도우미의 시작을 확인하지 못했습니다. 두레이는 종료하지 않았습니다. '+(exited?'종료 코드: '+exitCode+(exitSignal?' ('+exitSignal+')':'')+'. ':'준비 대기 시간 초과. ')+path.join(job.dir,'helper-stderr.log')+'를 확인해 주세요.');
}

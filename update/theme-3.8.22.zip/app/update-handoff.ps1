﻿param([Parameter(Mandatory=$true)][string]$Job)
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath $Job -Raw -Encoding UTF8 | ConvertFrom-Json
$jobDir=Split-Path -Parent $Job
$guard=$null
$ownsGuard=$false
$closed=$false
function Result([string]$phase,[string]$message){
 @{phase=$phase;message=$message;version=$config.version;token=$config.token;at=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $jobDir 'result.json') -Encoding UTF8
}
function DoorayProcesses {
 $session=[Diagnostics.Process]::GetCurrentProcess().SessionId
 @(foreach($process in (Get-Process -Name DoorayMessenger -ErrorAction SilentlyContinue)){
  if($process.SessionId -ne $session){continue}
  $file=$process.Path
  if(-not $file){throw '두레이 프로세스의 실행 경로를 확인하지 못했습니다. 실행 중인 두레이를 유지합니다.'}
  if(-not [String]::Equals([IO.Path]::GetFullPath($file),[IO.Path]::GetFullPath($config.dooray),[StringComparison]::OrdinalIgnoreCase)){continue}
  if(-not [DoorayExit]::Matches($process.Id,$config.dooray)){throw '두레이의 사용자 또는 일반 사용자 권한을 확인하지 못했습니다. 실행 중인 두레이를 유지합니다.'}
  $process
 })
}
function FileHash([string]$file){
 $stream=[IO.File]::OpenRead($file);$algorithm=[Security.Cryptography.SHA256]::Create()
 try{([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$algorithm.Dispose()}
}
function Reopen {
 if(@(DoorayProcesses).Count -eq 0){Start-Process -FilePath $config.dooray -WorkingDirectory (Split-Path -Parent $config.dooray) -WindowStyle Normal | Out-Null}
 $reopenDeadline=[DateTime]::UtcNow.AddSeconds(20)
 $stable=0;$previousPids=''
 while($true){
  $running=@(DoorayProcesses);$pids=($running.Id | Sort-Object)-join ','
  if($running.Count -gt 0){if($pids -eq $previousPids){$stable++}else{$stable=1}}else{$stable=0};$previousPids=$pids
  if($stable -ge 3){foreach($process in $running){if([DoorayExit]::Restore($process.Id,$config.dooray)){return}}}
  if([DateTime]::UtcNow -gt $reopenDeadline){if($running.Count -eq 0){throw '두레이 재실행 후 실행 중인 프로세스를 확인하지 못했습니다.'};throw '두레이 프로세스는 실행 중이지만 표시된 기본 창의 복원을 확인하지 못했습니다.'}
  Start-Sleep -Milliseconds 500
 }
}
try {
 $guard=New-Object System.Threading.Mutex($false,'Local\DoorayPlus-UpdateHandoff')
 try{$ownsGuard=$guard.WaitOne(0)}catch [System.Threading.AbandonedMutexException]{$ownsGuard=$true}
 if(-not $ownsGuard){throw '다른 업데이트가 진행 중입니다.'}
 if($config.kind -notin @('patch','installer')){throw 'Invalid update kind'}
 if(-not (Test-Path -LiteralPath $config.dooray -PathType Leaf)){throw 'Dooray executable missing'}
 if($config.kind -eq 'installer'){
  if((FileHash $config.installer.file) -ne $config.installer.sha256){throw 'Installer hash mismatch'}
 }
 Add-Type -TypeDefinition @'
using System;using System.Linq;public static class DoorayExit {
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr menu);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern int GetMenuString(IntPtr menu,uint item,System.Text.StringBuilder text,int length,uint flags);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool PostMessage(IntPtr window,uint message,UIntPtr wparam,IntPtr lparam);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr window,int command);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
 [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)] struct Rect {public int Left,Top,Right,Bottom;}
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr window,out Rect rect);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int processId);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process,int flags,System.Text.StringBuilder path,ref int size);
 [System.Runtime.InteropServices.DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
 [System.Runtime.InteropServices.DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr token,int informationClass,out int information,int length,out int returnLength);
 [System.Runtime.InteropServices.DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 delegate bool EnumWindowProc(IntPtr window,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowProc callback,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
 static uint? ExitCommand(IntPtr menu){
  if(menu==IntPtr.Zero)return null;
  for(int i=0;i<GetMenuItemCount(menu);i++){
   var text=new System.Text.StringBuilder(256);GetMenuString(menu,(uint)i,text,text.Capacity,0x400);
   string label=System.Text.RegularExpressions.Regex.Replace(text.ToString(),@"\(&.\)|&|\t.*","").Trim();
   if(new[]{"끝내기","종료","Exit","Quit"}.Any(value=>String.Equals(value,label,StringComparison.OrdinalIgnoreCase))){uint command=GetMenuItemID(menu,i);if(command!=UInt32.MaxValue)return command;}
   var child=ExitCommand(GetSubMenu(menu,i));if(child.HasValue)return child;
  }return null;
 }
 public static bool SafeCaller(){using(var identity=System.Security.Principal.WindowsIdentity.GetCurrent()){return !new System.Security.Principal.WindowsPrincipal(identity).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);}}
 public static bool Matches(int id,string expected){
  IntPtr process=IntPtr.Zero,token=IntPtr.Zero;
  try{
   using(var target=System.Diagnostics.Process.GetProcessById(id))using(var current=System.Diagnostics.Process.GetCurrentProcess()){if(target.SessionId!=current.SessionId)return false;}
   process=OpenProcess(0x1000,false,id);if(process==IntPtr.Zero)return false;
   var name=new System.Text.StringBuilder(32768);int size=name.Capacity;
   if(!QueryFullProcessImageName(process,0,name,ref size)||!String.Equals(System.IO.Path.GetFullPath(name.ToString()),System.IO.Path.GetFullPath(expected),StringComparison.OrdinalIgnoreCase))return false;
   if(!OpenProcessToken(process,8,out token))return false;int elevated,returned;
   if(!GetTokenInformation(token,20,out elevated,sizeof(int),out returned)||elevated!=0)return false;
   using(var owner=new System.Security.Principal.WindowsIdentity(token))using(var current=System.Security.Principal.WindowsIdentity.GetCurrent())return owner.User.Value==current.User.Value;
  }catch{return false;}finally{if(token!=IntPtr.Zero)CloseHandle(token);if(process!=IntPtr.Zero)CloseHandle(process);}
 }
public static bool Restore(int id,string expected){if(!Matches(id,expected))return false;bool found=false;EnumWindows((window,data)=>{uint pid;GetWindowThreadProcessId(window,out pid);if(pid==(uint)id && GetMenu(window)!=IntPtr.Zero){if(!IsWindowVisible(window)||IsIconic(window))ShowWindowAsync(window,9);SetForegroundWindow(window);Rect rect;found=IsWindowVisible(window)&&!IsIconic(window)&&GetWindowRect(window,out rect)&&rect.Right>rect.Left&&rect.Bottom>rect.Top;if(found)return false;}return true;},IntPtr.Zero);return found;}
public static bool Request(int id){bool requested=false;EnumWindows((window,data)=>{uint pid;GetWindowThreadProcessId(window,out pid);if(pid!=(uint)id)return true;uint? command=ExitCommand(GetMenu(window));if(command.HasValue){requested=PostMessage(window,0x111,new UIntPtr(command.Value),IntPtr.Zero);if(requested)return false;}return true;},IntPtr.Zero);return requested;}}
'@
 if(-not [DoorayExit]::SafeCaller()){throw '업데이트 도우미는 일반 사용자 권한으로 실행해야 합니다.'}
 Result 'ready' '업데이트 도우미가 준비되었습니다.'
 $authorizationDeadline=[DateTime]::UtcNow.AddSeconds(25)
 while($true){
  $authorization=$null;try{$authorization=Get-Content -LiteralPath (Join-Path $jobDir 'proceed.flag') -Raw -Encoding UTF8}catch{}
  if($authorization -eq $config.token){break}
  if([DateTime]::UtcNow -gt $authorizationDeadline){throw '업데이트 시작 승인이 전달되지 않아 두레이를 종료하지 않았습니다.'}
  Start-Sleep -Milliseconds 100
 }
 Start-Sleep -Milliseconds 800
 Result 'closing' '두레이를 종료하고 있습니다.'
 foreach($process in (DoorayProcesses)){if(-not [DoorayExit]::Request($process.Id)){[void]$process.CloseMainWindow()}}
 $deadline=[DateTime]::UtcNow.AddSeconds(25)
 while(@(DoorayProcesses).Count -gt 0){if([DateTime]::UtcNow -gt $deadline){throw '두레이가 종료되지 않았습니다. 확인 창을 처리한 뒤 다시 시도하세요. 강제 종료하지 않았습니다.'};Start-Sleep -Milliseconds 250}
 $closed=$true
 if($config.kind -eq 'installer'){
  Result 'installing' '관리자 권한 승인을 기다립니다.'
  if((FileHash $config.installer.file) -ne $config.installer.sha256){throw 'Installer hash mismatch'}
  $setup=Start-Process -FilePath $config.installer.file -ArgumentList '--update' -Verb RunAs -Wait -PassThru -WindowStyle Hidden
  if($setup.ExitCode -ne 0){throw ('설치가 완료되지 않았습니다. 종료 코드: '+$setup.ExitCode)}
 }else{
  Result 'applying' '패치를 적용하고 있습니다.'
  $deadline=[DateTime]::UtcNow.AddSeconds(120)
  while($true){
   $state=$null;try{$state=Get-Content -LiteralPath (Join-Path $config.data 'update-state.json') -Raw -Encoding UTF8 | ConvertFrom-Json}catch{}
   if($state -and $state.active -eq $config.version){break}
   if($state -and $state.failed -contains $config.version){throw '새 패치 실행에 실패해 이전 버전으로 복구되었습니다.'}
   if([DateTime]::UtcNow -gt $deadline){throw '패치 적용 대기 시간이 초과되었습니다. 기존 두레이를 다시 실행합니다.'}
   Start-Sleep -Milliseconds 500
  }
 }
 Result 'reopening' '두레이를 다시 실행하고 확인하고 있습니다.'
 Reopen
 Result 'complete' '업데이트 적용 후 두레이를 다시 실행했습니다.'
}catch{
 $message=$_.Exception.Message
 if($closed){try{Reopen}catch{$message+=' 재실행 실패: '+$_.Exception.Message}}
 Result 'error' $message
 Add-Type -AssemblyName System.Windows.Forms
 [void][System.Windows.Forms.MessageBox]::Show($message,'두레이 플러스 업데이트')
}finally{if($ownsGuard){$guard.ReleaseMutex()};if($guard){$guard.Dispose()}}

// Public, read-only GitLab access. No Dooray cookies or messages leave this helper.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const PROJECT='neokyaru/dooooraytheme';
const API='https://gitlab.com/api/v4/projects/'+encodeURIComponent(PROJECT);
const MAX_IMAGE=8*1024*1024, MAX_JSON=1024*1024;
const IMAGE=/\.(png|gif|jpe?g|webp)$/i;
export function repositoryPath(value){
  if(typeof value!=='string'||value.length>1000||value.startsWith('/')||/[\\\x00-\x1f]/.test(value)||value.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('잘못된 이모티콘 경로입니다.');
  return value;
}
export function imageType(bytes){
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';
  if(/^GIF8[79]a$/.test(bytes.subarray(0,6).toString()))return 'image/gif';
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
  if(bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP')return 'image/webp';
  throw Error('지원하지 않는 이미지 파일입니다.');
}
export function normalizePack(manifest,manifestPath,ref){
  const base=manifestPath.slice(0,manifestPath.lastIndexOf('/')+1);
  const resolve=f=>repositoryPath(f.startsWith('packs/')?f:base+f);
  if(!manifest||!Array.isArray(manifest.items||manifest.emoticons))throw Error(manifestPath+': items 목록이 필요합니다.');
  const seen=new Set();const items=(manifest.items||manifest.emoticons).slice(0,500).map((item,index)=>{
    if(typeof item==='string')item={file:item};
    const path=resolve(item.file||item.path||'');if(!path.startsWith('packs/')||!IMAGE.test(path))throw Error('PNG/GIF/JPG/WebP만 등록할 수 있습니다.');
    const id=String(item.id||index+1);if(seen.has(id))throw Error('팩 안에 중복 ID가 있습니다.');seen.add(id);
    return {id,path,ref,label:String(item.label||item.name||path.split('/').pop()).slice(0,100)};
  });
  const icon=manifest.icon?resolve(manifest.icon):items[0]?.path;
  return {id:String(manifest.id||base),name:String(manifest.name||manifest.id||base.split('/').filter(Boolean).pop()).slice(0,100),icon,ref,items};
}
export function createEmoticonRepository({fetcher=fetch,cacheDir=process.env.LOCALAPPDATA?path.join(process.env.LOCALAPPDATA,'DoorayTheme','emoticon-cache'):null,retryDelay=500}={}){
  let catalogCache=null,catalogAt=0,catalogPending=null,catalogDisk=null,catalogChecked=0,cacheBytes=0,active=0,lastPrune=0,writesSincePrune=0;const waiting=[],assets=new Map(),inflight=new Map();
  const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
  const cacheFile=key=>path.join(cacheDir,digest(key)+'.json');let cacheWrites=Promise.resolve();
  async function cached(key){if(!cacheDir)return null;try{const file=cacheFile(key),stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>12*1024*1024)return null;const record=JSON.parse(await fs.readFile(file,'utf8')),bytes=Buffer.from(record.data,'base64');if(bytes.length>MAX_IMAGE||digest(bytes)!==record.hash)return null;imageType(bytes);return bytes}catch{return null}}
  function saveCache(key,bytes){if(!cacheDir)return Promise.resolve();cacheWrites=cacheWrites.catch(()=>{}).then(async()=>{
    await fs.mkdir(cacheDir,{recursive:true});const file=cacheFile(key),temp=file+'.'+crypto.randomUUID()+'.tmp';
    try{await fs.writeFile(temp,JSON.stringify({hash:digest(bytes),data:bytes.toString('base64')}),{flag:'wx'});await fs.rename(temp,file)}finally{await fs.unlink(temp).catch(()=>{})}
    if(++writesSincePrune<16&&Date.now()-lastPrune<60000)return;lastPrune=Date.now();writesSincePrune=0;
    const entries=[];for(const name of await fs.readdir(cacheDir)){if(!/^[a-f0-9]{64}\.json$/.test(name))continue;const p=path.join(cacheDir,name),s=await fs.lstat(p);if(s.isFile()&&!s.isSymbolicLink())entries.push({p,size:s.size,at:s.mtimeMs})}
    entries.sort((a,b)=>a.at-b.at);let total=entries.reduce((n,e)=>n+e.size,0),count=entries.length;
    for(const entry of entries){if(total<=128*1024*1024&&count<=256)break;await fs.unlink(entry.p);total-=entry.size;count--}
  }).catch(()=>{});return cacheWrites}
  async function limited(fn){if(active>=4)await new Promise(r=>waiting.push(r));else active++;try{return await fn()}finally{const next=waiting.shift();if(next)next();else active--;}}
  async function request(route,max=MAX_JSON){
    const response=await fetcher(API+route,{signal:AbortSignal.timeout(20000),redirect:'error',credentials:'omit'});
    if(!response.ok){const error=Error(response.status===404?'저장소 또는 목록 파일이 아직 없거나 공개되지 않았습니다.':response.status===429?'GitLab 요청이 많습니다. 잠시 후 다시 시도해 주세요.':'GitLab 읽기 실패 ('+response.status+')');error.status=response.status;throw error;}
    if(Number(response.headers.get('content-length'))>max)throw Error('이모티콘 파일이 너무 큽니다.');
    let size=0;const chunks=[];for await(const chunk of response.body){size+=chunk.length;if(size>max)throw Error('이모티콘 파일이 너무 큽니다.');chunks.push(Buffer.from(chunk));}
    return Buffer.concat(chunks);
  }
  const raw=(p,ref,max)=>request('/repository/files/'+encodeURIComponent(repositoryPath(p))+'/raw?ref='+encodeURIComponent(ref),max);
  const json=async(p,ref)=>JSON.parse((await raw(p,ref,MAX_JSON)).toString('utf8').replace(/^\uFEFF/,''));
  async function readCatalog(){
    const commit=JSON.parse((await request('/repository/commits/HEAD')).toString());const ref=commit.id;
    if(!/^[a-f\d]{40}$/i.test(ref))throw Error('GitLab 버전 정보를 읽지 못했습니다.');
    if(catalogCache?.ref===ref&&!catalogCache.warnings.length)return catalogCache;
    let catalog;try{catalog=await json('catalog.json',ref)}catch(e){if(e.status!==404)throw e;catalog=await json('packs.json',ref)}
    if(typeof catalog.packs==='string')catalog={...catalog,packs:await json(catalog.packs,ref)};
    const entries=Array.isArray(catalog)?catalog:Array.isArray(catalog.packs)?catalog.packs:catalog.packs?.packs;
    if(!Array.isArray(entries))throw Error('catalog.json에 packs 배열이 필요합니다.');
    const results=await Promise.all(entries.slice(0,100).map(entry=>limited(async()=>{
      try{
        let file,manifest;
        if(typeof entry==='string')file=entry.endsWith('.json')?entry:entry.replace(/\/$/,'')+'/pack.json';
        else {file=entry.manifest||((entry.path||entry.folder||('packs/'+entry.id)).replace(/\/$/,'')+'/pack.json');if(Array.isArray(entry.items||entry.emoticons))manifest=entry;}
        file=repositoryPath(file);if(!file.startsWith('packs/'))throw Error('팩은 packs 폴더 아래에 두어 주세요.');
        if(!manifest){try{manifest=await json(file,ref)}catch(e){if(e.status!==404||!file.endsWith('/pack.json'))throw e;file=file.replace(/\/pack.json$/,'/packs.json');manifest=await json(file,ref)}}
        return {pack:normalizePack(manifest,file,ref)};
      }catch(e){return {warning:e.message}}
    })));
    const packs=results.filter(x=>x.pack).map(x=>x.pack),warnings=results.filter(x=>x.warning).map(x=>x.warning);
    if(!packs.length)throw Error(warnings[0]||'등록된 이모티콘 팩이 없습니다.');
    if(warnings.length&&catalogCache)throw Error('일부 팩을 읽지 못해 저장된 목록을 유지합니다. '+warnings[0]);
    return {repository:PROJECT,ref,packs,warnings};
  }
  // Catalog and image files live outside signed releases, so restart/update preserves them.
  async function readSavedCatalog(){
    if(!cacheDir)return;
    try{
      const file=path.join(cacheDir,'catalog-v1.json'),stat=await fs.lstat(file);
      if(!stat.isFile()||stat.isSymbolicLink()||stat.size>16*1024*1024)return;
      const saved=JSON.parse(await fs.readFile(file,'utf8')),value=saved.catalog;
      if(saved.version!==1||value?.repository!==PROJECT||!Number.isFinite(saved.at)||saved.at>Date.now()+60000||!/^[a-f\d]{40}$/i.test(value.ref)||!Array.isArray(value.packs)||!value.packs.length||value.packs.length>100||!Array.isArray(value.warnings))return;
      for(const pack of value.packs){
        if(typeof pack.id!=='string'||typeof pack.name!=='string'||pack.ref!==value.ref||!Array.isArray(pack.items)||pack.items.length>500)return;
        if(pack.icon&&(!repositoryPath(pack.icon).startsWith('packs/')||!IMAGE.test(pack.icon)))return;
        for(const item of pack.items)if(typeof item.id!=='string'||typeof item.label!=='string'||item.ref!==value.ref||!repositoryPath(item.path).startsWith('packs/')||!IMAGE.test(item.path))return;
      }
      catalogCache=value;catalogAt=saved.at;
    }catch{} // A damaged/unavailable cache is a miss, never a startup failure.
  }
  async function saveCatalog(value){
    if(!cacheDir)return;const file=path.join(cacheDir,'catalog-v1.json'),temp=file+'.'+crypto.randomUUID()+'.tmp';
    try{await fs.mkdir(cacheDir,{recursive:true});await fs.writeFile(temp,JSON.stringify({version:1,at:catalogAt,catalog:value}),{flag:'wx'});await fs.rename(temp,file)}catch{}finally{await fs.unlink(temp).catch(()=>{})}
  }
  function revalidate(){
    if(catalogPending)return catalogPending;
    catalogChecked=Date.now();
    catalogPending=readCatalog().then(async value=>{catalogCache=value;catalogAt=Date.now();await saveCatalog(value);return value}).finally(()=>{catalogPending=null});return catalogPending;
  }
  async function catalog(refresh=false){
    catalogDisk ||= readSavedCatalog();await catalogDisk;
    if(refresh)return revalidate();
    if(catalogCache){
      // Stale-while-revalidate: offline startup still displays the last valid catalog.
      if(Date.now()-Math.max(catalogAt,catalogChecked)>300000)void revalidate().catch(()=>{});
      return catalogCache;
    }
    return revalidate();
  }
  async function image(p,ref,refresh=false){
    p=repositoryPath(p);if(!p.startsWith('packs/')||!IMAGE.test(p)||!/^[a-f\d]{40}$/i.test(ref))throw Error('유효하지 않은 이모티콘입니다.');
    const key=ref+'/'+p;if(refresh&&assets.has(key)){cacheBytes-=assets.get(key).size;assets.delete(key)}if(assets.has(key))return assets.get(key).result;if(inflight.has(key))return inflight.get(key);
    const promise=(async()=>{let bytes=refresh?null:await cached(key);if(!bytes){await limited(async()=>{for(let attempt=0;attempt<3;attempt++){try{bytes=await raw(p,ref,MAX_IMAGE);imageType(bytes);break}catch(e){const transient=e.status===408||e.status===429||e.status>=500||e.name==='TypeError'||e.name==='TimeoutError'||e.name==='AbortError';if(!transient||attempt===2)throw e;await new Promise(r=>setTimeout(r,retryDelay*(attempt+1)))}}});await saveCache(key,bytes)}const type=imageType(bytes);const result={data:'data:'+type+';base64,'+bytes.toString('base64')};
      while(cacheBytes+bytes.length>32*1024*1024&&assets.size){const k=assets.keys().next().value;cacheBytes-=assets.get(k).size;assets.delete(k)}
      assets.set(key,{result,size:bytes.length});cacheBytes+=bytes.length;return result;
    })().finally(()=>inflight.delete(key));inflight.set(key,promise);return promise;
  }
  return {catalog,image};
}

// Mutable boot policy. Delivered inside every signed release; never install this as the fixed host.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,checkRemote,newer} from './update-store.mjs';
// Isolated retry policy; importing tests extract only these functions, never
// the installed-host entry point below. Integrity errors are not retryable.
export function temporaryPolicyReadError(error){return ['EACCES','EPERM','EBUSY'].includes(error?.code);}
export function policyReadRetryDelay(attempt){return Math.min(60000,5000*2**Math.min(Math.max(0,attempt-1),4));}
export async function waitForPolicyReadRetry(attempt,{now=()=>performance.now(),sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms)),stopped=async()=>false}={}){
 let remaining=policyReadRetryDelay(attempt),previous=now();
 while(remaining>0){
  if(await stopped())return false;
  const current=now();if(current>=previous)remaining-=current-previous;previous=current;
  if(remaining<=0)break;
  await sleep(Math.min(250,remaining));
 }
 return !await stopped();
}
// End isolated policy read retry.
const root=process.env.DOORAY_INSTALL_ROOT;
const policyVersion=path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
if(process.argv.includes('--check')){console.log(JSON.stringify({bootProtocol:1,mode:'offline-capsule-boot',mutableController:true}));process.exit(0)}
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
const openStore=()=>new UpdateStore({data,publicKey}).init();
const log=async s=>fs.appendFile(path.join(userData,'boot.log'),new Date().toISOString()+' '+s+'\n').catch(()=>{});
let child=null,closing=false;
function stop(){closing=true;try{child?.kill()}catch{}process.exit(0)}
process.on('disconnect',stop);process.on('message',m=>{if(m?.type==='shutdown')stop()});
process.on('SIGTERM',stop);process.on('SIGINT',stop);process.on('exit',()=>{try{child?.kill()}catch{}});
async function disabled(){for(const n of ['stop-agent.flag','theme-disabled.flag'])try{await fs.access(path.join(userData,n));return true}catch{}return false}
try{
 let store=await openStore();
 const envelope=JSON.parse(await fs.readFile(path.join(root,'seed/latest.json'),'utf8'));
 const seed=verifyManifest(envelope,publicKey);
 const seedBytes=await fs.readFile(path.join(root,'seed',seed.archive));
 await store.stage(envelope,seedBytes);
 if(store.state.active)await store.queue(envelope,seedBytes);
 if(store.state.trial&&store.state.trialStarted){
  let health;try{health=JSON.parse(await fs.readFile(path.join(userData,'healthy.flag'),'utf8'))}catch{}
  if(health?.version===store.state.active)await store.confirm();
  else {store.state.trialStarted=false;await store.persist();await log('Interrupted trial retained for startup verification: '+store.state.active)}
 }
 if(!store.state.active){store.state.active=seed.version;store.state.trial=false;await store.persist()}
 // A newer authenticated policy can recover even if the old updater is broken.
 // This covers both normal staged releases and manually imported signed patches.
 if(newer(policyVersion,store.state.active)&&!store.state.failed.includes(policyVersion)&&(!store.state.pending||newer(policyVersion,store.state.pending))){
  await store.validate(policyVersion);store.state.pending=policyVersion;await store.persist();
 }
 if(store.state.pending){await store.activate();if(process.env.DOORAY_POLICY_HOST==='1'&&store.state.active!==policyVersion)process.exit(75)}
 let failures=0,readFailures=0;
 while(!closing&&!await disabled()){
  store=await openStore();
  let manifest;
  try{manifest=await store.validate(store.state.active);readFailures=0}catch(e){
   if(temporaryPolicyReadError(e)){
    const attempt=++readFailures;await log('Release verification temporarily unreadable: '+e.code+'; retry in '+policyReadRetryDelay(attempt)+'ms');
    if(!await waitForPolicyReadRetry(attempt,{stopped:async()=>closing||await disabled()}))break;
    continue;
   }
   await log('Validation failed: '+e.message);if(!await store.rollback())break;continue;
  }
  const version=store.state.active;
  if(store.state.trial){store.state.trialStarted=true;await store.persist()}
  let heartbeat=Date.now();
  const runtime=manifest.files['app/runtime/node.exe']?path.join(store.dir(version),'app/runtime/node.exe'):process.execPath;
  const running=spawn(runtime,[path.join(store.dir(version),'app/update-supervisor.mjs')],{cwd:store.dir(version),windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],env:{...process.env,DOORAY_INSTALL_ROOT:root}});
  child=running;
  running.on('message',m=>{if(m?.type==='supervisor-alive'&&m.version===version)heartbeat=Date.now()});
  const watchdog=setInterval(()=>{void disabled().then(v=>{if(v)stop()})},2000);
  const code=await new Promise(r=>{running.once('error',()=>r(-1));running.once('exit',r)});
  clearInterval(watchdog);child=null;
  if(closing)break;
  store=await openStore();
  if(code===75&&store.state.active!==version){if(process.env.DOORAY_POLICY_HOST==='1')process.exit(75);failures=0;continue}
  if(code===0)break;
  // Windows closes console processes during shutdown/logoff. This is not a
  // failed release, even when the process had not yet confirmed its first run.
  if(code===null||[0x40010004,0xC000013A].includes(code>>>0)){
   await log('System termination retained release: '+version+' code='+code);break;
  }
  await log('Supervisor failed: '+version+' code='+code);
  // A previously confirmed release must not be downgraded by a later process
  // termination. Integrity failures are still handled by validate above.
  if(!store.state.trial){await log('Confirmed release retained; checking signed recovery update: '+version);try{await checkRemote(store);if(store.state.pending){await store.activate();process.exit(75)}}catch(e){await log('Recovery check deferred: '+e.message)}break;}
  if(++failures>3||!await store.rollback())break;
 }
}catch(e){await log('Boot failed: '+e.message)}

process.exit(0);

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
export async function createDownloadSettings(data,defaultFolder,{legacyFolders=[]}={}){
  const file=path.join(data,'download-settings.json');let current=defaultFolder;
  const allowed=new Set([defaultFolder,...legacyFolders].map(p=>path.resolve(p).toLowerCase()));
  try{const saved=JSON.parse(await fs.readFile(file,'utf8'));if(saved.schema===1){if(typeof saved.folder==='string'&&path.isAbsolute(saved.folder))current=path.normalize(saved.folder);for(const p of saved.folders||[])if(typeof p==='string'&&path.isAbsolute(p))allowed.add(path.resolve(p).toLowerCase());}}catch{}
  allowed.add(path.resolve(current).toLowerCase());let writes=Promise.resolve();
  const settings={get folder(){return current},defaultFolder,allowed,
    set(folder){const next=folder===null?defaultFolder:folder;if(typeof next!=='string'||!path.isAbsolute(next)||/[\r\n\x00]/.test(next))return Promise.reject(Error('올바른 절대 폴더 경로가 필요합니다.'));
      const operation=async()=>{const normalized=path.normalize(next);if(!(await fs.stat(normalized)).isDirectory())throw Error('저장 폴더를 찾을 수 없습니다.');const folders=new Set([...allowed,path.resolve(normalized).toLowerCase()]);const temp=file+'.'+crypto.randomUUID()+'.tmp';try{await fs.writeFile(temp,JSON.stringify({schema:1,folder:normalized===defaultFolder?null:normalized,folders:[...folders]}),{flag:'wx'});await fs.rename(temp,file);}catch(e){await fs.unlink(temp).catch(()=>{});throw e;}current=normalized;allowed.add(path.resolve(normalized).toLowerCase());return current;};
      const result=writes.then(operation);writes=result.catch(()=>{});return result;
    }};return settings;
}

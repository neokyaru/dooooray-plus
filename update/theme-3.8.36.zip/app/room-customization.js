// Per-account room styling and muted-room notification exceptions. No server settings are modified.
function doorayRoomStyle(value){
 const s=value&&typeof value==='object'?value:{};const color=(v,d)=>/^#[a-f\d]{6}$/i.test(v||'')?v:d;
 const result={enabled:s.enabled===true,bg:color(s.bg,'#e8f1ff'),text:color(s.text,'#172c48'),border:color(s.border,'#739bce'),width:Number.isFinite(s.width)?Math.max(0,Math.min(6,s.width)):1,borderStyle:['solid','dashed','dotted'].includes(s.borderStyle)?s.borderStyle:'solid',font:typeof s.font==='string'?s.font.slice(0,120):''};
 if(s.themes&&typeof s.themes==='object'){result.themes={};for(const mode of ['default','excel','vscode'])if(s.themes[mode]&&typeof s.themes[mode]==='object')result.themes[mode]=doorayRoomStyle({...s.themes[mode],themes:undefined});}return result;
}
function doorayRoomConfig(value){
 const s=value&&typeof value==='object'?value:{};const rooms={};
 for(const [id,room] of Object.entries(s.rooms||{}).slice(0,500)){
  if(!/^\d+$/.test(id)||!room||typeof room!=='object')continue;const people={};
  for(const [uid,p] of Object.entries(room.people||{}).slice(0,2000)){if(!/^\d+$/.test(uid)||!p||typeof p!=='object')continue;people[uid]={name:typeof p.name==='string'?p.name.slice(0,120):uid,style:doorayRoomStyle(p.style),notify:p.notify===true};}
  rooms[id]={name:typeof room.name==='string'?room.name.slice(0,120):id,localMuted:room.localMuted===true,people};
 }
 return {version:1,defaults:doorayRoomStyle(s.defaults),ownDefaults:doorayRoomStyle(s.ownDefaults),rooms};
}
function doorayRoomNoticeAllowed({log,roomEnabled,opted,selfId,now,started,main,globalEnabled}){
 const sentAt=log?.sentAt;const at=typeof sentAt==='number'?sentAt:typeof sentAt==='string'?(/^\d{13}$/.test(sentAt)?Number(sentAt):Date.parse(sentAt)):NaN;return main&&globalEnabled&&!roomEnabled&&opted&&log&&[0,2,4,5,8,9,10].includes(Number(log.type))&&String(log.senderId)!==String(selfId)&&/^\d+$/.test(String(log.senderId))&&/^\d+$/.test(String(log.channelId))&&/^\d+$/.test(String(log.id))&&Number.isFinite(at)&&at>=started-2000&&at<=now+30000&&now-at<60000;
}
// Compare server message times against the same origin's HTTP clock, anchored to monotonic time.
function doorayNoticeClock({fetcher=globalThis.fetch,wall=()=>Date.now(),mono=()=>performance.now(),url='/messenger'}={}){
 let anchor=null,pending=null,nextCheck=0;
 const current=()=>anchor?anchor.server+(mono()-anchor.mono):wall();
 async function now(){
  if(typeof fetcher!=='function')return current();
  if(!pending&&mono()>=nextCheck){pending=(async()=>{const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),5000),begin=mono();
   try{const response=await fetcher(url,{method:'HEAD',cache:'no-store',credentials:'same-origin',signal:abort.signal});const end=mono(),date=Date.parse(response.headers.get('date')||'');
    if(!response.ok||!Number.isFinite(date)||end-begin>5000)throw Error('Server clock unavailable');
    anchor={server:date+500+(end-begin)/2,mono:end};nextCheck=end+300000;
   }catch{nextCheck=mono()+30000}finally{clearTimeout(timeout)}
  })().finally(()=>{pending=null});}
  if(pending)await pending;return current();
 }
 return {now};
}
// A style element inside a tab still affects the entire settings shadow root.
// Share only layout rules here; controls inherit the settings panel's own theme.
function doorayRoomSettingsCSS(uiCSS){
 const layout='.dp-editor-actions>*{max-width:100%}.dp-person-editor,.dp-default-editor,.dp-own-editor{min-width:0;max-width:100%}.dp-editor-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:8px 0}.dp-person-editor h3,.dp-room-label{overflow-wrap:anywhere}.dp-room-label{display:block;margin:8px 0}.dp-members{margin-top:8px}.dp-member-search{margin-top:4px}'+uiCSS.slice(uiCSS.indexOf('.grid{'),uiCSS.indexOf('.primary{'))+'input[type=color]{width:52px;height:30px;padding:2px}input[type=number]{width:58px}';
 return layout.replace(/([^{}]+)\{([^{}]*)\}/g,(_,selectors,body)=>selectors.split(',').map(s=>'[data-dp-tab="bubbles"] '+s.trim()).join(',')+'{'+body+'}');
}
function doorayRoomProfile(value,theme){
 const style=doorayRoomStyle(value),mode=theme.mode||'default';
 const saved=style.themes?.[mode]||(mode==='default'&&style.enabled?style:null);
 const profile=doorayRoomStyle(saved||{...theme,enabled:false});
 if(mode==='excel'||mode==='vscode'){profile.width=1;profile.borderStyle='solid';}
 return profile;
}
function doorayRoomSaveProfile(value,theme,profile){
 const style=doorayRoomStyle(value);return {...style,themes:{...style.themes,[theme.mode||'default']:doorayRoomStyle(profile)}};
}
function doorayRoomResetProfile(value,mode){const style=doorayRoomStyle(value);if(mode==='default')style.enabled=false;if(style.themes)delete style.themes[mode];return style;}
function doorayRoomHasStyle(value){return value?.enabled||Object.values(value?.themes||{}).some(s=>s.enabled);}
function doorayMemberRows(root,getProps){
 const result=[];
 for(const row of root.querySelectorAll('div')){
  if(row.closest('.dp-member-notify')||result.some(x=>x.row.contains(row)))continue;
  const p=getProps(row,p=>p.memberId,12),uid=String(p?.memberId||'');
  if(/^\d+$/.test(uid))result.push({row,uid});
 }
 return result;
}
// Semantic markers are supplied by the shared native-DOM adapter. The bounded
// React fallback also supports startup before that adapter has marked the view.
function doorayRoomMessages(root,getProps){
 const result=new Map(),excluded='[contenteditable="true"],.js-main-editor,[role="dialog"],[aria-modal="true"],[data-dp-extension],.dt-received-emoticon';
 const validLog=p=>p?.log&&['channelId','senderId'].every(k=>/^\d+$/.test(String(p.log[k]??'')));
 const fiber=el=>el?.[Object.keys(el).find(k=>k.startsWith('__reactFiber'))];
 const direct=el=>el?.[Object.keys(el).find(k=>k.startsWith('__reactProps'))]||fiber(el)?.memoizedProps;
 const accept=(text,bubble)=>{
  if(!text||!bubble||!root.contains(bubble)||!bubble.contains(text)||text.closest(excluded)||bubble.matches('[data-logid],[class*="js-log-right-content-"],[data-dp-native~="message-content"],[data-dp-native~="message-group"]')||bubble.querySelector('textarea,[contenteditable="true"]'))return;
  const p=getProps(text,validLog);if(p)result.set(text,{text,bubble,log:p.log});
 };
 for(const text of root.querySelectorAll('[data-dp-native~="message-text"],.sc-chbbiW'))accept(text,text.closest('[data-dp-native~="message-bubble"]')||text.closest('.sc-iyvyFf'));
 for(const section of root.querySelectorAll('[class*="js-log-right-content-"],[data-logid]')){
  if(section.closest(excluded)||section.querySelector('[data-dp-native~="message-text"]'))continue;
  for(const text of section.querySelectorAll('span,div,p')){
   if(result.has(text)||text.closest(excluded))continue;
   // Stop at the first enclosing host node. A username, read count or link
   // must not inherit a message model from an unrelated ancestor component.
   let f=fiber(text),message=false,hasLog=validLog(direct(text)),bubble=null;const seen=new Set();
   for(let i=0;f&&i<45&&!seen.has(f);i++,f=f.return){
    seen.add(f);if(f.stateNode?.nodeType===1&&f.stateNode!==text){if(message)bubble=f.stateNode;break;}
    if(validLog(f.memoizedProps)){hasLog=true;if(Object.prototype.hasOwnProperty.call(f.memoizedProps,'chunks'))message=true;}
   }
   const html=direct(text)?.dangerouslySetInnerHTML;
   if(!bubble&&hasLog&&html&&Object.prototype.hasOwnProperty.call(html,'__html'))bubble=text.parentElement;
   if(bubble&&bubble!==section&&section.contains(bubble))accept(text,bubble);
  }
 }
 return [...result.values()];
}
function installDoorayRooms({themeShadow,onError=()=>{},notifyOverride,getTheme=()=>({mode:'default',bg:'#e8f1ff',text:'#172c48',border:'#739bce',width:1,borderStyle:'solid',font:''})}={}){
 const getProps=(node,predicate,limit=45)=>{const direct=node?.[Object.keys(node).find(k=>k.startsWith('__reactProps'))];if(direct&&predicate(direct))return direct;let f=node?.[Object.keys(node).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<limit;i++,f=f.return){const p=f.memoizedProps;if(p&&predicate(p))return p;}return null};
 const discover=()=>{for(const node of [document.querySelector('.js-main-editor,[data-dp-native~="editor"]'),document.querySelector('[data-dp-native~="message-text"],[class*="js-log-right-content-"],[data-logid],.sc-chbbiW'),...document.querySelectorAll('#root > *')]){const p=getProps(node,p=>p.actions?.stores,100);if(p)return p.actions;}return null};
 let actions=null,key='',config=doorayRoomConfig({}),disposed=false,socket=null,started=performance.now(),roomId='',lastRoom='',lastMembers='',timer,scheduled=false,lastList='',themeStamp='';
 const noticeClock=doorayNoticeClock();
 const changed=new Map(),changedTexts=new Map(),rows=new Map(),pendingNotices=new Set(),bellMarks=new Map();let muteDialog=null,noticeHook=null;let settingsRevision=0;
 const css=document.createElement('style');css.textContent='#root [data-dp-bubble][data-dp-bubble]{background:var(--dp-bg)!important;color:var(--dp-text)!important;border:var(--dp-width) var(--dp-border-style) var(--dp-border)!important}#root [data-dp-bubble][data-dp-bubble] :is([data-dp-native~="message-text"],[data-dp-room-text]),#root [data-dp-bubble][data-dp-bubble] :is([data-dp-native~="message-text"],[data-dp-room-text]) :not(img):not(svg){color:var(--dp-text)!important}#root [data-dp-bubble][data-dp-mode=excel]{border:0!important;box-shadow:inset 0 0 0 1px var(--dp-border)!important}#root [data-dp-font][data-dp-font][data-dp-font],#root [data-dp-font][data-dp-font][data-dp-font] :is([data-dp-native~="message-text"],[data-dp-room-text]),#root [data-dp-font][data-dp-font][data-dp-font] :is([data-dp-native~="message-text"],[data-dp-room-text]) :not(img):not(svg){font-family:var(--dp-font)!important}.dp-member-notify{position:absolute!important;right:6px!important;top:50%!important;transform:translateY(-50%);font:11px "Malgun Gothic",sans-serif!important;padding:5px 7px!important;border:1px solid var(--dt-border,#aaa)!important;border-radius:6px!important;background:var(--dt-surface,#eee)!important;color:var(--dt-text,#333)!important;cursor:pointer;z-index:1}.dp-member-notify[aria-pressed="true"]{background:#1768b5!important;color:white!important}.dp-member-notify:disabled{opacity:.5;cursor:default}';document.head.append(css);
 const uiCSS=':host{font:12px "Malgun Gothic",sans-serif;color:var(--dt-text,#24334b)}*{box-sizing:border-box}[hidden]{display:none!important}button,input,select{font:inherit}button{cursor:pointer;border:1px solid var(--dt-border,#6f839b);border-radius:6px;padding:6px 10px;background:var(--dt-surface,#fff);color:inherit}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid #448eff;outline-offset:2px}input,select{min-width:0;color:inherit;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#8c9bb0);border-radius:5px;padding:5px}input[type=color]{width:52px;height:30px;padding:2px}input[type=number]{width:58px}.grid{display:grid;grid-template-columns:minmax(0,1fr);gap:10px;padding:10px 0}.field{display:flex;align-items:center;justify-content:space-between;gap:8px;white-space:nowrap;min-width:0;max-width:100%}.field select{width:160px;max-width:65%;flex:0 1 160px;min-width:0}.wide{grid-column:1/-1}.bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.bar strong{flex:1}.note{font-size:11px;opacity:.8;line-height:1.6}.list{display:grid;gap:8px;max-height:240px;overflow:auto;margin-top:10px}.item{display:flex;align-items:center;gap:10px;border:1px solid var(--dt-border,#bbb);padding:8px;border-radius:8px}.item .who{flex:1;min-width:0;overflow-wrap:anywhere}.sample{padding:7px 12px;border-radius:7px;display:inline-block;max-width:100%;overflow-wrap:anywhere}.primary{background:#236bc1;color:#fff;border-color:#236bc1}label{cursor:pointer}';
 function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e}
 function error(e){onError(e.message||String(e));if(roomHint)roomHint.textContent=e.message||String(e)}
 function theme(uid){const t=getTheme()||{};return {...t,...(String(uid)===String(actions?.stores.userStore.id)&&t.own?{bg:t.own}:{}),mode:t.mode||'default'};}
 function room(){return actions?.stores.channelsStore.getById(roomId)}
 function baseStyle(uid){return String(uid)===String(actions?.stores.userStore.id)?config.ownDefaults:config.defaults}
 function roomEnabled(id){return actions.stores.channelsStore.isChannelNotificationOn(id)&&!config.rooms[id]?.localMuted}
 function roomName(c){return c?.title||c?.members?.map(id=>memberName(String(id))).filter(Boolean).join(', ').slice(0,120)||'현재 대화방'}
 function memberName(id){return actions?.stores.membersStore.getById(id)?.name||id}
 function save(next){try{const clean=doorayRoomConfig(next);const raw=JSON.stringify(clean);if(raw.length>2e6)throw Error('설정 저장 용량을 초과했습니다.');localStorage.setItem(key,raw);config=clean;settingsRevision++;lastList='';refreshList();applyBubbles();updateMemberButtons();return true}catch(e){error(e);return false}}
 function setPerson(cid,uid,patch){if(!key||!/^\d+$/.test(cid)||!/^\d+$/.test(uid))return false;const next=doorayRoomConfig(config);const c=actions.stores.channelsStore.getById(cid);next.rooms[cid]||={name:roomName(c),localMuted:false,people:{}};next.rooms[cid].people[uid]={name:memberName(uid),style:doorayRoomStyle({}),notify:false,...next.rooms[cid].people[uid],...patch};return save(next)}
 function applyStyle(el,s){el.style.background=s.bg;el.style.color=s.text;el.style.border=s.width+'px '+s.borderStyle+' '+s.border;el.style.fontFamily=s.font?JSON.stringify(s.font):(theme().font?JSON.stringify(theme().font):'');el.style.borderRadius=theme().mode==='excel'?'0':theme().mode==='vscode'?'2px':'7px';el.style.boxShadow=theme().mode==='vscode'?'inset 3px 0 #007acc':''}
 function editor(parent,initial,onSave,{defaults=false,own=false,onReset}={}){
  const form=node('form');form.innerHTML='<div class="grid"><label class="wide"><input name="enabled" type="checkbox"> '+(defaults?(own?'내 말풍선 꾸미기 사용':'상대방 기본 말풍선 꾸미기 사용'):'이 사용자의 말풍선 꾸미기 사용')+'</label><label class="field">배경색 <input name="bg" type="color"></label><label class="field">글자색 <input name="text" type="color"></label><label class="field">테두리 색 <input name="border" type="color"></label><label class="field">두께 <input name="width" type="number" min="0" max="6" step="0.5"></label><label class="field">테두리 <select name="borderStyle"><option value="solid">실선</option><option value="dashed">파선</option><option value="dotted">점선</option></select></label><label class="field">폰트 <select name="font"></select></label></div><div class="dp-editor-actions"><span class="sample">테스트</span><button class="primary" type="submit">저장</button></div><p class="note feedback" role="status"></p>';
  form.prepend(node('p','값을 변경하면 꾸미기가 켜지고 즉시 적용·저장됩니다.','note'));
  const fontLabel='테마 기본 ('+(theme().fontLabel||theme().font||'Dooray 기본 글꼴')+')';
  const select=form.elements.font;select.append(new Option(fontLabel,''));for(const option of themeShadow.querySelector('#font')?.options||[]){if(option.value!=='original')select.append(new Option(option.text,option.value))}if(initial.font&&![...select.options].some(o=>o.value===initial.font))select.append(new Option(initial.font,initial.font));
  for(const k of ['enabled','bg','text','border','width','borderStyle','font']){if(k==='enabled')form.elements[k].checked=initial[k];else form.elements[k].value=initial[k]}
  select.addEventListener('focus',()=>{const selected=select.value;select.replaceChildren(new Option(fontLabel,''));for(const option of themeShadow.querySelector('#font')?.options||[])if(option.value!=='original')select.append(new Option(option.text,option.value));if(selected&&![...select.options].some(o=>o.value===selected))select.append(new Option(selected,selected));select.value=selected;});
  const read=()=>doorayRoomStyle(Object.fromEntries(['enabled','bg','text','border','width','borderStyle','font'].map(k=>[k,k==='enabled'?form.elements[k].checked:k==='width'?Number(form.elements[k].value):form.elements[k].value])));
  if(theme().mode!=='default'){for(const k of ['width','borderStyle']){form.elements[k].disabled=true;form.elements[k].title=theme().mode==='excel'?'엑셀 격자선은 1px 실선으로 유지합니다.':'VS Code 카드 테두리는 1px 실선으로 유지합니다.';}form.prepend(node('p',theme().mode==='excel'?'격자선은 1px 실선으로 유지합니다. 색과 글꼴을 변경할 수 있습니다.':'코드 카드 테두리와 왼쪽 강조선은 유지합니다. 색과 글꼴을 변경할 수 있습니다.','note'));}
  if(onReset){const reset=node('button','테마 기본값으로 초기화');reset.type='button';reset.onclick=onReset;form.querySelector('.dp-editor-actions').append(reset);}
  const preview=()=>applyStyle(form.querySelector('.sample'),read());let lastApplied=JSON.stringify(read());
  const applyNow=e=>{if(e?.target?.name&&e.target.name!=='enabled')form.elements.enabled.checked=true;preview();const value=read(),signature=JSON.stringify(value);if(signature===lastApplied)return;if(onSave(value)){lastApplied=signature;form.querySelector('.feedback').textContent=value.enabled?'실시간으로 적용·저장했습니다.':'꾸미기를 해제했습니다.'}else form.querySelector('.feedback').textContent='저장하지 못했습니다.'};
  form.oninput=applyNow;form.onchange=applyNow;form.onsubmit=e=>{e.preventDefault();preview();if(onSave(read())){lastApplied=JSON.stringify(read());form.querySelector('.feedback').textContent='저장했습니다.'}else form.querySelector('.feedback').textContent='저장하지 못했습니다.'};preview();parent.append(form);return form;
 }
 function renderPersonEditor(){
  if(!personBox||!memberList)return;const uid=memberList.value,cid=roomId;personBox.replaceChildren();if(!uid)return;
  const t=theme(uid),specific=config.rooms[cid]?.people[uid]?.style,base=doorayRoomProfile(baseStyle(uid),t);
  const initial=doorayRoomProfile(specific,t);if(!specific?.themes?.[t.mode]&&!(t.mode==='default'&&specific?.enabled)&&base.enabled)Object.assign(initial,{...base,enabled:false});
  const commit=style=>{if(cid!==String(actions.stores.mainDetailUiState.currentChannelId)){error(Error('대화방이 바뀌었습니다. 현재 방의 멤버를 다시 선택해 주세요.'));return false}return setPerson(cid,uid,{style})};
  personBox.append(node('h3',memberName(uid)+'님의 말풍선'));
  editor(personBox,initial,s=>commit(doorayRoomSaveProfile(config.rooms[cid]?.people[uid]?.style,t,s)),{onReset:()=>{if(commit(doorayRoomResetProfile(config.rooms[cid]?.people[uid]?.style,t.mode)))renderPersonEditor()}});
 }
 function refreshPanel(){
  if(!memberList)return;const c=room();if(!c){roomLabel.textContent='대화방을 열어 주세요.';memberList.replaceChildren();personBox.replaceChildren();memberList.disabled=true;lastMembers='';return;}
  const members=(c.members||[]).map(x=>String(typeof x==='string'||typeof x==='number'?x:x.memberId||x.id)).filter(x=>/^\d+$/.test(x));
  const query=memberSearch.value.trim().toLowerCase(),visible=members.filter(id=>memberName(id).toLowerCase().includes(query));
  const signature=roomId+':'+members.map(id=>id+memberName(id)).join(',')+':'+query+':'+themeStamp;
  if(signature!==lastMembers){const selected=memberList.value;roomLabel.textContent=roomName(c);memberList.replaceChildren(...visible.map(id=>new Option(memberName(id),id)));memberList.disabled=!visible.length;if(visible.length)memberList.selectedIndex=0;if(roomId===lastRoom&&visible.includes(selected))memberList.value=selected;roomHint.textContent=visible.length?'선택한 사람의 설정은 이 대화방에만 적용됩니다.':'표시할 멤버가 없습니다.';lastMembers=signature;lastRoom=roomId;renderPersonEditor();}
 }
 function entries(){return Object.entries(config.rooms).flatMap(([cid,r])=>Object.entries(r.people).filter(([,p])=>doorayRoomHasStyle(p.style)||p.notify).map(([uid,p])=>({cid,uid,r,p})))}
 function fillList(target,onlyRoom){target.replaceChildren();let count=0;for(const {cid,uid,r,p}of entries()){if(onlyRoom&&cid!==roomId)continue;count++;const row=node('div',undefined,'item'),who=node('div',undefined,'who');who.append(node('strong',memberName(uid)||p.name),node('div',r.name+(p.notify?' · 알림 켜짐':''),'note'));const sample=node('span','테스트','sample');const t=theme(uid),specific=doorayRoomProfile(p.style,t),base=doorayRoomProfile(baseStyle(uid),t);applyStyle(sample,specific.enabled?specific:base.enabled?base:doorayRoomProfile({},t));const remove=node('button','해제');remove.type='button';remove.setAttribute('aria-label',p.name+' 설정 해제');remove.onclick=()=>{const next=doorayRoomConfig(config);delete next.rooms[cid].people[uid];if(!Object.keys(next.rooms[cid].people).length&&!next.rooms[cid].localMuted)delete next.rooms[cid];if(save(next)&&cid===roomId)renderPersonEditor()};row.append(who,sample,remove);target.append(row)}if(!count)target.append(node('p','저장된 사용자 설정이 없습니다.','note'));}
 function refreshList(){const sig=roomId+':'+settingsRevision;if(sig===lastList)return;lastList=sig;if(globalList)fillList(globalList,false);}
 function restore(el,record){for(const [name,[value,priority]]of record)if(value)el.style.setProperty(name,value,priority);else el.style.removeProperty(name);el.removeAttribute('data-dp-bubble');el.removeAttribute('data-dp-font');el.removeAttribute('data-dp-mode');}
 function restoreText(text,value){if(value===null)text.removeAttribute('data-dp-room-text');else text.setAttribute('data-dp-room-text',value)}
 function applyBubbles(){
  const touched=new Set(),texts=new Set(),root=document.querySelector('#root');for(const {text,bubble,log} of root?doorayRoomMessages(root,getProps):[]){const specific=config.rooms[String(log.channelId)]?.people[String(log.senderId)]?.style;const t=theme(String(log.senderId)),personal=doorayRoomProfile(specific,t),base=doorayRoomProfile(baseStyle(log.senderId),t),s=personal.enabled?personal:base.enabled?base:null;if(!s)continue;touched.add(bubble);texts.add(text);if(!changedTexts.has(text))changedTexts.set(text,text.getAttribute('data-dp-room-text'));if(!text.hasAttribute('data-dp-room-text'))text.setAttribute('data-dp-room-text','');if(!changed.has(bubble))changed.set(bubble,new Map(['--dp-bg','--dp-text','--dp-border','--dp-width','--dp-border-style','--dp-font'].map(k=>[k,[bubble.style.getPropertyValue(k),bubble.style.getPropertyPriority(k)]])));bubble.setAttribute('data-dp-bubble','');if(bubble.getAttribute('data-dp-mode')!==t.mode)bubble.setAttribute('data-dp-mode',t.mode);for(const[k,v]of Object.entries({'--dp-bg':s.bg,'--dp-text':s.text,'--dp-border':s.border,'--dp-width':s.width+'px','--dp-border-style':s.borderStyle,'--dp-font':s.font?JSON.stringify(s.font):'inherit'})){if(bubble.style.getPropertyValue(k)!==v)bubble.style.setProperty(k,v)}bubble.toggleAttribute('data-dp-font',!!s.font);}
  for(const [el,r]of changed)if(!touched.has(el)||!el.isConnected){restore(el,r);changed.delete(el)}
  for(const [text,value]of changedTexts)if(!texts.has(text)||!text.isConnected){restoreText(text,value);changedTexts.delete(text)}
 }
 function updateMemberButtons(){
  const live=new Set(),c=room();if(c&&!roomEnabled(roomId))for(const {row,uid} of [...document.querySelectorAll('.js-user-setting-member-list')].flatMap(root=>doorayMemberRows(root,getProps))){
   if(!/^\d+$/.test(uid)||!c.members?.some(x=>String(typeof x==='string'||typeof x==='number'?x:x.memberId||x.id)===uid))continue;live.add(row);
   let r=rows.get(row);if(!r){const button=node('button');button.className='dp-member-notify';button.type='button';r={button,position:row.style.position,padding:row.style.paddingRight};row.style.position='relative';row.style.paddingRight='88px';row.append(button);rows.set(row,r);button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const cid=button.dataset.room,mid=button.dataset.member;if(roomEnabled(cid))return;setPerson(cid,mid,{notify:!config.rooms[cid]?.people[mid]?.notify})});for(const name of ['mousedown','pointerdown','dblclick'])button.addEventListener(name,e=>e.stopPropagation());}
   const enabled=config.rooms[roomId]?.people[uid]?.notify===true;r.button.dataset.room=roomId;r.button.dataset.member=uid;const label=enabled?'알림 켜짐':'알림 꺼짐';if(r.button.textContent!==label)r.button.textContent=label;r.button.setAttribute('aria-pressed',String(enabled));r.button.setAttribute('aria-label',memberName(uid)+' 개별 알림 '+(enabled?'켜짐':'꺼짐'));r.button.disabled=String(actions.stores.userStore.id)===uid;r.button.title=r.button.disabled?'본인이 보낸 메시지는 알리지 않습니다.':'이 방의 전체 알림을 끈 상태에서 이 사람의 새 메시지만 알립니다.';
  }
  for(const [row,r]of rows)if(!live.has(row)||!row.isConnected){r.button.remove();row.style.position=r.position;row.style.paddingRight=r.padding;rows.delete(row)}
 }
 function claim(log){const ledgerKey=key+'.seen';let seen={};try{seen=JSON.parse(localStorage.getItem(ledgerKey)||'{}')}catch{}const id=String(log.channelId)+':'+String(log.id);if(seen[id])return false;seen[id]=Date.now();const kept=Object.fromEntries(Object.entries(seen).filter(([,at])=>Number.isFinite(at)&&Date.now()-at<86400000).slice(-500));try{localStorage.setItem(ledgerKey,JSON.stringify(kept))}catch{return false}return true}
 async function onMessage(event){try{
  const eventSocket=socket,eventKey=key,eventStarted=started;
  const raw=JSON.parse(event.data);if(!(raw.type==='channelLog'&&raw.action==='create'||raw.type==='channelLogCreate'))return;const logs=raw.content||raw.contents;
  const serverNow=await noticeClock.now();if(disposed||socket!==eventSocket||key!==eventKey)return;const serverStarted=serverNow-(performance.now()-eventStarted);
  for(const log of Array.isArray(logs)?logs:[logs]){if(!log)continue;const cid=String(log.channelId),uid=String(log.senderId),c=actions.stores.channelsStore.getById(cid);if(!c)continue;const handler=actions.websocketActions.log;
   if(!doorayRoomNoticeAllowed({log,roomEnabled:roomEnabled(cid),opted:config.rooms[cid]?.people[uid]?.notify===true,selfId:actions.stores.userStore.id,now:serverNow,started:serverStarted,main:actions.stores.uiState.isMainView===true,globalEnabled:['loud','silent'].includes(actions.stores.globalSettingStore.notification)}))continue;
   if(handler.isNotificationAvailableTime&&!handler.isNotificationAvailableTime())continue;
   const ctx={channel:c,log};const token=cid+':'+log.id;if(pendingNotices.has(token))continue;pendingNotices.add(token);
   try{if(!claim(log))continue;const person=memberName(uid),title=roomName(c)||'두레이 플러스',body=person+'님이 새 메시지를 보냈습니다.';if(notifyOverride)notifyOverride({title,body,channelId:cid});else handler.handleNotificationParams(log,title,body)}finally{pendingNotices.delete(token)}
  }
 }catch(e){console.warn('Dooray Plus individual notification:',e.message)}}

 function hookLocalMute(){
  const h=actions?.websocketActions?.log;if(noticeHook?.handler===h)return;if(noticeHook&&noticeHook.handler.showNotification===noticeHook.wrapped)noticeHook.handler.showNotification=noticeHook.original;
  if(!h||typeof h.showNotification!=='function')return;const original=h.showNotification;const wrapped=function(ctx){const id=String(ctx?.log?.channelId||ctx?.channel?.channelId||'');if(config.rooms[id]?.localMuted)return;return original.apply(this,arguments)};h.showNotification=wrapped;noticeHook={handler:h,original,wrapped};
 }
 function setLocalMute(id,value){const next=doorayRoomConfig(config);next.rooms[id]||={name:roomName(actions.stores.channelsStore.getById(id)),localMuted:false,people:{}};next.rooms[id].localMuted=value;return save(next)}
 function closeMuteDialog(){muteDialog?.remove();muteDialog=null}
 function showMuteDialog(button,cid){
  closeMuteDialog();muteDialog=node('div');muteDialog.style.cssText='position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;background:#0005';const sh=muteDialog.attachShadow({mode:'open'}),already=config.rooms[cid]?.localMuted===true;
  sh.innerHTML='<style>'+uiCSS+'.dialog{width:380px;max-width:calc(100vw - 32px);padding:20px;background:var(--dt-bg,#fff);border:1px solid var(--dt-border,#aaa);border-radius:12px;box-shadow:0 12px 40px #0006}.local{display:flex;align-items:center;gap:10px;border:3px solid #e23945;background:#e2394514;padding:14px 10px;border-radius:8px;font-weight:bold;color:var(--dt-text,#222)}.local input{width:22px;height:22px;accent-color:#d5293a;outline:2px solid #e23945;outline-offset:3px}.danger{color:#e23945;font-weight:700}.bar{justify-content:flex-end}</style><section class="dialog" role="dialog" aria-modal="true" aria-labelledby="mute-title"><h3 id="mute-title">'+(already?'이 컴퓨터의 방 알림':'대화방 알림 끄기')+'</h3><p class="room note"></p><label class="local"><input type="checkbox" id="local">이 컴퓨터에서만 알림 끄기</label><p class="note danger">체크하면 다른 컴퓨터·모바일의 알림 설정은 변경하지 않습니다.</p><p class="note explanation"></p><div class="bar"><button id="cancel" type="button">취소</button><button id="apply" class="primary" type="button">적용</button></div><p class="note status" role="status"></p></section>';
  sh.querySelector('.room').textContent=roomName(actions.stores.channelsStore.getById(cid));const checkbox=sh.querySelector('#local');checkbox.checked=already;const explain=()=>{sh.querySelector('.explanation').textContent=already?'체크를 해제하면 이 컴퓨터의 방 알림 차단을 해제합니다.':checkbox.checked?'이 PC에서만 끕니다. 멤버/설정에서 지정한 사람의 예외 알림은 유지됩니다.':'체크하지 않으면 기존 두레이 방식으로 방 알림을 끕니다. 다른 기기에도 영향을 줄 수 있습니다.'};checkbox.onchange=explain;explain();
  const cancel=()=>{closeMuteDialog();button.focus()};sh.querySelector('#cancel').onclick=cancel;sh.querySelector('#apply').onclick=async()=>{if(cid!==roomId){sh.querySelector('.status').textContent='대화방이 바뀌었습니다. 취소 후 다시 시도해 주세요.';return}try{if(already||checkbox.checked){if(!setLocalMute(cid,checkbox.checked))return;}else{await actions.channelActions.updateNotification(cid,'never');}closeMuteDialog();tick();button.focus()}catch(e){sh.querySelector('.status').textContent='알림 설정 실패: '+e.message}};
  sh.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();cancel()}if(e.key==='Tab'){const list=[...sh.querySelectorAll('input,button')],i=list.indexOf(sh.activeElement);if(e.shiftKey&&i===0){e.preventDefault();list.at(-1).focus()}else if(!e.shiftKey&&i===list.length-1){e.preventDefault();list[0].focus()}}});document.body.append(muteDialog);checkbox.focus();
 }
 function bellClick(e){const button=e.target instanceof Element?e.target.closest('button'):null;if(!button||!actions||!room())return;const p=getProps(button,p=>p.name==='notification',22);if(!p)return;if(!roomEnabled(roomId)&&!config.rooms[roomId]?.localMuted)return;e.preventDefault();e.stopImmediatePropagation();showMuteDialog(button,roomId)}
 document.addEventListener('click',bellClick,true);
 function markBells(){const live=new Set();for(const button of document.querySelectorAll('#root button')){const p=getProps(button,p=>p.name==='notification',22);if(!p)continue;live.add(button);if(config.rooms[roomId]?.localMuted){if(!bellMarks.has(button))bellMarks.set(button,{outline:button.style.outline,title:button.getAttribute('title')});button.style.outline='2px solid #e23945';button.title='이 컴퓨터에서만 알림 꺼짐 · 클릭해서 변경';}else if(bellMarks.has(button)){const old=bellMarks.get(button);button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;bellMarks.delete(button)}}for(const [button,old]of bellMarks)if(!live.has(button)){button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;bellMarks.delete(button)}}

 function attachSocket(){const next=actions?.websocketActions.ws?.socket;if(socket===next)return;socket?.removeEventListener('message',onMessage);socket=next;if(socket){started=performance.now();void noticeClock.now();socket.addEventListener('message',onMessage)}}
 const tabRoot=themeShadow.querySelector('[data-dp-tab="bubbles"]');let globalList=null,defaultBox=null,ownBox=null,memberList=null,personBox=null,memberSearch=null,roomLabel=null,roomHint=null;
 if(tabRoot){tabRoot.innerHTML='<h3>현재 대화방 · 사용자별 설정</h3><strong class="dp-room-label"></strong><label class="wide">멤버 검색 <input name="memberSearch" class="dp-member-search" type="text" placeholder="이름 검색"></label><select name="memberList" class="dp-members" size="5" aria-label="말풍선을 꾸밀 대화방 멤버"></select><p class="note dp-room-hint"></p><div class="dp-person-editor"></div><details><summary>전체 대화방 · 상대방 기본 말풍선</summary><h3>상대방 기본 말풍선</h3><p class="note">모든 방의 상대방 메시지에만 적용합니다. 내 말풍선은 변경하지 않습니다. 방별 사용자 설정이 우선합니다.</p><div class="dp-default-editor"></div></details><details><summary>전체 대화방 · 내 말풍선</summary><p class="note">내가 보낸 메시지에만 적용합니다. 방별로 나를 선택해 저장한 설정이 있으면 그 설정이 우선합니다.</p><div class="dp-own-editor"></div></details><h3>저장된 사용자 설정</h3><p class="note">이름 · 테스트 말풍선 · 대화방별 설정</p><div class="dp-all-settings list"></div>';const style=node('style');style.textContent=doorayRoomSettingsCSS(uiCSS);tabRoot.prepend(style);globalList=tabRoot.querySelector('.dp-all-settings');defaultBox=tabRoot.querySelector('.dp-default-editor');ownBox=tabRoot.querySelector('.dp-own-editor');memberList=tabRoot.querySelector('.dp-members');personBox=tabRoot.querySelector('.dp-person-editor');memberSearch=tabRoot.querySelector('.dp-member-search');roomLabel=tabRoot.querySelector('.dp-room-label');roomHint=tabRoot.querySelector('.dp-room-hint');memberList.onchange=renderPersonEditor;memberSearch.oninput=()=>{lastMembers='';refreshPanel()};}
 function renderDefaults(){
  for(const [scope,box,own]of [['defaults',defaultBox,false],['ownDefaults',ownBox,true]]){
   if(!box)continue;box.replaceChildren();const t=theme(own?actions?.stores.userStore.id:undefined);
   editor(box,doorayRoomProfile(config[scope],t),s=>{const ok=save({...config,[scope]:doorayRoomSaveProfile(config[scope],t,s)});if(ok)renderPersonEditor();return ok},{defaults:true,own,onReset:()=>{if(save({...config,[scope]:doorayRoomResetProfile(config[scope],t.mode)})){renderDefaults();renderPersonEditor()}}});
  }
 }

 function tick(){if(disposed)return;try{actions=discover()||actions;if(!actions)return;const user=String(actions.stores.userStore.id||'');if(!/^\d+$/.test(user))return;const nextKey='dooray-plus.rooms.v1.'+user;if(key!==nextKey){socket?.removeEventListener('message',onMessage);socket=null;key=nextKey;try{config=doorayRoomConfig(JSON.parse(localStorage.getItem(key)||'{}'))}catch{config=doorayRoomConfig({})}settingsRevision++;renderDefaults();lastList='';lastMembers='';}const nextRoom=String(actions.stores.mainDetailUiState.currentChannelId||'');if(nextRoom!==roomId&&memberSearch)memberSearch.value='';roomId=nextRoom;const stamp=JSON.stringify(theme());if(stamp!==themeStamp){themeStamp=stamp;lastMembers='';lastList='';renderDefaults();}hookLocalMute();attachSocket();applyBubbles();updateMemberButtons();markBells();refreshPanel();refreshList();}catch(e){console.warn('Dooray Plus room UI:',e.message)}}
 const storage=e=>{if(e.key!==key)return;try{config=doorayRoomConfig(JSON.parse(e.newValue||'{}'));settingsRevision++;lastMembers='';renderDefaults();tick()}catch{}};window.addEventListener('storage',storage);
 const observer=new MutationObserver(()=>{if(!scheduled){scheduled=true;setTimeout(()=>{scheduled=false;tick()},160)}});observer.observe(document.querySelector('#root')||document.body,{subtree:true,childList:true});timer=setInterval(tick,1500);tick();
 return {open(){tick();refreshPanel()},refresh(){tick()},dispose(){disposed=true;clearInterval(timer);observer.disconnect();socket?.removeEventListener('message',onMessage);window.removeEventListener('storage',storage);document.removeEventListener('click',bellClick,true);closeMuteDialog();if(noticeHook&&noticeHook.handler.showNotification===noticeHook.wrapped)noticeHook.handler.showNotification=noticeHook.original;for(const [button,old]of bellMarks){button.style.outline=old.outline;if(old.title===null)button.removeAttribute('title');else button.title=old.title;}for(const [el,r]of changed)restore(el,r);for(const [text,value]of changedTexts)restoreText(text,value);for(const [row,r]of rows){r.button.remove();row.style.position=r.position;row.style.paddingRight=r.padding}css.remove()},diagnostics(){return {roomReady:!!room(),styled:changed.size,memberButtons:rows.size,socketConnected:socket?.readyState===1,configured:entries().length}}};
}
function installDooraySettingsTabs(shadow){
 const scroll=shadow.querySelector('.scroll'),items=[...scroll.children],nav=document.createElement('div');nav.className='dp-tabs';nav.setAttribute('role','tablist');nav.setAttribute('aria-label','설정 분류');const style=document.createElement('style');style.textContent='.dp-tabs{display:flex;gap:4px;padding:10px 12px;border-bottom:1px solid #465269;flex-wrap:wrap}.dp-tabs button{flex:1;padding:7px 8px;font-size:12px}.dp-tabs [aria-selected="true"]{background:#3268b9;color:white}.dp-tab{padding-top:8px}.dp-tab h3{font-size:13px;margin:10px 0}.dp-tab[hidden]{display:none!important}';shadow.append(style);scroll.before(nav);const sections={};
 for(const[id,label]of [['basic','기본'],['detail','디테일'],['bubbles','말풍선'],['downloads','다운로드'],['manage','관리']]){const section=document.createElement('section');section.className='dp-tab';section.dataset.dpTab=id;section.id='dp-tab-'+id;section.setAttribute('role','tabpanel');section.hidden=id!=='basic';sections[id]=section;scroll.append(section);const button=document.createElement('button');button.type='button';button.textContent=label;button.id='dp-tab-button-'+id;button.setAttribute('role','tab');button.setAttribute('aria-controls',section.id);section.setAttribute('aria-labelledby',button.id);button.setAttribute('aria-selected',String(id==='basic'));button.tabIndex=id==='basic'?0:-1;button.onclick=()=>{for(const child of nav.children){child.setAttribute('aria-selected',String(child===button));child.tabIndex=child===button?0:-1}for(const[key,p]of Object.entries(sections))p.hidden=key!==id;scroll.scrollTop=0};nav.append(button);}
 nav.addEventListener('keydown',e=>{const buttons=[...nav.children];const index=buttons.indexOf(document.activeElement===shadow.host?shadow.activeElement:document.activeElement);if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const n=e.key==='Home'?0:e.key==='End'?buttons.length-1:(index+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[n].click();buttons[n].focus()});
 for(const el of items){let id='basic';if(el.classList.contains('mode')||el.id==='advanced')id='detail';else if(el.querySelector('#toastSeconds'))id='downloads';else if(el.querySelector('#export,#repairEmoticons,#checkUpdate')||el.textContent.includes('모든 문제에 대한 책임'))id='manage';sections[id].append(el);}return sections;
}

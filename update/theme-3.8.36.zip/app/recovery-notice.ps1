﻿# Windows PowerShell 5.1. This UI is started only by a verified per-user release.
# No request field can select an executable, URL, action, or filesystem target.
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

function Assert-RecoveryNoticePath([string]$Path, [bool]$RequireFile) {
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path.IndexOfAny([IO.Path]::GetInvalidPathChars()) -ge 0) { throw 'invalid-path' }
    $full = [IO.Path]::GetFullPath($Path)
    if (-not [string]::Equals($full, $Path, [StringComparison]::OrdinalIgnoreCase) -or $full -notmatch '^[A-Za-z]:\\') { throw 'invalid-path' }
    $cursor = $full
    while ($cursor) {
        if (-not [IO.File]::Exists($cursor) -and -not [IO.Directory]::Exists($cursor)) { throw 'missing-path' }
        $attributes = [IO.File]::GetAttributes($cursor)
        if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'reparse-path' }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ([string]::Equals($parent, $cursor, [StringComparison]::OrdinalIgnoreCase)) { break }
        $cursor = $parent
    }
    if ($RequireFile -and (([IO.File]::GetAttributes($full) -band [IO.FileAttributes]::Directory) -ne 0)) { throw 'not-file' }
    return $full
}

function Get-ValidatedRecoveryNotice([string]$RequestPath, [string]$LocalData, [string]$CurrentSid, [bool]$Elevated, [long]$Now, [int]$CurrentSession) {
    if ($Elevated -or $CurrentSid -notmatch '^S-1-[0-9]+(?:-[0-9]+)+$' -or $CurrentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) { throw 'invalid-user-token' }
    $data = [IO.Path]::Combine([IO.Path]::GetFullPath($LocalData), 'DoorayTheme')
    $folder = [IO.Path]::Combine($data, 'recovery-notices')
    $path = Assert-RecoveryNoticePath $RequestPath $true
    if (-not [string]::Equals([IO.Path]::GetDirectoryName($path), $folder, [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-request-folder' }
    $name = [IO.Path]::GetFileName($path)
    if ($name -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\.json$') { throw 'invalid-request-name' }
    $token = [IO.Path]::GetFileNameWithoutExtension($path)
    $stream = $null
    $reader = $null
    try {
        $stream = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        if ($stream.Length -lt 2 -or $stream.Length -gt 65536) { throw 'invalid-request-size' }
        $reader = New-Object IO.StreamReader($stream, (New-Object Text.UTF8Encoding($false, $true)), $true)
        $request = $reader.ReadToEnd() | ConvertFrom-Json
    } finally {
        if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() }
    }
    if ($request -isnot [Management.Automation.PSCustomObject]) { throw 'invalid-schema' }
    $allowed = @('schema','version','reason','kind','available','pending','installerVersion','at','token','jobToken','session','userSid','windowsSession')
    foreach ($property in $request.PSObject.Properties.Name) { if ($property -notin $allowed) { throw 'unknown-field' } }
    foreach ($required in $allowed) {
        if ($required -notin $request.PSObject.Properties.Name) { throw 'missing-field' }
    }
    if ($request.schema -isnot [int] -or $request.schema -ne 2) { throw 'invalid-schema' }
    foreach ($field in @('version','available','pending','installerVersion')) {
        $value = $request.$field
        if ($field -ne 'version' -and $null -eq $value) { continue }
        if ($value -isnot [string] -or $value -notmatch '^(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})$') { throw 'invalid-version' }
    }
    if ($request.reason -isnot [string] -or $request.reason -cnotin @('load-timeout','connection-unavailable','engine-error')) { throw 'invalid-reason' }
    if ($request.kind -isnot [string] -or $request.kind -cnotin @('patch','installer','unknown')) { throw 'invalid-kind' }
    if ($request.token -isnot [string] -or -not [string]::Equals($request.token, $token, [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid-token' }
    if ($request.userSid -isnot [string] -or $request.userSid -cne $CurrentSid) { throw 'wrong-user' }
    if ($CurrentSession -le 0 -or $request.windowsSession -isnot [int] -or $request.windowsSession -ne $CurrentSession) { throw 'wrong-session' }
    foreach($field in @('jobToken','session')) { if($request.$field -isnot [string] -or $request.$field -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') { throw 'invalid-token' } }
    if($request.installerVersion -and ([version]$request.installerVersion -lt [version]$request.version)) { throw 'older-installer' }
    if (($request.at -isnot [long] -and $request.at -isnot [int]) -or $request.at -le 0 -or $request.at -lt ($Now - 900000) -or $request.at -gt ($Now + 30000)) { throw 'expired-request' }
    return [pscustomobject]@{ Request=$request; Path=$path; Data=$data; Receipt=[IO.Path]::Combine($folder, $token+'.result.json') }
}

function Write-RecoveryNoticeReceipt($Notice, [string]$Status, [string]$Reason='') {
    if ($Status -cnotin @('accepted','balloon-shown','clicked','closed','failed')) { throw 'invalid-status' }
    if ($Reason -and $Reason -cne 'ui-unavailable') { throw 'invalid-status-reason' }
    $null = Assert-RecoveryNoticePath ([IO.Path]::GetDirectoryName($Notice.Receipt)) $false
    if ([IO.File]::Exists($Notice.Receipt) -or [IO.Directory]::Exists($Notice.Receipt)) { $null = Assert-RecoveryNoticePath $Notice.Receipt $true }
    $record = [ordered]@{schema=2; version=$Notice.Request.version; token=$Notice.Request.token; jobToken=$Notice.Request.jobToken; session=$Notice.Request.session; userSid=$Notice.Request.userSid; windowsSession=$Notice.Request.windowsSession; at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds(); status=$Status}
    if ($Reason) { $record.reason=$Reason }
    $temporary = $Notice.Receipt+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    $stream = $null
    try {
        $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes(($record | ConvertTo-Json -Compress))
        $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $stream.Write($bytes,0,$bytes.Length); $stream.Dispose(); $stream=$null
        if ([IO.File]::Exists($Notice.Receipt)) { [IO.File]::Replace($temporary, $Notice.Receipt, [Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temporary, $Notice.Receipt) }
    } finally {
        if ($stream) { $stream.Dispose() }
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}

function Get-RecoveryNoticeText([string]$Kind) {
    if ($Kind -cnotin @('patch','installer','unknown')) { throw 'invalid-kind' }
    return '두레이 플러스 실행이 안됐습니다. 복구 안내를 확인해 주세요.'
}

function Get-RecoveryDownloadUrl($Version) {
    if($null -eq $Version) { return 'https://github.com/neokyaru/dooooray-plus/tree/main/update/v2' }
    if($Version -isnot [string] -or $Version -notmatch '^(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})$') { throw 'invalid-installer-version' }
    return 'https://raw.githubusercontent.com/neokyaru/dooooray-plus/main/update/v2/DoorayPlus-'+$Version+'-Setup.exe'
}

function New-RecoveryNoticeLaunch([string]$Action, [string]$Data, $InstallerVersion=$null) {
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.UseShellExecute = $true
    switch -CaseSensitive ($Action) {
        'page' { $start.FileName=Get-RecoveryDownloadUrl $InstallerVersion }
        'logs' {
            $null = Assert-RecoveryNoticePath $Data $false
            if (-not [IO.Directory]::Exists($Data)) { throw 'not-directory' }
            $start.FileName = [IO.Path]::Combine([Environment]::GetFolderPath('Windows'),'explorer.exe')
            $start.Arguments = '"'+$Data+'"'
        }
        default { throw 'invalid-action' }
    }
    return $start
}

function Write-RecoveryNoticeAction($Notice, [long]$Now) {
    if($Now -lt $Notice.Request.at -or $Now -gt ($Notice.Request.at+900000)) { throw 'expired-request' }
    $directory=[IO.Path]::GetDirectoryName($Notice.Path)
    $null=Assert-RecoveryNoticePath $directory $false
    $file=[IO.Path]::Combine($directory,$Notice.Request.token+'.action.json')
    if([IO.File]::Exists($file) -or [IO.Directory]::Exists($file)) { throw 'action-already-requested' }
    $value=[ordered]@{schema=2;token=$Notice.Request.token;jobToken=$Notice.Request.jobToken;session=$Notice.Request.session;userSid=$Notice.Request.userSid;windowsSession=$Notice.Request.windowsSession;action='restart';at=$Now}
    $temporary=$file+'.'+[Guid]::NewGuid().ToString('N')+'.tmp';$stream=$null
    try {
        $bytes=(New-Object Text.UTF8Encoding($false)).GetBytes(($value|ConvertTo-Json -Compress))
        $stream=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $stream.Write($bytes,0,$bytes.Length);$stream.Dispose();$stream=$null
        $null=Assert-RecoveryNoticePath $directory $false
        [IO.File]::Move($temporary,$file)
    } finally {if($stream){$stream.Dispose()};if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
}

function Read-RecoveryNoticeProgress($Notice, [long]$Now) {
    $file=[IO.Path]::Combine([IO.Path]::GetDirectoryName($Notice.Path),$Notice.Request.token+'.progress.json')
    if(-not [IO.File]::Exists($file)){return $null}
    $null=Assert-RecoveryNoticePath $file $true
    $stream=$null;$reader=$null
    try{
        $stream=[IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        if($stream.Length -gt 8192){throw 'progress-size'}
        $reader=New-Object IO.StreamReader($stream,(New-Object Text.UTF8Encoding($false,$true)),$true)
        $value=$reader.ReadToEnd()|ConvertFrom-Json
    }finally{if($reader){$reader.Dispose()}elseif($stream){$stream.Dispose()}}
    $fields=@('schema','token','jobToken','session','userSid','windowsSession','version','phase','code','at')
    if($value -isnot [Management.Automation.PSCustomObject] -or $value.PSObject.Properties.Name.Count -ne $fields.Count){throw 'progress-schema'}
    foreach($name in $value.PSObject.Properties.Name){if($name -cnotin $fields){throw 'progress-schema'}}
    if($value.schema -isnot [int] -or $value.schema -ne 2){throw 'progress-schema'}
    foreach($name in @('token','jobToken','session','userSid','version')){if($value.$name -isnot [string] -or $value.$name -cne $Notice.Request.$name){throw 'progress-identity'}}
    if($value.windowsSession -isnot [int] -or $value.windowsSession -ne $Notice.Request.windowsSession){throw 'progress-session'}
    if(($value.at -isnot [long] -and $value.at -isnot [int]) -or $value.at -lt $Notice.Request.at -or $value.at -gt ($Now+30000) -or $Now-$value.at -gt 900000){throw 'progress-expired'}
    if($value.phase -cnotin @('checking','stopping','starting','restarting','complete','error')){throw 'progress-phase'}
    if($value.code -cnotin @('checking','stopping','starting','restarting','recovered','already-ready','busy','disabled','expired','identity-unavailable','close-timeout','reopen-timeout','plus-not-ready','helper-stalled','recovery-failed')){throw 'progress-code'}
    return $value
}

function Get-RecoveryProgressText([string]$Code) {
    switch -CaseSensitive ($Code) {
        'checking' {return '복구 가능 여부를 확인하고 있습니다.'}
        'stopping' {return '플러스 연결 도우미를 정리하고 있습니다.'}
        'starting' {return '두레이 플러스의 실제 적용 상태를 확인하고 있습니다.'}
        'restarting' {return '두레이를 정상 종료하고 다시 실행하고 있습니다.'}
        'recovered' {return '두레이 플러스가 다시 실행되어 정상 적용됐습니다.'}
        'already-ready' {return '두레이 플러스가 이미 정상 적용되어 있습니다.'}
        'busy' {return '업데이트 또는 다른 복구가 진행 중입니다. 완료 후 다시 시도해 주세요.'}
        'disabled' {return '직접 중지한 상태입니다. 중지 설정은 변경하지 않았습니다.'}
        'expired' {return '복구 요청이 만료되었습니다. 새 안내에서 다시 시도해 주세요.'}
        'identity-unavailable' {return '두레이 실행 경로·사용자 정보를 확인하지 못해 종료하지 않았습니다.'}
        'close-timeout' {return '두레이가 종료되지 않았습니다. 확인 창을 처리해 주세요. 강제 종료하지 않았습니다.'}
        'reopen-timeout' {return '두레이 창의 재실행을 확인하지 못했습니다. 로그를 확인해 주세요.'}
        'plus-not-ready' {return '두레이 창은 실행됐지만 플러스 적용을 확인하지 못했습니다. 최신 설치 파일로 복구해 주세요.'}
        'helper-stalled' {return '이전 도우미의 종료를 확인하지 못했습니다. 중복 실행하지 않았습니다.'}
        default {return '복구를 완료하지 못했습니다. 설치 파일 또는 로그 폴더를 확인해 주세요.'}
    }
}

function Show-RecoveryNoticeDetails([bool]$UserAction=$true) {
    $state=$script:RecoveryNoticeUI
    if($state.Form -and -not $state.Form.IsDisposed){return}
    $state.Clicked=$true
    if($UserAction){try{Write-RecoveryNoticeReceipt $state.Notice 'clicked'}catch{}}
    $form=New-Object DoorayRecoveryNoticeForm;$state.Form=$form
    $form.Text='두레이 플러스 복구';$form.StartPosition='CenterScreen';$form.ClientSize=New-Object Drawing.Size(530,350)
    $form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false;$form.MinimizeBox=$true;$form.Font=New-Object Drawing.Font('Malgun Gothic',9)
    $label=New-Object Windows.Forms.Label;$label.Location=New-Object Drawing.Point(20,18);$label.Size=New-Object Drawing.Size(490,82)
    $label.Text="두레이 플러스 실행이 안됐습니다`r`n현재 버전: "+$state.Notice.Request.version
    if($state.Notice.Request.installerVersion){$label.Text+="`r`n확인된 최신 설치 파일: "+$state.Notice.Request.installerVersion}
    else{$label.Text+="`r`n최신 설치 파일 버전은 확인하지 못했습니다. 배포 페이지를 확인해 주세요."}
    $form.Controls.Add($label)
    $page=New-Object Windows.Forms.Button;$page.Location=New-Object Drawing.Point(20,105);$page.Size=New-Object Drawing.Size(240,32)
    $page.Text=if($state.Notice.Request.installerVersion){'최신 설치 파일 다운로드'}else{'배포 페이지 열기'}
    $page.Add_Click({try{$n=$script:RecoveryNoticeUI.Notice;$null=[Diagnostics.Process]::Start((New-RecoveryNoticeLaunch 'page' $n.Data $n.Request.installerVersion))}catch{$script:RecoveryNoticeUI.Status.Text='설치 파일 안내를 열지 못했습니다.'}})
    $logs=New-Object Windows.Forms.Button;$logs.Text='로그 폴더 열기';$logs.Location=New-Object Drawing.Point(270,105);$logs.Size=New-Object Drawing.Size(240,32)
    $logs.Add_Click({try{$null=[Diagnostics.Process]::Start((New-RecoveryNoticeLaunch 'logs' $script:RecoveryNoticeUI.Notice.Data))}catch{$script:RecoveryNoticeUI.Status.Text='로그 폴더를 열지 못했습니다.'}})
    $warning=New-Object Windows.Forms.Label;$warning.Location=New-Object Drawing.Point(20,154);$warning.Size=New-Object Drawing.Size(490,36)
    $warning.Text='재실행 시 두레이 창이 닫힐 수 있습니다. 작성 중인 내용을 먼저 저장해 주세요.';$form.Controls.Add($warning)
    $confirm=New-Object Windows.Forms.CheckBox;$confirm.Location=New-Object Drawing.Point(20,195);$confirm.Size=New-Object Drawing.Size(490,25)
    $confirm.Text='작성 중인 내용을 저장했으며 종료·재실행에 동의합니다.';$state.Confirm=$confirm
    $restart=New-Object Windows.Forms.Button;$restart.Text='두레이와 플러스 재실행';$restart.Location=New-Object Drawing.Point(20,228);$restart.Size=New-Object Drawing.Size(270,34);$restart.Enabled=$false;$state.Restart=$restart
    $confirm.Add_CheckedChanged({$s=$script:RecoveryNoticeUI;$s.Restart.Enabled=$s.Confirm.Checked -and -not $s.Processing})
    $restart.Add_Click({$s=$script:RecoveryNoticeUI;if(-not $s.Confirm.Checked -or $s.Processing){return};try{Write-RecoveryNoticeAction $s.Notice ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds());$s.Processing=$true;$s.ProcessingAt=$s.Clock.ElapsedMilliseconds;$s.Restart.Enabled=$false;$s.Confirm.Enabled=$false;$s.Status.Text='복구 요청을 전달했습니다.'}catch{$s.Status.Text='복구 요청이 만료됐거나 전달되지 않았습니다. 새 안내에서 다시 시도해 주세요.'}})
    $status=New-Object Windows.Forms.Label;$status.Location=New-Object Drawing.Point(20,276);$status.Size=New-Object Drawing.Size(490,50);$form.Controls.Add($status);$state.Status=$status
    $close=New-Object Windows.Forms.Button;$close.Text='닫기';$close.Location=New-Object Drawing.Point(395,228);$close.Size=New-Object Drawing.Size(115,34);$close.Add_Click({$script:RecoveryNoticeUI.Form.Close()})
    $form.Controls.AddRange(@($page,$logs,$confirm,$restart,$close));$form.CancelButton=$close;$form.Add_FormClosed({$script:RecoveryNoticeUI.Context.ExitThread()});$form.Show()
}

function Invoke-DoorayPlusRecoveryNotice {
    $notice=$null; $context=$null; $icon=$null; $timer=$null; $script:RecoveryNoticeUI=$null
    try {
        $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
        try {
            $principal=New-Object Security.Principal.WindowsPrincipal($identity)
            $notice=Get-ValidatedRecoveryNotice $env:DOORAY_PLUS_NOTICE_FILE ([Environment]::GetFolderPath('LocalApplicationData')) $identity.User.Value ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) ([Diagnostics.Process]::GetCurrentProcess().SessionId)
        } finally { $identity.Dispose() }
    } catch { [Console]::Error.WriteLine('Recovery notice request rejected.'); return 2 }
    try {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition 'public sealed class DoorayRecoveryNoticeForm : System.Windows.Forms.Form { protected override bool ShowWithoutActivation { get { return true; } } }'
        [Windows.Forms.Application]::EnableVisualStyles()
        $context=New-Object Windows.Forms.ApplicationContext
        $icon=New-Object Windows.Forms.NotifyIcon
        $timer=New-Object Windows.Forms.Timer
        $script:RecoveryNoticeUI=[pscustomobject]@{Notice=$notice; Context=$context; Icon=$icon; Timer=$timer; Form=$null; Status=$null; Confirm=$null; Restart=$null; Processing=$false; ProcessingAt=0; FinishedAt=-1; Clicked=$false; Clock=[Diagnostics.Stopwatch]::StartNew()}
        $icon.Icon=[Drawing.SystemIcons]::Warning
        $icon.Text='두레이 플러스 복구 안내'
        $icon.BalloonTipTitle='두레이 플러스 실행이 안됐습니다'
        $icon.BalloonTipText=Get-RecoveryNoticeText $notice.Request.kind
        $icon.BalloonTipIcon='Warning'
        $icon.Add_BalloonTipShown({try { Write-RecoveryNoticeReceipt $script:RecoveryNoticeUI.Notice 'balloon-shown' } catch {}})
        $icon.Add_BalloonTipClicked({try { Show-RecoveryNoticeDetails } catch { $script:RecoveryNoticeUI.Context.ExitThread() }})
        $icon.Add_DoubleClick({try { Show-RecoveryNoticeDetails } catch { $script:RecoveryNoticeUI.Context.ExitThread() }})
        $timer.Interval=1000
        $timer.Add_Tick({
            $state=$script:RecoveryNoticeUI;$elapsed=$state.Clock.ElapsedMilliseconds
            if($state.Processing){
                try{$progress=Read-RecoveryNoticeProgress $state.Notice ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds());if($progress){$state.Status.Text=Get-RecoveryProgressText $progress.code;if($progress.phase -in @('complete','error')){$state.Processing=$false;$state.FinishedAt=$elapsed}}}catch{}
                if($state.Processing -and $elapsed-$state.ProcessingAt -ge 240000){$state.Status.Text='복구 결과를 확인하지 못했습니다. 설치 파일 또는 로그 폴더를 확인해 주세요.';$state.Processing=$false;$state.FinishedAt=$elapsed}
            }
            $limit=if($state.Processing){$state.ProcessingAt+240000}elseif($state.FinishedAt -ge 0){$state.FinishedAt+15000}elseif($state.Clicked){300000}else{75000}
            if($elapsed -ge $limit){$state.Context.ExitThread()}
        })
        $icon.Visible=$true
        $icon.ShowBalloonTip(12000)
        # Show the requested recovery controls even when Windows suppresses the
        # balloon. This bounded nonmodal form does not activate or stay topmost.
        Show-RecoveryNoticeDetails $false
        # This is a delivery request acknowledgment, not proof the user saw it.
        Write-RecoveryNoticeReceipt $notice 'accepted'
        $timer.Start()
        [Windows.Forms.Application]::Run($context)
        try { Write-RecoveryNoticeReceipt $notice 'closed' } catch {}
        return 0
    } catch {
        try { Write-RecoveryNoticeReceipt $notice 'failed' 'ui-unavailable' } catch {}
        [Console]::Error.WriteLine('Recovery notice UI unavailable.')
        return 3
    } finally {
        $state=$script:RecoveryNoticeUI
        if($state){
            try {if($state.Form){$state.Form.Dispose()}}catch{}
            $script:RecoveryNoticeUI=$null
        }
        try {if($timer){$timer.Stop();$timer.Dispose()}}catch{}
        try {if($icon){$icon.Visible=$false;$icon.Dispose()}}catch{}
        try {if($context){$context.Dispose()}}catch{}
    }
}

# Runtime entry. Tests load function definitions only and never invoke this UI.
exit (Invoke-DoorayPlusRecoveryNotice)

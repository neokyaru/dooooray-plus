import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';
import {fetchLimited,hash,validVersion,newer,atomicJSON,updateURL} from './update-store.mjs';
import {resolveInstallPaths} from './update-handoff.mjs';
export function verifyInstaller(envelope,key){
 const m=envelope?.manifest;
 if(!m||!crypto.verify(null,Buffer.from(JSON.stringify(m)),key,Buffer.from(envelope.signature||'','base64')))throw Error('Installer signature invalid');
 if(m.schema!==1||!validVersion(m.version)||m.file!=='DoorayPlus-'+m.version+'-Setup.exe'||!Number.isSafeInteger(m.size)||m.size<1||m.size>128*1024*1024||!/^[a-f0-9]{64}$/.test(m.sha256)||typeof m.required!=='boolean')throw Error('Invalid installer metadata');
 if(Object.hasOwn(m,'installLayout')&&m.installLayout!=='independent-user-v1')throw Error('Invalid installer layout metadata');
 if(!m.hostFiles||Object.keys(m.hostFiles).sort().join(',')!=='boot-store.mjs,launcher.mjs,update-public.pem'||Object.values(m.hostFiles).some(v=>!/^[a-f0-9]{64}$/.test(v)))throw Error('Invalid installer host contract');return m;
}
export async function installerStatus(root,key,active,fetcher=fetch,pathOptions){
 let e;try{e=JSON.parse((await fetchLimited(updateURL('installer.json'),256*1024,fetcher)).toString())}catch(e){if(e.message==='GitHub update HTTP 404')return null;throw e}
 const m=verifyInstaller(e,key);if(active&&newer(active,m.version))return null;
 const layoutChanged=m.installLayout==='independent-user-v1'&&(await resolveInstallPaths(root,pathOptions)).layout!==m.installLayout;
 let changed=false;for(const [file,digest]of Object.entries(m.hostFiles)){if(await fs.readFile(path.join(root,'app',file)).then(b=>hash(b)!==digest,()=>true))changed=true;}
 return {manifest:m,envelope:e,needed:changed||layoutChanged||(m.required&&(!active||newer(m.version,active)))};
}
export async function downloadInstaller(info,key,dir,fetcher=fetch){
 const m=verifyInstaller(info.envelope,key);const bytes=await fetchLimited(updateURL(m.file),128*1024*1024,fetcher,{timeoutMs:600000});
 if(bytes.length!==m.size||hash(bytes)!==m.sha256)throw Error('Installer verification failed');
 await fs.mkdir(dir,{recursive:true});const file=path.join(dir,m.file);await fs.writeFile(file,bytes);await atomicJSON(path.join(dir,'installer.json'),info.envelope);return {file,sha256:m.sha256};
}

// Signed updater-owned Windows notices. No browser/Dooray process is needed.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {validVersion,newer} from './update-store.mjs';
import {verifyNoticeDirectory,verifyNoticeFile} from './recovery-notice.mjs';

const ownDirectory=path.dirname(fileURLToPath(import.meta.url));
const guid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const positive=value=>Number.isSafeInteger(value)&&value>0;
const phaseSet=new Set(['checking','downloading','confirming','restarting','complete','error']);
const codes=new Set(['window-required','downloads-active','update-changed','busy','check-failed','helper-failed','updated','cancelled','action-expired']);
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export const UPDATE_NOTICE_COMMAND="$ErrorActionPreference='Stop'; & ([ScriptBlock]::Create([IO.File]::ReadAllText($env:DOORAY_PLUS_UPDATE_NOTICE_SCRIPT)))";
export function backgroundUpdateCandidate(result,fallback){
 if(!result||!['available','ready'].includes(result.status))return null;
 const active=result.active==null?fallback:result.active;if(!validVersion(active))return null;
 const versions=[result.available,result.pending].filter(v=>validVersion(v)&&newer(v,active));
 if(!versions.length)return null;const available=versions.reduce((a,b)=>newer(a,b)?a:b);
 return {version:active,available,kind:result.kind==='installer'&&available===result.available?'installer':'patch'};
}
export async function sendBackgroundUpdateNotice({file,request,scriptPath=path.join(ownDirectory,'update-notice.ps1'),signal},{filesystem=fs,spawnProcess=spawn,directory=ownDirectory,environment=process.env,clock=()=>performance.now(),pause=wait,acknowledgmentMs=6000}={}){
 scriptPath=path.resolve(scriptPath);directory=path.resolve(directory);
 if(path.dirname(scriptPath).toLowerCase()!==directory.toLowerCase()||path.basename(scriptPath)!=='update-notice.ps1')throw Error('Update notice script outside signed release');
 await verifyNoticeDirectory(directory,filesystem);const script=await verifyNoticeFile(scriptPath,filesystem);if(script.size>256*1024)throw Error('Update notice script too large');
 await verifyNoticeDirectory(path.dirname(file),filesystem);if(signal?.aborted)return false;
 const exe=path.join(environment.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const args=['-NoLogo','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-STA','-EncodedCommand',Buffer.from(UPDATE_NOTICE_COMMAND,'utf16le').toString('base64')];
 let child,exited=false,accepted=false;const abort=()=>{try{child?.kill()}catch{}};
 try{
  child=spawnProcess(exe,args,{windowsHide:true,detached:false,stdio:'ignore',env:{...environment,DOORAY_PLUS_HANDOFF_JOB_FILE:'',DOORAY_PLUS_UPDATE_NOTICE_FILE:file,DOORAY_PLUS_UPDATE_NOTICE_SCRIPT:scriptPath}});
  signal?.addEventListener('abort',abort,{once:true});child.once('exit',()=>{exited=true});
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Notice spawn timeout')),acknowledgmentMs);child.once('spawn',()=>{clearTimeout(timer);resolve()});child.once('error',error=>{clearTimeout(timer);reject(error)})});child.unref?.();
  const receipt=file.replace(/\.json$/i,'.result.json'),started=clock();
  while(!signal?.aborted&&clock()-started<acknowledgmentMs){
   try{
    await verifyNoticeDirectory(path.dirname(receipt),filesystem);const stat=await verifyNoticeFile(receipt,filesystem);if(stat.size>8192)return false;
    const value=JSON.parse((await filesystem.readFile(receipt,'utf8')).replace(/^\uFEFF/,''));
    if(value?.schema===1&&value.token===request.token&&value.jobToken===request.jobToken&&value.version===request.version&&value.available===request.available&&positive(value.at)&&value.at>=request.at-30000&&value.at<=request.at+900000){
     if(['accepted','balloon-shown','clicked','closed'].includes(value.status)){accepted=true;return true;}if(value.status==='failed')return false;
    }
   }catch(error){if(error.code!=='ENOENT'&&!(error instanceof SyntaxError))return false;}
   if(exited)break;await pause(125);
  }
  return false;
 }finally{signal?.removeEventListener('abort',abort);if(!accepted||signal?.aborted)abort();}
}

export function createBackgroundUpdateNotice({root,userData,version,onApply=async()=>{},log=()=>{},filesystem=fs,sender=sendBackgroundUpdateNotice,platform=process.platform,clock={monotonic:()=>performance.now(),wall:()=>Date.now()}}={}){
 const directory=path.join(userData,'update-notices'),stateFile=path.join(directory,'state-v1.json'),jobs=new Map(),attempts=new Map(),notified=new Set();
 let ready=false,disposed=false,sending=null,polling=false,current=null,storageError=false,controller=null;
 const note=code=>{try{log('Background update notice: '+code)?.catch?.(()=>{})}catch{}};
 async function writeJSON(file,value){
  await verifyNoticeDirectory(directory,filesystem);try{await verifyNoticeFile(file,filesystem)}catch(error){if(error.code!=='ENOENT')throw error;}
  const temp=file+'.'+crypto.randomUUID()+'.tmp';try{await filesystem.writeFile(temp,JSON.stringify(value),{flag:'wx',mode:0o600});await verifyNoticeDirectory(directory,filesystem);await filesystem.rename(temp,file)}finally{try{await verifyNoticeDirectory(directory,filesystem);await filesystem.unlink(temp)}catch{}}
 }
 async function stopped(){for(const name of ['stop-agent.flag','theme-disabled.flag'])try{await filesystem.lstat(path.join(userData,name));return true}catch(error){if(error.code!=='ENOENT')return true;}return false;}
 const initialized=(async()=>{try{
  await verifyNoticeDirectory(directory,filesystem,true);await filesystem.mkdir(directory,{recursive:true});await verifyNoticeDirectory(directory,filesystem);
  try{const stat=await verifyNoticeFile(stateFile,filesystem);if(stat.size>32768)throw Error('Oversize state');const value=JSON.parse(await filesystem.readFile(stateFile,'utf8'));if(value?.schema===1&&Array.isArray(value.notified)&&value.notified.length<=64)for(const v of value.notified)if(validVersion(v))notified.add(v)}catch(error){if(error.code!=='ENOENT'&&!(error instanceof SyntaxError))throw error;}
  ready=true;
 }catch{storageError=true;note('storage-unavailable')}})();
 async function prune(){
  await verifyNoticeDirectory(directory,filesystem);const pattern=/^([0-9a-f-]{36})(?:\.(?:result|action|progress))?\.json$/i,groups=new Map();
  for(const entry of await filesystem.readdir(directory,{withFileTypes:true})){const match=pattern.exec(entry.name);if(!match||!guid.test(match[1])||!entry.isFile()||entry.isSymbolicLink())continue;const file=path.join(directory,entry.name);const stat=await verifyNoticeFile(file,filesystem);const g=groups.get(match[1])||{at:0,files:[]};g.at=Math.max(g.at,stat.mtimeMs);g.files.push(file);groups.set(match[1],g);}
  for(const g of [...groups.values()].sort((a,b)=>b.at-a.at).slice(31))if(g.at<clock.wall()-20*60000)for(const file of g.files){await verifyNoticeDirectory(directory,filesystem);const stat=await verifyNoticeFile(file,filesystem);if(stat.mtimeMs<clock.wall()-20*60000)await filesystem.unlink(file);}
 }
 function handles(){return platform==='win32'&&!disposed&&!storageError&&(!current||!!controller&&!controller.signal.aborted||(attempts.get(current.available)?.count||0)<3||notified.has(current.available));}
 function observe(result,{enabled=true}={}){
  current=enabled?backgroundUpdateCandidate(result,version):null;
  if(!current)controller?.abort();
  if(disposed||!current||platform!=='win32')return Promise.resolve({status:'suppressed'});
  if(sending)return sending;const candidate=current;
  sending=(async()=>{
   await initialized;if(!ready||disposed||!current||current.available!==candidate.available||await stopped())return {status:'suppressed'};
   if(notified.has(candidate.available))return {status:'already-notified'};
   const retry=attempts.get(candidate.available)||{count:0,at:0};if(retry.count>=3||clock.monotonic()<retry.at)return {status:'suppressed'};
   retry.count++;attempts.set(candidate.available,retry);controller=new AbortController();const attempt=controller;
   const token=crypto.randomUUID(),jobToken=crypto.randomUUID(),request={schema:1,...candidate,at:clock.wall(),token,jobToken},file=path.join(directory,token+'.json');
   try{
    await prune().catch(()=>note('cleanup-skipped'));await verifyNoticeDirectory(directory,filesystem);await filesystem.writeFile(file,JSON.stringify(request),{flag:'wx',mode:0o600});
    if(disposed||attempt.signal.aborted||!current||current.available!==candidate.available||await stopped())return {status:'suppressed'};
    const accepted=await sender({root,userData,file,request,signal:attempt.signal});
    if(accepted!==true||disposed||attempt.signal.aborted){retry.at=clock.monotonic()+30000*2**(retry.count-1);note('ui-unacknowledged');return {status:'unacknowledged'};}
    notified.add(candidate.available);while(notified.size>64)notified.delete(notified.values().next().value);
    jobs.set(token,{request,file,started:clock.monotonic(),consumed:false});
    try{await writeJSON(stateFile,{schema:1,notified:[...notified]})}catch{note('history-save-failed');}
    note('ui-accepted '+candidate.available);return {status:'accepted'};
   }catch{retry.at=clock.monotonic()+30000*2**(retry.count-1);note('delivery-failed');return {status:'failed'};}
   finally{if(controller===attempt)controller=null;}
  })().finally(()=>{sending=null});return sending;
 }
 async function pollActions(){
  if(disposed||polling||!ready)return;polling=true;try{
   for(const [token,job] of jobs){
    if(clock.monotonic()-job.started>15*60000||clock.monotonic()<job.started){jobs.delete(token);continue;}if(job.consumed)continue;
    const progress=async(phase,code,handoffToken)=>{if(!phaseSet.has(phase)||code!==undefined&&!codes.has(code)||handoffToken!==undefined&&(!guid.test(handoffToken)||phase!=='restarting'))throw Error('Invalid update progress');await writeJSON(job.file.replace(/\.json$/,'.progress.json'),{schema:1,token,jobToken:job.request.jobToken,phase,at:clock.wall(),...(code?{code}:{}),...(handoffToken?{handoffToken}:{})});};
    let value;try{await verifyNoticeDirectory(directory,filesystem);const action=job.file.replace(/\.json$/,'.action.json'),stat=await verifyNoticeFile(action,filesystem);if(stat.size>4096)throw Error('Oversize action');value=JSON.parse((await filesystem.readFile(action,'utf8')).replace(/^\uFEFF/,''));}catch(error){if(error.code!=='ENOENT')note('action-rejected');continue;}
    if(Object.keys(value||{}).sort().join(',')!=='action,at,jobToken,schema,token'||value.schema!==1||value.token!==token||value.jobToken!==job.request.jobToken||value.action!=='apply'||!positive(value.at)||value.at<job.request.at||value.at>clock.wall()+30000||clock.wall()-value.at>120000){job.consumed=true;note('action-rejected');continue;}
    job.consumed=true;if(await stopped()||disposed)continue;
    // The user action is consumed once. The supervisor rechecks signatures,
    // target version, download/draft safety and exclusive handoff ownership.
    void Promise.resolve().then(()=>disposed?undefined:onApply({...job.request,progress})).catch(()=>progress('error','helper-failed')).catch(()=>{});
   }
  }finally{polling=false;}
 }
 return {observe,pollActions,handles,dispose(){disposed=true;controller?.abort();jobs.clear();},whenReady:()=>initialized};
}

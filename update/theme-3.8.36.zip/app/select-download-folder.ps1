$InitialDirectory=$env:DOORAY_THEME_PICK_INITIAL
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Choose the folder for new Dooray downloads'
$dialog.ShowNewFolderButton = $true
if (Test-Path -LiteralPath $InitialDirectory -PathType Container) { $dialog.SelectedPath = $InitialDirectory }
try {
 $ownerHandle = [DoorayWindowFocus]::Owner()
 if ($ownerHandle -ne [IntPtr]::Zero) {
  [DoorayWindowFocus]::Activate($ownerHandle)
  $owner = New-Object DoorayWindowOwner -ArgumentList $ownerHandle
  $result = $dialog.ShowDialog($owner)
 } else { $result = $dialog.ShowDialog() }
 if ($result -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) }
}
finally { $dialog.Dispose() }

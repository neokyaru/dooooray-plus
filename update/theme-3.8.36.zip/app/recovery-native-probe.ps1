$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
# Read-only process/window evidence. Never read titles, command lines or chat data.
try {
    Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;

public sealed class DoorayPresenceObservation {
    public string Path, UserSid;
    public int SessionId = -1;
    public bool IdentityKnown, ElevationKnown, Elevated, VisibleMainWindow;
}
public sealed class DoorayPresenceResult {
    public bool Known, Running, Interactive;
    public string Reason;
    public string Json() {
        return "{\"known\":" + (Known ? "true" : "false") + ",\"running\":" + (Running ? "true" : "false") +
            ",\"interactive\":" + (Interactive ? "true" : "false") + ",\"reason\":\"" + Reason + "\"}";
    }
}
public static class DoorayNativePresence {
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, int processId);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process, int flags, StringBuilder path, ref int size);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool GetTokenInformation(IntPtr token, int informationClass, out int information, int length, out int returnLength);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    delegate bool EnumWindowProc(IntPtr window, IntPtr data);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowProc callback, IntPtr data);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr window);
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr window, out Rect rect);

    static DoorayPresenceResult Unknown(string reason) { return new DoorayPresenceResult { Reason=reason }; }
    public static bool ValidPath(string value) {
        if (String.IsNullOrEmpty(value) || value.Length>32760 || !Regex.IsMatch(value,@"^[A-Za-z]:[\\/]") ||
            Regex.IsMatch(value,@"[\x00-\x1f<>""|?*]") || value.Substring(2).Contains(":")) return false;
        foreach (string part in value.Substring(3).Split(new char[] {'\\','/'}))
            if (part=="." || part==".." || part.EndsWith(".") || part.EndsWith(" ")) return false;
        return String.Equals(System.IO.Path.GetFileName(value),"DoorayMessenger.exe",StringComparison.OrdinalIgnoreCase);
    }
    static bool SamePath(string first, string second) {
        try { return String.Equals(System.IO.Path.GetFullPath(first),System.IO.Path.GetFullPath(second),StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }
    // Pure classification is also exercised with synthetic observations. Unknown
    // identity is not evidence that the program stopped; other users are ignored.
    public static DoorayPresenceResult Classify(string expected, string sid, int session, bool callerElevationKnown, bool callerElevated, DoorayPresenceObservation[] observations) {
        if (!ValidPath(expected)) return Unknown("invalid-path");
        if (String.IsNullOrEmpty(sid) || !Regex.IsMatch(sid,@"^S-1-\d+(?:-\d+)+$") || session<=0 || !callerElevationKnown || callerElevated) return Unknown("unsafe-caller");
        bool uncertain=false, running=false, interactive=false;
        foreach (DoorayPresenceObservation item in observations) {
            if (item==null) { uncertain=true; continue; }
            if (item.SessionId>=0 && item.SessionId!=session) continue;
            if (!String.IsNullOrEmpty(item.Path) && !SamePath(item.Path,expected)) continue;
            if (!item.IdentityKnown || item.SessionId!=session || String.IsNullOrEmpty(item.Path) || String.IsNullOrEmpty(item.UserSid)) { uncertain=true; continue; }
            if (!String.Equals(item.UserSid,sid,StringComparison.Ordinal)) continue;
            if (!item.ElevationKnown || item.Elevated) { uncertain=true; continue; }
            running=true; interactive |= item.VisibleMainWindow;
        }
        if (running) return new DoorayPresenceResult { Known=true, Running=true, Interactive=interactive, Reason="running" };
        return uncertain ? Unknown("identity-unavailable") : new DoorayPresenceResult { Known=true, Reason="not-running" };
    }
    static bool RegularPath(string expected) {
        try {
            string current=System.IO.Path.GetFullPath(expected); bool first=true;
            while (!String.IsNullOrEmpty(current)) {
                FileAttributes attributes=File.GetAttributes(current);
                if ((attributes & FileAttributes.ReparsePoint)!=0 || (first ? (attributes & FileAttributes.Directory)!=0 : (attributes & FileAttributes.Directory)==0)) return false;
                string parent=System.IO.Path.GetDirectoryName(current);
                if (String.Equals(parent,current,StringComparison.OrdinalIgnoreCase)) break;
                current=parent; first=false;
            }
            return true;
        } catch { return false; }
    }
    static bool VisibleMainWindow(int processId) {
        bool visible=false;
        bool enumerated=EnumWindows(delegate(IntPtr window,IntPtr data) {
            uint owner; GetWindowThreadProcessId(window,out owner); Rect rect;
            if (owner==(uint)processId && GetMenu(window)!=IntPtr.Zero && IsWindowVisible(window) && !IsIconic(window) &&
                GetWindowRect(window,out rect) && rect.Right>rect.Left && rect.Bottom>rect.Top) visible=true;
            return true;
        },IntPtr.Zero);
        return enumerated && visible;
    }
    static DoorayPresenceObservation Observe(Process candidate, string expected, string sid, int session) {
        var item=new DoorayPresenceObservation(); IntPtr process=IntPtr.Zero,token=IntPtr.Zero;
        try {
            item.SessionId=candidate.SessionId;
            if (item.SessionId!=session) return item;
            process=OpenProcess(0x1000,false,candidate.Id);
            if (process==IntPtr.Zero) return item;
            var name=new StringBuilder(32768); int size=name.Capacity;
            if (!QueryFullProcessImageName(process,0,name,ref size)) return item;
            item.Path=name.ToString();
            if (!SamePath(item.Path,expected)) return item;
            if (!OpenProcessToken(process,8,out token)) return item;
            using (var owner=new WindowsIdentity(token)) item.UserSid=owner.User==null?null:owner.User.Value;
            item.IdentityKnown=!String.IsNullOrEmpty(item.UserSid);
            if (!String.Equals(item.UserSid,sid,StringComparison.Ordinal)) return item;
            int elevated,returned; item.ElevationKnown=GetTokenInformation(token,20,out elevated,sizeof(int),out returned);
            item.Elevated=elevated!=0;
            if (item.ElevationKnown && !item.Elevated) item.VisibleMainWindow=VisibleMainWindow(candidate.Id);
        } catch { } finally { if(token!=IntPtr.Zero)CloseHandle(token); if(process!=IntPtr.Zero)CloseHandle(process); }
        return item;
    }
    public static DoorayPresenceResult Probe(string expected, string expectedSid) {
        if (!ValidPath(expected) || !RegularPath(expected)) return Unknown("invalid-path");
        try {
            using (var current=Process.GetCurrentProcess()) using (var identity=WindowsIdentity.GetCurrent()) {
                string sid=identity.User==null?null:identity.User.Value; int session=current.SessionId;
                IntPtr token=IntPtr.Zero; bool elevationKnown=false, elevated=true;
                try { int value,returned; if (OpenProcessToken(current.Handle,8,out token)) { elevationKnown=GetTokenInformation(token,20,out value,sizeof(int),out returned); elevated=value!=0; } }
                finally { if(token!=IntPtr.Zero)CloseHandle(token); }
                if ((!String.IsNullOrEmpty(expectedSid) && !String.Equals(sid,expectedSid,StringComparison.Ordinal)) || session<=0 || !elevationKnown || elevated) return Unknown("unsafe-caller");
                var observations=new List<DoorayPresenceObservation>();
                foreach (var candidate in Process.GetProcessesByName("DoorayMessenger")) using(candidate) observations.Add(Observe(candidate,expected,sid,session));
                return Classify(expected,sid,session,elevationKnown,elevated,observations.ToArray());
            }
        } catch { return Unknown("probe-error"); }
    }
}
'@ -Language CSharp -ErrorAction Stop | Out-Null
    [Console]::Write([DoorayNativePresence]::Probe($env:DOORAY_PLUS_NATIVE_PATH,$env:DOORAY_PLUS_NATIVE_SID).Json())
} catch {
    [Console]::Write('{"known":false,"running":false,"interactive":false,"reason":"probe-error"}')
}

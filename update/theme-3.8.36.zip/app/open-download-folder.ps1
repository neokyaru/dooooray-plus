param([Parameter(Mandatory=$true)][string]$Directory)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Directory -PathType Container)) { throw 'Download folder does not exist.' }
Start-Process -FilePath "$env:WINDIR\explorer.exe" -ArgumentList ('"' + [IO.Path]::GetFullPath($Directory) + '"') -WindowStyle Normal

// Public, read-only GitHub access. No Dooray cookies or messages leave this helper.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const PROJECT='neokyaru/dooooray-plus',LEGACY_PROJECT='neokyaru/dooooraytheme';
const RAW='https://raw.githubusercontent.com/'+PROJECT+'/';
const MAX_IMAGE=8*1024*1024, MAX_JSON=1024*1024;
const DEFAULT_RETRY=60000,MAX_RETRY=24*60*60*1000;
const IMAGE=/\.(png|gif|jpe?g|webp)$/i;
const PACK_VERSION=/^(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})\.(?:0|[1-9]\d{0,3})$/;
export function normalizePackAccess(value){
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('잘못된 팩 정보입니다.');
  const access={};
  if(Object.hasOwn(value,'password')){
    const password=value.password;
    if(typeof password!=='string'||![...password].length||[...password].length>128||/[\u0000-\u001f\u007f-\u009f]/u.test(password)||[...password].some(c=>{const n=c.codePointAt(0);return n>=0xd800&&n<=0xdfff}))throw Error('팩 암호는 제어문자를 제외한 1~128자로 입력해 주세요.');
    access.password=password;
  }
  if(Object.hasOwn(value,'minVersion')){
    if(typeof value.minVersion!=='string'||!PACK_VERSION.test(value.minVersion))throw Error('잘못된 팩 최소 버전입니다.');
    access.minVersion=value.minVersion;
  }
  if(access.password!==undefined){
    access.minVersion ||= '3.8.34';
    const n=access.minVersion.split('.').map(Number);
    if(n[0]<3||n[0]===3&&(n[1]<8||n[1]===8&&n[2]<34))throw Error('암호 팩의 최소 버전은 3.8.34 이상이어야 합니다.');
  }
  return access;
}
export function repositoryPath(value){
  if(typeof value!=='string'||value.length>1000||value.startsWith('/')||/[\\\x00-\x1f]/.test(value)||value.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('잘못된 이모티콘 경로입니다.');
  return value;
}
export function imageType(bytes){
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';
  if(/^GIF8[79]a$/.test(bytes.subarray(0,6).toString()))return 'image/gif';
  if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
  if(bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP')return 'image/webp';
  throw Error('지원하지 않는 이미지 파일입니다.');
}
export function normalizePack(manifest,manifestPath,ref){
  const packPath=repositoryPath(manifestPath);if(!packPath.startsWith('packs/')||!packPath.endsWith('.json'))throw Error('잘못된 팩 정보 경로입니다.');
  const access=normalizePackAccess(manifest);
  const base=manifestPath.slice(0,manifestPath.lastIndexOf('/')+1);
  const resolve=f=>repositoryPath(f.startsWith('packs/')?f:base+f);
  if(!manifest||!Array.isArray(manifest.items||manifest.emoticons))throw Error(manifestPath+': items 목록이 필요합니다.');
  const seen=new Set();const items=(manifest.items||manifest.emoticons).slice(0,500).map((item,index)=>{
    if(typeof item==='string')item={file:item};
    const path=resolve(item.file||item.path||'');if(!path.startsWith('packs/')||!IMAGE.test(path))throw Error('PNG/GIF/JPG/WebP만 등록할 수 있습니다.');
    const id=String(item.id||index+1);if(seen.has(id))throw Error('팩 안에 중복 ID가 있습니다.');seen.add(id);
    return {id,path,ref,label:String(item.label||item.name||path.split('/').pop()).slice(0,100)};
  });
  const icon=manifest.icon?resolve(manifest.icon):items[0]?.path;
  return {id:String(manifest.id||base),name:String(manifest.name||manifest.id||base.split('/').filter(Boolean).pop()).slice(0,100),icon,ref,packPath,items,...access};
}
export function createEmoticonRepository({fetcher=fetch,cacheDir=process.env.LOCALAPPDATA?path.join(process.env.LOCALAPPDATA,'DoorayTheme','emoticon-cache'):null,retryDelay=500,clock={wall:()=>Date.now(),monotonic:()=>performance.now()}}={}){
  let catalogCache=null,catalogAt=0,catalogPending=null,catalogDisk=null,catalogChecked=0,cacheBytes=0,active=0;const waiting=[],assets=new Map(),inflight=new Map();
  const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
  const cacheFile=key=>path.join(cacheDir,digest(key)+'.json');let cacheWrites=Promise.resolve();
  let rateLimited=false,rateUntil=0,rateUntilWall=0,rateGeneration=0,rateProbe=false,rateDisk=null,rateWrites=Promise.resolve();
  const rateError=()=>Object.assign(Error('이미지 저장소의 요청 제한으로 잠시 대기합니다. 잠시 후 다시 시도해 주세요.'),{status:429,retryAfterMs:Math.max(1000,Math.ceil(rateUntil-clock.monotonic()))});
  const rateBlocked=()=>rateLimited&&(rateProbe||clock.monotonic()<rateUntil);
  async function readRateLimit(){
    if(!cacheDir)return;
    try{
      const file=path.join(cacheDir,'rate-limit-v1.json'),stat=await fs.lstat(file);
      if(!stat.isFile()||stat.isSymbolicLink()||stat.size>4096)return;
      const value=JSON.parse(await fs.readFile(file,'utf8')),now=clock.wall();
      if(Object.keys(value||{}).sort().join(',')!=='at,repository,schema,until'||value.schema!==1||value.repository!==PROJECT||!Number.isSafeInteger(value.at)||!Number.isSafeInteger(value.until)||value.at<=0||value.at>now+30000||value.until<=value.at||value.until-value.at>MAX_RETRY||now-value.until>MAX_RETRY)return;
      rateLimited=true;rateUntilWall=value.until;rateUntil=clock.monotonic()+Math.max(0,Math.min(MAX_RETRY,value.until-now));
    }catch{} // A damaged record cannot block startup or a valid cached image.
  }
  function saveRateLimit(){
    if(!cacheDir)return Promise.resolve();
    const value={schema:1,repository:PROJECT,at:clock.wall(),until:rateUntilWall};
    rateWrites=rateWrites.catch(()=>{}).then(async()=>{
      const file=path.join(cacheDir,'rate-limit-v1.json');
      if(value.until<=value.at){await fs.unlink(file).catch(()=>{});return;}
      await fs.mkdir(cacheDir,{recursive:true});const temp=file+'.'+crypto.randomUUID()+'.tmp';
      try{await fs.writeFile(temp,JSON.stringify(value),{flag:'wx'});await fs.rename(temp,file)}finally{await fs.unlink(temp).catch(()=>{})}
    }).catch(()=>{});return rateWrites;
  }
  async function pauseForRateLimit(response){
    const header=(response.headers.get('retry-after')||'').trim();let delay=DEFAULT_RETRY;
    if(/^\d+(?:\.\d+)?$/.test(header)){const seconds=Number(header);if(Number.isFinite(seconds))delay=seconds*1000;}
    else if(/^[A-Za-z]{3}, /.test(header)){const date=Date.parse(header);if(Number.isFinite(date))delay=date-clock.wall();}
    delay=Math.max(1000,Math.min(MAX_RETRY,delay));rateLimited=true;rateGeneration++;
    rateUntil=Math.max(rateUntil,clock.monotonic()+delay);rateUntilWall=Math.max(rateUntilWall,clock.wall()+delay);
    await saveRateLimit();
  }
  async function cached(key){if(!cacheDir)return null;try{const file=cacheFile(key),stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>12*1024*1024)return null;const record=JSON.parse(await fs.readFile(file,'utf8')),bytes=Buffer.from(record.data,'base64');if(bytes.length>MAX_IMAGE||digest(bytes)!==record.hash)return null;imageType(bytes);return bytes}catch{return null}}
  function saveCache(key,bytes){if(!cacheDir)return Promise.resolve();cacheWrites=cacheWrites.catch(()=>{}).then(async()=>{
    await fs.mkdir(cacheDir,{recursive:true});const file=cacheFile(key),temp=file+'.'+crypto.randomUUID()+'.tmp';
    try{await fs.writeFile(temp,JSON.stringify({hash:digest(bytes),data:bytes.toString('base64')}),{flag:'wx'});await fs.rename(temp,file)}finally{await fs.unlink(temp).catch(()=>{})}
    // A successfully loaded immutable ref/path remains on disk across picker
    // pages, process restarts and program updates. Bound the in-memory cache
    // separately; visiting other packs must not evict previously saved images.
  }).catch(()=>{});return cacheWrites}
  async function limited(fn){if(active>=4)await new Promise(r=>waiting.push(r));else active++;try{return await fn()}finally{const next=waiting.shift();if(next)next();else active--;}}
  async function request(route,max=MAX_JSON){
    rateDisk ||= readRateLimit();await rateDisk;
    if(rateBlocked())throw rateError();
    const probing=rateLimited,generation=rateGeneration;if(probing)rateProbe=true;
    try{
      const response=await fetcher(RAW+route,{signal:AbortSignal.timeout(20000),redirect:'error',credentials:'omit'});
      if(response.status===429){await pauseForRateLimit(response);throw rateError();}
      if(!response.ok){const error=Error(response.status===404?'저장소 또는 목록 파일이 아직 없거나 공개되지 않았습니다.':'GitHub 읽기 실패 ('+response.status+')');error.status=response.status;throw error;}
      if(Number(response.headers.get('content-length'))>max)throw Error('이모티콘 파일이 너무 큽니다.');
      let size=0;const chunks=[];for await(const chunk of response.body){size+=chunk.length;if(size>max)throw Error('이모티콘 파일이 너무 큽니다.');chunks.push(Buffer.from(chunk));}
      if(probing&&generation===rateGeneration){rateLimited=false;rateUntil=0;rateUntilWall=0;await saveRateLimit();}
      return Buffer.concat(chunks);
    }catch(error){
      // A failed recovery probe must not release the queued callers into another
      // burst. A concurrent 429 owns its newer deadline and is never shortened.
      if(probing&&rateLimited&&generation===rateGeneration&&clock.monotonic()>=rateUntil){
        rateUntil=clock.monotonic()+DEFAULT_RETRY;rateUntilWall=clock.wall()+DEFAULT_RETRY;await saveRateLimit();
      }
      throw error;
    }finally{if(probing)rateProbe=false;}
  }
  const raw=(p,ref,max)=>request(ref+'/'+repositoryPath(p).split('/').map(encodeURIComponent).join('/'),max);
  const parseJSON=bytes=>{try{return JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''))}catch{throw Error('이모티콘 JSON 형식을 확인하지 못했습니다.')}};
  const json=async(p,ref)=>parseJSON(await raw(p,ref,MAX_JSON));
  function pendingPack(file,entry,ref,fallback){
    const base=file.slice(0,file.lastIndexOf('/'));
    const old=catalogCache?.packs||[];
    let candidates=old.filter(pack=>pack.packPath===file);
    if(!candidates.length&&typeof entry?.id==='string')candidates=old.filter(pack=>pack.packPath===undefined&&pack.id.normalize('NFC')===entry.id.normalize('NFC'));
    if(!candidates.length)candidates=old.filter(pack=>pack.packPath===undefined&&pack.items.length&&pack.items.every(item=>item.path.startsWith(base+'/')));
    const previous=candidates.length===1?candidates[0]:fallback;
    const pack=previous?{...previous,items:previous.items.map(item=>({...item}))}:{id:String(entry?.id||base),name:String(entry?.name||entry?.id||base.split('/').pop()).slice(0,100),ref,packPath:file,items:[]};
    const version=pack.minVersion?.split('.').map(Number);
    if(!version||version[0]<3||version[0]===3&&(version[1]<8||version[1]===8&&version[2]<34))pack.minVersion='3.8.34';
    return {...pack,packPath:file,accessPending:true};
  }
  async function readCatalog(){
    const index=parseJSON(await request('main/emoticon-index.json',8192));
    if(!index||Array.isArray(index)||Object.keys(index).sort().join(',')!=='ref,repository,schema'||index.schema!==1||index.repository!==PROJECT||typeof index.ref!=='string'||!/^[a-f\d]{40}$/i.test(index.ref))throw Error('이모티콘 버전 정보를 읽지 못했습니다.');
    const ref=index.ref;
    if(catalogCache?.ref===ref&&!catalogCache.warnings.length&&!catalogCache.packs.some(pack=>pack.accessPending))return catalogCache;
    let catalog;try{catalog=await json('catalog.json',ref)}catch(e){if(e.status!==404)throw e;catalog=await json('packs.json',ref)}
    if(typeof catalog.packs==='string')catalog={...catalog,packs:await json(catalog.packs,ref)};
    const publicEntries=Array.isArray(catalog)?catalog:Array.isArray(catalog?.packs)?catalog.packs:catalog?.packs?.packs;
    const lockedEntries=Array.isArray(catalog)?[]:catalog?.lockedPacks??[];
    if(!Array.isArray(publicEntries)||!Array.isArray(lockedEntries)||publicEntries.length+lockedEntries.length>100)throw Error('catalog.json에 총 100개 이하의 packs/lockedPacks 배열이 필요합니다.');
    const entries=[...publicEntries.map(entry=>({entry,locked:false})),...lockedEntries.map(entry=>({entry,locked:true}))];
    const results=await Promise.all(entries.map(({entry,locked})=>limited(async()=>{
      let file;
      try{
        let manifest;
        if(typeof entry==='string')file=entry.endsWith('.json')?entry:entry.replace(/\/$/,'')+'/pack.json';
        else {file=entry.manifest||((entry.path||entry.folder||('packs/'+entry.id)).replace(/\/$/,'')+'/pack.json');if(Array.isArray(entry.items||entry.emoticons))manifest=entry;}
        file=repositoryPath(file);if(!file.startsWith('packs/'))throw Error('팩은 packs 폴더 아래에 두어 주세요.');
        if(!manifest){try{manifest=await json(file,ref)}catch(e){if(e.status!==404||!file.endsWith('/pack.json'))throw e;file=file.replace(/\/pack.json$/,'/packs.json');manifest=await json(file,ref)}}
        const pack=normalizePack(manifest,file,ref);if(locked&&pack.password===undefined)throw Error('lockedPacks의 팩에는 암호가 필요합니다.');
        return {pack,file,locked};
      }catch(e){return {warning:e.message,file,entry,locked}}
    })));
    const warnings=results.filter(x=>x.warning).map(x=>x.warning);
    const pending=new Map();
    const validIntent=file=>{try{return repositoryPath(file).startsWith('packs/')&&file.endsWith('.json')}catch{return false}};
    for(const result of results){
      if(result.warning&&result.locked&&validIntent(result.file)){
        const fallback=results.find(other=>other.pack?.packPath===result.file)?.pack;
        pending.set(result.file,pendingPack(result.file,result.entry,ref,fallback));
      }
    }
    const observedLocked=results.some(result=>result.locked&&validIntent(result.file));
    const packs=[];
    for(const result of results){
      if(pending.has(result.file)){
        if(!packs.some(pack=>pack.packPath===result.file))packs.push(pending.get(result.file));
      }else if(result.pack)packs.push(result.pack);
      else if(observedLocked&&result.warning&&result.file){
        // Preserve unrelated immutable data, conservatively pausing that
        // failed manifest too while successful public packs stay available.
        const old=catalogCache?.packs.find(pack=>pack.packPath===result.file);
        if(old)packs.push(pendingPack(result.file,result.entry,ref,old));
      }
    }
    const paths=new Set(),ids=new Set();for(const pack of packs){const id=pack.id.normalize('NFC');if(paths.has(pack.packPath)||ids.has(id))throw Error('중복된 이모티콘 팩입니다.');paths.add(pack.packPath);ids.add(id);}
    if(!packs.length)throw Error(warnings[0]||'등록된 이모티콘 팩이 없습니다.');
    if(warnings.length&&catalogCache&&!observedLocked)throw Error('일부 팩을 읽지 못해 저장된 목록을 유지합니다. '+warnings[0]);
    return {repository:PROJECT,ref,packs,warnings};
  }
  // Catalog and image files live outside signed releases, so restart/update preserves them.
  async function readSavedCatalog(){
    if(!cacheDir)return;
    try{
      const file=path.join(cacheDir,'catalog-v1.json'),stat=await fs.lstat(file);
      if(!stat.isFile()||stat.isSymbolicLink()||stat.size>16*1024*1024)return;
      const saved=JSON.parse(await fs.readFile(file,'utf8')),value=saved.catalog;
      if(![1,2].includes(saved.version)||![PROJECT,LEGACY_PROJECT].includes(value?.repository)||!Number.isFinite(saved.at)||saved.at>clock.wall()+60000||!/^[a-f\d]{40}$/i.test(value.ref)||!Array.isArray(value.packs)||!value.packs.length||value.packs.length>100||!Array.isArray(value.warnings))return;
      const ids=new Set(),paths=new Set();
      for(const pack of value.packs){
        const pending=pack.accessPending===true;
        if(Object.hasOwn(pack,'accessPending')&&!pending)return;
        if(typeof pack.id!=='string'||typeof pack.name!=='string'||!/^[a-f\d]{40}$/i.test(pack.ref)||!pending&&pack.ref!==value.ref||!Array.isArray(pack.items)||pack.items.length>500)return;
        const access=normalizePackAccess(pack),id=pack.id.normalize('NFC');if(ids.has(id))return;ids.add(id);
        if(pack.packPath!==undefined){const p=repositoryPath(pack.packPath);if(!p.startsWith('packs/')||!p.endsWith('.json')||paths.has(p))return;paths.add(p);}
        if(access.password!==undefined&&(saved.version!==2||pack.packPath===undefined||pack.minVersion===undefined))return;
        if(pending&&(saved.version!==2||pack.packPath===undefined||pack.minVersion===undefined||!PACK_VERSION.test(pack.minVersion)))return;
        if(pending){const n=pack.minVersion.split('.').map(Number);if(n[0]<3||n[0]===3&&(n[1]<8||n[1]===8&&n[2]<34))return;}
        if(pack.icon&&(!repositoryPath(pack.icon).startsWith('packs/')||!IMAGE.test(pack.icon)))return;
        for(const item of pack.items)if(typeof item.id!=='string'||typeof item.label!=='string'||item.ref!==pack.ref||!repositoryPath(item.path).startsWith('packs/')||!IMAGE.test(item.path))return;
      }
      // The Git history is mirrored unchanged. Preserve every immutable item
      // ref/path; only the provider label changes, never the referenced bytes.
      catalogCache={...value,repository:PROJECT};catalogAt=saved.at;
    }catch{} // A damaged/unavailable cache is a miss, never a startup failure.
  }
  async function saveCatalog(value){
    if(!cacheDir)return;const file=path.join(cacheDir,'catalog-v1.json'),temp=file+'.'+crypto.randomUUID()+'.tmp';
    // Old clients must re-read their public-only catalog instead of accepting a
    // newer saved catalog whose password policies they do not understand.
    const version=value.packs.some(pack=>pack.accessPending===true||pack.password!==undefined||pack.minVersion!==undefined)?2:1;
    try{await fs.mkdir(cacheDir,{recursive:true});await fs.writeFile(temp,JSON.stringify({version,at:catalogAt,catalog:value}),{flag:'wx'});await fs.rename(temp,file)}catch{}finally{await fs.unlink(temp).catch(()=>{})}
  }
  function revalidate(){
    if(catalogPending)return catalogPending;
    catalogChecked=clock.wall();
    catalogPending=readCatalog().then(async value=>{catalogCache=value;catalogAt=clock.wall();await saveCatalog(value);return value}).finally(()=>{catalogPending=null});return catalogPending;
  }
  async function catalog(refresh=false){
    catalogDisk ||= readSavedCatalog();await catalogDisk;
    if(refresh)return revalidate();
    if(catalogCache){
      // Stale-while-revalidate: offline startup still displays the last valid catalog.
      if(clock.wall()-Math.max(catalogAt,catalogChecked)>300000)void revalidate().catch(()=>{});
      return catalogCache;
    }
    return revalidate();
  }
  function remember(key,bytes){
    const type=imageType(bytes),result={data:'data:'+type+';base64,'+bytes.toString('base64')};
    if(assets.has(key)){cacheBytes-=assets.get(key).size;assets.delete(key)}
    while(cacheBytes+bytes.length>32*1024*1024&&assets.size){const k=assets.keys().next().value;cacheBytes-=assets.get(k).size;assets.delete(k)}
    assets.set(key,{result,size:bytes.length});cacheBytes+=bytes.length;return result;
  }
  async function image(p,ref,refresh=false){
    p=repositoryPath(p);if(!p.startsWith('packs/')||!IMAGE.test(p)||!/^[a-f\d]{40}$/i.test(ref))throw Error('유효하지 않은 이모티콘입니다.');
    const key=ref+'/'+p;if(assets.has(key)&&!refresh)return assets.get(key).result;
    // Even an explicit refresh of this very item cannot make an exact valid
    // disk hit wait for a network response or the shared rate-limit gate.
    if(!refresh){const bytes=await cached(key);if(bytes)return assets.has(key)?assets.get(key).result:remember(key,bytes);}
    if(inflight.has(key))return inflight.get(key);
    const promise=(async()=>{let bytes=await cached(key);if(refresh){rateDisk ||= readRateLimit();await rateDisk;if(rateBlocked()){if(assets.has(key))return assets.get(key).result;}else bytes=null;}
      if(!bytes){await limited(async()=>{for(let attempt=0;attempt<3;attempt++){try{bytes=await raw(p,ref,MAX_IMAGE);imageType(bytes);break}catch(e){const transient=e.status===408||e.status>=500||e.name==='TypeError'||e.name==='TimeoutError'||e.name==='AbortError';if(!transient||attempt===2)throw e;await new Promise(r=>setTimeout(r,retryDelay*(attempt+1)))}}});await saveCache(key,bytes)}return remember(key,bytes);
    })().finally(()=>inflight.delete(key));inflight.set(key,promise);return promise;
  }
  return {catalog,image};
}

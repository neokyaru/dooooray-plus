// Versioned update supervisor: delivered and replaced with every signed user release.
import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {UpdateStore,verifyManifest,checkRemote,atomicJSON,newer,fetchLimited,updateURL} from './update-store.mjs';
import {installerStatus,downloadInstaller,verifyInstaller} from './installer-update.mjs';
import {prepareHandoff,startHandoff,resolveInstallPaths} from './update-handoff.mjs';
import {createRecoveryNotice,runRecoveryRestart} from './recovery-notice.mjs';
import {createNativePresenceProbe} from './native-presence.mjs';
import {createBackgroundUpdatePolicy} from './background-update-policy.mjs';
import {createBackgroundUpdateNotice,backgroundUpdateCandidate} from './background-update-notice.mjs';
import {createOwnedChildRetirement} from './compatibility.mjs';
const root=process.env.DOORAY_INSTALL_ROOT;
const ownVersion=path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const userData=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
const data=path.join(userData,'engine-v1');
const publicKey=await fs.readFile(path.join(root,'app/update-public.pem'),'utf8');
if(process.argv.includes('--check')){console.log(JSON.stringify({controller:ownVersion,mode:'per-user-signed-updates',runtime:process.version}));process.exit(0);}
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(process.env.DOORAY_LEGACY_BRIDGE?19353:19351,'127.0.0.1',()=>r(true))})){await fs.appendFile(path.join(userData,'updater.log'),new Date().toISOString()+' Supervisor singleton port unavailable; another instance or port conflict\n').catch(()=>{});process.exit(0);}
await fs.mkdir(data,{recursive:true});
const store=await new UpdateStore({data,publicKey}).init();
const disabled=path.join(userData,'theme-disabled.flag'),stopFlag=path.join(userData,'stop-agent.flag'),healthy=process.env.DOORAY_ENGINE_HEALTH||path.join(userData,'healthy.flag'),releaseError=process.env.DOORAY_ENGINE_ERROR||path.join(userData,'release-error.json');
const exists=async p=>{try{await fs.access(p);return true}catch{return false}};
const log=async message=>{try{const file=path.join(userData,'updater.log');if((await fs.stat(file).catch(()=>({size:0}))).size>1048576)await fs.rename(file,file+'.previous');await fs.appendFile(file,new Date().toISOString()+' '+message+'\n')}catch{}};
const nativePresence=createNativePresenceProbe({root});
const updateSchedule=createBackgroundUpdatePolicy();
const backgroundNotice=createBackgroundUpdateNotice({root,userData,version:ownVersion,onApply:applyBackgroundUpdate,log});
const recoverySession=crypto.randomUUID();
const recoveryNotice=createRecoveryNotice({root,userData,version:ownVersion,session:recoverySession,onRestart:recoverFromNotice,scriptPath:path.join(path.dirname(fileURLToPath(import.meta.url)),'recovery-notice.ps1'),log});
const expectedExit=new WeakSet();let childReady=false;let mayActivate=false;let child=null,busy=false,remoteBusy=false,activationBusy=false,closing=false,holdUntilClose=false,started=0,wasPresent=false,lastCheck=0,crashed=false;
let exitRequested=null;
let recoveryBusy=null,recoveryActivationHold=false,verifiedInstallerVersion=null;
const retiring=createOwnedChildRetirement({graceMs:9000,killWaitMs:1000,onExit(){if(exitRequested!==null&&!child&&!retiring.busy)process.exit(exitRequested);},onStalled(){void diagnostic('blocked','helper shutdown could not be confirmed');}});
function retireHelper(running=child){if(!running)return Promise.resolve(true);expectedExit.add(running);if(child===running)child=null;return retiring.retire(running);}
function requestExit(code){exitRequested=code;if(!child&&!retiring.busy)process.exit(code);}
// All recovery state is per helper attempt, independent of the wall clock and remote checks.
let retryAt=0,retryCount=0,sessionId='',healthStamp=null,lastHealthy=0,stableSince=0,lastTick=performance.now(),resumeGrace=0,diagnosticKey='',diagnosticQueue=Promise.resolve();
let recoveryPhase='connecting',recoveryReason='',nativePageState='unknown';
const backgroundPreflights=new Map();
function releaseBackgroundLease(running){try{if(running?.connected)running.send({type:'background-unreserve'})}catch{}}
function preflightBackground(running=child){
 if(!running||running!==child||!running.connected)return Promise.resolve({known:false});
 const id=crypto.randomUUID();return new Promise(resolve=>{const timer=setTimeout(()=>{backgroundPreflights.delete(id);resolve({known:false})},5000);backgroundPreflights.set(id,{running,resolve,timer});try{running.send({type:'background-preflight',id})}catch{clearTimeout(timer);backgroundPreflights.delete(id);resolve({known:false})}});
}
async function applyBackgroundUpdate(request){
 const progress=async(phase,code,handoffToken)=>{try{await request.progress(phase,code,handoffToken)}catch{}};
 if(closing||recoveryBusy||activationBusy||handoffBusy||activeHandoff){await progress('error','busy');return;}
 handoffBusy=true;const generation=++handoffGeneration;let reserved=null,applying=null;
 const ensure=()=>{if(closing||recoveryBusy||generation!==handoffGeneration)throw Error('cancelled')};
 const preflight=async()=>{ensure();const native=await nativePresence.refreshFresh();ensure();if(!native.known)throw Error('window-required');if(native.running){reserved=child;const check=await preflightBackground(reserved);ensure();if(check.downloads>0)throw Error('downloads-active');if(!check.known||check.drafts!==0||check.reserved!==true||reserved!==child)throw Error('window-required');}};
 try{
  await progress('checking');await preflight();const checked=await remote(true,false);ensure();if(checked.status==='error')throw Error('check-failed');
  if(!newer(request.available,store.state.active)){await progress('complete','updated');return;}
  const candidate=backgroundUpdateCandidate(checked,store.state.active);if(!candidate||candidate.available!==request.available||candidate.kind!==request.kind)throw Error('update-changed');
  await progress('downloading');let installer=null;
  if(candidate.kind==='installer'){if(installerInfo?.manifest.version!==candidate.available)throw Error('update-changed');installer=await downloadInstaller(installerInfo,publicKey,path.join(data,'installers',candidate.available));}
  else{const downloaded=await remote(true,true);ensure();if(downloaded.status==='error')throw Error('check-failed');if(store.state.pending!==candidate.available)throw Error('update-changed');await store.validate(candidate.available);}
  ensure();await progress('confirming');ensure();
  const prepared=await prepareHandoff({root,data,version:candidate.available,kind:candidate.kind,installer});ensure();
  prepared.reservedChild=reserved;applying=prepared;activeHandoff=prepared;handoffJob=null;
  if(candidate.kind==='patch')await store.validate(candidate.available);
  const ensureOwner=()=>{ensure();if(activeHandoff!==prepared)throw Error('cancelled')};ensureOwner();
  await progress('restarting',undefined,prepared.token);ensureOwner();
  // The Windows notice already owns a progress window for this action.
  await startHandoff(prepared,undefined,async()=>{ensureOwner();await preflight();ensureOwner();prepared.reservedChild=reserved},async()=>{});prepared.authorized=true;handoffBusy=false;
 }catch(error){
  if(applying&&activeHandoff===applying)activeHandoff=null;
  if(generation===handoffGeneration){cancelPreparation();lastResult={status:'error',error:'백그라운드 업데이트를 진행하지 못했습니다. ('+(['window-required','downloads-active','update-changed','cancelled','check-failed'].includes(error.message)?error.message:'helper-failed')+')'};}
  await progress('error',['window-required','downloads-active','update-changed','cancelled','check-failed'].includes(error.message)?error.message:'helper-failed');await log('Background apply deferred: '+error.message);
 }finally{if(!applying||activeHandoff!==applying)releaseBackgroundLease(reserved);if(generation===handoffGeneration)handoffBusy=false;}
}
function observeRecovery(present,native){
 const checked=['current','ahead','available','ready'].includes(lastResult.status);
 void recoveryNotice.observe({present,nativeRunning:native?.known?native.running:null,nativeInteractive:native?.known&&native.interactive===true,phase:recoveryPhase,reason:recoveryReason,retryCount,version:store.state.active||ownVersion,available:checked?lastResult.available||null:null,pending:checked?store.state.pending:null,kind:checked?lastResult.kind:'unknown',updateChecked:checked,installerChecked:checked&&!!verifiedInstallerVersion,installerVersion:verifiedInstallerVersion,enabled:!closing,paused:closing||!!recoveryBusy||!!activeHandoff||handoffBusy||performance.now()<resumeGrace||nativePageState==='login'||recoveryReason.includes('waiting-login')}).catch(()=>{});
}
async function diagnostic(phase,reason=''){
 recoveryPhase=phase;recoveryReason=reason;
 const key=phase+'|'+reason+'|'+store.state.active;if(key===diagnosticKey)return;diagnosticKey=key;
 const value={phase,reason,version:store.state.active,helperPid:child?.pid||null,retryCount,at:Date.now()};
 diagnosticQueue=diagnosticQueue.then(async()=>{await atomicJSON(path.join(userData,'connection-status.json'),value).catch(()=>{});await log('Connection '+phase+(reason?': '+reason:''));});await diagnosticQueue;
}
async function retryHelper(reason){
 if(activeHandoff||recoveryBusy)return;
  cancelPreparation();const old=child;childReady=false;healthStamp=null;stableSince=0;
  void retireHelper(old);
 await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});
 retryCount++;const delay=Math.min(60000,5000*2**Math.min(retryCount-1,4));retryAt=performance.now()+delay;
 await diagnostic('retrying',reason+'; retry in '+delay+'ms');
}
function temporaryReleaseReadError(error){return ['EACCES','EPERM','EBUSY'].includes(error?.code);}
async function currentFault(){try{const fault=JSON.parse(await fs.readFile(releaseError,'utf8'));return fault?.version===store.state.active&&fault.session===sessionId?fault:null}catch{return null}}
async function monitorHelper(){
 if(activeHandoff||recoveryBusy)return;
 if(await currentFault()){await fail('runtime-error');return;}
 let health=null;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
 const now=performance.now();
 if(health?.version===store.state.active&&health.session===sessionId&&Number.isFinite(health.at)){
  if(health.at!==healthStamp){healthStamp=health.at;lastHealthy=now;}
  if(now-lastHealthy<=30000){
   if(!childReady){childReady=true;stableSince=now;}await diagnostic('ready');
   if(store.state.trial)await store.confirm();
   if(now-stableSince>=30000){retryCount=0;retryAt=0;}return;
  }
 }
 if(now<resumeGrace)return;
 if((!childReady&&now-started>45000)||(childReady&&now-lastHealthy>45000))await retryHelper(childReady?'health-stalled':'startup-timeout');
}
async function activate(){
  if(!canActivatePending())return;const proof=await nativePresence.refreshFresh();if(!proof.known||proof.running||!canActivatePending())return;activationBusy=true;
  try{await store.activate();if(store.state.active!==ownVersion)process.exit(75);}finally{activationBusy=false;}
}
function canActivatePending(){return !closing&&!recoveryBusy&&!recoveryActivationHold&&!retiring.busy&&exitRequested===null&&!activationBusy&&!remotePromise&&!handoffBusy&&!!store.state.pending&&(!activeHandoff||(activeHandoff.authorized===true&&activeHandoff.config.kind==='patch'&&activeHandoff.config.version===store.state.pending));}
async function recoverFromNotice(request){
 let healthyGuard=async()=>{};
 const progress=async(phase,code)=>{try{await request.progress(phase,code,phase==='complete'?healthyGuard:undefined)}catch(error){if(phase==='complete')throw error}};
 const waiting=performance.now();while(busy&&!closing&&performance.now()-waiting<5000)await new Promise(resolve=>setTimeout(resolve,50));
 if(busy||closing||recoveryBusy||activationBusy||handoffBusy||activeHandoff||remotePromise||retiring.busy||exitRequested!==null||nativePageState==='login'){await progress('error','busy');return;}
 const owner={token:request.jobToken,version:store.state.active,native:null,deadline:waiting+220000,lastReady:null};recoveryBusy=owner;recoveryActivationHold=true;
 const ensureCurrent=async()=>{
  if(closing||recoveryBusy!==owner||activeHandoff||handoffBusy||activationBusy||store.state.active!==owner.version||request.version!==owner.version||request.session!==recoverySession||!request.isCurrent())throw Object.assign(Error('Recovery request expired'),{code:'expired'});
  if(performance.now()>=owner.deadline)throw Object.assign(Error('Recovery deadline exceeded'),{code:'recovery-failed'});
  if(await exists(disabled)||await exists(stopFlag))throw Object.assign(Error('Recovery disabled'),{code:'disabled'});
  if(closing||recoveryBusy!==owner||store.state.active!==owner.version||!request.isCurrent())throw Object.assign(Error('Recovery request expired'),{code:'expired'});
 };
 healthyGuard=async()=>{
  await ensureCurrent();const proof=owner.lastReady;if(!proof)throw Object.assign(Error('Plus health not confirmed'),{code:'plus-not-ready'});
  let health;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
  const fault=await currentFault();await ensureCurrent();
  if(fault||child!==proof.running||!proof.running.connected||sessionId!==proof.session||health?.version!==owner.version||health.session!==proof.session||!Number.isFinite(health.at))throw Object.assign(Error('Plus health no longer ready'),{code:'plus-not-ready'});
 };
 const waitReady=async(running,timeout)=>{
  const attempt=sessionId,begin=performance.now();
  const validAttempt=async()=>{await ensureCurrent();if(child!==running||!running.connected||sessionId!==attempt)return false;const fault=await currentFault();await ensureCurrent();return !fault&&child===running&&running.connected&&sessionId===attempt;};
  while(performance.now()-begin<timeout&&performance.now()<owner.deadline){
   if(!await validAttempt())return false;
   let health;try{health=JSON.parse(await fs.readFile(healthy,'utf8'))}catch{}
   if(!await validAttempt())return false;
   if(health?.version===owner.version&&health.session===attempt&&Number.isFinite(health.at)){
    childReady=true;healthStamp=health.at;lastHealthy=performance.now();stableSince=lastHealthy;retryAt=0;retryCount=0;crashed=false;holdUntilClose=false;
    if(store.state.trial)await store.confirm();if(!await validAttempt())return false;await diagnostic('ready');if(!await validAttempt())return false;owner.lastReady={running,session:attempt};return true;
   }
   await new Promise(resolve=>setTimeout(resolve,250));
  }return false;
 };
 const restartFeature=async()=>{await ensureCurrent();if(!await retireHelper())throw Object.assign(Error('Helper exit unconfirmed'),{code:'helper-stalled'});await ensureCurrent();await store.validate(owner.version);await ensureCurrent();crashed=false;return spawnFeature(ensureCurrent);};
 try{
  await ensureCurrent();await progress('stopping','stopping');let running=await restartFeature();await progress('starting','starting');
  if(await waitReady(running,15000)){await progress('complete','recovered');return;}
  await ensureCurrent();await progress('stopping','stopping');if(!await retireHelper())throw Object.assign(Error('Helper exit unconfirmed'),{code:'helper-stalled'});
  await ensureCurrent();const paths=await resolveInstallPaths(root);await ensureCurrent();if(paths.userSid!==request.identity.userSid)throw Object.assign(Error('Recovery identity unavailable'),{code:'identity-unavailable'});
  await runRecoveryRestart({request,paths,userData,version:owner.version,ensureCurrent,progress,onChild:value=>owner.native=value},{timeoutMs:Math.min(110000,Math.max(1000,owner.deadline-performance.now()))});
  await ensureCurrent();running=await restartFeature();await progress('starting','starting');
  if(!await waitReady(running,45000))throw Object.assign(Error('Plus health not confirmed'),{code:'plus-not-ready'});
  await ensureCurrent();await progress('complete','recovered');
 }catch(error){
  const allowed=['busy','disabled','expired','identity-unavailable','close-timeout','reopen-timeout','plus-not-ready','helper-stalled'];
  await progress('error',allowed.includes(error.code)?error.code:'recovery-failed');await log('Recovery restart failed: '+(allowed.includes(error.code)?error.code:'recovery-failed'));
 }finally{
  const release=()=>{if(recoveryBusy===owner){recoveryBusy=null;retryAt=performance.now()+5000;}};
  // An authorized helper may be completing a normal reopen after our deadline.
  // Keep its exclusive ownership until actual exit; never kill native Dooray.
  if(owner.native&&!owner.native.exited)void owner.native.exit.then(release);else release();
 }
}
async function spawnFeature(ensureCurrent=async()=>{if(closing||recoveryBusy)throw Error('Feature startup deferred during recovery');}){
  await ensureCurrent();
  await fs.unlink(healthy).catch(()=>{});await fs.unlink(releaseError).catch(()=>{});started=performance.now();childReady=false;healthStamp=null;lastHealthy=started;stableSince=0;sessionId=crypto.randomUUID();if(store.state.trial){store.state.trialStarted=true;await store.persist();}await ensureCurrent();
  const running=spawn(process.execPath,[path.join(store.dir(store.state.active),'app/launcher.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc'],cwd:store.dir(store.state.active),env:{...process.env,DOORAY_ENGINE_SESSION:sessionId}});child=running;connectUpdates(running);
  running.on('error',e=>{if(child===running){if(!running.pid){child=null;crashed='helper-spawn-error';}else if(!activeHandoff&&!recoveryBusy)void retryHelper('helper-ipc-error');void log('Helper process error: '+e.message)}});
  running.once('exit',(code)=>{if(child===running){child=null;const systemExit=code===null||[0x40010004,0xC000013A].includes(code>>>0);crashed=wasPresent&&!closing&&!expectedExit.has(running)&&!systemExit?(code===0?'helper-stopped':'helper-exited'):false;void log('Helper exited: code='+code+' expected='+expectedExit.has(running));}});
  await log('Loaded user release '+store.state.active);await diagnostic('connecting');
  return running;
}
process.on('disconnect',()=>shutdown());
process.on('message',m=>{if(m?.type==='shutdown')void shutdown()});
setInterval(()=>{if(process.connected)process.send({type:'supervisor-alive',version:ownVersion})},2000).unref();
if(process.connected)process.send({type:'supervisor-alive',version:ownVersion});
async function shutdown(){if(closing)return;closing=true;cancelPreparation();nativePresence.dispose();recoveryNotice.dispose();backgroundNotice.dispose();for(const p of backgroundPreflights.values()){clearTimeout(p.timer);p.resolve({known:false})}backgroundPreflights.clear();void retireHelper();requestExit(0);if(!await retiring.wait())process.exit(0);}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);process.on('exit',()=>{try{child?.kill()}catch{}retiring.forceRemaining();});
async function fail(reason){cancelPreparation();await log('Release failed: '+store.state.active+' '+reason);void retireHelper();
  if(!store.state.trial){await log('Confirmed release retained: '+store.state.active+' '+reason);if(['runtime-error','helper-exited','bootstrap-error'].includes(reason)){await retryHelper(reason);}else{holdUntilClose=true;await diagnostic('blocked',reason);}return;}
  const previous=await store.rollback();await fs.unlink(releaseError).catch(()=>{});holdUntilClose=true;
  if(previous){requestExit(75);return;}
  await log('No healthy release; retry on next launch');await shutdown();
}
let remotePromise=null,remoteDownload=false,lastResult={status:'idle'},installerInfo=null,handoffJob=null,handoffBusy=false,activeHandoff=null,handoffGeneration=0;
function cancelPreparation(){handoffGeneration++;handoffJob=null;handoffBusy=false;}
const updateStatus=()=>({...lastResult,...(activeHandoff?{status:'restarting'}:{}),active:store.state.active,pending:store.state.pending,checkedAt:lastCheck,backgroundNotice:backgroundNotice.handles()});
async function remote(force=false,download=true){
 if(activationBusy||recoveryBusy)return {...updateStatus(),status:'restarting'};
 if(remotePromise){const covered=remoteDownload;await remotePromise;if(!download||covered||store.state.pending)return updateStatus();return remote(force,download);}
 if(!updateSchedule.begin(performance.now(),{force}))return updateStatus();
 lastCheck=Date.now();lastResult={status:download?'downloading':'checking'};
 remoteDownload=download;
 remotePromise=(async()=>{try{
  verifiedInstallerVersion=null;let warning=null;try{installerInfo=await installerStatus(root,publicKey,store.state.active);const version=installerInfo?.manifest?.version;if(version&&!newer(store.state.active,version))verifiedInstallerVersion=version;}catch(e){installerInfo=null;if(e.code!=='INSTALLATION_STATE_INVALID'&&(e instanceof SyntaxError||/signature|metadata|contract/i.test(e.message)))throw e;warning='설치 업데이트 정보 확인 실패: '+e.message;await log(warning);
   // A missing local native path must not hide an independently signed repair
   // installer. This never marks the local installation current or ready.
   if(e.code==='INSTALLATION_STATE_INVALID')try{const envelope=JSON.parse((await fetchLimited(updateURL('installer.json'),256*1024,fetch)).toString());const manifest=verifyInstaller(envelope,publicKey);if(!newer(store.state.active,manifest.version))verifiedInstallerVersion=manifest.version;}catch{verifiedInstallerVersion=null;}
  }
  const result=await checkRemote(store,fetch,{download:download&&!installerInfo?.needed});
  if(store.state.pending)await store.validate(store.state.pending);
  lastResult={status:installerInfo?.needed?'available':store.state.pending?'ready':result?.available?'available':result?.ahead?'ahead':'current',available:installerInfo?.needed?installerInfo.manifest.version:result?.available||null,kind:installerInfo?.needed?'installer':'patch',remoteVersion:result?.remoteVersion||null,warning};if(store.state.pending)await log('Update staged: '+store.state.pending);
 }catch(e){verifiedInstallerVersion=null;lastResult={status:'error',error:e.message};await log('Update check deferred: '+e.message)}return updateStatus()})().finally(()=>{remotePromise=null});
 try{return await remotePromise}finally{updateSchedule.complete(lastResult.status!=='error',performance.now());}
}
function connectUpdates(running){running.on('message',async m=>{
 if(running===child&&m?.type==='background-preflight-result'&&m.version===store.state.active&&m.session===sessionId){const pending=backgroundPreflights.get(m.id);if(pending&&pending.running===running){clearTimeout(pending.timer);backgroundPreflights.delete(m.id);const v=m.result;pending.resolve(v&&typeof v.known==='boolean'&&typeof v.reserved==='boolean'&&Number.isInteger(v.drafts)&&v.drafts>=0&&Number.isInteger(v.downloads)&&v.downloads>=0?v:{known:false});}return;}
 if(running===child&&m?.type==='launcher-status'&&m.version===store.state.active&&m.session===sessionId){if(['connecting','reconnecting','waiting-page','waiting-theme','waiting-debug-port','waiting-target','waiting-navigation','waiting-login'].includes(m.phase))await diagnostic('connecting','launcher '+m.phase);return;}
 if(running!==child||!['update-check','update-status','update-install','update-apply','update-cancel'].includes(m?.type)||typeof m.id!=='string'||m.id.length>80)return;
 if(['update-install','update-apply'].includes(m.type)&&(recoveryBusy||(m.type==='update-install'&&(activationBusy||handoffBusy||activeHandoff)))){if(running.connected)running.send({type:'update-result',id:m.id,result:{...updateStatus(),status:'error',error:'업데이트가 이미 진행 중입니다.'}});return;}
 let result,applying=null,generation=handoffGeneration;try{
 if(m.type==='update-install'){
  if(handoffBusy)throw Error('업데이트가 이미 준비 중입니다.');handoffBusy=true;generation=++handoffGeneration;
  const ensureCurrent=()=>{if(closing||recoveryBusy||generation!==handoffGeneration||running!==child)throw Error('업데이트 준비가 취소되었습니다. 다시 시도해 주세요.');};
  const checked=await remote(true,false);ensureCurrent();if(checked.status==='error')throw Error(checked.error);
  let installer=null,version,kind=installerInfo?.needed?'installer':'patch';
  if(kind==='installer'){version=installerInfo.manifest.version;installer=await downloadInstaller(installerInfo,publicKey,path.join(data,'installers',version));}
  else{const downloaded=await remote(true,true);if(downloaded.status==='error')throw Error(downloaded.error);version=store.state.pending;if(!version)throw Error('적용할 새 업데이트가 없습니다.');await store.validate(version);}
  ensureCurrent();const prepared=await prepareHandoff({root,data,version,kind,installer});ensureCurrent();handoffJob=prepared;result={...updateStatus(),status:'prepared',token:handoffJob.token,kind,available:version};
 }else if(m.type==='update-apply'){
  if(!handoffJob||m.token!==handoffJob.token)throw Error('업데이트 준비 정보가 만료되었습니다. 다시 확인해 주세요.');
  applying=handoffJob;handoffJob=null;activeHandoff=applying;
  const ensureApplying=()=>{if(closing||recoveryBusy||generation!==handoffGeneration||running!==child||activeHandoff!==applying)throw Error('업데이트 준비가 취소되었습니다. 다시 확인해 주세요.');};
  if(applying.config.kind==='patch')await store.validate(applying.config.version);
  ensureApplying();await startHandoff(applying,undefined,ensureApplying);applying.authorized=true;result={...updateStatus(),status:'restarting'};handoffJob=null;handoffBusy=false;
 }else if(m.type==='update-cancel'){cancelPreparation();result=updateStatus();}
 else result=m.type==='update-check'?await remote(true,false):updateStatus();
 }catch(e){if(applying&&activeHandoff===applying)activeHandoff=null;if(generation===handoffGeneration){cancelPreparation();lastResult={status:'error',error:e.message};}result={...updateStatus(),status:'error',error:e.message};await log('Update handoff deferred: '+e.message)}
 if(running===child&&running.connected)try{running.send({type:'update-result',id:m.id,result})}catch{}
});}
async function targets(){try{const list=await(await fetch('http://127.0.0.1:19347/json/list',{signal:AbortSignal.timeout(1000)})).json();if(!Array.isArray(list)){nativePageState='unknown';return null}const pages=list.filter(t=>{try{const u=new URL(t.url);return t.type==='page'&&u.protocol==='https:'&&/(^|\.)(dooray|gov-dooray)\.com$/.test(u.hostname)}catch{return false}});const present=pages.some(t=>new URL(t.url).pathname.startsWith('/messenger'));nativePageState=present?'messenger':pages.length?'login':'unavailable';return present}catch(e){nativePageState='unavailable';return e.cause?.code==='ECONNREFUSED'?false:null}}
async function tick(){if(handoffBusy&&handoffJob&&Date.now()-handoffJob.config.createdAt>60000){cancelPreparation();}if(busy||closing)return;busy=true;let recoverySnapshot;try{
  const now=performance.now();if(now-lastTick>15000){resumeGrace=now+30000;await diagnostic('resuming','scheduler gap; allowing connection recovery');}lastTick=now;
  if(activeHandoff){let outcome;try{outcome=JSON.parse((await fs.readFile(path.join(activeHandoff.dir,'result.json'),'utf8')).replace(/^\uFEFF/,''))}catch{}if(outcome?.phase==='error'||Date.now()-activeHandoff.config.createdAt>20*60*1000){lastResult={status:'error',error:outcome?.message||'업데이트 실행 응답 시간이 초과되었습니다.'};releaseBackgroundLease(activeHandoff.reservedChild);activeHandoff=null;}else if(outcome?.phase==='complete'){releaseBackgroundLease(activeHandoff.reservedChild);activeHandoff=null;}}
  if(await exists(disabled)||await exists(stopFlag)){await diagnostic('disabled','explicit stop flag');await shutdown();return;}
  // The signed updater lives independently of the native app and renderer.
  if(!recoveryBusy&&!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  void backgroundNotice.pollActions().catch(()=>{});
  void recoveryNotice.pollActions().catch(()=>{});
  const present=await targets();let native=nativePresence.poll();
  updateSchedule.observeNative(present===true?{known:true,running:true}:native);
  // Negative cached evidence can predate a new native launch. Before a close
  // boundary can stop a helper or activate a patch, require a fresh OS query.
  if(present===false&&native.known&&!native.running&&(wasPresent||child||store.state.pending))native=await nativePresence.refreshFresh();
  if(closing)return;
  recoverySnapshot={present,native};
  if(recoveryBusy)return;
  if(recoveryActivationHold){native=await nativePresence.refreshFresh();if(native.known&&native.running)recoveryActivationHold=false;}
  // A live native window can lose its debugging port during a vendor update.
  // Check signed recovery updates independently; never interpret that outage
  // (or an unknown process probe) as permission to activate a pending release.
  if(!recoveryBusy&&!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  if(present===null){await diagnostic('waiting','debug endpoint unavailable (19347)');if(child)await monitorHelper();return;}
  if(!present&&(!native.known||native.running)){await diagnostic('waiting',nativePageState==='login'?'launcher waiting-login':'native Dooray still running; messenger connection unavailable');if(child)await monitorHelper();return;}
  if(!present&&(handoffBusy||activeHandoff)&&!canActivatePending()){if(child)await monitorHelper();return;}
  if(!present){holdUntilClose=false;crashed=false;mayActivate=true;retryAt=0;retryCount=0;if(wasPresent&&child)void retireHelper();wasPresent=false;
    await diagnostic('waiting','no Dooray messenger target (19347)');if(!child&&canActivatePending())await activate();return;
  }
  const firstPresent=!wasPresent;
  if(firstPresent&&!child)mayActivate=false;
  wasPresent=true;
  // Remote I/O must never hold the local feature startup or recovery loop.
  if(!recoveryBusy&&!remotePromise&&!handoffBusy&&!activeHandoff&&updateSchedule.due(performance.now()))void remote(false);
  if(holdUntilClose||retiring.busy||exitRequested!==null)return;
  if(child){await monitorHelper();return;}
  if(activeHandoff)return;
  if(!child&&mayActivate)mayActivate=false;
  if(crashed){const reason=crashed;crashed=false;if(await currentFault())await fail('runtime-error');else if(reason==='helper-exited')await fail(reason);else await retryHelper(reason);return;}
  if(performance.now()<retryAt)return;
  if(!store.state.active){await fail('missing-active-release');return;}
  try{await store.validate(store.state.active)}catch(e){
   // An OS read denial is not a completed integrity verdict. Retry the same
   // signed release with backoff, including an unconfirmed first run; the
   // next attempt must pass the entire signature/file verification again.
   if(temporaryReleaseReadError(e)){await log('Release verification temporarily unreadable: '+e.code);await retryHelper('release-read-'+e.code);return;}
   await fail(e.message);return;
  }
  await spawnFeature();
}catch(e){await log('Bootstrap error: '+e.message);if(child&&!activeHandoff&&!recoveryBusy)await fail('bootstrap-error');}finally{if(recoverySnapshot)observeRecovery(recoverySnapshot.present,recoverySnapshot.native);void backgroundNotice.observe(updateStatus(),{enabled:!closing&&!recoveryBusy&&!activeHandoff&&!handoffBusy}).catch(()=>{});busy=false}}

try{if(store.state.active!==ownVersion)process.exit(75);if(process.env.DOORAY_INSTALL_ROOT&&!process.connected)await shutdown();else{await tick();if(!closing)setInterval(tick,2000);}}catch(e){await log('Initialization deferred: '+e.message);await shutdown();}

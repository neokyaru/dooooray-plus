// Scheduling only: the caller owns signed metadata checks, cancellation, notices,
// handoff/stop guards and safe activation. No Dooray/CDP connection is required.
const SUCCESS_INTERVAL_MS = 30 * 60 * 1000;
const FAILURE_DELAYS_MS = Object.freeze([30000, 60000, 120000, 240000, 300000]);

export function createBackgroundUpdatePolicy({intervalMs = SUCCESS_INTERVAL_MS, retryDelaysMs = FAILURE_DELAYS_MS} = {}) {
 if (!Number.isFinite(intervalMs) || intervalMs <= 0 || !Array.isArray(retryDelaysMs) || !retryDelaysMs.length || retryDelaysMs.some(value => !Number.isFinite(value) || value <= 0 || value > 300000)) throw new TypeError('Invalid background update schedule');
 const retryDelays = [...retryDelaysMs];
 let nextAt = -Infinity, lastAt = null, inFlight = false, failures = 0;
 let knownNative = null, requested = 0, startedRequest = 0;

 function time(now) {
  if (!Number.isFinite(now) || now < 0) throw new TypeError('A non-negative monotonic timestamp is required');
  // A changed clock origin must not postpone the next check for the old uptime.
  // An existing request still owns the slot until its caller completes it.
  if (lastAt !== null && now < lastAt) nextAt = now;
  lastAt = now;
  return now;
 }
 function isDue(now) { return !inFlight && (requested !== startedRequest || now >= nextAt); }

 return Object.freeze({
  due(now) { return isDue(time(now)); },
  begin(now, {force = false} = {}) {
   const at = time(now);
   if (inFlight || !force && !isDue(at)) return false;
   inFlight = true;
   startedRequest = requested;
   return true;
  },
  complete(ok, now) {
   const at = time(now);
   if (!inFlight) return false;
   inFlight = false;
   if (ok === true) {
    failures = 0;
    nextAt = at + intervalMs;
   } else {
    failures = Math.min(failures + 1, retryDelays.length);
    nextAt = at + retryDelays[failures - 1];
   }
   return true;
  },
  observeNative(evidence) {
   // Unknown/denied evidence is not a close, and never creates a fake restart.
   if (!evidence || evidence.known !== true || typeof evidence.running !== 'boolean') return false;
   const reopened = knownNative === false && evidence.running;
   knownNative = evidence.running;
   // Preserve a restart during an in-flight check; its result may predate the
   // restart and must not consume this one additional refresh request.
   if (reopened) requested++;
   return reopened;
  }
 });
}

$ErrorActionPreference = 'Stop'
$targetDirectory = [IO.Path]::GetFullPath($env:DOORAY_THEME_FOLDER).TrimEnd('\')
$ownerHandle = [DoorayWindowFocus]::Owner()
$shell = New-Object -ComObject Shell.Application
$deadline = [DateTime]::UtcNow.AddSeconds(4)
do {
 foreach ($candidate in @($shell.Windows())) {
  try {
   if ([IO.Path]::GetFullPath($candidate.Document.Folder.Self.Path).TrimEnd('\') -ieq $targetDirectory) {
    $handle = [IntPtr]([long]$candidate.HWND)
    $foreground = [DoorayWindowFocus]::GetForegroundWindow()
    # Do not steal focus if the user already moved to an unrelated application.
    if ($foreground -eq $ownerHandle -or $foreground -eq $handle) { [DoorayWindowFocus]::Activate($handle) }
    return
   }
  } catch { }
 }
 Start-Sleep -Milliseconds 100
} while ([DateTime]::UtcNow -lt $deadline)

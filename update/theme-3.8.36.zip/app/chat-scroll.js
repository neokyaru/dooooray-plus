// One owner for conversation bottom-follow. Never sends messages, replaces a
// native handler or infers a send from composing/modified Enter events.
function installChatScroll({document=globalThis.document,getTargets=()=>[],now=()=>performance.now(),requestFrame,cancelFrame,ResizeObserver,MutationObserver}={}){
  const win=document.defaultView||globalThis;
  requestFrame ||= win.requestAnimationFrame.bind(win);cancelFrame ||= win.cancelAnimationFrame.bind(win);
  ResizeObserver ||= win.ResizeObserver;MutationObserver ||= win.MutationObserver;
  const states=new Map(),observedRefs=new Map(),tokenOwner={};let disposed=false,refreshing=false,writes=0;
  const geometry=scroll=>({top:Math.max(0,Number(scroll.scrollTop)||0),height:Number(scroll.scrollHeight)||0,client:Number(scroll.clientHeight)||0});
  const near=m=>Math.max(0,m.height-m.client)-m.top<=3;
  const changed=(a,b)=>Math.abs(a.height-b.height)>.5||Math.abs(a.client-b.client)>.5;
  const hasMessages=scroll=>!!scroll.querySelector('[data-dp-native~="message-group"],[data-logid]');
  const editable=node=>!!node?.closest?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]');
  function relevant(state,node){return !node||node===state.scroll||state.scroll.contains(node)||node.contains?.(state.scroll)||state.editor&&(node===state.editor||state.editor.contains(node)||node.contains?.(state.editor));}
  function current(state){return !disposed&&states.get(state.scroll)===state&&state.scroll.isConnected;}
  function cancel(state){state.follow=false;state.allowRearm=false;state.tailHistory=[];state.revision++;state.remaining=0;state.writtenTop=null;if(state.frame){cancelFrame(state.frame);state.frame=0}}
  function anchorIdentity(node){
    const id=node.getAttribute?.('data-logid');if(id!==null&&id!==undefined)return 'log:'+id;
    const section=node.matches?.('[class*="js-log-right-content-"]')?node:node.querySelector?.('[class*="js-log-right-content-"]');
    const token=[...(section?.classList||[])].find(value=>value.startsWith('js-log-right-content-'));
    return token?'content:'+token:null;
  }
  const validAnchor=(state,anchor,requireIdentity=false)=>!!(anchor?.node.isConnected&&state.scroll.contains(anchor.node)&&(!requireIdentity||anchor.identity!==null)&&(anchor.identity===null||anchorIdentity(anchor.node)===anchor.identity));
  function measureAnchor(state){
    const viewport=state.scroll.getBoundingClientRect();
    const candidates=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');
    for(const node of candidates.length?candidates:state.content.children){const rect=node.getBoundingClientRect();if(rect.height>0&&rect.bottom>viewport.top&&rect.top<viewport.bottom)return {node,offset:rect.top-viewport.top,identity:anchorIdentity(node)};}
    return null;
  }
  // A native composer handler can scroll its conversation even when the reader
  // is far above the tail. Capture before that handler runs, then keep the real
  // visible message (not the subsequently forced scrollTop) as the reading intent.
  function captureReading(state){return {anchor:measureAnchor(state),top:geometry(state.scroll).top};}
  function holdReading(state){if(!state.follow&&!state.readingHold)state.readingHold=captureReading(state);}
  function readingGesture(state,direction){
    state.tailHistory=[];
    if(state.readingHold){state.readingHold=captureReading(state);state.readingNavigation={direction,at:now()};}
  }
  function readingNavigation(state,value,old){
    if(state.drag||state.touchMoving)return true;
    const intent=state.readingNavigation,age=intent?now()-intent.at:Infinity;
    if(!intent||age<0||age>900){state.readingNavigation=null;return false;}
    const delta=value.top-old.top;
    if(Math.abs(delta)<.5)return false;
    return intent.direction===0||Math.sign(delta)===intent.direction;
  }
  function acceptReadingNavigation(state,value,old){
    if(!readingNavigation(state,value,old))return false;
    state.readingHold=captureReading(state);state.revision++;
    if(near(value)&&!state.drag&&!state.touchMoving){state.follow=true;state.readingHold=null;state.readingNavigation=null;state.allowRearm=false;}
    else if(state.readingNavigation?.direction===0)state.readingNavigation=null;
    state.metrics=value;return true;
  }
  function restoreReading(state){
    const hold=state.readingHold;if(!hold||!current(state))return;
    const value=geometry(state.scroll),anchor=hold.anchor;
    let top=hold.top;
    if(validAnchor(state,anchor,true))top=value.top+anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top-anchor.offset;
    if(Math.abs(value.top-top)>.5)write(state,top);
    // Native history prepending may already have preserved the same anchor.
    // Retain its updated numeric position as the fallback if that row is recycled.
    hold.top=geometry(state.scroll).top;state.metrics=geometry(state.scroll);
  }
  function rememberTail(state,value){
    if(!state.follow||!near(value))return;
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    const previous=state.tailHistory[state.tailHistory.length-1];
    if(!previous||Math.abs(previous.height-value.height)>.5||Math.abs(previous.client-value.client)>.5)state.tailHistory.push({height:value.height,client:value.client,at});
    if(state.tailHistory.length>12)state.tailHistory.shift();
  }
  function restoredTail(state,value){
    const at=now();state.tailHistory=state.tailHistory.filter(point=>at-point.at>=0&&at-point.at<=5000);
    // Dooray can restore either the old scrollTop or its old content extent
    // adjusted for the resized composer. Only these proven tail coordinates
    // qualify; an arbitrary jump elsewhere in history still cancels following.
    return state.tailHistory.some(point=>Math.abs(value.top-Math.max(0,point.height-point.client))<=3||Math.abs(value.top-Math.max(0,point.height-value.client))<=3);
  }
  function write(state,top){
    if(!current(state))return;state.writing=true;
    try{state.scroll.scrollTop=top;writes++;state.metrics=geometry(state.scroll);state.writtenTop=state.metrics.top;}finally{state.writing=false}
  }
  function schedule(state){
    if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    state.remaining=3;state.stable=0;if(!state.frame)state.frame=requestFrame(()=>settle(state));
  }
  function settle(state){
    state.frame=0;refresh();if(!current(state)||!state.follow&&!state.readingHold||state.drag||state.touchMoving)return;
    if(!state.follow){
      // A wheel/key can move the browser before its asynchronous scroll event.
      // A layout observer must not restore the pre-gesture reading snapshot.
      acceptReadingNavigation(state,geometry(state.scroll),state.metrics);
      if(!state.follow){restoreReading(state);state.remaining=0;return;}
    }
    const before=geometry(state.scroll);
    // Newly mounted empty panes may still receive Dooray's saved reading
    // position. Measure that native restoration before taking ownership.
    if(state.unsettled){if(before.height>before.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(before)}state.metrics=before;state.remaining=0;return;}
    if(changed(before,state.metrics))rememberTail(state,state.metrics);
    const gap=Math.max(0,before.height-before.client)-before.top;
    if(gap>.5)write(state,state.scroll.scrollHeight);
    const after=geometry(state.scroll);state.stable=!changed(before,after)&&Math.max(0,after.height-after.client)-after.top<=.5?state.stable+1:0;
    rememberTail(state,after);state.metrics=after;state.remaining--;
    if(state.remaining>0&&state.stable<2)state.frame=requestFrame(()=>settle(state));
  }
  function onScroll(state){
    refresh();if(!current(state))return;const value=geometry(state.scroll),old=state.metrics;
    if(state.writing){state.metrics=value;return;}
    const layoutChanged=changed(value,old),own=state.writtenTop!==null&&Math.abs(value.top-state.writtenTop)<.75;
    if(layoutChanged)rememberTail(state,old);
    const restoring=restoredTail(state,value);
    state.writtenTop=null;
    if(state.readingHold&&!state.follow&&!own){
      if(!acceptReadingNavigation(state,value,old)){restoreReading(state);return;}
    }
    if(state.drag||state.touchMoving){state.follow=false;}
    else if(state.unsettled&&layoutChanged){if(value.height>value.client||hasMessages(state.scroll)){state.unsettled=false;state.follow=near(value)}}
    else if(state.follow&&!own&&value.top<old.top-.5&&!layoutChanged&&!near(value)&&!restoring){cancel(state);}
    else if(!state.follow&&!state.readingHold&&near(value)&&(value.top>old.top+.5||state.allowRearm)){state.follow=true;state.allowRearm=false;}
    else if(!state.follow&&!layoutChanged&&!own&&Math.abs(value.top-old.top)>.5){state.revision++;}
    state.metrics=value;if(state.follow){if(near(value))rememberTail(state,value);if(layoutChanged||restoring)schedule(state);}
  }
  const resize=ResizeObserver?new ResizeObserver(entries=>{refresh();for(const state of states.values())if(entries.some(entry=>state.observed.has(entry.target)))schedule(state)}):null;
  function observeSize(state){
    if(!state.sizeDirty)return;state.sizeDirty=false;
    const next=new Set([state.scroll,state.content]);if(state.editor)next.add(state.editor);
    // Dooray can put the message groups directly in a fixed-height scroller;
    // observing that viewport alone would miss late fonts and inline images.
    for(const child of [...state.content.children].slice(-512))next.add(child);
    const last=state.scroll.querySelectorAll('[data-dp-native~="message-group"],[data-logid]');if(last.length)next.add(last[last.length-1]);
    for(const node of state.observed)if(!next.has(node))releaseSize(node);
    for(const node of next)if(!state.observed.has(node)){const count=observedRefs.get(node)||0;if(!count)resize?.observe(node);observedRefs.set(node,count+1)}
    state.observed=next;
  }
  function releaseSize(node){const count=observedRefs.get(node)||0;if(count<=1){observedRefs.delete(node);resize?.unobserve(node)}else observedRefs.set(node,count-1);}
  function attach(target){
    const scroll=target.scroll,metrics=geometry(scroll),state={scroll,content:target.content||scroll,editor:target.editor||null,roomKey:target.roomKey,metrics,follow:near(metrics),frame:0,remaining:0,stable:0,revision:0,writtenTop:null,writing:false,drag:false,touchMoving:false,touchY:null,allowRearm:false,tailHistory:[],readingHold:null,readingNavigation:null,observed:new Set(),sizeDirty:true,unsettled:metrics.height<=metrics.client&&!hasMessages(scroll)};
    state.scrollEvent=()=>onScroll(state);
    state.wheel=event=>{if(event.deltaY<0){readingGesture(state,-1);cancel(state);}else if(event.deltaY>0){readingGesture(state,1);state.allowRearm=true;if(near(geometry(scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}}};
    state.pointer=event=>{const rect=scroll.getBoundingClientRect(),width=Math.max(12,(Number(scroll.offsetWidth)||scroll.clientWidth)-scroll.clientWidth);if(event.target===scroll&&event.pointerType!=='touch'&&event.clientX>=rect.right-width&&event.clientX<=rect.right+1){readingGesture(state,0);state.drag=true;cancel(state)}};
    state.touchStart=event=>{state.touchY=event.touches?.[0]?.clientY??null;state.touchMoving=false;};
    state.touchMove=event=>{const y=event.touches?.[0]?.clientY;if(state.touchY!==null&&Number.isFinite(y)&&Math.abs(y-state.touchY)>2){readingGesture(state,Math.sign(state.touchY-y));state.touchMoving=true;cancel(state)}};
    scroll.addEventListener('scroll',state.scrollEvent,{passive:true});scroll.addEventListener('wheel',state.wheel,{passive:true});scroll.addEventListener('pointerdown',state.pointer,{passive:true});scroll.addEventListener('touchstart',state.touchStart,{passive:true});scroll.addEventListener('touchmove',state.touchMove,{passive:true});
    states.set(scroll,state);observeSize(state);return state;
  }
  function detach(state){
    cancel(state);for(const node of state.observed)releaseSize(node);state.observed.clear();
    for(const [event,handler]of [['scroll',state.scrollEvent],['wheel',state.wheel],['pointerdown',state.pointer],['touchstart',state.touchStart],['touchmove',state.touchMove]])state.scroll.removeEventListener(event,handler);
    states.delete(state.scroll);
  }
  function refresh(){
    if(disposed||refreshing)return;refreshing=true;
    try{
      let targets;try{targets=getTargets()||[]}catch{targets=[]}
      const selected=new Map();for(const target of targets){if(!target?.scroll?.isConnected||target.scroll.clientHeight<=0||target.roomKey===undefined||target.roomKey===null||target.roomKey==='')continue;if(!selected.has(target.scroll))selected.set(target.scroll,target);}
      for(const state of states.values()){const target=selected.get(state.scroll);if(!target||target.roomKey!==state.roomKey)detach(state);}
      for(const target of selected.values()){
        let state=states.get(target.scroll);if(!state){attach(target);continue;}
        const content=target.content||target.scroll,editor=target.editor||null;
        if(content!==state.content||editor!==state.editor){state.content=content;state.editor=editor;state.sizeDirty=true;observeSize(state);schedule(state)}else observeSize(state);
      }
    }finally{refreshing=false}
  }
  function notifyLayout(node){if(disposed)return;refresh();for(const state of states.values())if(relevant(state,node))schedule(state);}
  function beforeLayout(node){
    if(disposed)return null;refresh();const records=[];
    for(const state of states.values())if(relevant(state,node))records.push({state,revision:state.revision,roomKey:state.roomKey,follow:state.follow,metrics:geometry(state.scroll),anchor:state.follow?null:measureAnchor(state)});
    return {owner:tokenOwner,records};
  }
  function afterLayout(token){
    if(disposed||token?.owner!==tokenOwner)return;refresh();
    for(const record of token.records){const state=record.state;if(!current(state)||record.roomKey!==state.roomKey||record.revision!==state.revision)continue;
      if(record.follow&&state.follow){
        const value=geometry(state.scroll);
        // Excel temporarily removes row min-heights while measuring. Chromium
        // can clamp top during that owned transaction, then report a scroll only
        // after the final height is restored. Keep the actually observed clamp
        // as evidence, without treating any unrelated history jump as a restore.
        if(value.top<record.metrics.top-.5&&!near(value)){
          state.tailHistory.push({height:value.top+value.client,client:value.client,at:now()});
          if(state.tailHistory.length>12)state.tailHistory.shift();
        }
        schedule(state);continue;
      }
      // Explicit decoration/theme changes can occur above a reader. Preserve
      // a real visible anchor, and avoid doubling the browser's own anchoring.
      const anchor=record.anchor;if(!record.follow&&!state.follow&&validAnchor(state,anchor)){
        const offset=anchor.node.getBoundingClientRect().top-state.scroll.getBoundingClientRect().top,delta=offset-anchor.offset;
        if(Math.abs(delta)>.5)write(state,state.scroll.scrollTop+delta);
      }
    }
  }
  function eventNodes(event){
    const supplied=event.composedPath?.()||[],nodes=supplied.filter(node=>node?.nodeType===1).slice(0,32);
    if(nodes.length)return nodes;
    for(let node=event.target?.nodeType===1?event.target:event.target?.parentElement;node&&nodes.length<32;node=node.parentElement||node.getRootNode?.().host)nodes.push(node);
    return nodes;
  }
  // Native metadata is optional. A stale React getter or Proxy must not abort
  // the capture listener or prevent a valid accessible control from working.
  const read=(value,key)=>{try{return value?.[key]}catch{return undefined}};
  const readPath=(value,...keys)=>keys.reduce((current,key)=>read(current,key),value);
  function models(node){
    let keys=[];try{keys=Object.keys(node)}catch{}
    const found=[],seen=new Set(),add=value=>{if(value&&typeof value==='object'&&!seen.has(value)){seen.add(value);found.push(value)}};
    add(read(node,keys.find(key=>key.startsWith('__reactProps'))));
    let fiber=read(node,keys.find(key=>key.startsWith('__reactFiber')));
    for(let count=0;fiber&&count<12;count++,fiber=read(fiber,'return')){const host=read(fiber,'stateNode');if(read(host,'nodeType')===1&&host!==node)break;add(read(fiber,'memoizedProps'))}
    return found;
  }
  function navigationLabel(value){
    if(typeof value!=='string'||value.length>160)return false;
    const label=value.replace(/[\s\u200b-\u200d\ufeff_-]/g,'').toLowerCase();
    return /^(?:(?:파일|사진|이미지|영상|동영상)(?:의)?)?(?:(?:원본|해당|이)?)?(?:대화|채팅|메시지|검색결과|인용메시지|답글원문)(?:위치|원문)?(?:로|으로)?(?:바로)?(?:가기|이동|보기)$/.test(label)||/^(?:handle)?(?:go(?:to)?|jump(?:to)?|move(?:to)?|showin)(?:the)?(?:message|conversation|chat|log)$/.test(label)||/^(?:open|select)searchresult$/.test(label);
  }
  function navigationAction(nodes){
    if(!nodes.length||editable(nodes[0]))return false;
    if(nodes.some(node=>node.matches('button:disabled,input:disabled,[aria-disabled="true"]')))return false;
    const explicit=nodes.some(node=>node.hasAttribute('data-dt-goto')&&node.getAttribute('data-dt-goto')!=='false');
    // Pack names and other Plus UI captions are user data, even when their
    // wording happens to match a native GoTo action. Only owned GoTo controls
    // carry the explicit marker; ordinary native Shadow controls remain valid.
    if(!explicit&&nodes.some(node=>node.matches('[id^="dooray-theme-"],.dt-emoticon-custom,.dt-emoticon-context-menu,.dt-emoticon-hover-preview,.dt-received-emoticon')))return false;
    let childHint=false;
    for(const node of nodes.slice(0,16)){
      if(node===document.body||node===document.documentElement||node.id==='root'||node.matches('[data-dp-native~="scroll"],.js-scroll-area,[contenteditable="true"]'))break;
      if(node.hasAttribute('data-dt-goto')&&node.getAttribute('data-dt-goto')!=='false')return true;
      const control=node.matches('button,[role="button"],a,[role="link"],[role="menuitem"],[role="option"]');
      if(control&&(childHint||[node.getAttribute('aria-label'),node.getAttribute('title'),node.textContent].some(navigationLabel)))return true;
      const props=models(node),hint=[node.getAttribute('data-action'),node.getAttribute('data-testid')];
      for(const p of props){for(const key of ['action','actionName','actionType','command','commandName','name','iconName','aria-label','title'])hint.push(read(p,key));const handler=read(p,'onClick'),name=read(handler,'name');if(typeof handler==='function'&&typeof name==='string')hint.push(name.replace(/^bound /,''))}
      const ownHint=hint.some(navigationLabel);
      if(control&&ownHint)return true;
      if(ownHint&&props.some(p=>typeof read(p,'onClick')==='function'))return true;
      childHint ||= ownHint;
    }
    return false;
  }
  const numeric=value=>(typeof value==='string'||typeof value==='number')&&/^\d+$/.test(String(value))?String(value):null;
  function navigationScope(nodes){
    const all=[...states.values()],owned=all.filter(state=>nodes.some(node=>node===state.scroll||state.scroll.contains(node)||state.editor?.contains(node)));
    if(owned.length)return owned;
    for(const node of nodes){
      if(node===document.body||node===document.documentElement)break;
      const enclosed=all.filter(state=>node.contains(state.scroll)||state.editor&&node.contains(state.editor));
      if(enclosed.length===1)return enclosed;
      if(enclosed.length>1)break;
    }
    let channel=null,thread=null,user=null;
    for(const node of nodes.slice(0,16)){
      const explicit=numeric(node.getAttribute('data-dt-navigation-channel'));
      if(explicit){channel=explicit;thread=numeric(node.getAttribute('data-dt-navigation-thread'));break;}
    }
    if(!channel)for(const node of nodes.slice(0,16)){
      if(node===document.body||node===document.documentElement||node.id==='root')break;
      for(const p of models(node)){
        const target=[read(p,'file'),read(p,'log')].find(value=>value&&numeric(read(value,'channelId')));
        if(target){channel=numeric(read(target,'channelId'));thread=numeric(read(target,'threadChannelId')??read(p,'threadChannelId'));user=numeric(readPath(p,'actions','stores','userStore','id'));break;}
      }
      if(channel)break;
    }
    if(channel){
      const matched=all.filter(state=>{const parts=typeof state.roomKey==='string'?state.roomKey.split('|'):[];return parts.length===4&&parts[0]===win.location?.origin&&numeric(parts[1])&&numeric(parts[2])&&parts[2]===channel&&(!thread||parts[3]===thread)&&(!user||parts[1]===user)});
      if(matched.length===1)return matched;
      return [];
    }
    return all.length===1?all:[];
  }
  function releaseNavigation(state){state.readingHold=null;state.readingNavigation=null;cancel(state);state.metrics=geometry(state.scroll);}
  function explicitNavigation(event,nodes=eventNodes(event)){
    if(!navigationAction(nodes))return false;
    for(const state of navigationScope(nodes))releaseNavigation(state);
    return true;
  }
  const key=event=>{
    if(disposed)return;refresh();
    if(!event.isComposing&&event.keyCode!==229&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&['Enter',' '].includes(event.key)&&explicitNavigation(event))return;
    for(const state of states.values())if(relevant(state,event.target)){
      if(editable(event.target)){
        if(!state.editor?.contains(event.target))continue;
        holdReading(state);
        if(!event.isComposing&&event.keyCode!==229&&event.key==='Enter'&&!event.shiftKey&&!event.ctrlKey&&!event.altKey&&!event.metaKey&&state.follow){state.unsettled=false;rememberTail(state,geometry(state.scroll));schedule(state)}
        continue;
      }
      if(event.isComposing||event.keyCode===229)continue;
      if(['ArrowUp','PageUp','Home'].includes(event.key)||event.key===' '&&event.shiftKey){readingGesture(state,-1);cancel(state);}
      else if(['ArrowDown','PageDown','End'].includes(event.key)||event.key===' '){readingGesture(state,1);state.allowRearm=true;}
      else readingGesture(state,0);
    }
  };
  const editorInput=event=>{if(disposed)return;refresh();for(const state of states.values())if(state.editor?.contains(event.target))holdReading(state);};
  // Native search/quote navigation wins over an old restore hint. Clicking or
  // editing a different pane must not release this pane's saved reading intent.
  const pointerIntent=event=>{
    if(disposed)return;refresh();const nodes=eventNodes(event);if(explicitNavigation(event,nodes))return;
    for(const state of navigationScope(nodes)){
      if(nodes.some(node=>state.editor?.contains(node))){holdReading(state);continue;}
      const message=nodes.find(node=>node.matches('[data-logid],[class*="js-log-right-content-"]'));
      const inside=nodes.some(node=>node===state.scroll||state.scroll.contains(node)),jump=!!message&&!inside;
      // Submit buttons can be siblings of the editor. An arbitrary click is
      // not permission to discard a saved reading position. A proven message
      // navigation releases the hold, including asynchronously loaded results.
      if(jump)releaseNavigation(state);
      else if(inside){state.tailHistory=[];state.readingHold=null;state.readingNavigation=null;state.revision++;}
    }
  };
  const pointerUp=()=>{for(const state of states.values())if(state.drag){state.drag=false;state.readingNavigation=null;if(near(geometry(state.scroll))){state.follow=true;state.readingHold=null;schedule(state)}else if(state.readingHold)state.readingHold=captureReading(state)}};
  const touchEnd=()=>{for(const state of states.values()){const moved=state.touchMoving;state.touchY=null;state.touchMoving=false;if(moved&&near(geometry(state.scroll))){state.follow=true;state.readingHold=null;state.readingNavigation=null;schedule(state)}else if(moved&&state.readingHold)state.readingHold=captureReading(state)}};
  const mutation=MutationObserver?new MutationObserver(records=>{
    if(disposed)return;for(const state of states.values())if(records.some(record=>relevant(state,record.target)))state.sizeDirty=true;
    refresh();for(const state of states.values())if(records.some(record=>relevant(state,record.target)))schedule(state);
  }):null;
  mutation?.observe(document.documentElement||document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','class','hidden']});
  const onLoad=event=>notifyLayout(event.target),onResize=()=>notifyLayout(),onFonts=()=>notifyLayout();
  document.addEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.addEventListener(event,editorInput,true);document.addEventListener('pointerdown',pointerIntent,true);document.addEventListener('click',pointerIntent,true);document.addEventListener('pointerup',pointerUp,true);document.addEventListener('pointercancel',pointerUp,true);document.addEventListener('touchend',touchEnd,true);document.addEventListener('touchcancel',touchEnd,true);document.addEventListener('load',onLoad,true);document.addEventListener('loadedmetadata',onLoad,true);win.addEventListener('resize',onResize);
  document.fonts?.addEventListener?.('loadingdone',onFonts);document.fonts?.ready?.then(()=>{if(!disposed)onFonts()}).catch(()=>{});
  refresh();
  return {
    refresh,beforeLayout,afterLayout,notifyLayout,
    isFollowing(node){if(disposed)return false;refresh();return [...states.values()].some(state=>relevant(state,node)&&state.follow)},
    diagnostics(){return {targets:states.size,following:[...states.values()].filter(state=>state.follow).length,pending:[...states.values()].filter(state=>state.frame).length,writes}},
    dispose(){if(disposed)return;disposed=true;mutation?.disconnect();resize?.disconnect();for(const state of [...states.values()])detach(state);document.removeEventListener('keydown',key,true);for(const event of ['beforeinput','input','compositionstart'])document.removeEventListener(event,editorInput,true);document.removeEventListener('pointerdown',pointerIntent,true);document.removeEventListener('click',pointerIntent,true);document.removeEventListener('pointerup',pointerUp,true);document.removeEventListener('pointercancel',pointerUp,true);document.removeEventListener('touchend',touchEnd,true);document.removeEventListener('touchcancel',touchEnd,true);document.removeEventListener('load',onLoad,true);document.removeEventListener('loadedmetadata',onLoad,true);win.removeEventListener('resize',onResize);document.fonts?.removeEventListener?.('loadingdone',onFonts);}
  };
}

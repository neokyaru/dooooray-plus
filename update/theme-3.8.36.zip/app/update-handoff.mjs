import fs from 'node:fs/promises';import path from 'node:path';import crypto from 'node:crypto';import {spawn,execFile} from 'node:child_process';import {fileURLToPath} from 'node:url';
import {atomicJSON,hash} from './update-store.mjs';
import {verifyNoticeDirectory,verifyNoticeFile} from './recovery-notice.mjs';
const signedDirectory=path.dirname(fileURLToPath(import.meta.url));
export const HANDOFF_PROGRESS_COMMAND="$ErrorActionPreference='Stop'; & ([ScriptBlock]::Create([IO.File]::ReadAllText($env:DOORAY_PLUS_UPDATE_NOTICE_SCRIPT)))";
const sidPattern=/^S-1-\d+(?:-\d+)+$/;
const installError=message=>Object.assign(Error('Installation metadata invalid: '+message),{code:'INSTALLATION_STATE_INVALID'});
function localPath(value){
 if(typeof value!=='string'||value.length>32760||!/^[a-z]:[\\/]/i.test(value)||/[\x00-\x1f<>"|?*]/.test(value)||value.slice(2).includes(':'))throw installError('로컬 절대 경로가 필요합니다.');
 const parts=value.slice(3).split(/[\\/]/);if(parts.some(part=>part==='.'||part==='..'||/[. ]$/.test(part)))throw installError('설치 경로 형식을 확인할 수 없습니다.');
 return path.resolve(value);
}
const samePath=(a,b)=>a.toLowerCase()===b.toLowerCase();
async function checkedPath(value,type){
 let current=value,first=true,result;
 while(true){
  const stat=await fs.lstat(current);
  if(stat.isSymbolicLink())throw installError('연결된 설치 경로는 사용할 수 없습니다.');
  if(first){result=stat;if(type==='directory'?!stat.isDirectory():!stat.isFile())throw installError('설치 경로의 파일 형식이 올바르지 않습니다.');}
  else if(!stat.isDirectory())throw installError('설치 경로의 상위 폴더를 확인할 수 없습니다.');
  const parent=path.dirname(current);if(parent===current)break;current=parent;first=false;
 }
 return result;
}
async function currentUserSid(){
 const executable=path.join(process.env.SystemRoot||'C:\\Windows','System32','whoami.exe');
 return new Promise((resolve,reject)=>execFile(executable,['/user','/fo','csv','/nh'],{windowsHide:true,timeout:5000,maxBuffer:8192,encoding:'utf8'},(error,stdout)=>{
  if(error){reject(installError('현재 사용자 SID를 확인하지 못했습니다.'));return;}
  const matches=stdout.match(/\bS-1-\d+(?:-\d+)+\b/g);if(matches?.length!==1){reject(installError('현재 사용자 SID를 확인하지 못했습니다.'));return;}resolve(matches[0]);
 }));
}
function stateField(xml,name){
 const opening=xml.match(new RegExp('<'+name+'(?=[\\s>/])','g'))||[],closing=xml.match(new RegExp('</'+name+'\\s*>','g'))||[];
 const values=[...xml.matchAll(new RegExp('<'+name+'>([^<]*)</'+name+'>','g'))];
 if(opening.length!==1||closing.length!==1||values.length!==1)throw installError(name+' 필드가 없거나 중복되었습니다.');
 const raw=values[0][1];
 if(raw.replace(/&(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);/g,'').includes('&'))throw installError('지원하지 않는 XML 엔티티입니다.');
 return raw.replace(/&(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);/g,(_,entity)=>{
  const named={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};if(Object.hasOwn(named,entity))return named[entity];
  const code=entity.startsWith('#x')?parseInt(entity.slice(2),16):Number(entity.slice(1));
  if(!Number.isSafeInteger(code)||code<32||code>0x10ffff||(code>=0xd800&&code<=0xdfff))throw installError('유효하지 않은 XML 문자입니다.');return String.fromCodePoint(code);
 });
}
export async function resolveInstallPaths(root,{getUserSid=currentUserSid,programFiles=process.env.ProgramW6432||process.env.ProgramFiles}={}){
 try{
 root=localPath(root);await checkedPath(root,'directory');const statePath=path.join(root,'install-state.xml');let xml;
 try{
  const stat=await checkedPath(statePath,'file');if(stat.size>65536)throw installError('설치 상태 파일을 확인할 수 없습니다.');
  xml=await fs.readFile(statePath,'utf8');
 }catch(error){
  if(error.code!=='ENOENT')throw error;
  if(path.basename(root).toLowerCase()!=='dooraytheme')throw installError('분리 설치 상태 파일이 없습니다.');
  const dooray=path.join(path.dirname(root),'DoorayMessenger.exe');await checkedPath(root,'directory');await checkedPath(dooray,'file');
  return {root,dooray,layout:'legacy',userSid:null};
 }
 xml=xml.replace(/^\uFEFF/,'').trim().replace(/^<\?xml\s[^?]*\?>\s*/,'');
 if(xml.includes('<!')||xml.includes('<?')||!/^<InstallState(?:\s[^>]*)?>[\s\S]*<\/InstallState>$/.test(xml))throw installError('설치 상태 XML을 확인할 수 없습니다.');
 const recordedRoot=localPath(stateField(xml,'InstallDirectory')),dooray=localPath(stateField(xml,'DoorayPath')),userSid=stateField(xml,'UserSid');
 if(!samePath(recordedRoot,root)||!sidPattern.test(userSid)||userSid!==await getUserSid())throw installError('설치 루트 또는 사용자 SID가 일치하지 않습니다.');
 if(path.basename(dooray).toLowerCase()!=='dooraymessenger.exe')throw installError('두레이 실행 파일 이름이 올바르지 않습니다.');
 const legacyRoot=path.join(path.dirname(dooray),'DoorayTheme');let layout;
 if(samePath(root,legacyRoot))layout='legacy';
 else if(samePath(root,path.join(localPath(programFiles),'Dooray Plus',userSid)))layout='independent-user-v1';
 else throw installError('허용된 두레이 플러스 설치 경로가 아닙니다.');
 if(layout==='independent-user-v1'&&dooray.toLowerCase().startsWith(root.toLowerCase()+path.sep))throw installError('두레이 본체와 플러스 설치 폴더는 분리되어야 합니다.');
 await checkedPath(dooray,'file');
 return {root,dooray,layout,userSid};
 }catch(error){if(error.message?.startsWith('Installation metadata invalid:'))throw error;throw installError('설치 상태 또는 실행 파일을 읽고 검증하지 못했습니다.');}
}
export async function prepareHandoff({root,data,version,kind,installer},pathOptions){
 const paths=await resolveInstallPaths(root,pathOptions);root=paths.root;const dooray=paths.dooray;
 const token=crypto.randomUUID(),dir=path.join(data,'handoffs',token);await fs.mkdir(dir,{recursive:true});
 const config={token,version,kind,dooray,root,data,installer:installer||null,createdAt:Date.now()};
 await fs.writeFile(path.join(dir,'run.ps1'),'\ufeff'+(await fs.readFile(path.join(path.dirname(fileURLToPath(import.meta.url)),'update-handoff.ps1'),'utf8')).replace(/^\ufeff/,''),'utf8');
 await atomicJSON(path.join(dir,'job.json'),config);return {token,dir,config};
}
// A separate GUI process stays responsive while the helper waits for Setup/UAC
// and survives the feature process stopping. It can only observe the fixed job.
export async function startHandoffProgress(job,spawnProcess=spawn,{filesystem=fs,directory=signedDirectory,environment=process.env}={}){
 directory=path.resolve(directory);const script=path.join(directory,'update-notice.ps1');
 await verifyNoticeDirectory(directory,filesystem);const stat=await verifyNoticeFile(script,filesystem);if(stat.size>256*1024)throw Error('Update progress script too large');
 const exe=path.join(environment.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const args=['-NoLogo','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-STA','-EncodedCommand',Buffer.from(HANDOFF_PROGRESS_COMMAND,'utf16le').toString('base64')];
 const child=spawnProcess(exe,args,{windowsHide:true,detached:false,stdio:'ignore',env:{...environment,DOORAY_PLUS_UPDATE_NOTICE_SCRIPT:script,DOORAY_PLUS_UPDATE_NOTICE_FILE:'',DOORAY_PLUS_HANDOFF_JOB_FILE:path.join(job.dir,'job.json')}});
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Update progress spawn timeout')),3000);child.once('spawn',()=>{clearTimeout(timer);resolve()});child.once('error',error=>{clearTimeout(timer);reject(error)})});child.unref?.();
}
export async function startHandoff(job,spawnProcess=spawn,ensureAuthorized=()=>{},startProgress=startHandoffProgress){
 if(Date.now()-job.config.createdAt>15*60*1000)throw Error('업데이트 준비 시간이 만료되었습니다. 다시 확인해 주세요.');
 if(job.config.installer&&hash(await fs.readFile(job.config.installer.file))!==job.config.installer.sha256)throw Error('Installer verification failed');
 const exe=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const stderr=await fs.open(path.join(job.dir,'helper-stderr.log'),'a'),stdout=await fs.open(path.join(job.dir,'helper-stdout.log'),'a');
 let child,exited=false,exitCode=null,exitSignal=null;
 // Detached PowerShell may exit 0 before executing -File on Windows without a console.
 // A detached hidden cmd owns the console; encoded PowerShell avoids shell interpretation of job paths.
 const quotePS=value=>"'"+value.replaceAll("'","''")+"'";
 const command='& '+quotePS(path.join(job.dir,'run.ps1'))+' -Job '+quotePS(path.join(job.dir,'job.json'));
 const encoded=Buffer.from(command,'utf16le').toString('base64');
 const wrapper=path.join(process.env.SystemRoot||'C:\\Windows','System32','cmd.exe');
 try{
  child=spawnProcess(wrapper,['/d','/s','/c','""'+exe+'" -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -STA -ExecutionPolicy Bypass -EncodedCommand '+encoded+'"'],{detached:true,windowsHide:true,windowsVerbatimArguments:true,stdio:['ignore',stdout.fd,stderr.fd]});
  child.once('exit',(code,signal)=>{exited=true;exitCode=code;exitSignal=signal});
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject)});child.unref();
 }finally{await stdout.close();await stderr.close()}
 const deadline=Date.now()+20000;
 while(Date.now()<deadline){
  let result;try{result=JSON.parse((await fs.readFile(path.join(job.dir,'result.json'),'utf8')).replace(/^\ufeff/,''))}catch{}
  if(result?.phase==='ready'&&result.version===job.config.version&&result.token===job.token){
   try{await startProgress(job)}catch{try{await fs.appendFile(path.join(job.dir,'helper-stdout.log'),new Date().toISOString()+' progress-ui unavailable\n')}catch{}}
   if(exited)throw Error('업데이트 도우미가 종료되어 시작을 확인하지 못했습니다. 두레이는 종료하지 않았습니다.');
   const ready=JSON.parse((await fs.readFile(path.join(job.dir,'result.json'),'utf8')).replace(/^\ufeff/,''));
   if(exited||ready?.phase!=='ready'||ready.version!==job.config.version||ready.token!==job.token||Date.now()-job.config.createdAt>15*60*1000)throw Error('업데이트 도우미의 준비 상태가 변경되었습니다. 두레이는 종료하지 않았습니다.');
   await ensureAuthorized();
   if(exited)throw Error('업데이트 도우미가 종료되어 시작을 확인하지 못했습니다. 두레이는 종료하지 않았습니다.');
   await fs.writeFile(path.join(job.dir,'proceed.flag'),job.token,{flag:'wx'});return;
  }
  if(result?.phase==='error')throw Error(result.message||'업데이트 도우미 시작 실패');
  if(exited)break;
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 throw Error('업데이트 도우미의 시작을 확인하지 못했습니다. 두레이는 종료하지 않았습니다. '+(exited?'종료 코드: '+exitCode+(exitSignal?' ('+exitSignal+')':'')+'. ':'준비 대기 시간 초과. ')+path.join(job.dir,'helper-stderr.log')+'를 확인해 주세요.');
}

﻿# Windows PowerShell 5.1. The user approves this one-shot recovery in the notice UI.
# This helper never changes Plus flags, release state, tasks, registry or security.
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'

function Initialize-RecoveryRestartNative {
    if ('RecoveryNative' -as [type]) { return }
    # Adapted from the signed update handoff: held limited-query process handles
    # prove path/token/session/creation identity before any native window request.
    Add-Type -TypeDefinition @'
using System;using System.Linq;
internal abstract class RecoveryProcessBackend {
 internal abstract IntPtr Open(int id);
 internal abstract uint Wait(IntPtr process);
 internal abstract bool? PidExists(int id);
 internal abstract bool Path(IntPtr process,out string value);
 internal abstract bool Token(IntPtr process,out IntPtr token);
 internal abstract bool Started(IntPtr process,out long value);
 internal abstract bool Session(IntPtr token,out int value);
 internal abstract bool Elevated(IntPtr token,out int value);
 internal abstract bool Owner(IntPtr token,out string value);
 internal abstract int CurrentSession {get;}
 internal abstract string CurrentOwner {get;}
 internal abstract void Close(IntPtr handle);
}
public static class RecoveryNative {
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr menu);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr menu,int position);
 [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern int GetMenuString(IntPtr menu,uint item,System.Text.StringBuilder text,int length,uint flags);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool PostMessage(IntPtr window,uint message,UIntPtr wparam,IntPtr lparam);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr window,int command);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
 [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)] struct Rect {public int Left,Top,Right,Bottom;}
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr window,out Rect rect);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int processId);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process,int flags,System.Text.StringBuilder path,ref int size);
 [System.Runtime.InteropServices.DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
 [System.Runtime.InteropServices.DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr token,int informationClass,out int information,int length,out int returnLength);
 [System.Runtime.InteropServices.DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr process,out long created,out long exited,out long kernel,out long user);
 delegate bool EnumWindowProc(IntPtr window,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowProc callback,IntPtr data);
 [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
 sealed class NativeProcessProbe : RecoveryProcessBackend {
  internal override IntPtr Open(int id){return OpenProcess(0x00100000|0x1000,false,id);}
  internal override uint Wait(IntPtr process){return WaitForSingleObject(process,0);}
  internal override bool? PidExists(int id){
   System.Diagnostics.Process[] processes=null;
   try{processes=System.Diagnostics.Process.GetProcesses();foreach(var process in processes)if(process.Id==id)return true;return false;}
   catch{return null;}finally{if(processes!=null)foreach(var process in processes)process.Dispose();}
  }
  internal override bool Path(IntPtr process,out string value){var name=new System.Text.StringBuilder(32768);int size=name.Capacity;bool ok=QueryFullProcessImageName(process,0,name,ref size);value=ok?name.ToString():null;return ok;}
  internal override bool Token(IntPtr process,out IntPtr token){return OpenProcessToken(process,8,out token);}
  internal override bool Started(IntPtr process,out long value){long exited,kernel,user;return GetProcessTimes(process,out value,out exited,out kernel,out user)&&value>0;}
  internal override bool Session(IntPtr token,out int value){int returned;return GetTokenInformation(token,12,out value,sizeof(int),out returned)&&returned>=sizeof(int);}
  internal override bool Elevated(IntPtr token,out int value){int returned;return GetTokenInformation(token,20,out value,sizeof(int),out returned)&&returned>=sizeof(int);}
  internal override bool Owner(IntPtr token,out string value){using(var owner=new System.Security.Principal.WindowsIdentity(token)){value=owner.User==null?null:owner.User.Value;return value!=null;}}
  internal override int CurrentSession {get{using(var current=System.Diagnostics.Process.GetCurrentProcess())return current.SessionId;}}
  internal override string CurrentOwner {get{using(var current=System.Security.Principal.WindowsIdentity.GetCurrent())return current.User==null?null:current.User.Value;}}
  internal override void Close(IntPtr handle){CloseHandle(handle);}
 }
 public sealed class RecoveryLease : IDisposable {
  internal RecoveryProcessBackend Backend;internal IntPtr Process,Token;public string Status="unknown";public int Id;public long StartedAt;
  internal bool Alive(){return Process!=IntPtr.Zero&&Backend.Wait(Process)==258;}
  public void Dispose(){try{if(Token!=IntPtr.Zero)Backend.Close(Token);}finally{Token=IntPtr.Zero;if(Process!=IntPtr.Zero)Backend.Close(Process);Process=IntPtr.Zero;}}
 }
 static string VerifiedState(RecoveryLease lease,string aliveState){uint state=lease.Backend.Wait(lease.Process);return state==0?"gone":state==258?aliveState:"unknown";}
 internal static RecoveryLease OpenIdentity(int id,string expected,RecoveryProcessBackend backend){
  var lease=new RecoveryLease{Backend=backend,Id=id};
  try{
   if(id<=0||String.IsNullOrWhiteSpace(expected)||!System.IO.Path.IsPathRooted(expected))return lease;
   expected=System.IO.Path.GetFullPath(expected);
   lease.Process=backend.Open(id);
   // OpenProcess errors (including ERROR_INVALID_PARAMETER) are not proof of
   // death. Only a successful fresh PID snapshot can establish absence here.
   if(lease.Process==IntPtr.Zero){lease.Status=backend.PidExists(id)==false?"gone":"unknown";return lease;}
   uint initial=backend.Wait(lease.Process);if(initial!=258){lease.Status=initial==0?"gone":"unknown";return lease;}
   string actual;if(!backend.Path(lease.Process,out actual)||String.IsNullOrWhiteSpace(actual)){lease.Status=VerifiedState(lease,"unknown");return lease;}
   if(!String.Equals(System.IO.Path.GetFullPath(actual),expected,StringComparison.OrdinalIgnoreCase)){lease.Status=VerifiedState(lease,"other");return lease;}
   if(!backend.Token(lease.Process,out lease.Token)||lease.Token==IntPtr.Zero){lease.Status=VerifiedState(lease,"unknown");return lease;}
   int session;if(!backend.Session(lease.Token,out session)){lease.Status=VerifiedState(lease,"unknown");return lease;}
   if(session!=backend.CurrentSession){lease.Status=VerifiedState(lease,"other");return lease;}
   int elevated;if(!backend.Elevated(lease.Token,out elevated)||elevated!=0){lease.Status=VerifiedState(lease,"unknown");return lease;}
   string owner,current=backend.CurrentOwner;if(!backend.Owner(lease.Token,out owner)||String.IsNullOrEmpty(current)||!String.Equals(owner,current,StringComparison.Ordinal)){lease.Status=VerifiedState(lease,"unknown");return lease;}
   if(!backend.Started(lease.Process,out lease.StartedAt)||lease.StartedAt<=0){lease.Status=VerifiedState(lease,"unknown");return lease;}
   lease.Status=VerifiedState(lease,"matching");return lease;
  }catch{if(lease.Process!=IntPtr.Zero)try{lease.Status=VerifiedState(lease,"unknown");}catch{lease.Status="unknown";}return lease;}
 }
 internal static string InspectWithBackend(int id,string expected,RecoveryProcessBackend backend){using(var lease=OpenIdentity(id,expected,backend))return lease.Status;}
 internal static bool WithMatchingProcess(int id,string expected,RecoveryProcessBackend backend,Func<RecoveryLease,bool> action){using(var lease=OpenIdentity(id,expected,backend)){return lease.Status=="matching"&&lease.Alive()&&action(lease);}}
 public static string Inspect(int id,string expected){return InspectWithBackend(id,expected,new NativeProcessProbe());}
 static bool SameLiveWindow(RecoveryLease lease,IntPtr window){uint pid;GetWindowThreadProcessId(window,out pid);return pid==(uint)lease.Id&&lease.Alive();}
 static uint? ExitCommand(IntPtr menu){
  if(menu==IntPtr.Zero)return null;
  for(int i=0;i<GetMenuItemCount(menu);i++){
   var text=new System.Text.StringBuilder(256);GetMenuString(menu,(uint)i,text,text.Capacity,0x400);
   string label=System.Text.RegularExpressions.Regex.Replace(text.ToString(),@"\(&.\)|&|\t.*","").Trim();
   if(new[]{"끝내기","종료","Exit","Quit"}.Any(value=>String.Equals(value,label,StringComparison.OrdinalIgnoreCase))){uint command=GetMenuItemID(menu,i);if(command!=UInt32.MaxValue)return command;}
   var child=ExitCommand(GetSubMenu(menu,i));if(child.HasValue)return child;
  }return null;
 }
 public static bool SafeCaller(){using(var identity=System.Security.Principal.WindowsIdentity.GetCurrent()){return !new System.Security.Principal.WindowsPrincipal(identity).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);}}
 public static bool Matches(int id,string expected){return Inspect(id,expected)=="matching";}
 public static bool Restore(RecoveryLease lease){if(lease==null||lease.Status!="matching"||!lease.Alive())return false;
  bool found=false;EnumWindows((window,data)=>{if(!lease.Alive())return false;if(SameLiveWindow(lease,window)&&GetMenu(window)!=IntPtr.Zero){
   if((!IsWindowVisible(window)||IsIconic(window))&&SameLiveWindow(lease,window))ShowWindowAsync(window,9);
   if(SameLiveWindow(lease,window))SetForegroundWindow(window);Rect rect;
   found=SameLiveWindow(lease,window)&&IsWindowVisible(window)&&!IsIconic(window)&&GetWindowRect(window,out rect)&&rect.Right>rect.Left&&rect.Bottom>rect.Top;if(found)return false;
  }return true;},IntPtr.Zero);return found;
 }
 public static bool Request(RecoveryLease lease){if(lease==null||lease.Status!="matching"||!lease.Alive())return false;
  bool requested=false;EnumWindows((window,data)=>{if(!lease.Alive())return false;if(!SameLiveWindow(lease,window))return true;IntPtr menu=GetMenu(window);if(menu==IntPtr.Zero)return true;
   uint? command=ExitCommand(menu);if(SameLiveWindow(lease,window))requested=command.HasValue?PostMessage(window,0x111,new UIntPtr(command.Value),IntPtr.Zero):PostMessage(window,0x10,UIntPtr.Zero,IntPtr.Zero);
   return !requested;
  },IntPtr.Zero);return requested;
 }
 public static string LeaseState(RecoveryLease lease){if(lease==null||lease.Process==IntPtr.Zero)return "unknown";return VerifiedState(lease,lease.Status);}
 public static RecoveryLease[] Snapshot(string expected){
  var leases=new System.Collections.Generic.List<RecoveryLease>();System.Diagnostics.Process[] processes=null;
  try{processes=System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(expected));foreach(var process in processes)leases.Add(OpenIdentity(process.Id,expected,new NativeProcessProbe()));return leases.ToArray();}
  catch{foreach(var lease in leases)lease.Dispose();throw;}finally{if(processes!=null)foreach(var process in processes)process.Dispose();}
 }
 public static string CurrentSid {get{using(var identity=System.Security.Principal.WindowsIdentity.GetCurrent())return identity.User.Value;}}
 public static int SessionId {get{using(var process=System.Diagnostics.Process.GetCurrentProcess())return process.SessionId;}}
 public static bool NormalToken(){IntPtr token=IntPtr.Zero;try{using(var process=System.Diagnostics.Process.GetCurrentProcess()){if(!OpenProcessToken(process.Handle,8,out token))return false;int elevated,returned;return GetTokenInformation(token,20,out elevated,4,out returned)&&returned>=4&&elevated==0;}}finally{if(token!=IntPtr.Zero)CloseHandle(token);}}
 public static bool HasStandardExplorer(){var leases=Snapshot(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"explorer.exe"));try{foreach(var lease in leases)if(lease.Status=="matching"&&lease.Alive())return true;return false;}finally{foreach(var lease in leases)lease.Dispose();}}
 public static void Start(string executable){if(!NormalToken()||SessionId<=0||!HasStandardExplorer())throw new InvalidOperationException("identity-unavailable");var start=new System.Diagnostics.ProcessStartInfo(executable){UseShellExecute=false,WorkingDirectory=System.IO.Path.GetDirectoryName(executable),Arguments="",WindowStyle=System.Diagnostics.ProcessWindowStyle.Normal};using(var process=System.Diagnostics.Process.Start(start)){if(process==null)throw new InvalidOperationException("reopen-timeout");}}
}
'@
}

function Assert-RecoveryRestartPath([string]$Path,[bool]$File) {
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path -notmatch '^[A-Za-z]:\\' -or $Path.IndexOf(':',2) -ge 0 -or $Path.IndexOfAny([IO.Path]::GetInvalidPathChars()) -ge 0) { throw 'identity-unavailable' }
    $full=[IO.Path]::GetFullPath($Path)
    if (-not [string]::Equals($full,$Path,[StringComparison]::OrdinalIgnoreCase)) { throw 'identity-unavailable' }
    $cursor=$full
    while ($cursor) {
        if (-not [IO.File]::Exists($cursor) -and -not [IO.Directory]::Exists($cursor)) { throw 'identity-unavailable' }
        $attributes=[IO.File]::GetAttributes($cursor)
        if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'identity-unavailable' }
        $parent=[IO.Path]::GetDirectoryName($cursor)
        if ([string]::Equals($parent,$cursor,[StringComparison]::OrdinalIgnoreCase)) { break }
        $cursor=$parent
    }
    if ($File -ne [IO.File]::Exists($full)) { throw 'identity-unavailable' }
    return $full
}
function Read-RecoveryRestartJSON([string]$Path) {
    $null=Assert-RecoveryRestartPath $Path $true
    $stream=$null;$reader=$null
    try {
        $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        if ($stream.Length -lt 2 -or $stream.Length -gt 65536) { throw 'request-expired' }
        $reader=New-Object IO.StreamReader($stream,(New-Object Text.UTF8Encoding($false,$true)),$true)
        $record=$reader.ReadToEnd() | ConvertFrom-Json
        if ($record -isnot [Management.Automation.PSCustomObject]) { throw 'request-expired' }
        return $record
    } finally { if ($reader) { $reader.Dispose() } elseif ($stream) { $stream.Dispose() } }
}
function Assert-RecoveryRestartFields($Record,[string[]]$Fields) {
    $names=@($Record.PSObject.Properties.Name)
    if ($names.Count -ne $Fields.Count) { throw 'request-expired' }
    foreach ($name in $names) { if ($name -cnotin $Fields) { throw 'request-expired' } }
}
function Assert-RecoveryRestartInstallation($Checked) {
    $job=$Checked.Job
    $root=Assert-RecoveryRestartPath $job.root $false
    $dooray=Assert-RecoveryRestartPath $job.dooray $true
    if ([IO.Path]::GetFileName($dooray) -ine 'DoorayMessenger.exe') { throw 'identity-unavailable' }
    $independent=[IO.Path]::Combine($Checked.ProgramFiles,'Dooray Plus',$job.userSid)
    $legacy=[IO.Path]::Combine([IO.Path]::GetDirectoryName($dooray),'DoorayTheme')
    if (-not [string]::Equals($root,$independent,[StringComparison]::OrdinalIgnoreCase) -and -not [string]::Equals($root,$legacy,[StringComparison]::OrdinalIgnoreCase)) { throw 'identity-unavailable' }
    if ([string]::Equals($root,$independent,[StringComparison]::OrdinalIgnoreCase) -and $dooray.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'identity-unavailable' }
    $null=Assert-RecoveryRestartPath ([IO.Path]::Combine($root,'.dooray-theme-owned')) $true
    $state=Assert-RecoveryRestartPath ([IO.Path]::Combine($root,'install-state.xml')) $true
    if ((New-Object IO.FileInfo($state)).Length -gt 65536) { throw 'identity-unavailable' }
    $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null;$settings.MaxCharactersInDocument=65536
    $reader=$null
    try {
        $reader=[Xml.XmlReader]::Create($state,$settings);$xml=New-Object Xml.XmlDocument;$xml.XmlResolver=$null;$xml.Load($reader)
        if ($xml.DocumentElement.Name -cne 'InstallState') { throw 'identity-unavailable' }
        foreach ($pair in @(@('UserSid',$job.userSid),@('InstallDirectory',$root),@('DoorayPath',$dooray))) {
            $nodes=@($xml.DocumentElement.SelectNodes($pair[0]))
            if ($nodes.Count -ne 1 -or $nodes[0].ChildNodes.Count -ne 1 -or $nodes[0].FirstChild.NodeType -ne [Xml.XmlNodeType]::Text -or -not [string]::Equals($nodes[0].InnerText,$pair[1],[StringComparison]::OrdinalIgnoreCase)) { throw 'identity-unavailable' }
        }
    } finally { if ($reader) { $reader.Dispose() } }
}
function Get-ValidatedRecoveryRestartJob([string]$Path,[string]$LocalData,[string]$Sid,[bool]$Elevated,[int]$WindowsSession,[long]$Now,[string]$ProgramFiles) {
    if ($Elevated -or $WindowsSession -le 0 -or $Sid -notmatch '^S-1-[0-9]+(?:-[0-9]+)+$' -or $Sid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) { throw 'identity-unavailable' }
    $file=Assert-RecoveryRestartPath $Path $true
    $dir=[IO.Path]::GetDirectoryName($file);$token=[IO.Path]::GetFileName($dir)
    $data=[IO.Path]::Combine([IO.Path]::GetFullPath($LocalData),'DoorayTheme')
    if ([IO.Path]::GetFileName($file) -cne 'job.json' -or $token -notmatch '^[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$' -or -not [string]::Equals([IO.Path]::GetDirectoryName($dir),[IO.Path]::Combine($data,'recovery-jobs'),[StringComparison]::OrdinalIgnoreCase)) { throw 'identity-unavailable' }
    $job=Read-RecoveryRestartJSON $file
    Assert-RecoveryRestartFields $job @('schema','token','noticeToken','session','userSid','windowsSession','version','root','dooray','createdAt')
    if ($job.schema -isnot [int] -or $job.schema -ne 1 -or $job.windowsSession -isnot [int] -or $job.windowsSession -ne $WindowsSession -or $job.userSid -isnot [string] -or $job.userSid -cne $Sid) { throw 'identity-unavailable' }
    foreach ($name in @('token','noticeToken','session')) { if ($job.$name -isnot [string] -or $job.$name -notmatch '^[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$') { throw 'request-expired' } }
    if (-not [string]::Equals($job.token,$token,[StringComparison]::OrdinalIgnoreCase) -or $job.version -isnot [string] -or $job.version -notmatch '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$') { throw 'request-expired' }
    if (($job.createdAt -isnot [long] -and $job.createdAt -isnot [int]) -or $job.createdAt -lt $Now-30000 -or $job.createdAt -gt $Now+5000) { throw 'request-expired' }
    if ($job.root -isnot [string] -or $job.dooray -isnot [string]) { throw 'identity-unavailable' }
    $checked=[pscustomobject]@{Job=$job;Path=$file;Directory=$dir;Data=$data;ProgramFiles=[IO.Path]::GetFullPath($ProgramFiles)}
    Assert-RecoveryRestartInstallation $checked
    return $checked
}
function Test-RecoveryRestartProceed($Checked,$Record,[long]$Now) {
    Assert-RecoveryRestartFields $Record @('schema','token','session','userSid','windowsSession','version','at','action')
    if ($Record.schema -isnot [int] -or $Record.schema -ne 1 -or $Record.windowsSession -isnot [int] -or $Record.windowsSession -ne $Checked.Job.windowsSession -or $Record.action -isnot [string] -or $Record.action -cne 'restart') { throw 'request-expired' }
    foreach ($name in @('token','session','userSid','version')) { if ($Record.$name -isnot [string] -or $Record.$name -cne $Checked.Job.$name) { throw 'request-expired' } }
    if (($Record.at -isnot [long] -and $Record.at -isnot [int]) -or $Record.at -lt $Checked.Job.createdAt -or $Record.at -lt $Now-30000 -or $Record.at -gt $Now+5000) { throw 'request-expired' }
    return $true
}
function Write-RecoveryRestartRecord($Checked,[string]$Phase,[string]$Code='') {
    if ($Phase -cnotin @('ready','closing','reopening','complete','error')) { throw 'recovery-failed' }
    if ($Code -cnotin @('','identity-unavailable','close-timeout','reopen-timeout','request-expired','cancelled','stop-requested','recovery-failed','restart-complete')) { throw 'recovery-failed' }
    $null=Assert-RecoveryRestartPath $Checked.Directory $false
    $file=[IO.Path]::Combine($Checked.Directory,$(if ($Phase -ceq 'ready') {'ready.json'}else{'result.json'}))
    if ([IO.File]::Exists($file) -or [IO.Directory]::Exists($file)) { $null=Assert-RecoveryRestartPath $file $true }
    $job=$Checked.Job;$record=[ordered]@{schema=1;token=$job.token;session=$job.session;userSid=$job.userSid;windowsSession=$job.windowsSession;version=$job.version;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();phase=$Phase}
    if ($Phase -cne 'ready') { $record.code=$Code }
    $temporary=$file+'.'+[Guid]::NewGuid().ToString('N')+'.tmp';$stream=$null
    try {
        $bytes=(New-Object Text.UTF8Encoding($false)).GetBytes(($record | ConvertTo-Json -Compress))
        $stream=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);$stream.Write($bytes,0,$bytes.Length);$stream.Dispose();$stream=$null
        if ([IO.File]::Exists($file)) { [IO.File]::Replace($temporary,$file,[Management.Automation.Language.NullString]::Value) } else { [IO.File]::Move($temporary,$file) }
    } finally { if ($stream) {$stream.Dispose()};if ([IO.File]::Exists($temporary)) {[IO.File]::Delete($temporary)} }
}
function New-RecoveryRestartBackend($Clock) {
    $now={return $Clock.ElapsedMilliseconds}.GetNewClosure()
    return @{
        Now=$now; Utc={return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}; Sleep={param($ms) Start-Sleep -Milliseconds $ms}
        Validate={param($c) if (-not [RecoveryNative]::NormalToken() -or [RecoveryNative]::CurrentSid -cne $c.Job.userSid -or [RecoveryNative]::SessionId -ne $c.Job.windowsSession) {throw 'identity-unavailable'};Assert-RecoveryRestartInstallation $c}
        Stop={param($c) foreach ($name in @('stop-agent.flag','theme-disabled.flag')) {$p=[IO.Path]::Combine($c.Data,$name);if ([IO.File]::Exists($p) -or [IO.Directory]::Exists($p)) {return $true}};return $false}
        ReadProceed={param($c) $p=[IO.Path]::Combine($c.Directory,'proceed.json');if ([IO.File]::Exists($p) -or [IO.Directory]::Exists($p)) {return (Read-RecoveryRestartJSON $p)};return $null}
        Claim={param($c) $null=Assert-RecoveryRestartPath $c.Directory $false;$f=[IO.File]::Open([IO.Path]::Combine($c.Directory,'started.flag'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);$f.Dispose()}
        Record={param($c,$phase,$code) Write-RecoveryRestartRecord $c $phase $code}
        Snapshot={param($c) return [RecoveryNative]::Snapshot($c.Job.dooray)}
        State={param($lease) return [RecoveryNative]::LeaseState($lease)}
        Request={param($lease) return [RecoveryNative]::Request($lease)}
        Restore={param($lease) return [RecoveryNative]::Restore($lease)}
        Start={param($c) [RecoveryNative]::Start($c.Job.dooray)}
        Dispose={param($lease) $lease.Dispose()}
    }
}
function Get-RecoveryRestartLeases($Checked,$Backend) {
    $leases=@(& $Backend.Snapshot $Checked)
    try { foreach ($lease in $leases) {if ((& $Backend.State $lease) -cnotin @('matching','gone','other')) {throw 'identity-unavailable'}};return ,$leases }
    catch {foreach ($lease in $leases) {& $Backend.Dispose $lease};throw}
}
function Invoke-RecoveryReopen($Checked,$Backend,[long]$Deadline) {
    $launched=$false
    while ((& $Backend.Now) -lt $Deadline) {
        & $Backend.Validate $Checked
        $leases=Get-RecoveryRestartLeases $Checked $Backend
        try {
            $running=@($leases | Where-Object { (& $Backend.State $_) -ceq 'matching' })
            foreach ($lease in $running) {if (& $Backend.Restore $lease) {return}}
            if (-not $launched) {& $Backend.Start $Checked;$launched=$true}
        } finally {foreach ($lease in $leases) {& $Backend.Dispose $lease}}
        & $Backend.Sleep 250
    }
    throw 'reopen-timeout'
}
function Invoke-RecoveryRestartCore($Checked,$Backend) {
    $begin=& $Backend.Now;$overall=$begin+90000;$closed=$false;$authorized=$false;$closeRequested=$false;$reopenDeadline=$null
    try {
        if (& $Backend.Stop $Checked) {throw 'stop-requested'}
        & $Backend.Validate $Checked
        & $Backend.Record $Checked 'ready' ''
        while ($true) {
            if (& $Backend.Stop $Checked) {throw 'stop-requested'}
            if ((& $Backend.Now) -ge $begin+30000) {throw 'request-expired'}
            $proceed=& $Backend.ReadProceed $Checked
            if ((& $Backend.Now) -ge $begin+30000) {throw 'request-expired'}
            if ($null -ne $proceed) {$null=Test-RecoveryRestartProceed $Checked $proceed (& $Backend.Utc);break}
            & $Backend.Sleep 100
        }
        if (& $Backend.Stop $Checked) {throw 'stop-requested'}
        & $Backend.Validate $Checked
        try {& $Backend.Claim $Checked} catch {throw 'request-expired'}
        $authorized=$true;$closeDeadline=[Math]::Min($overall,((& $Backend.Now)+30000));$leases=Get-RecoveryRestartLeases $Checked $Backend
        try {
            if (& $Backend.Stop $Checked) {throw 'stop-requested'}
            & $Backend.Record $Checked 'closing' '';$closeRequested=$true
            foreach ($lease in $leases) {if ((& $Backend.Now) -ge $closeDeadline) {throw 'close-timeout'};if ((& $Backend.State $lease) -ceq 'matching') {$null=& $Backend.Request $lease}}
        } finally {foreach ($lease in $leases) {& $Backend.Dispose $lease}}
        while ($true) {
            $leases=Get-RecoveryRestartLeases $Checked $Backend
            try {$running=@($leases | Where-Object {(& $Backend.State $_) -ceq 'matching'}).Count} finally {foreach ($lease in $leases) {& $Backend.Dispose $lease}}
            if ($running -eq 0) {$closed=$true;break}
            if (& $Backend.Stop $Checked) {throw 'stop-requested'}
            if ((& $Backend.Now) -ge $closeDeadline) {throw 'close-timeout'}
            & $Backend.Sleep 250
        }
        if (& $Backend.Stop $Checked) {throw 'stop-requested'}
        $reopenDeadline=[Math]::Min($overall,((& $Backend.Now)+30000))
        & $Backend.Record $Checked 'reopening' ''
        Invoke-RecoveryReopen $Checked $Backend $reopenDeadline
        & $Backend.Record $Checked 'complete' 'restart-complete'
        return $true
    } catch {
        $code=$_.Exception.Message
        if ($code -cnotin @('identity-unavailable','close-timeout','reopen-timeout','request-expired','cancelled','stop-requested')) {$code='recovery-failed'}
        # Only after user authorization and proven native exit may error recovery
        # reopen the native app. Keep explicit Plus stop flags intact.
        if ($authorized -and $closeRequested -and -not $closed) {
            try {$leases=Get-RecoveryRestartLeases $Checked $Backend;try {$closed=@($leases | Where-Object {(& $Backend.State $_) -ceq 'matching'}).Count -eq 0} finally {foreach ($lease in $leases) {& $Backend.Dispose $lease}}} catch {}
        }
        if ($closed -and (& $Backend.Now) -lt $overall) {
            if ($null -eq $reopenDeadline) {$reopenDeadline=[Math]::Min($overall,((& $Backend.Now)+30000))}
            try {Invoke-RecoveryReopen $Checked $Backend $reopenDeadline} catch {}
        }
        try {& $Backend.Record $Checked 'error' $code} catch {}
        return $false
    }
}
function Start-RecoveryRestart([string]$JobPath) {
    $clock=[Diagnostics.Stopwatch]::StartNew();$guard=$null;$jobGuard=$null;$owns=$false;$ownsJob=$false;$checked=$null;$canWrite=$false
    try {
        Initialize-RecoveryRestartNative
        $programFiles=$env:ProgramW6432;if (-not $programFiles) {$programFiles=$env:ProgramFiles}
        $checked=Get-ValidatedRecoveryRestartJob $JobPath $env:LOCALAPPDATA ([RecoveryNative]::CurrentSid) (-not [RecoveryNative]::NormalToken()) ([RecoveryNative]::SessionId) ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) $programFiles
        $guard=New-Object Threading.Mutex($false,'Local\DoorayPlus-UpdateHandoff')
        try {$owns=$guard.WaitOne(0)} catch [Threading.AbandonedMutexException] {$owns=$true}
        if (-not $owns) {return 1}
        $jobGuard=New-Object Threading.Mutex($false,('Local\DoorayPlus-Recovery-'+$checked.Job.userSid+'-'+$checked.Job.token))
        try {$ownsJob=$jobGuard.WaitOne(0)} catch [Threading.AbandonedMutexException] {$ownsJob=$true}
        if (-not $ownsJob) {return 1}
        # Do not overwrite the result of an already running/completed job when
        # this observer process is accidentally launched twice.
        $started=[IO.Path]::Combine($checked.Directory,'started.flag')
        if ([IO.File]::Exists($started) -or [IO.Directory]::Exists($started)) {return 1}
        $canWrite=$true
        $backend=New-RecoveryRestartBackend $clock
        if (Invoke-RecoveryRestartCore $checked $backend) {return 0};return 1
    } catch {
        if ($checked -and $canWrite) {try {Write-RecoveryRestartRecord $checked 'error' 'identity-unavailable'} catch {}}
        [Console]::Error.WriteLine('Recovery restart validation failed.');return 1
    } finally {if ($ownsJob) {$jobGuard.ReleaseMutex()};if ($jobGuard) {$jobGuard.Dispose()};if ($owns) {$guard.ReleaseMutex()};if ($guard) {$guard.Dispose()};$clock.Stop()}
}

if ($MyInvocation.InvocationName -ne '.') {
    exit (Start-RecoveryRestart $env:DOORAY_PLUS_RECOVERY_JOB)
}

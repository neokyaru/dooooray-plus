# One short foreground handoff; no topmost, resizing, or reparenting.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;
public class DoorayWindowOwner : IWin32Window {
 public IntPtr Handle {get;private set;}
 public DoorayWindowOwner(IntPtr handle){Handle=handle;}
}
public static class DoorayWindowFocus {
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
 [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr h,int command);
 public static IntPtr Owner(){int session=Process.GetCurrentProcess().SessionId;foreach(var p in Process.GetProcessesByName("DoorayMessenger"))using(p){try{if(p.SessionId==session&&p.MainWindowHandle!=IntPtr.Zero)return p.MainWindowHandle;}catch{}}return IntPtr.Zero;}
 public static void Activate(IntPtr target){
  if(target==IntPtr.Zero)return;
  uint pid;uint active=GetWindowThreadProcessId(GetForegroundWindow(),out pid),own=GetCurrentThreadId();bool attached=false;
  try{if(active!=0&&active!=own)attached=AttachThreadInput(own,active,true);if(IsIconic(target))ShowWindowAsync(target,9);BringWindowToTop(target);SetForegroundWindow(target);}
  finally{if(attached)AttachThreadInput(own,active,false);}
 }
}
'@

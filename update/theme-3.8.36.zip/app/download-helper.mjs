import {createEmoticonRepository} from './emoticon-repository.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {createDownloadSettings} from './download-settings.mjs';
import {resolveDownloads,openFolder,chooseDownloadFolder,commitDownloadFile} from './download-paths.mjs';

// The transport owns every CDP callback. A socket which remains OPEN without
// answering is retired, rather than keeping one more callback on every tick.
// Imports are side-effect free so the actual implementation can be tested with
// synthetic sockets and clocks, without starting the helper or touching Dooray.
export function createDownloadTransport({sessions=new Map(),WebSocketImpl=globalThis.WebSocket,fetcher=globalThis.fetch,
 command=async()=>null,getState=()=>({}),onInvalidated=()=>{},onRetired=()=>{},onStalledClose=()=>{},log=()=>{},
 setTimer=setTimeout,clearTimer=clearTimeout,commandTimeoutMs=15000,openTimeoutMs=5000,queryTimeoutMs=3000,
 maxPending=64,maxSessions=16,maxContexts=128,maxBindings=64,maxPendingBytes=128*1024*1024,maxMessageBytes=16*1024*1024}={}) {
 let disposed=false,refreshing=null,queryController=null,queryCancel=null,pendingBytes=0,stateRevision=0,serializedRevision=-1,serializedState=null;const closing=new Map();
 const bufferedBytes=()=>[...[...sessions.values()].map(s=>s.ws),...closing.keys()].reduce((sum,ws)=>sum+(Number(ws.bufferedAmount)||0),0);
 const report=reason=>{try{log(reason)}catch{}};
 const deadlineLimit=method=>method==='Network.loadNetworkResource'?600000:60000;
 const deadlineFor=method=>method==='IO.close'?2000:method==='Network.loadNetworkResource'?600000:method==='IO.read'?60000:commandTimeoutMs;
 function stateJSON(){
  if(serializedRevision!==stateRevision){const next=JSON.stringify(getState());if(Buffer.byteLength(next,'utf8')>maxMessageBytes)throw Error('다운로드 상태 크기 초과');serializedState=next;serializedRevision=stateRevision;}
  return serializedState;
 }
 const targetInfo=t=>{try{
  if(!t||t.type!=='page'||typeof t.id!=='string'||!t.id||t.id.length>200||typeof t.url!=='string'||t.url.length>4096)return null;
  const url=new URL(t.url),socket=new URL(t.webSocketDebuggerUrl);
  if(url.protocol!=='https:'||url.username||url.password||!/(^|\.)(dooray|gov-dooray)\.com$/.test(url.hostname)||!/^\/messenger(?:\/|$)/.test(url.pathname))return null;
  if(socket.protocol!=='ws:'||!['127.0.0.1','localhost'].includes(socket.hostname)||socket.port!=='19347'||socket.username||socket.password||socket.search||socket.hash||!socket.pathname.startsWith('/devtools/page/'))return null;
  return {id:t.id,origin:url.origin,socket:socket.href,key:socket.href+'|'+url.origin};
 }catch{return null}};
 function attach(t){
  const info=targetInfo(t);if(disposed||!info)return null;
  const previous=sessions.get(info.id);if(previous?.identity===info.key&&previous.active())return previous;
  previous?.close('target-replaced');if(sessions.size+closing.size>=maxSessions)return null;
  let ws;try{ws=new WebSocketImpl(info.socket)}catch{report('socket-create-failed');return null}
  const pending=new Map(),orphans=new Map(),contexts=new Map(),bindings=new Map();let seq=0,closed=false,opening,publication=null,dirty=false,sessionBytes=0;
  const current=()=>!disposed&&!closed&&sessions.get(info.id)===s;
  const s={ws,origin:info.origin,identity:info.key,preflightEpoch:0,ready:false,contexts,active:current,
   createAbortController:()=>new AbortController(),
   send(method,params={},options={}){
    if(!current()||ws.readyState!==1)return Promise.reject(Error('다운로드 연결이 종료되었습니다.'));
    if(options.signal?.aborted)return Promise.reject(Error('요청이 취소되었습니다.'));
    if(pending.size+orphans.size>=maxPending)return Promise.reject(Error('다운로드 요청이 많습니다. 잠시 후 다시 시도해 주세요.'));
    let raw,bytes;const id=++seq;try{raw=JSON.stringify({id,method,params});bytes=Buffer.byteLength(raw,'utf8')}catch{return Promise.reject(Error('올바르지 않은 다운로드 요청입니다.'))}
    if(bytes>maxMessageBytes||pendingBytes+bytes>maxPendingBytes||bufferedBytes()+bytes>maxPendingBytes)return Promise.reject(Error('다운로드 응답이 밀려 있습니다. 잠시 후 다시 시도해 주세요.'));
    return new Promise((resolve,reject)=>{
     let timer;pendingBytes+=bytes;sessionBytes+=bytes;
     const finish=(error,result)=>{if(!pending.has(id))return;pending.delete(id);pendingBytes-=bytes;sessionBytes-=bytes;clearTimer(timer);options.signal?.removeEventListener('abort',abort);error?reject(error):resolve(result)};
     const abort=()=>{
      // A cancelled resource load may still create a native stream. Keep only a
      // bounded tombstone until its reply, then close that stream without a job.
      if(pending.has(id)&&(method==='Network.loadNetworkResource'||options.releaseOnCancel===true))orphans.set(id,{kind:method==='Network.loadNetworkResource'?'stream':'object',timer:setTimer(()=>retire('cancelled-load-timeout'),deadlineLimit(method))});
      finish(Error('요청이 취소되었습니다.'));
     };
     pending.set(id,{finish});timer=setTimer(()=>{finish(Error('다운로드 연결 응답 시간 초과'));retire('command-timeout')},Math.min(deadlineLimit(method),Math.max(1,options.timeoutMs??deadlineFor(method))));
     options.signal?.addEventListener('abort',abort,{once:true});
     try{ws.send(raw)}catch{finish(Error('다운로드 연결 전송 실패'));retire('send-failed')}
    });
   },
   close:reason=>retire(reason||'closed'),
   diagnostics:()=>({pending:pending.size,pendingBytes:sessionBytes,orphans:orphans.size,contexts:contexts.size,bindings:bindings.size,publishing:!!publication,dirty,ready:s.ready})
  };
  function invalidate(){s.preflightEpoch++;for(const binding of bindings.values())binding.abort();bindings.clear();try{onInvalidated(s)}catch{}}
  function retire(reason){
   if(closed)return;closed=true;s.ready=false;dirty=false;clearTimer(opening);invalidate();contexts.clear();
   for(const entry of [...pending.values()])entry.finish(Error('다운로드 연결 종료: '+reason));pending.clear();for(const orphan of orphans.values())clearTimer(orphan.timer);orphans.clear();
   if(sessions.get(info.id)===s)sessions.delete(info.id);
   ws.onopen=ws.onmessage=ws.onclose=ws.onerror=null;
   // Global WebSocket has no terminate(). If its close handshake itself stalls,
   // stop this helper instead of accumulating abandoned native sockets forever.
   if(!disposed&&ws.readyState!==3){
    const finish=()=>{clearTimer(closing.get(ws));closing.delete(ws);ws.onclose=ws.onerror=null};
    closing.set(ws,setTimer(()=>{finish();try{onStalledClose()}catch{}},2000));ws.onclose=finish;ws.onerror=()=>{if(ws.readyState===3)finish()};
   }
   try{ws.close()}catch{};try{onRetired(s,reason)}catch{};report(reason);
  }
  function publishOne(){
   if(!current()||!s.ready)return;
   if(publication){dirty=true;return}
   dirty=false;
   let expression;try{expression='window.__doorayDownloadsReady=Date.now();window.__doorayDownloadsChanged?.('+stateJSON()+')'}catch{return}
   publication=s.send('Runtime.evaluate',{expression}).catch(()=>{}).finally(()=>{publication=null;if(dirty&&current())publishOne()});
  }
  s.publish=publishOne;sessions.set(info.id,s);
  opening=setTimer(()=>retire('open-timeout'),openTimeoutMs);
  ws.onopen=()=>{if(!current())return;clearTimer(opening);void (async()=>{try{
   await s.send('Runtime.enable',{});if(!current())return;
   await s.send('Runtime.addBinding',{name:'__doorayDownloadCommand'});if(!current())return;
   s.ready=true;publishOne();
  }catch{retire('registration-failed')}})()};
  async function bindingCalled(m){
   const contextId=m.params?.executionContextId,context=contexts.get(contextId);
   if(!context||m.params?.name!=='__doorayDownloadCommand'||typeof m.params.payload!=='string'||m.params.payload.length>65536)return;
   let p;try{p=JSON.parse(m.params.payload)}catch{return}
   if(!p||typeof p.requestId!=='string'||!p.requestId||p.requestId.length>80||bindings.has(p.requestId))return;
   const reply=async(result,error)=>{if(!current()||contexts.get(contextId)!==context)return;
    try{await s.send('Runtime.evaluate',{contextId,expression:'window.__doorayDownloadReply?.('+JSON.stringify(p.requestId)+','+JSON.stringify(result)+','+JSON.stringify(error)+')'})}
    catch{if(current()&&contexts.get(contextId)===context)await s.send('Runtime.evaluate',{contextId,expression:'window.__doorayDownloadReply?.('+JSON.stringify(p.requestId)+',null,"다운로드 응답이 밀려 있습니다. 잠시 후 다시 시도해 주세요.")'}).catch(()=>{})}
   };
   if(bindings.size>=maxBindings){await reply(null,'다운로드 요청이 많습니다. 잠시 후 다시 시도해 주세요.');return}
   const controller=new AbortController();bindings.set(p.requestId,controller);let timer,cancel,timedOut=false;
   const waitMs=['update-install','update-apply','update-check'].includes(p.op)?720000:p.op==='choose-folder'?190000:String(p.op).startsWith('emoticon-')?120000:30000;
   const aborted=new Promise((_,reject)=>{cancel=()=>reject(Error('요청이 취소되었습니다.'));controller.signal.addEventListener('abort',cancel,{once:true});timer=setTimer(()=>{timedOut=true;controller.abort()},waitMs)});
   try{const result=await Promise.race([Promise.resolve().then(()=>{if(controller.signal.aborted)throw Error('요청이 취소되었습니다.');return command(s,p,{signal:controller.signal})}),aborted]);if(!controller.signal.aborted)await reply(result,null)}
   catch(error){if(timedOut)await reply(null,'작업 응답 시간 초과. 다시 시도해 주세요.');else if(!controller.signal.aborted)await reply(null,String(error?.message||'작업 실패').slice(0,300))}
   finally{clearTimer(timer);controller.signal.removeEventListener('abort',cancel);if(bindings.get(p.requestId)===controller)bindings.delete(p.requestId)}
  }
  ws.onmessage=e=>{
   if(!current())return;let m;try{m=JSON.parse(e.data)}catch{retire('invalid-response');return}
   if(!m||typeof m!=='object')return;
   if(Number.isSafeInteger(m.id)){
    const entry=pending.get(m.id);if(entry)entry.finish(m.error?Error(String(m.error.message||'CDP 요청 실패').slice(0,200)):null,m.result);
    else if(orphans.has(m.id)){const orphan=orphans.get(m.id);clearTimer(orphan.timer);orphans.delete(m.id);const handle=orphan.kind==='stream'?m.result?.resource?.stream:m.result?.result?.objectId;if(typeof handle==='string'&&handle)void s.send(orphan.kind==='stream'?'IO.close':'Runtime.releaseObject',orphan.kind==='stream'?{handle}:{objectId:handle},{timeoutMs:2000}).catch(()=>{})}
    return;
   }
   if(m.method==='Runtime.executionContextCreated'){
    const c=m.params?.context;if(!c||!Number.isSafeInteger(c.id))return;
    if(contexts.has(c.id)){invalidate();contexts.delete(c.id)}
    s.preflightEpoch++;
    if(c.origin===info.origin&&c.auxData?.isDefault===true){if(contexts.size>=maxContexts){retire('context-limit');return}contexts.set(c.id,{frameId:typeof c.auxData?.frameId==='string'?c.auxData.frameId:null})}
   }
   if(m.method==='Runtime.executionContextsCleared'){invalidate();contexts.clear()}
   if(m.method==='Runtime.executionContextDestroyed'){invalidate();contexts.delete(m.params?.executionContextId)}
   if(m.method==='Runtime.bindingCalled')void bindingCalled(m).catch(()=>{});
  };
  ws.onclose=()=>{if(current())retire('socket-closed')};ws.onerror=()=>{if(current())retire('socket-error')};return s;
 }
 function reconcile(targets){
  if(disposed)return;if(!Array.isArray(targets)||targets.length>512)throw Error('잘못된 대상 목록');
  const valid=new Map(),duplicates=new Set();
  for(const target of targets){const info=targetInfo(target);if(!info)continue;if(valid.has(info.id)){duplicates.add(info.id);continue}valid.set(info.id,{target,info})}
  for(const id of duplicates)valid.delete(id);
  for(const [id,s] of [...sessions]){const next=valid.get(id);if(!next||s.identity!==next.info.key)s.close('target-removed')}
  for(const {target} of valid.values()){if(sessions.size>=maxSessions)break;attach(target)}
 }
 function refresh(){
  if(disposed)return Promise.resolve(false);if(refreshing)return refreshing;
  const controller=new AbortController();queryController=controller;
  let timer;
  const operation=(async()=>{
   const response=await fetcher('http://127.0.0.1:19347/json/list',{signal:controller.signal,redirect:'error',credentials:'omit'});
   if(disposed||controller.signal.aborted){void response.body?.cancel?.().catch(()=>{});return false}
   if(!response.ok){void response.body?.cancel?.().catch(()=>{});throw Error('대상 목록 조회 실패')}const declared=Number(response.headers?.get?.('content-length'));
   if(declared>2*1024*1024){void response.body?.cancel?.().catch(()=>{});throw Error('대상 목록 크기 초과')}
   let text='';
   if(response.body?.getReader){const reader=response.body.getReader();const decoder=new TextDecoder();let bytes=0,ended=false;const cancel=()=>{void reader.cancel().catch(()=>{})};controller.signal.addEventListener('abort',cancel,{once:true});try{while(true){const value=await reader.read();if(value.done){ended=true;break}bytes+=value.value.byteLength;if(bytes>2*1024*1024)throw Error('대상 목록 크기 초과');text+=decoder.decode(value.value,{stream:true})}text+=decoder.decode()}finally{controller.signal.removeEventListener('abort',cancel);if(!ended)cancel();reader.releaseLock()}}
   else{text=await response.text();if(text.length>2*1024*1024)throw Error('대상 목록 크기 초과')}
   if(disposed||controller.signal.aborted)return false;reconcile(JSON.parse(text));return true;
  })();
  const deadline=new Promise((_,reject)=>{queryCancel=()=>{controller.abort();reject(Error('대상 목록 조회 취소'))};timer=setTimer(()=>{controller.abort();reject(Error('대상 목록 응답 시간 초과'))},queryTimeoutMs)});
  refreshing=Promise.race([operation,deadline]).catch(()=>false).finally(()=>{clearTimer(timer);if(queryController===controller){queryController=null;queryCancel=null}refreshing=null});return refreshing;
 }
 return {sessions,attach,reconcile,refresh,publish(changed=true){if(disposed)return;if(changed)stateRevision++;for(const s of sessions.values())s.publish()},
  dispose(){if(disposed)return;disposed=true;serializedState=null;queryCancel?.();for(const s of [...sessions.values()])s.close('helper-stopping');sessions.clear();for(const [ws,timer] of closing){clearTimer(timer);ws.onclose=ws.onerror=null;try{ws.close()}catch{}}closing.clear()},
  diagnostics(){const values=[...sessions.values()].map(s=>s.diagnostics());return {sessions:sessions.size,pending:values.reduce((n,s)=>n+s.pending,0),pendingBytes,bufferedBytes:bufferedBytes(),orphans:values.reduce((n,s)=>n+s.orphans,0),contexts:values.reduce((n,s)=>n+s.contexts,0),bindings:values.reduce((n,s)=>n+s.bindings,0),closing:closing.size,refreshing:!!refreshing}}
 };
}

export function createDownloadShutdown({jobs,transport,preflight,updateRequests,stopPolling=()=>{},save=async()=>{},closeLock=()=>{},exit=()=>{},log=()=>{},setTimer=setTimeout,clearTimer=clearTimeout,timeoutMs=6000}) {
 let stopping=null;
 return reason=>{
  if(stopping)return stopping;
  let finish;stopping=new Promise(resolve=>finish=resolve);let finished=false;
  const done=timedOut=>{if(finished)return;finished=true;clearTimer(deadline);if(timedOut)log('shutdown-cleanup-timeout');closeLock();finish();exit(0)};
  const deadline=setTimer(()=>done(true),timeoutMs);stopPolling();preflight.dispose();
  for(const request of updateRequests.values()){clearTimer(request.timer);request.reject(Error('업데이트 연결 종료'))}updateRequests.clear();
  for(const job of jobs.values()){if(!job.committing){job.cancelled=true;job.controller?.abort()}}
  transport.dispose();
  void Promise.allSettled([...jobs.values()].map(job=>job.done)).then(()=>save()).catch(()=>{}).finally(()=>done(false));return stopping;
 };
}
export function createUpdatePreflight({sessions,jobs,now=()=>performance.now(),isApplying=()=>false,timeoutMs=2500,setTimer=setTimeout,clearTimer=clearTimeout}) {
 let backgroundLeaseUntil=0,lastAt=null,generation=0,disposed=false;
 const pending=new Set();
 const expression="[...document.querySelectorAll('[contenteditable=\"true\"],textarea')].some(e=>(e.innerText||e.value||'').trim().length>0)";
 function clock(){const at=now();if(!Number.isFinite(at)||at<0){backgroundLeaseUntil=0;return null}if(lastAt!==null&&at<lastAt)backgroundLeaseUntil=0;lastAt=at;return at}
 function probe(session){return new Promise((resolve,reject)=>{
  const controller=new AbortController();let settled=false,timer;const finish=(error,value)=>{if(settled)return;settled=true;clearTimer(timer);pending.delete(cancel);controller.abort();error?reject(error):resolve(value)};
  const cancel=()=>finish(Error('preflight disposed'));pending.add(cancel);timer=setTimer(()=>finish(Error('preflight timeout')),timeoutMs);
  Promise.resolve().then(()=>{if(settled||disposed)throw Error('preflight disposed');return session.send('Runtime.evaluate',{expression,returnByValue:true},{signal:controller.signal})}).then(result=>{
   if(result?.exceptionDetails||typeof result?.result?.value!=='boolean')throw Error('invalid preflight result');
   finish(null,result.result.value);
  }).catch(error=>finish(error));
 });}
 async function inspect(){
  if(disposed)return {known:false,drafts:0,downloads:jobs.size};
  const snapshot=[...sessions].map(([id,session])=>({id,session,epoch:session.preflightEpoch||0}));
  if(!snapshot.length||snapshot.some(x=>x.session.ws?.readyState!==1))return {known:false,drafts:0,downloads:jobs.size};
  const results=await Promise.all(snapshot.map(async x=>{try{return {known:true,draft:await probe(x.session)}}catch{return {known:false,draft:false}}}));
  const stable=!disposed&&snapshot.length===sessions.size&&snapshot.every(x=>sessions.get(x.id)===x.session&&x.session.ws?.readyState===1&&(x.session.preflightEpoch||0)===x.epoch);
  return {known:stable&&results.every(x=>x.known),drafts:results.filter(x=>x.draft).length,downloads:jobs.size};
 }
 return {
  inspect,
  async reserve(){const request=++generation,result=await inspect(),at=clock();const reserved=!disposed&&request===generation&&result.known&&result.drafts===0&&result.downloads===0&&!isApplying()&&at!==null;
   if(request===generation)backgroundLeaseUntil=reserved?at+15*60*1000:0;
   return {...result,reserved};
  },
  unreserve(){generation++;backgroundLeaseUntil=0},
  downloadBlocked(){const at=clock();return isApplying()||at!==null&&at<backgroundLeaseUntil},
  dispose(){disposed=true;generation++;backgroundLeaseUntil=0;for(const cancel of [...pending])cancel()}
 };
}
// End isolated update preflight.

// Evaluated only in the verified top-frame default context. Creating this
// object does not start a request, so an aborted creation can simply release
// its late objectId. Cookies never leave the browser. No blob/arrayBuffer or
// full-response collection is used: one pull plus at most one pending read.
export function createPageDownloadStream(expectedOrigin){
 if(window!==window.top||location.origin!==expectedOrigin||typeof fetch!=='function'||typeof AbortController!=='function'||typeof btoa!=='function')throw Error('download context unavailable');
 const max=1024*1024,controller=new AbortController();let reader=null,pending=null,rest=null,offset=0,ended=false,closed=false,opening=false,pulling=false,idleTimer=null;
 async function close(){if(closed)return {closed:true};closed=true;clearTimeout(idleTimer);controller.abort();const previous=reader;pending=null;rest=null;reader=null;if(previous)try{await previous.cancel()}catch{}return {closed:true};}
 const arm=()=>{clearTimeout(idleTimer);idleTimer=setTimeout(()=>{void close()},65000);};
 function check(){if(closed||controller.signal.aborted||location.origin!==expectedOrigin)throw Error('download closed');}
 function encode(bytes){const parts=[];for(let i=0;i<bytes.length;i+=32768)parts.push(String.fromCharCode(...bytes.subarray(i,i+32768)));return btoa(parts.join(''));}
 return {
  async open(value){
   check();if(opening)throw Error('download already opened');opening=true;arm();
   const url=new URL(value);if(url.origin!==expectedOrigin||url.username||url.password||url.search||url.hash||!/^\/messenger\/v2\/api\/channel\/\d+\/file\/\d+$/.test(url.pathname))throw Error('download address rejected');
   let response;try{response=await fetch(url.href,{credentials:'include',redirect:'error',cache:'no-store',signal:controller.signal});}catch(error){check();return {success:false,kind:error?.name==='TypeError'?'fetch-type':'network'};}check();
   if(!response.ok){controller.abort();return {success:false,kind:'http',status:response.status};}
   if(!response.body||typeof response.body.getReader!=='function'){controller.abort();return {success:false,kind:'capability',status:response.status};}
   try{reader=response.body.getReader();if(typeof reader.read!=='function'||typeof reader.cancel!=='function')throw Error('unsupported reader');}catch{controller.abort();return {success:false,kind:'capability',status:response.status};}return {success:true,status:response.status,total:Number(response.headers.get('content-length'))||0};
  },
  async read(size){
   check();if(!reader||pulling||!Number.isInteger(size)||size<1||size>max)throw Error('download read rejected');pulling=true;arm();
   try{
    const chunks=[];let length=0;
    while(length<size){
     check();
     if(rest){const count=Math.min(size-length,rest.byteLength-offset);chunks.push(rest.subarray(offset,offset+count));length+=count;offset+=count;if(offset===rest.byteLength){rest=null;offset=0;}if(length===size)break;}
     if(ended)break;
     if(!pending)pending=reader.read();
     let next,timer;
     if(length){try{next=await Promise.race([pending,new Promise(resolve=>{timer=setTimeout(()=>resolve(null),8)})]);}finally{clearTimeout(timer)}if(next===null)break;}
     else next=await pending;
     pending=null;check();
     if(next.done){ended=true;break;}
     if(!(next.value instanceof Uint8Array)||next.value.byteLength>2*max)throw Error('download chunk rejected');
     rest=next.value;offset=0;if(!rest.byteLength){rest=null;throw Error('empty download chunk');}
    }
    const bytes=new Uint8Array(length);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}
    return {data:encode(bytes),base64Encoded:true,eof:ended&&!rest};
   }finally{pulling=false;}
  },
  close
 };
}

async function openPageDownloadStream(session,url,{signal}={}){
 let objectId=null,closed=false,opened=false,closePromise=null;
 const close=()=>{if(closePromise)return closePromise;closed=true;closePromise=(async()=>{if(!objectId)return true;let cancelled=!opened,released=false;if(opened)try{const result=await session.send('Runtime.callFunctionOn',{objectId,functionDeclaration:'function(){return this.close()}',returnByValue:true,awaitPromise:true},{timeoutMs:2000});cancelled=!result?.exceptionDetails&&result?.result?.value?.closed===true;}catch{}try{await session.send('Runtime.releaseObject',{objectId},{timeoutMs:2000});released=true;}catch{}return cancelled&&released;})();return closePromise;};
 try{
  const tree=await session.send('Page.getFrameTree',{}, {signal}),frameId=tree?.frameTree?.frame?.id;
  const candidates=[...(session.contexts||[])].filter(([,context])=>typeof frameId==='string'&&context.frameId===frameId);
  if(candidates.length!==1)throw Object.assign(Error('다운로드할 기본 화면을 확인하지 못했습니다. 잠시 후 다시 시도해 주세요.'),{code:'STREAM_CAPABILITY'});
  const [contextId,context]=candidates[0],epoch=session.preflightEpoch;
  const current=()=>{if(closed||signal?.aborted||session.active?.()===false||session.preflightEpoch!==epoch||session.contexts.get(contextId)!==context)throw Error('다운로드 화면이 변경되었거나 요청이 취소되었습니다.');};
  current();const created=await session.send('Runtime.evaluate',{contextId,expression:'('+createPageDownloadStream.toString()+')('+JSON.stringify(session.origin)+')',returnByValue:false},{signal,releaseOnCancel:true});
  objectId=created?.result?.objectId;if(created?.exceptionDetails||typeof objectId!=='string'||!objectId)throw Object.assign(Error('이 화면에서 스트리밍 다운로드를 시작할 수 없습니다.'),{code:'STREAM_CAPABILITY'});current();
  const call=async(method,args=[])=>{current();const result=await session.send('Runtime.callFunctionOn',{objectId,functionDeclaration:method==='open'?'function(url){return this.open(url)}':'function(size){return this.read(size)}',arguments:args.map(value=>({value})),awaitPromise:true,returnByValue:true},{signal,timeoutMs:60000});current();if(result?.exceptionDetails||!result?.result||!Object.hasOwn(result.result,'value'))throw Error('다운로드 스트림을 읽지 못했습니다. 권한·연결·파일 만료를 확인해 주세요.');return result.result.value;};
  opened=true;const metadata=await call('open',[url]);if(metadata?.success!==true||!Number.isInteger(metadata.status)||metadata.status<200||metadata.status>=300)throw Object.assign(Error('다운로드 응답을 확인하지 못했습니다.'+(Number.isInteger(metadata?.status)?' HTTP '+metadata.status:'')),{code:['fetch-type','capability'].includes(metadata?.kind)?'STREAM_CAPABILITY':'DOWNLOAD_RESPONSE'});
  return {total:Number.isFinite(metadata.total)&&metadata.total>0?metadata.total:0,read:size=>call('read',[size]),close};
 }catch(error){error.streamClosed=await close();throw error;}
}

export async function openDownloadStream(session,url,{signal}={}){
 const target=new URL(url);if(target.origin!==session.origin||target.username||target.password||target.search||target.hash||!/^\/messenger\/v2\/api\/channel\/\d+\/file\/\d+$/.test(target.pathname))throw Error('지원하지 않는 파일 주소입니다.');
 const epoch=session.preflightEpoch;
 try{return await openPageDownloadStream(session,url,{signal})}catch(error){
  // Only an unavailable streaming capability before any reader body pull may
  // use the existing authenticated browser API, once and after owned cleanup.
  // HTTP errors, cancellation, stale contexts and partial transfers never retry.
  if(error.code!=='STREAM_CAPABILITY'||error.streamClosed!==true||signal?.aborted||session.active?.()===false||session.preflightEpoch!==epoch)throw error;
 }
 let handle=null,closed=false;
 const close=async()=>{if(closed)return;closed=true;if(handle)await session.send('IO.close',{handle},{timeoutMs:2000}).catch(()=>{});};
 try{
  const tree=await session.send('Page.getFrameTree',{}, {signal});
  const {resource}=await session.send('Network.loadNetworkResource',{frameId:tree.frameTree.frame.id,url:target.href,options:{disableCache:true,includeCredentials:true}},{signal,timeoutMs:600000});
  handle=resource?.stream;if(!resource?.success||resource.httpStatusCode>=400||typeof handle!=='string'||!handle)throw Error('다운로드 실패: '+(resource?.httpStatusCode||'권한/만료 확인'));
  if(signal?.aborted||session.active?.()===false||session.preflightEpoch!==epoch)throw Error('다운로드 화면이 변경되었거나 요청이 취소되었습니다.');
  const total=Number(Object.entries(resource.headers||{}).find(([key])=>key.toLowerCase()==='content-length')?.[1]);
  return {total:Number.isFinite(total)&&total>0?total:0,read:size=>{if(closed||signal?.aborted||session.preflightEpoch!==epoch)throw Error('다운로드가 취소되었습니다.');return session.send('IO.read',{handle,size},{signal,timeoutMs:60000})},close};
 }catch(error){await close();throw error;}
}

async function main(){
const emoticons=createEmoticonRepository();let stopping=false,tickTimer=null;
let shutdown=()=>{stopping=true;process.exit(0)};
process.on('disconnect',()=>void shutdown('parent-disconnected'));
process.on('message',m=>{if(m?.type==='shutdown')void shutdown('parent-shutdown')});
if(process.env.DOORAY_ENGINE_SESSION&&!process.connected){shutdown('parent-already-disconnected');return}
const lock=net.createServer(s=>s.end());if(!await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(19349,'127.0.0.1',()=>r(true))}))process.exit(0);
const defaultFolder=await resolveDownloads();
const dataDir=path.join(process.env.LOCALAPPDATA,'DoorayTheme');
await fs.mkdir(defaultFolder,{recursive:true});await fs.mkdir(dataDir,{recursive:true});
const downloadSettings=await createDownloadSettings(dataDir,defaultFolder,{legacyFolders:[path.join(process.env.USERPROFILE,'Downloads','Dooray'),path.join(defaultFolder,'Dooray')]});
const allowedFolders=downloadSettings.allowed;let pickingFolder=null;
const historyFile=path.join(dataDir,'managed-downloads.json');let items=[];try{items=JSON.parse(await fs.readFile(historyFile,'utf8'));if(!Array.isArray(items))items=[];}catch{}
for(const i of items)if(i.status==='downloading')i.status='interrupted';
let saveQueue=null,saveDirty=false;function save(){saveDirty=true;if(saveQueue)return saveQueue;saveQueue=(async()=>{while(saveDirty){saveDirty=false;await fs.writeFile(historyFile,JSON.stringify(items)).catch(()=>{})}})().finally(()=>{saveQueue=null;if(saveDirty)return save()});return saveQueue;}
let completionId="",startId="",batchFailed=false;const jobs=new Map();const sessions=new Map();const state=()=>({folder:downloadSettings.folder,defaultFolder,completionId,startId,items:items.map(({path:localPath,...x})=>x)});
function publish(){transport.publish()}
const safeName=name=>(String(name||'download').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'').replace(/^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?=\.|$)/i,'_$1').slice(0,150)||'download');
// One sequential 1 MiB reply/write at a time: no prefetch queue or whole-file
// Buffer. Progress is shared across jobs so concurrent files do not multiply
// full-history publication work; start/finish/cancel still publish immediately.
const downloadChunkSize=1024*1024;let lastDownloadProgress=-Infinity;
function publishDownloadProgress(){const at=globalThis.performance?.now?.()??Date.now();if(at<lastDownloadProgress||at-lastDownloadProgress>=250){lastDownloadProgress=at;publish();}}
async function writeDownloadChunk(file,bytes,job){
 let offset=0;while(offset<bytes.length){if(job.cancelled||job.controller?.signal.aborted)throw Error('취소됨');const result=await file.write(bytes,offset,bytes.length-offset);if(!Number.isInteger(result?.bytesWritten)||result.bytesWritten<=0||result.bytesWritten>bytes.length-offset)throw Error('다운로드 파일 쓰기에 실패했습니다.');offset+=result.bytesWritten;}
}
async function download(s,p){
 const url=new URL(p.url);if(url.origin!==s.origin||url.username||url.password||url.hash||!/^\/messenger\/v2\/api\/channel\/\d+\/file\/\d+$/.test(url.pathname)||url.search)throw Error('지원하지 않는 파일 주소입니다.');
 if(jobs.size>=16)throw Error('진행 중인 다운로드가 많습니다. 완료 후 다시 시도해 주세요.');
 const id=crypto.randomUUID(),name=safeName(p.name),parts=url.pathname.split('/'),folder=downloadSettings.folder,temp=path.join(folder,'.dooray-'+id+'.part');
 const item={id,name,path:path.join(folder,name),received:0,total:Number(p.total)||0,status:'downloading',at:Date.now(),channelId:parts[5],fileId:parts[7],logId:/^\d+$/.test(p.logId||'')?p.logId:null};
 const job={cancelled:false,handle:null,session:s,controller:s.createAbortController?.()};
 if(!jobs.size)batchFailed=false;jobs.set(id,job);items.unshift(item);startId=id;publish();void save();
 job.done=(async()=>{let file,stream;try{
  stream=await openDownloadStream(s,url.href,{signal:job.controller?.signal});job.handle=stream;if(job.cancelled)throw Error('취소됨');
  if(stream.total>0)item.total=stream.total;
  file=await fs.open(temp,'wx');let emptyReads=0;
  while(true){
   if(job.cancelled)throw Error('취소됨');const chunk=await stream.read(downloadChunkSize);if(job.cancelled)throw Error('취소됨');
   if(typeof chunk?.data!=='string'||typeof chunk.eof!=='boolean'||chunk.data.length>Math.ceil(downloadChunkSize/3)*4+4)throw Error('다운로드 데이터 크기/형식이 올바르지 않습니다.');
   const b=Buffer.from(chunk.data,chunk.base64Encoded?'base64':'utf8');if(b.length>downloadChunkSize)throw Error('다운로드 데이터 크기 초과');
   if(!b.length&&!chunk.eof&&++emptyReads>=3)throw Error('다운로드 데이터가 도착하지 않습니다.');if(b.length)emptyReads=0;
   await writeDownloadChunk(file,b,job);item.received+=b.length;
   publishDownloadProgress();if(chunk.eof)break;
  }
  await file.close();file=null;if(job.cancelled)throw Error('취소됨');job.committing=true;
  item.path=await commitDownloadFile(temp,folder,name);item.name=path.basename(item.path);item.status='complete';item.seen=false;item.total=item.received;
 }catch(e){item.status=job.cancelled?'cancelled':'error';item.error=String(e.message).slice(0,180)}
 finally{
  if(file)await file.close().catch(()=>{});
  // Reader cancellation and object release each have a separate bounded command,
  // even after the transfer's request signal has been aborted.
  if(stream)await stream.close().catch(()=>{});
  await fs.unlink(temp).catch(()=>{});if(item.status!=='complete')batchFailed=true;jobs.delete(id);
  if(!jobs.size&&!batchFailed)completionId=crypto.randomUUID();publish();void save();
 }})();return {id};
}
const updateRequests=new Map();let applyingUpdate=false;
const updatePreflight=createUpdatePreflight({sessions,jobs,isApplying:()=>applyingUpdate});
const backgroundRequestId=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
process.on('message',m=>{
 if(m?.type==='background-unreserve'){updatePreflight.unreserve();return}
 if(m?.type==='background-preflight'&&backgroundRequestId(m.id)){
  void updatePreflight.reserve().catch(()=>({known:false,drafts:0,downloads:jobs.size,reserved:false})).then(result=>{if(process.connected)try{process.send({type:'background-preflight-result',id:m.id,result})}catch{}});return;
 }
 if(m?.type!=='update-result')return;const p=updateRequests.get(m.id);if(p)p.resolve(m.result)
});
process.on('exit',()=>updatePreflight.dispose());
function requestUpdate(type,args={},options={}){return new Promise((resolve,reject)=>{
 if(stopping||options.signal?.aborted)return reject(Error('요청이 취소되었습니다.'));
 if(!process.connected)return reject(Error('업데이트 지원 설치 파일로 전환 설치해 주세요.'));
 if(updateRequests.size>=64)return reject(Error('업데이트 요청이 많습니다. 잠시 후 다시 시도해 주세요.'));
 const id=crypto.randomUUID();let timer;
 const finish=(error,result)=>{if(!updateRequests.has(id))return;updateRequests.delete(id);clearTimeout(timer);options.signal?.removeEventListener('abort',abort);error?reject(error):resolve(result)};
 const abort=()=>finish(Error('요청이 취소되었습니다.'));
 timer=setTimeout(()=>finish(Error('업데이트 응답 시간 초과')),720000);
 updateRequests.set(id,{timer,resolve:result=>finish(null,result),reject:error=>finish(error)});
 options.signal?.addEventListener('abort',abort,{once:true});
 try{process.send({type,id,token:args.token},error=>{if(error)finish(Error('업데이트 연결 종료'))})}catch{finish(Error('업데이트 연결 종료'))}
});}
async function command(s,p,options={}){
if((typeof stopping!=='undefined'&&stopping)||options.signal?.aborted)throw Error('요청이 취소되었습니다.');
if(p.op==='choose-folder'){if(!pickingFolder)pickingFolder=(async()=>{const selected=await chooseDownloadFolder(downloadSettings.folder);if(selected!==null)await downloadSettings.set(selected);publish();return state();})().finally(()=>{pickingFolder=null});return pickingFolder;}
if(p.op==='reset-folder'){await downloadSettings.set(null);publish();return state();}
if(p.op==='open-current-folder'){await openFolder(downloadSettings.folder);return true;}
if(p.op==='update-preflight'){const result=await updatePreflight.inspect();if(!result.known)throw Error('작성 중인 내용을 확인하지 못했습니다. 다시 시도해 주세요.');return {drafts:result.drafts,downloads:result.downloads};}
if(['update-check','update-status','update-install','update-apply','update-cancel'].includes(p.op)){if(['update-install','update-apply'].includes(p.op)&&jobs.size)throw Error('진행 중인 다운로드가 있습니다. 완료 후 업데이트해 주세요.');if(p.op==='update-apply')applyingUpdate=true;try{const result=await requestUpdate(p.op,p,options);if(p.op==='update-cancel'||result.status==='error')applyingUpdate=false;return result}catch(e){applyingUpdate=false;throw e}}if(p.op==='emoticon-catalog')return emoticons.catalog(p.refresh===true);if(p.op==='emoticon-image')return emoticons.image(p.path,p.ref,p.refresh===true);if(p.op==='list')return state();if(p.op==='seen'){const ids=new Set(Array.isArray(p.ids)?p.ids:[]);for(const item of items)if(item.status==='complete'&&ids.has(item.id))item.seen=true;await save();publish();return true;}if(p.op==='cancel'){const job=jobs.get(p.id);if(!job||job.committing)return false;job.cancelled=true;job.controller?.abort();return true;}if(p.op==='download'){if(updatePreflight.downloadBlocked())throw Error('업데이트 적용 중입니다. 재실행 후 다운로드해 주세요.');return download(s,p);}if(p.op==='forget'||p.op==='clear'){if(p.op==='forget'&&typeof p.id!=='string')throw Error('다운로드 기록 ID가 필요합니다.');items=p.op==='clear'?[]:items.filter(x=>x.id!==p.id);await save();publish();return state();}if(!['open','folder'].includes(p.op))throw Error('지원하지 않는 작업입니다.');const item=items.find(x=>x.id===p.id);if(!item||item.status!=='complete')throw Error('완료된 파일이 없습니다.');const file=path.resolve(item.path);if(!allowedFolders.has(path.dirname(file).toLowerCase()))throw Error('관리 폴더 밖의 파일입니다.');if(p.op==='folder'){await openFolder(path.dirname(file));return true;}const stat=await fs.lstat(file);if(!stat.isFile()||stat.isSymbolicLink())throw Error('일반 파일만 열 수 있습니다.');if(p.op==='open'&&/\.(exe|com|bat|cmd|ps1|vbs|js|msi|scr|lnk|url|hta)$/i.test(file))throw Error('실행 파일은 폴더에서 직접 확인해 주세요.');await new Promise((resolve,reject)=>{const child=spawn('explorer.exe',p.op==='folder'?[path.dirname(file)]:[file],{windowsHide:false,stdio:'ignore'});child.once('error',reject);child.once('spawn',resolve);});return true;}
// Retained as the command-router extraction boundary used by isolated regressions.
async function attach(t){return transport.attach(t)}
let cancellation=null;
const transport=createDownloadTransport({sessions,command,getState:state,
 onInvalidated(session){for(const job of jobs.values())if(job.session===session&&!job.committing)job.controller?.abort();updatePreflight.unreserve();if(!stopping&&!cancellation)cancellation=requestUpdate('update-cancel').catch(()=>{}).finally(()=>{cancellation=null})},
 onRetired(session){for(const job of jobs.values())if(job.session===session&&!job.committing)job.controller?.abort()},
 onStalledClose(){void shutdown('socket-close-timeout')},
 log:reason=>{if(!['target-removed','helper-stopping'].includes(reason))process.stderr.write('Download transport: '+reason+'\n')}
});
shutdown=createDownloadShutdown({jobs,transport,preflight:updatePreflight,updateRequests,
 stopPolling(){stopping=true;clearInterval(tickTimer)},save,
 closeLock(){try{lock.close()}catch{}},exit:code=>process.exit(code),
 log:reason=>process.stderr.write('Download helper: '+reason+'\n')
});
let busy=false;
async function tick(){if(busy||stopping)return;busy=true;try{
 for(const name of ['stop-agent.flag','theme-disabled.flag']){let exists=false;try{await fs.access(path.join(dataDir,name));exists=true}catch{}if(exists){void shutdown('disabled');return}}
 if(!stopping)await transport.refresh();if(!stopping)transport.publish(false);
}catch{}finally{busy=false}}
await tick();if(!stopping)tickTimer=setInterval(tick,1500);
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 main().catch(()=>{process.stderr.write('Download helper startup failed.\n');process.exit(1)});
}

// Signed, read-only OS evidence for recovery while the browser debug target is absent.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFile as nativeExecFile} from 'node:child_process';
import {resolveInstallPaths} from './update-handoff.mjs';

const sidPattern=/^S-1-\d+(?:-\d+)+$/;
const reasons=new Set(['running','not-running','invalid-path','unsafe-caller','identity-unavailable','probe-error']);
const unknown=reason=>Object.freeze({known:false,running:false,interactive:false,reason});
const validExecutable=value=>typeof value==='string'&&value.length<=32760&&/^[a-z]:[\\/]/i.test(value)&&!/[\x00-\x1f<>"|?*]/.test(value)&&!value.slice(2).includes(':')&&!value.slice(3).split(/[\\/]/).some(part=>part==='.'||part==='..'||/[. ]$/.test(part))&&path.win32.basename(value).toLowerCase()==='dooraymessenger.exe';
function parseResult(stdout){
 const value=JSON.parse(String(stdout).replace(/^\uFEFF/,''));
 if(!value||typeof value!=='object'||Object.keys(value).sort().join(',')!=='interactive,known,reason,running'||!reasons.has(value.reason)||['known','running','interactive'].some(k=>typeof value[k]!=='boolean'))throw Error('invalid-output');
 if(value.interactive&&!value.running||!value.known&&(value.running||value.interactive)||value.known&&(value.running?value.reason!=='running':value.reason!=='not-running')||!value.known&&['running','not-running'].includes(value.reason))throw Error('invalid-output');
 return Object.freeze({known:value.known,running:value.running,interactive:value.interactive,reason:value.reason});
}
export function createNativePresenceProbe({root,execFile=nativeExecFile,resolvePaths=resolveInstallPaths,readFile=fs.readFile,now=()=>performance.now(),env=process.env,platform=process.platform,intervalMs=15000,timeoutMs=3000}={}){
 const interval=Math.max(15000,Number.isFinite(intervalMs)?intervalMs:15000),deadline=Math.min(3000,Math.max(10,Number.isFinite(timeoutMs)?timeoutMs:3000));
 let latest=unknown('not-checked'),nextAt=-Infinity,completedAt=-Infinity,inflight=null,controller=null,disposed=false;
 const systemRoot=env.SystemRoot||'C:\\Windows';
 const runFile=(file,args,options)=>new Promise((resolve,reject)=>{
  if(options.signal.aborted){reject(Error('timeout'));return;}
  try{execFile(file,args,options,(error,stdout)=>error?reject(error):resolve(stdout));}catch(error){reject(error);}
 });
 function begin(force=false){
  if(disposed||inflight||!force&&now()<nextAt)return inflight;
  nextAt=now()+interval;
  if(platform!=='win32'){latest=unknown('unsupported-platform');completedAt=now();return null;}
  const abort=new AbortController();controller=abort;
  let timedOut=false,timer;
  const options=()=>({windowsHide:true,encoding:'utf8',timeout:deadline,maxBuffer:8192,signal:abort.signal,env:{...env}});
  const work=async()=>{
   const getUserSid=async()=>{const stdout=await runFile(path.win32.join(systemRoot,'System32','whoami.exe'),['/user','/fo','csv','/nh'],options());const matches=String(stdout).match(/\bS-1-\d+(?:-\d+)+\b/g);if(matches?.length!==1)throw Error('invalid-path');return matches[0];};
   let paths,script;
   try{[paths,script]=await Promise.all([resolvePaths(root,{getUserSid,programFiles:env.ProgramW6432||env.ProgramFiles}),readFile(path.join(path.dirname(fileURLToPath(import.meta.url)),'recovery-native-probe.ps1'),'utf8')]);}
   catch{throw Error('invalid-path');}
   if(abort.signal.aborted||disposed)throw Error('timeout');
   if(!paths||!validExecutable(paths.dooray)||paths.userSid!=null&&!sidPattern.test(paths.userSid))throw Error('invalid-path');
   const encoded=Buffer.from(String(script).replace(/^\uFEFF/,''),'utf16le').toString('base64');
   const stdout=await runFile(path.win32.join(systemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe'),['-NoProfile','-NonInteractive','-WindowStyle','Hidden','-EncodedCommand',encoded],{...options(),env:{...env,DOORAY_PLUS_NATIVE_PATH:paths.dooray,DOORAY_PLUS_NATIVE_SID:paths.userSid||''}});
   try{return parseResult(stdout)}catch{throw Error('invalid-output');}
  };
  const expired=new Promise((_,reject)=>{timer=setTimeout(()=>{timedOut=true;abort.abort();reject(Error('timeout'));},deadline);});
  inflight=Promise.race([work(),expired]).then(result=>{if(!disposed){latest=result;completedAt=now();}return latest;},error=>{if(!disposed){latest=unknown(timedOut?'timeout':['invalid-path','invalid-output'].includes(error.message)?error.message:'probe-error');completedAt=now();}return latest;}).finally(()=>{clearTimeout(timer);if(controller===abort)controller=null;inflight=null;});
  return inflight;
 }
 return {
  poll(){if(disposed)return unknown('disposed');if(Number.isFinite(completedAt)&&now()-completedAt>interval+deadline)latest=unknown('stale');begin();return latest;},
  refresh(){if(disposed)return Promise.resolve(unknown('disposed'));begin();return inflight||Promise.resolve(latest);},
  // Only a critical close/activation decision bypasses the normal poll cache.
  // Join any query already in progress; never start concurrent native probes.
  refreshFresh(){if(disposed)return Promise.resolve(unknown('disposed'));begin(true);return inflight||Promise.resolve(latest);},
  dispose(){disposed=true;controller?.abort();latest=unknown('disposed');}
 };
}

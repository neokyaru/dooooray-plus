// Adds video/PDF previews while retaining native attachment details and handlers.
function installInlineVideos({getFile,resolveURL,scrollController}={}){
  getFile ||= card=>{
    const props=card[Object.keys(card).find(k=>k.startsWith('__reactProps'))];if(props?.file)return props.file;
    let f=card[Object.keys(card).find(k=>k.startsWith('__reactFiber'))];for(let i=0;f&&i<40;i++,f=f.return)if(f.memoizedProps?.file)return f.memoizedProps.file;return null;
  };
  resolveURL ||= file=>'/messenger/v2/api/channel/'+file.channelId+'/file/'+file.id;
  const entries=new Map();let disposed=false,timer=0;
  const probe=document.createElement('video');
  const fileName=file=>typeof file.fileName==='string'&&file.fileName?file.fileName:typeof file.title==='string'?file.title:'';
  const fileMime=file=>typeof file.mimeType==='string'?file.mimeType.trim().toLowerCase():'';
  const mediaType=file=>{const ext=fileName(file).split('.').pop().toLowerCase();const types={mp4:'video/mp4',m4v:'video/mp4',webm:'video/webm',ogv:'video/ogg',ogg:'video/ogg',mov:'video/quicktime'};const type=types[ext];return type&&probe.canPlayType(type)?type:null};
  // Generic download MIME metadata can still accompany a PDF name. Opening it
  // remains the native filename action; this module never fetches PDF bytes.
  const previewKind=file=>/\.pdf$/i.test(fileName(file).trim())||fileMime(file)==='application/pdf'?'pdf':mediaType(file)?'video':null;
  const identity=(file,kind)=>[kind,String(file.channelId),String(file.id),fileName(file),fileMime(file)].join('\0');
  const css=document.createElement('style');css.id='dooray-plus-inline-videos';css.textContent=`
  .dt-inline-video-card{position:relative!important;box-sizing:border-box!important;width:360px!important;max-width:100%!important;height:auto!important;max-height:none!important;padding-top:calc(var(--dt-video-card-width,360px)*.5625 + 12px)!important}
  .dt-inline-video-preview{position:absolute;top:0;left:0;right:0;aspect-ratio:16/9;border-radius:8px 8px 0 0;overflow:hidden;background:radial-gradient(ellipse at 50% 30%,#304860,#111c2b 75%);color:#fff;font:12px/1.4 'Malgun Gothic',sans-serif;isolation:isolate}
  .dt-inline-video-preview video{width:100%;height:100%;display:block;object-fit:contain;background:#10151c}
  .dt-inline-video-preview [hidden]{display:none!important}
  .dt-inline-video-play{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;width:100%;border:0!important;background:transparent!important;color:#fff!important;cursor:pointer;font:inherit}
  .dt-inline-video-play .play-icon{display:grid;place-items:center;width:54px;height:54px;border:1px solid #ffffff80;border-radius:50%;background:#ffffff20;font-size:23px;padding-left:3px;box-shadow:0 4px 16px #0003}
  .dt-inline-video-play:hover .play-icon{background:#ffffff38}.dt-inline-video-play:focus-visible{outline:3px solid #8bc9ff;outline-offset:-3px}
  .dt-inline-video-note{position:absolute;left:10px;right:44px;top:8px;margin:0;padding:5px 8px;border-radius:5px;background:#10151ce8;color:#fff;pointer-events:none;font:11px/1.4 'Malgun Gothic',sans-serif}
  .dt-inline-video-cancel{position:absolute;right:6px;top:6px;display:grid;place-items:center;width:28px;height:28px;padding:0;border:1px solid #ffffff40;border-radius:50%;background:#10151ccc;color:white;cursor:pointer;font-size:18px}
  .dt-inline-pdf-card{position:relative!important;margin-bottom:calc(var(--dt-pdf-card-margin,0px) + 32px)!important;overflow:visible!important}
  .dt-inline-pdf-preview{position:absolute!important;top:100%;left:0;right:0;height:32px;box-sizing:border-box;display:flex;align-items:center;justify-content:flex-end;gap:6px;min-width:0;padding-top:4px}
  .dt-inline-pdf-open{display:inline-flex!important;align-items:center;justify-content:center;gap:5px;flex:none;width:auto!important;height:auto!important;min-height:26px;padding:3px 8px!important;border:1px solid var(--dt-border,#cbd3df)!important;border-radius:5px;background:var(--dt-bg,#fff)!important;color:var(--dt-accent,#2563a6)!important;font:12px/1.4 'Malgun Gothic',sans-serif!important;cursor:pointer}
  .dt-inline-pdf-open:hover{background:var(--dt-hover,#edf3fa)!important}.dt-inline-pdf-open:focus-visible{outline:2px solid var(--dt-accent,#2563a6);outline-offset:2px}
  .dt-inline-pdf-note{font:11px/1.4 'Malgun Gothic',sans-serif;color:var(--dt-text,#354052);overflow-wrap:anywhere}.dt-inline-pdf-note[hidden]{display:none!important}
  `;document.head.append(css);
  function layoutChange(card,change){const layout=scrollController?.beforeLayout(card);try{return change()}finally{if(scrollController)scrollController.afterLayout(layout)}}
  const resize=new ResizeObserver(records=>{if(disposed)return;for(const {target}of records){if(entries.get(target)?.kind!=='video')continue;const width=target.clientWidth;if(width>0&&target.style.getPropertyValue('--dt-video-card-width')!==width+'px')layoutChange(target,()=>target.style.setProperty('--dt-video-card-width',width+'px'))}});
  function remove(card,entry){layoutChange(card,()=>{if(entry.kind==='pdf'){entry.button.onclick=null;card.classList.remove('dt-inline-pdf-card');if(entry.margin)card.style.setProperty('--dt-pdf-card-margin',entry.margin,entry.marginPriority);else card.style.removeProperty('--dt-pdf-card-margin')}else{entry.video.onloadedmetadata=null;entry.video.onresize=null;entry.video.pause();entry.video.removeAttribute('src');entry.video.load();resize.unobserve(card);card.classList.remove('dt-inline-video-card');if(entry.width)card.style.setProperty('--dt-video-card-width',entry.width);else card.style.removeProperty('--dt-video-card-width')}entry.view.remove();entries.delete(card)})}
  function mount(card,file){
    const key=identity(file,'video'),old=entries.get(card);if(old?.key===key&&old.view.parentNode===card)return;if(old)remove(card,old);
    const layout=scrollController?.beforeLayout(card);
    // The shared controller owns both following and history anchors. Keep the
    // original local fallback only for standalone consumers without it.
    const scroll=scrollController?null:card.closest('[data-dp-native~="scroll"],.js-scroll-area'),top=scroll?.scrollTop,bottom=scroll&&scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<48,above=scroll&&card.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,height=card.getBoundingClientRect().height;
    const view=document.createElement('div');view.className='dt-inline-video-preview';view.setAttribute('aria-label','영상 미리보기');
    const video=document.createElement('video');video.preload='none';video.playsInline=true;video.hidden=true;video.setAttribute('aria-label',(file.fileName||'영상')+' 재생');
    const play=document.createElement('button');play.type='button';play.className='dt-inline-video-play';play.setAttribute('aria-label','채팅방에서 영상 재생');play.innerHTML='<span class="play-icon" aria-hidden="true">▶</span><span>영상 재생</span>';
    const note=document.createElement('p');note.className='dt-inline-video-note';note.setAttribute('role','status');note.hidden=true;
    const cancel=document.createElement('button');cancel.type='button';cancel.className='dt-inline-video-cancel';cancel.textContent='×';cancel.setAttribute('aria-label','영상 재생 중지');cancel.hidden=true;
    view.append(video,play,note,cancel);const entry={key,kind:'video',view,video,width:card.style.getPropertyValue('--dt-video-card-width'),generation:0};
    const notifyLayout=()=>{if(!disposed&&card.isConnected&&entries.get(card)===entry)scrollController?.notifyLayout(card)};video.onloadedmetadata=notifyLayout;video.onresize=notifyLayout;
    const reset=()=>{entry.generation++;video.pause();video.removeAttribute('src');video.load();video.hidden=true;video.controls=false;play.hidden=false;cancel.hidden=true;note.hidden=true};
    const failed=()=>{if(disposed||!view.isConnected||!video.hasAttribute('src'))return;reset();note.textContent='미리보기를 재생할 수 없습니다. 아래 다운로드 버튼을 이용해 주세요.';note.hidden=false};
    play.onclick=e=>{e.preventDefault();for(const other of entries.values())if(other!==entry)other.video?.pause();const generation=++entry.generation;video.hidden=false;play.hidden=true;cancel.hidden=false;video.controls=true;note.hidden=false;note.textContent='영상 준비 중… 파일 크기와 형식에 따라 시간이 걸릴 수 있습니다.';video.src=resolveURL(file);video.play().catch(()=>{if(entry.generation===generation)failed()})};
    cancel.onclick=e=>{e.preventDefault();reset()};video.onplaying=()=>{note.hidden=true};video.onwaiting=()=>{if(video.hasAttribute('src')){note.textContent='영상 데이터를 불러오는 중…';note.hidden=false}};video.onerror=failed;
    for(const event of ['click','dblclick','pointerdown'])view.addEventListener(event,e=>e.stopPropagation());
    entries.set(card,entry);card.classList.add('dt-inline-video-card');card.prepend(view);card.style.setProperty('--dt-video-card-width',card.clientWidth+'px');resize.observe(card);
    if(scrollController)scrollController.afterLayout(layout);else if(bottom)scroll.scrollTop=scroll.scrollHeight;else if(above)scroll.scrollTop=top+card.getBoundingClientRect().height-height;
  }
  const expiredPDF=file=>file?.expired===true||file?.isExpired===true;
  function nativePDFTarget(card,file){
    const name=fileName(file).trim();if(!name||name.length>1024||expiredPDF(file)||card.closest('[hidden],[inert],[aria-disabled="true"]'))return null;
    const excluded='a[download],input,textarea,select,[contenteditable="true"],.dt-inline-pdf-preview,.dt-inline-video-preview,.dt-emoticon-custom,.dt-received-emoticon';
    const visibility=new WeakMap(),visible=node=>{for(let current=node;current;current=current.parentElement){let shown=visibility.get(current);if(shown===undefined){const style=document.defaultView?.getComputedStyle(current);shown=!!style&&style.display!=='none'&&style.visibility!=='hidden'&&style.visibility!=='collapse';visibility.set(current,shown)}if(!shown)return false}return true};
    const blocked=node=>{if(!visible(node))return true;for(let current=node;current;current=current.parentElement){if(current.matches(excluded)||current.hidden||current.hasAttribute('inert')||current.hasAttribute('disabled')||current.disabled===true||current.getAttribute('aria-disabled')?.toLowerCase()==='true')return true;
      if(current.matches('button,[role="button"],a')){const labels=[current.getAttribute('aria-label'),current.getAttribute('title'),current.textContent].filter(value=>typeof value==='string').map(value=>value.trim()).filter(value=>value!==name);if(labels.some(value=>/다운로드|download/i.test(value)))return true;}
      if(current===card)return false;
    }return true};
    const ownClick=node=>{try{const props=node[Object.keys(node).find(key=>key.startsWith('__reactProps'))];if(typeof props?.onClick==='function')return true;const fiber=node[Object.keys(node).find(key=>key.startsWith('__reactFiber'))];return fiber?.stateNode===node&&typeof fiber.memoizedProps?.onClick==='function'}catch{return false}};
    const clickPath=node=>{for(let current=node,depth=0;current&&depth<8;current=current.parentElement,depth++){if(ownClick(current))return true;if(current===card)break}return false};
    const named=node=>['title','aria-label','aria-description'].some(attribute=>node.getAttribute(attribute)?.trim()===name)||(node.textContent?.length<=1056&&node.textContent.trim()===name);
    const matches=[],consider=node=>{if(typeof node.click==='function'&&named(node)&&!blocked(node)&&clickPath(node))matches.push(node)};
    const walker=document.createTreeWalker(card,NodeFilter.SHOW_ELEMENT,{acceptNode:node=>node.matches(excluded)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let visited=0,node=walker.nextNode();
    for(;node&&visited<400;node=walker.nextNode(),visited++)consider(node);if(node||!matches.length)return null;
    // Several nested labels may describe one filename. Two separate regions
    // are ambiguous even when a surrounding card has a click handler.
    for(let i=0;i<matches.length;i++)for(let j=i+1;j<matches.length;j++)if(!matches[i].contains(matches[j])&&!matches[j].contains(matches[i]))return null;
    const target=[...matches].reverse().find(ownClick)||matches[matches.length-1];return target?.isConnected&&card.contains(target)&&!blocked(target)?target:null;
  }
  function mountPDF(card,file){
    const key=identity(file,'pdf'),old=entries.get(card);if(old?.key===key&&old.view.parentNode===card){old.button.disabled=expiredPDF(file);return}if(old)remove(card,old);
    const layout=scrollController?.beforeLayout(card),scroll=scrollController?null:card.closest('[data-dp-native~="scroll"],.js-scroll-area'),top=scroll?.scrollTop,bottom=scroll&&scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<48,above=scroll&&card.getBoundingClientRect().bottom<scroll.getBoundingClientRect().top,height=card.getBoundingClientRect().height;
    const view=document.createElement('div');view.className='dt-inline-pdf-preview';
    const button=document.createElement('button');button.type='button';button.className='dt-inline-pdf-open';button.textContent='PDF 미리보기';button.setAttribute('aria-label',(fileName(file)||'PDF 파일')+' 미리보기');button.disabled=expiredPDF(file);
    const note=document.createElement('span');note.className='dt-inline-pdf-note';note.setAttribute('role','status');note.hidden=true;view.append(button,note);
    const entry={key,kind:'pdf',view,button,margin:card.style.getPropertyValue('--dt-pdf-card-margin'),marginPriority:card.style.getPropertyPriority('--dt-pdf-card-margin')};
    button.onclick=event=>{event.preventDefault();event.stopPropagation();if(disposed||!card.isConnected||entries.get(card)!==entry)return;const current=getFile(card);if(!validFile(current)||previewKind(current)!=='pdf'||identity(current,'pdf')!==key){scan();return}const target=nativePDFTarget(card,current);if(target){note.hidden=true;target.click()}else{note.textContent='파일 이름을 눌러 주세요.';note.hidden=false}};
    for(const event of ['keydown','keyup'])button.addEventListener(event,e=>{if(e.key==='Enter'||e.key===' ')e.stopPropagation()});
    for(const event of ['click','dblclick','pointerdown'])view.addEventListener(event,e=>e.stopPropagation());
    const margin=document.defaultView?.getComputedStyle(card).marginBottom||'0px';entries.set(card,entry);card.style.setProperty('--dt-pdf-card-margin',margin);card.classList.add('dt-inline-pdf-card');card.append(view);
    if(scrollController)scrollController.afterLayout(layout);else if(bottom)scroll.scrollTop=scroll.scrollHeight;else if(above)scroll.scrollTop=top+card.getBoundingClientRect().height-height;
  }
  const validFile=file=>file&&/^\d+$/.test(String(file.id))&&/^\d+$/.test(String(file.channelId));
  function cards(){
    const result=new Set([...entries.keys()].filter(card=>card.isConnected));
    const hinted='[data-dp-native~="file-card"],.sc-RcBXQ',excluded='[data-dt-file-view],.dt-inline-video-preview,.dt-inline-pdf-preview,.dt-emoticon-custom,.js-sticker-emotion,[contenteditable="true"]';
    for(const card of document.querySelectorAll(hinted))if(!card.closest(excluded))result.add(card);
    const areas=[...document.querySelectorAll('[data-dp-native~="scroll"],.js-scroll-area')],cache=new WeakMap();
    const fileFor=node=>{if(!cache.has(node))cache.set(node,getFile(node));return cache.get(node)};
    for(const area of areas.filter(n=>!areas.some(other=>other!==n&&other.contains(n)))){
      // Inspect only rendered chat descendants. A file prop belongs to its
      // outermost native card, never to every nested label/download button.
      const walker=document.createTreeWalker(area,NodeFilter.SHOW_ELEMENT,{acceptNode:node=>node.matches(excluded)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let visited=0;
      for(let node=walker.nextNode();node&&visited++<4000;node=walker.nextNode()){
        const file=fileFor(node);if(!validFile(file))continue;
        const hintedCard=node.closest(hinted);if(hintedCard&&area.contains(hintedCard)){result.add(hintedCard);continue;}
        let card=node;
        for(let depth=0,parent=card.parentElement;parent&&parent!==area&&depth<16;parent=parent.parentElement,depth++){
          const candidate=fileFor(parent);if(!validFile(candidate)||String(candidate.id)!==String(file.id)||String(candidate.channelId)!==String(file.channelId))break;card=parent;
        }
        result.add(card);
      }
    }
    // Props are inherited through React fibers. Coalesce descendants found by
    // that walk so one attachment receives exactly one player.
    const candidates=[...result];return candidates.filter(card=>!card.closest(excluded)&&!candidates.some(parent=>parent!==card&&parent.contains(card)&&validFile(fileFor(parent))&&String(fileFor(parent).id)===String(fileFor(card)?.id)&&String(fileFor(parent).channelId)===String(fileFor(card)?.channelId)));
  }
  function scan(){timer=0;if(disposed)return;const activeCards=new Set(cards());for(const card of activeCards){
    // Keep the existing file-library layout; this player belongs to chat attachments.
    if(card.closest('[data-dt-file-view]'))continue;
    const file=getFile(card),kind=validFile(file)?previewKind(file):null;if(kind==='video')mount(card,file);else if(kind==='pdf')mountPDF(card,file);else if(entries.has(card))remove(card,entries.get(card));
  }for(const[card,entry]of entries)if(!activeCards.has(card)||!card.isConnected||card.closest('[data-dt-file-view]'))remove(card,entry)}
  const changes=new MutationObserver(()=>{if(!timer)timer=setTimeout(scan,120)});changes.observe(document,{childList:true,subtree:true});scan();
  const poll=setInterval(()=>{if(!document.hidden)scan()},2500);
  const dispose=()=>{disposed=true;clearTimeout(timer);clearInterval(poll);changes.disconnect();for(const[card,entry]of entries)remove(card,entry);resize.disconnect();css.remove()};dispose.scan=scan;return dispose;
}

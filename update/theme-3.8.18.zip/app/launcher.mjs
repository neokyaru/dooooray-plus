import {makeBootstrap,isNavigationError} from './compatibility.mjs';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const data=path.join(process.env.LOCALAPPDATA||root,'DoorayTheme');
const disabled=path.join(data,'theme-disabled.flag');
const log=message=>{try{fs.mkdirSync(data,{recursive:true});const f=path.join(data,'launcher.log');if(fs.existsSync(f)&&fs.statSync(f).size>1048576)fs.renameSync(f,path.join(data,'launcher.previous.log'));fs.appendFileSync(f,new Date().toISOString()+' '+message+'\n')}catch{}};
const port=19347;
if(process.argv.includes('--check')){console.log(JSON.stringify({version:'3.8.18',mode:'attach-only',versionRestricted:false,runtime:process.version,themePresent:fs.existsSync(path.join(root,'app/theme.js'))}));process.exit(0)}
// The native launcher starts Dooray first. This helper never launches, kills,
// waits for, or modifies the vendor program, and never displays blocking dialogs.
if(fs.existsSync(disabled))process.exit(0);
const lock=net.createServer(s=>s.end());
const acquired=await new Promise(r=>{lock.once('error',()=>r(false));lock.listen(port+1,'127.0.0.1',()=>r(true))});
if(!acquired)process.exit(0);
let downloadProcess=null;
function ensureDownloads(){if(downloadProcess||stopped)return;downloadProcess=spawn(process.execPath,[path.join(root,'app/download-helper.mjs')],{windowsHide:true,stdio:['ignore','ignore','ignore','ipc']});const child=downloadProcess;child.on('message',m=>{if(['update-check','update-status','update-install','update-apply','update-cancel'].includes(m?.type)&&typeof m.id==='string'&&m.id.length<=80){if(process.connected)process.send(m);else if(child.connected)child.send({type:'update-result',id:m.id,result:{status:'error',error:'업데이트 지원 설치 파일로 전환 설치해 주세요.'}})}});child.once('error',()=>{if(downloadProcess===child)downloadProcess=null});child.once('exit',()=>{if(downloadProcess===child)downloadProcess=null});}
process.on('message',m=>{if(m?.type==='update-result'&&downloadProcess?.connected)downloadProcess.send(m)});
process.on('exit',()=>{try{downloadProcess?.kill()}catch{}});
const clients=new Map();let stopped=false,busy=false,misses=0;
function stop(reason){if(stopped)return;stopped=true;try{downloadProcess?.kill()}catch{}if(reason){log(reason);try{fs.writeFileSync((process.env.DOORAY_ENGINE_ERROR||path.join(data,'release-error.json')),JSON.stringify({version:'3.8.18',reason}))}catch{}}
 for(const c of clients.values()){clearInterval(c.poll);try{c.send('Runtime.evaluate',{expression:"window.__doorayThemeEmergencyStop?.('helper-disabled')"});if(c.script)c.send('Page.removeScriptToEvaluateOnNewDocument',{identifier:c.script});setTimeout(()=>c.ws.close(),200)}catch{}}
 lock.close();setTimeout(()=>process.exit(0),300).unref();
}
process.on('message',m=>{if(m?.type==='shutdown')stop()});
process.on('uncaughtException',()=>stop('helper-error'));process.on('unhandledRejection',()=>stop('helper-error'));
const source=fs.readFileSync(path.join(root,'app/theme.js'),'utf8');
const bootstrap=makeBootstrap(source);
async function targets(){try{const response=await fetch('http://127.0.0.1:'+port+'/json/list',{signal:AbortSignal.timeout(1000)});return await response.json()}catch{return null}}
function allowed(t){try{const u=new URL(t.url);return t.type==='page'&&u.protocol==='https:'&&['dooray.com','gov-dooray.com'].some(d=>u.hostname===d||u.hostname.endsWith('.'+d))&&u.pathname.startsWith('/messenger')}catch{return false}}
async function tick(){if(stopped||busy)return;busy=true;try{
 if(fs.existsSync(disabled)||fs.existsSync(path.join(data,'stop-agent.flag'))){stop();return}
 const list=await targets();if(!Array.isArray(list)){if(++misses>=20)stop();return}misses=0;ensureDownloads();
 for(const t of list){if(!allowed(t)||clients.has(t.id))continue;
  const u=new URL(t.webSocketDebuggerUrl);if(u.protocol!=='ws:'||!['127.0.0.1','localhost','[::1]'].includes(u.hostname)||Number(u.port)!==port)continue;
  const ws=new WebSocket(u);let id=0;const c={ws,poll:null,script:null,send(method,params){ws.send(JSON.stringify({id:++id,method,params}));return id}};clients.set(t.id,c);let registration;
  ws.onopen=()=>{c.send('Page.enable',{});c.send('Runtime.enable',{});registration=c.send('Page.addScriptToEvaluateOnNewDocument',{source:bootstrap});c.send('Runtime.evaluate',{expression:bootstrap});c.poll=setInterval(()=>{if(ws.readyState===WebSocket.OPEN){c.send('Runtime.evaluate',{expression:bootstrap});c.send('Runtime.evaluate',{expression:"({blocked:window.__doorayThemeBlocked||'',ready:!!window.__doorayTheme})",returnByValue:true})}},2000);log('Theme connected')};
  ws.onmessage=e=>{try{const m=JSON.parse(e.data);if(m.id===registration)c.script=m.result?.identifier;if(m.error&&isNavigationError(m.error))return;if(m.error||m.result?.exceptionDetails){stop('theme-evaluation-error');return}const status=m.result?.result?.value;if(status?.ready){try{fs.writeFileSync((process.env.DOORAY_ENGINE_HEALTH||path.join(data,'healthy.flag')),JSON.stringify({version:'3.8.18',at:Date.now()}))}catch{}}const reason=status?.blocked;if(typeof reason==='string'&&reason&&!['removed','helper-disabled','page-structure-unavailable'].includes(reason))stop('theme-stopped: '+reason.slice(0,100))}catch{stop('helper-response-error')}};
  ws.onclose=()=>{clearInterval(c.poll);clients.delete(t.id)};ws.onerror=()=>{clearInterval(c.poll);ws.close();clients.delete(t.id)};
 }
 }finally{busy=false}}
await tick();setInterval(tick,2000);
